"""Exercise cancellation and immediate reuse after a verified Flash Next step."""

from argparse import ArgumentParser
import http.client
import json
from pathlib import Path
import socket
import subprocess

import run_sampling_controls as controls


ROOT = Path(__file__).resolve().parent
STEPS = "ax_engine_steps_total"
ACTIVE = "ax_engine_generation_active_streams"
ACCEPTED = "ax_engine_flash_next_mtp_accepted_steps_total"
LIVE = "ax_engine_jobs_in_flight"
ROUTE_VERIFIED = "ax_mlx_flash_next_mtp_verified_steps"
ROUTE_ACCEPTED = "ax_mlx_flash_next_mtp_accepted_steps"
TRACKED = (STEPS, ACCEPTED, *controls.KEYS)


def counters(metrics, keys):
    return {key: metrics[key] for key in keys}


def delta(before, after):
    return {key: after[key] - before[key] for key in TRACKED}


def request_body(ids):
    return {"model": controls.MODEL, "input_tokens": ids,
            "max_output_tokens": controls.BUDGET, "sampling": controls.BASE}


def write_line(path, row):
    with path.open("a") as out:
        out.write(json.dumps(row, allow_nan=False) + "\n")


def sse_frames(response):
    fields = {}
    while True:
        raw = response.readline()
        if not raw:
            assert not fields
            return
        line = raw.rstrip(b"\r\n")
        if not line and fields:
            assert set(fields) == {b"event", b"data"}
            yield fields[b"event"].decode(), json.loads(fields[b"data"])
            fields.clear()
        elif line and not line.startswith(b":"):
            name, mark, value = line.partition(b":")
            assert mark and name not in fields
            fields[name] = value.lstrip()


def disconnect(base, ids, mode, before, trace):
    host, port = base.removeprefix("http://").split(":")
    conn = http.client.HTTPConnection(host, int(port), timeout=90)
    request_id = None
    tokens = []
    decode_widths = []
    try:
        conn.request("POST", "/v1/generate/stream", json.dumps(request_body(ids)), {"Content-Type": "application/json"})
        with conn.getresponse() as response:
            assert response.status == 200
            for phase, event in sse_frames(response):
                assert phase in {"request", "step"}, "Stream completed before disconnect"
                state = event["request"]
                if phase == "request":
                    assert request_id is None and state["prompt_tokens"] == ids
                    request_id = state["request_id"]
                    continue
                assert state["request_id"] == request_id
                step = event["step"]
                more = event.get("delta_tokens", [])
                if tokens and more:
                    decode_widths.append(len(more))
                tokens.extend(more)
                # The emitted deltas are the stream's visible prefix. Preserve
                # the snapshot fields independently for diagnostics.
                write_line(trace, {"step": step.get("step_id"), "delta": more,
                                   "reported_output_length": state["output_len"],
                                   "reported_history_length": len(state["output_tokens"]),
                                   "state": state["state"]})
                if len(tokens) < 5 or (mode == "required" and not {1, 2} <= set(decode_widths)):
                    continue
                current = controls.get_metrics(base)
                assert state["state"] == "runnable"
                assert current[ACTIVE] == 1 and current[LIVE] == 1
                assert len(tokens) < controls.BUDGET
                observed = {"prefix": tokens, "open_streams": current[ACTIVE], "open_jobs": current[LIVE],
                            "visible_output_len": len(tokens), "visible_step": event["step"]["step_id"],
                            "decode_widths": decode_widths,
                            "while_open": delta(before, current)}
                assert conn.sock is not None
                conn.sock.shutdown(socket.SHUT_RDWR)
                return observed
    finally:
        conn.close()
    raise AssertionError("Native stream ended before a controlled disconnect")


def call(base, endpoint, body=None):
    return json.loads(controls.native.request(base, endpoint, body))


def stepwise_cancel(base, ids, mode, before):
    launched = call(base, "/v1/requests", request_body(ids))
    target = f"/v1/requests/{launched['request_id']}"
    assert launched["state"] == "waiting"
    for _ in range(20):
        event = call(base, "/v1/step", {})
        current = call(base, target)
        route = current["route"]["crossover_decisions"]
        if current["output_len"] >= 3 and (mode == "disabled"
                or 0 < route.get(ROUTE_ACCEPTED, 0) < route.get(ROUTE_VERIFIED, 0)):
            break
    else:
        raise AssertionError("Expected an active stepwise request with accepted and rejected drafts")
    prefix = current["output_tokens"]
    assert current["state"] == "runnable" and 3 <= len(prefix) < controls.BUDGET
    during = controls.get_metrics(base)
    assert during[LIVE] == 1 and during[ACTIVE] == 0
    terminal = call(base, target + "/cancel", {})
    assert terminal["state"] == "cancelled" and terminal["finish_reason"] == "cancelled"
    assert terminal["output_tokens"] == prefix
    final = call(base, target)
    assert final == terminal
    return {"prefix": prefix, "visible_route": route, "while_open": delta(before, during),
            "open_jobs": during[LIVE], "open_streams": during[ACTIVE],
            "last_progress_step": event["step_id"], "terminal": terminal}


def checked_action(base, name, perform):
    before = controls.wait_drained(base)
    result = perform(before)
    after = controls.wait_drained(base)
    assert all(value >= 0 for value in delta(before, after).values())
    assert all(after[key] == before[key] for key in controls.native.ERRORS)
    assert all(after[key] == before[key] for key in (controls.FALLBACK,))
    return {"case": name, **result, "metrics": delta(before, after),
            "drained": counters(after, controls.DRAINED)}


def verify(rows, mode, ids):
    expected = ("baseline", "disconnect", "same-prompt-after-disconnect",
                "stepwise-cancel", "same-prompt-after-stepwise-cancel")
    assert [row["case"] for row in rows] == list(expected)
    baseline, dropped, first_reuse, cancelled, last_reuse = rows
    oracle = baseline["output_ids"]
    assert len(oracle) == controls.BUDGET and all(type(token) is int and token >= 0 for token in oracle)
    for row in (baseline, first_reuse, last_reuse):
        assert row["output_ids"] == oracle and row["terminal_reason"] == "max_output_tokens"
        assert row["metrics"][controls.VERIFIED] == baseline["metrics"][controls.VERIFIED]
        assert row["metrics"][ACCEPTED] == baseline["metrics"][ACCEPTED]
    for row in rows:
        metrics = row["metrics"]
        assert set(metrics) == set(TRACKED) and all(value >= 0 for value in metrics.values())
        assert metrics[controls.FALLBACK] == 0 and all(metrics[k] == 0 for k in controls.native.ERRORS)
        assert set(row["drained"]) == set(controls.DRAINED) and not any(row["drained"].values())
        assert 0 <= metrics[ACCEPTED] <= metrics[controls.VERIFIED]
        if mode == "disabled":
            assert metrics[controls.VERIFIED] == 0
    assert dropped["open_streams"] == 1 and cancelled["open_streams"] == 0
    for row in (dropped, cancelled):
        assert row["open_jobs"] == 1
        assert 3 <= len(row["prefix"]) < controls.BUDGET
        assert row["prefix"] == oracle[:len(row["prefix"])]
        assert 0 < row["metrics"][STEPS] < baseline["metrics"][STEPS]
    assert dropped["visible_output_len"] == len(dropped["prefix"])
    if mode == "required":
        assert {1, 2} <= set(dropped["decode_widths"])
        observed_verified = len(dropped["decode_widths"])
        observed_accepted = dropped["decode_widths"].count(2)
        assert observed_verified <= dropped["while_open"][controls.VERIFIED]
        assert observed_accepted <= dropped["while_open"][ACCEPTED]
        assert 0 < dropped["metrics"][ACCEPTED] < dropped["metrics"][controls.VERIFIED]
        route = cancelled["visible_route"]
        assert 0 < route[ROUTE_ACCEPTED] < route[ROUTE_VERIFIED]
        assert cancelled["metrics"][controls.VERIFIED] == route[ROUTE_VERIFIED]
        assert cancelled["metrics"][ACCEPTED] == route[ROUTE_ACCEPTED]
        terminal_route = cancelled["terminal"]["route"]["crossover_decisions"]
        assert terminal_route[ROUTE_VERIFIED] == route[ROUTE_VERIFIED]
        assert terminal_route[ROUTE_ACCEPTED] == route[ROUTE_ACCEPTED]
        assert 0 < dropped["metrics"][controls.VERIFIED] < baseline["metrics"][controls.VERIFIED]
        assert 0 < baseline["metrics"][ACCEPTED]
    terminal = cancelled["terminal"]
    assert terminal["state"] == terminal["finish_reason"] == "cancelled"
    assert terminal["prompt_tokens"] == ids and terminal["output_tokens"] == cancelled["prefix"]


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--mode", choices=("disabled", "required"))
    for flag in ("binary", "pack", "out"):
        cli.add_argument(f"--{flag}", type=Path)
    cli.add_argument("--check-inputs", action="store_true")
    args = cli.parse_args()
    ids = controls.prompt()
    build = controls.read(ROOT / "build.json")
    assert build["codesign_verified"] and build["server_sha256"] == controls.SERVER
    assert controls.digest(ROOT / "source.patch") == build["patch_sha256"]
    if args.check_inputs:
        print("Bound the frozen 512-token prompt and signed runtime.")
        return
    assert controls.digest(args.binary) == controls.SERVER
    inventory = controls.read(ROOT / "mxfp4-inventory.json")
    assert len(inventory["members"]) == 49
    manifest = controls.native.validate_inventory(args.pack, inventory)
    assert manifest == {"model-manifest.json": controls.digest(ROOT / "model-manifest.json")}
    args.out.mkdir()
    rows = []
    env = {"AX_FLASH_NEXT_MTP_COST": "0", "RUST_LOG": "info,ax_engine_mlx::flash_next_startup=debug"}
    with controls.serving.server(args, args.mode, controls.MODEL, args.pack, 1,
                                 env=env, guard=True, mtp=args.mode, prefill_chunk=2048,
                                 options=("--total-blocks", "2048", "--disable-ngram-acceleration")) as (base, pid):
        mapped = subprocess.check_output(["/usr/sbin/lsof", "-a", "-p", str(pid), "-d", "txt", "-Fn"], text=True)
        library, = [Path(line[1:]) for line in mapped.splitlines()
                    if line.startswith("n") and line.endswith("/libmlx.dylib")]
        assert controls.digest(library) == build["libmlx_sha256"]

        def full(_):
            return controls.stream(base, ids, controls.BASE)

        actions = (("baseline", full), ("disconnect", lambda before: disconnect(base, ids, args.mode, before, args.out / "disconnect-steps.jsonl")),
                   ("same-prompt-after-disconnect", full),
                   ("stepwise-cancel", lambda before: stepwise_cancel(base, ids, args.mode, before)),
                   ("same-prompt-after-stepwise-cancel", full))
        for name, action in actions:
            row = checked_action(base, name, action)
            rows.append(row)
            write_line(args.out / "cases.jsonl", row)
            print(f"{args.mode} {name}: {row['metrics'][controls.VERIFIED]} verification steps", flush=True)
        assert call(base, "/health")["status"] == "ok"

    log = args.out / f"{args.mode}.log"
    text = log.read_text()
    resident = [line for line in text.splitlines() if "Flash Next resident reader" in line]
    assert len(resident) == 1 and "reader=Mapped" in resident[0]
    for old, new in ((str(args.pack), "[pack]"), (str(ROOT), "[run]"), (str(Path.home()), "[home]"),
                     ("127.0.0.1", "[loopback]")):
        text = text.replace(old, new)
    log.write_text(text)
    samples = [json.loads(line) for line in (args.out / f"{args.mode}-samples.jsonl").read_text().splitlines()]
    assert samples and all(row["pressure"] == 1 and row["footprint_bytes"] <= 96 << 30 for row in samples)
    assert controls.native.validate_inventory(args.pack, inventory) == manifest
    verify(rows, args.mode, ids)
    version = subprocess.check_output(["/usr/bin/sw_vers", "-productVersion"], text=True).strip()
    receipt = {"mode": args.mode, "qualification": False, "server_sha256": controls.SERVER,
               "manifest": manifest, "macos": version, "publisher_members_verified_before_and_after": 49,
               "normal_pressure_samples": len(samples), "max_footprint_bytes": max(row["footprint_bytes"] for row in samples)}
    (args.out / "receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
