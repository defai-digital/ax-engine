"""Recheck cancellation counters on the guarded primary-tier reader."""

from argparse import ArgumentParser
import http.client
import json
from pathlib import Path
import re
import socket
import subprocess

import run_cancellation_controls as native
import run_sampling_controls as controls


ROOT = Path(__file__).resolve().parent
READER = "AlignedBuffered"
OPENAI_ACTIONS = ("baseline", "disconnect", "same-prompt-after-disconnect")


def openai_frames(response):
    done = False
    for raw in response:
        if not raw.startswith(b"data:"):
            continue
        payload = raw[len(b"data:"):].strip()
        assert not done
        if payload == b"[DONE]":
            done = True
            yield None
        else:
            yield json.loads(payload)
    assert done


def openai_stream(base, ids, mode, *, before=None):
    body = {"model": controls.MODEL, "prompt": ids, "temperature": 0.0,
            "ignore_eos": True, "max_tokens": controls.BUDGET, "stream": True,
            "stream_options": {"include_usage": True}}
    host, port = base.removeprefix("http://").split(":")
    conn = http.client.HTTPConnection(host, int(port), timeout=120)
    pieces, endings, usage, request_ids = [], [], [], set()
    try:
        conn.request("POST", "/v1/completions", json.dumps(body), {"Content-Type": "application/json"})
        with conn.getresponse() as response:
            assert response.status == 200
            for frame in openai_frames(response):
                if frame is None:
                    assert before is None, "OpenAI stream completed before disconnect"
                    continue
                request_ids.add(frame["id"])
                choices = frame["choices"]
                if frame.get("usage") is not None:
                    usage.append(frame["usage"])
                if not choices:
                    continue
                choice, = choices
                assert choice["index"] == 0
                if choice["text"]:
                    pieces.append(choice["text"])
                if choice["finish_reason"]:
                    endings.append(choice["finish_reason"])
                if before is None or len(pieces) < 3:
                    continue
                assert not endings
                current = controls.get_metrics(base)
                counts = native.delta(before, current)
                if mode == "required" and not 0 < counts[native.ACCEPTED] < counts[controls.VERIFIED]:
                    continue
                assert current[native.ACTIVE] == current[native.LIVE] == 1
                assert conn.sock is not None and len(request_ids) == 1
                conn.sock.shutdown(socket.SHUT_RDWR)
                return {"visible_text": "".join(pieces), "visible_chunks": len(pieces),
                        "open_jobs": current[native.LIVE], "open_streams": current[native.ACTIVE],
                        "while_open": counts}
    finally:
        conn.close()
    assert before is None, "An unfinished OpenAI stream was expected"
    record, = usage
    assert endings == ["length"] and len(request_ids) == 1
    assert record["prompt_tokens"] == len(ids) and record["completion_tokens"] == controls.BUDGET
    assert record["total_tokens"] == len(ids) + controls.BUDGET
    return {"text": "".join(pieces), "usage": record, "terminal_reason": endings[0]}


def verify_openai(rows, mode):
    assert [row["case"] for row in rows] == list(OPENAI_ACTIONS)
    baseline, dropped, reuse = rows
    assert baseline["text"] and baseline["text"] == reuse["text"]
    assert dropped["visible_text"] and baseline["text"].startswith(dropped["visible_text"])
    assert dropped["open_streams"] == dropped["open_jobs"] == 1
    assert 0 < dropped["metrics"][native.STEPS] < baseline["metrics"][native.STEPS]
    for row in rows:
        metrics = row["metrics"]
        assert set(metrics) == set(native.TRACKED) and all(value >= 0 for value in metrics.values())
        assert metrics[controls.FALLBACK] == 0 and all(metrics[key] == 0 for key in controls.native.ERRORS)
        assert set(row["drained"]) == set(controls.DRAINED) and not any(row["drained"].values())
        assert 0 <= metrics[native.ACCEPTED] <= metrics[controls.VERIFIED]
        if mode == "required":
            assert metrics[controls.VERIFIED] > 0
        else:
            assert metrics[controls.VERIFIED] == 0
    for row in (baseline, reuse):
        assert row["terminal_reason"] == "length"
        assert row["usage"]["completion_tokens"] == controls.BUDGET
        assert row["metrics"][controls.VERIFIED] == baseline["metrics"][controls.VERIFIED]
        assert row["metrics"][native.ACCEPTED] == baseline["metrics"][native.ACCEPTED]
    if mode == "required":
        while_open = dropped["while_open"]
        assert 0 < while_open[native.ACCEPTED] < while_open[controls.VERIFIED]
        assert while_open[controls.VERIFIED] <= dropped["metrics"][controls.VERIFIED]
        assert while_open[native.ACCEPTED] <= dropped["metrics"][native.ACCEPTED]


def ensure_library(pid, expected):
    mapped = subprocess.check_output(
        ["/usr/sbin/lsof", "-a", "-p", str(pid), "-d", "txt", "-Fn"], text=True)
    library, = [Path(line[1:]) for line in mapped.splitlines()
                if line.startswith("n") and line.endswith("/libmlx.dylib")]
    assert controls.digest(library) == expected


def run(args, ids, build):
    mode = args.mode
    native_mode = "required" if mode == "required" else "disabled"
    env = {"RUST_LOG": "info,ax_engine_mlx::flash_next_startup=debug"}
    if mode == "required":
        env["AX_FLASH_NEXT_MTP_COST"] = "0"
    native_rows, openai_rows = [], []
    with controls.serving.server(
        args, mode, controls.MODEL, args.pack, 1, env=env, guard=True, stream_experts="auto",
        mtp="required" if mode == "required" else None, prefill_chunk=2048,
        options=("--total-blocks", "2048", "--disable-ngram-acceleration"),
    ) as (base, pid):
        ensure_library(pid, build["libmlx_sha256"])

        def full(_):
            return controls.stream(base, ids, controls.BASE)

        native_actions = (
            ("baseline", full),
            ("disconnect", lambda before: native.disconnect(base, ids, native_mode, before, args.out / "disconnect-steps.jsonl")),
            ("same-prompt-after-disconnect", full),
            ("stepwise-cancel", lambda before: native.stepwise_cancel(base, ids, native_mode, before)),
            ("same-prompt-after-stepwise-cancel", full),
        )
        for name, action in native_actions:
            row = native.checked_action(base, name, action)
            native_rows.append(row)
            native.write_line(args.out / "cases.jsonl", row)
            print(f"{mode} native {name} completed", flush=True)

        for name in OPENAI_ACTIONS:
            row = native.checked_action(
                base, name, lambda before: openai_stream(
                    base, ids, mode, before=before if name == "disconnect" else None))
            openai_rows.append(row)
            native.write_line(args.out / "openai.jsonl", row)
            print(f"{mode} OpenAI {name} completed", flush=True)
        assert native.call(base, "/health")["status"] == "ok"

    native.verify(native_rows, native_mode, ids)
    verify_openai(openai_rows, mode)
    return native_rows, openai_rows


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--mode", choices=("default", "required"))
    for flag in ("binary", "pack", "link-root", "out"):
        cli.add_argument(f"--{flag}", type=Path)
    cli.add_argument("--check-inputs", action="store_true")
    args = cli.parse_args()
    ids = controls.prompt()
    build = controls.read(ROOT / "build.json")
    assert build["codesign_verified"] and build["server_sha256"] == controls.SERVER
    assert controls.digest(ROOT / "source.patch") == build["patch_sha256"]
    if args.check_inputs:
        print("Bound the frozen 512-token prompt, the fixed executable and both HTTP surfaces.")
        return
    assert controls.digest(args.binary) == controls.SERVER
    inventory = controls.read(ROOT / "mxfp4-inventory.json")
    assert len(inventory["members"]) == 49
    manifest = controls.native.validate_inventory(args.pack, inventory, args.link_root)
    assert manifest == {"model-manifest.json": controls.digest(ROOT / "model-manifest.json")}
    args.out.mkdir()
    run(args, ids, build)
    log = args.out / f"{args.mode}.log"
    text = log.read_text()
    reader, = [line for line in text.splitlines() if "Flash Next resident reader" in line]
    assert f"reader={READER}" in reader, reader
    for old, new in ((str(args.pack), "[pack]"), (str(ROOT), "[run]"), (str(Path.home()), "[home]")):
        text = text.replace(old, new)
    text = re.sub(r"127\.0\.0\.1(?::\d+)?", "[loopback]", text)
    log.write_text(text)
    samples = [json.loads(line) for line in (args.out / f"{args.mode}-samples.jsonl").read_text().splitlines()]
    assert samples and all(row["pressure"] == 1 and 0 < row["footprint_bytes"] <= 96 << 30 for row in samples)
    assert controls.native.validate_inventory(args.pack, inventory, args.link_root) == manifest
    version = subprocess.check_output(["/usr/bin/sw_vers", "-productVersion"], text=True).strip()
    receipt = {
        "mode": args.mode, "qualification": False, "server_sha256": controls.SERVER,
        "manifest": manifest, "macos": version, "publisher_members_verified_before_and_after": 49,
        "reader": READER, "native_actions": 5, "openai_actions": 3,
        "mtp_policy_flag": "required" if args.mode == "required" else None,
        "cost_controller_override": "0" if args.mode == "required" else None,
        "normal_pressure_samples": len(samples), "max_footprint_bytes": max(row["footprint_bytes"] for row in samples),
    }
    (args.out / "receipt.json").write_text(json.dumps(receipt, indent=2, sort_keys=True, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
