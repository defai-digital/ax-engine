#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
lab="$PWD"
local_pack_path="$1"
owner=$2
source_checkout=$3
python="$source_checkout/.venv/bin/python"
export PATH="$source_checkout/.venv/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export PYTHONDONTWRITEBYTECODE=1
start="$(ps -p "$owner" -o lstart= || true)"
printf 'Waiting for the local pinned software gate.\n'
while test -n "$start" && test "$(ps -p "$owner" -o lstart= || true)" = "$start"; do
    if (( SECONDS >= 7200 )); then exit 1; fi
    sleep 15
done
export DYLD_LIBRARY_PATH="$("$python" -c 'import importlib.metadata as m; assert m.version("mlx") == m.version("mlx-metal") == "0.32.4"; print(m.distribution("mlx").locate_file("mlx/lib"))')"
test "$(sysctl -n machdep.cpu.brand_string hw.memsize)" = "$(printf 'Apple M2 Ultra\n206158430208')"
test "$(git -C "$lab/source" rev-parse HEAD)" = "$(cat "$lab/candidate-commit.txt")"
shasum -a 256 -c live-inputs.sha256
pack="$(cat "$local_pack_path")"
exec /usr/bin/caffeinate -dimsu /usr/bin/env DYLD_LIBRARY_PATH="$DYLD_LIBRARY_PATH" "$python" -B -u \
  driver/run_grouped_prefill.py --binary "$lab/driver/ax-engine-server-grouped-lab" \
    --flash "$pack" --prompts "$lab/driver/prompts.jsonl" --inventory "$lab/driver/inventory.json" \
    --out "$lab/m2-real"
