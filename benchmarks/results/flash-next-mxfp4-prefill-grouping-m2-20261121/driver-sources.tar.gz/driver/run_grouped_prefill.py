"""Compare scheduler turns while retaining Flash Next's 512-token forwards."""

import argparse
import json
import os
from pathlib import Path
import statistics
import subprocess
import time

import check_flash_next_native_support as native
from run_flash_next_lifecycle import wait_drained
from run_flash_next_prefill_split_probe import MODEL, RESERVE_OPTIONS, disconnect_and_reuse, replay
from run_qwen38_reference_serving import server, write_json
from verify_flash_next_prefill_split import (
    COUNTERS, HOLDOUT_SHA, INVENTORY_SHA, SPLIT_PREFIX, metrics, verify_partition, verify_route_overlap,
)

PROMPT_LENGTH = 8192
ARMS = {"off": [], "one": [512, 512, 512, 511, 1], "two": [1024, 1023, 1]}


def gaps(request, peer):
    outputs = [s for s in request["scheduled_work"] if s["delta_token_count"]]
    prefill_ids = {s["step_id"] for s in peer["prefill_progress"]}
    intervals = [(b["received_seconds"] - a["received_seconds"],
                  a["step_id"] in prefill_ids or b["step_id"] in prefill_ids)
                 for a, b in zip(outputs, outputs[1:])]
    times = [delta for delta, _ in intervals]
    assert times and min(times) >= 0
    return {
        "request_id": request["request_id"],
        "gap_p95_seconds": statistics.quantiles(times, n=100, method="inclusive")[94],
        "gap_max_seconds": max(times),
        "intervals_at_or_over_100ms": sum(delta >= .1 for delta in times),
        "intervals_at_or_over_100ms_adjacent_to_peer_prefill": sum(
            delta >= .1 and shared for delta, shared in intervals
        ),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for option in ("binary", "flash", "prompts", "inventory", "out"):
        parser.add_argument(f"--{option}", type=Path, required=True)
    args = parser.parse_args()
    processes = subprocess.check_output(["/bin/ps", "-axo", "comm="], text=True)
    if any(Path(line.strip()).name.startswith("ax-engine-server") for line in processes.splitlines()):
        raise RuntimeError("Another process owns the inference device")
    assert native.sha256(args.prompts) == HOLDOUT_SHA[PROMPT_LENGTH]
    assert native.sha256(args.inventory) == INVENTORY_SHA
    binary_sha = native.sha256(args.binary)
    rows = [json.loads(line) for line in args.prompts.read_text().splitlines()]
    assert len(rows) == 2 and all(len(row["input_tokens"]) == PROMPT_LENGTH for row in rows)
    inventory = json.loads(args.inventory.read_text())
    manifest = native.validate_inventory(args.flash, inventory)
    environment = native.server_env()
    os.environ.clear()
    os.environ.update(environment)
    args.out.mkdir(parents=True, exist_ok=False)
    result = {"status": "running", "pack_revision": native.PACK_REVISION,
              "binary_sha256": binary_sha, "inventory_sha256": INVENTORY_SHA,
              "prompts_sha256": HOLDOUT_SHA[PROMPT_LENGTH], "arms": {}}

    def drain(url):
        counters = wait_drained(url)
        assert counters.keys() == COUNTERS and not any(counters.values())
        return counters

    expected = {}
    for name, widths in ARMS.items():
        arm = {"trials": [], "turn_widths": widths}
        result["arms"][name] = arm
        env = {"AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0",
               "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": str(int(name != "off")),
               "AX_MLX_FLASH_NEXT_PREFILL_SPLIT_PAIR": str(int(name == "two"))}
        options = ("--disable-ngram-acceleration", "--total-blocks", "2048",
                   "--max-batch-tokens", "2049", *RESERVE_OPTIONS)
        with server(args, name, MODEL, args.flash, 2, env=env, options=options,
                    stream_experts="auto", guard=True) as (base, _):
            assert "decision=resident" in (args.out / f"{name}.log").read_text()
            if name == "off":
                arm["serial"] = replay(base, rows, "serial", 0)
                expected = {row["prompt_id"]: row["output_tokens"] for row in arm["serial"]}
                assert len(expected) == 2 and all(len(ids) == 96 for ids in expected.values())
                for row in arm["serial"]:
                    assert verify_partition(row, PROMPT_LENGTH, False) == 0
                arm["serial_drained"] = drain(base)
            for leader in (0, 1):
                start = time.monotonic()
                replies = replay(base, rows, "decode-arrival", leader)
                elapsed = time.monotonic() - start
                splits = [verify_partition(row, PROMPT_LENGTH, bool(widths), widths)
                          for row in replies]
                assert splits[leader] == 0 and splits[1 - leader] == (4 if widths else 0)
                if widths:
                    verify_route_overlap({"requests": replies}, widths[0])
                assert all(row["output_tokens"] == expected[row["prompt_id"]] for row in replies)
                trial = {"requests": replies, "client_wall_seconds": elapsed, "leader": leader}
                trial["aggregate"] = metrics(trial)
                trial["per_request"] = [gaps(replies[i], replies[1 - i]) for i in (0, 1)]
                trial["drained"] = drain(base)
                arm["trials"].append(trial)
                write_json(args.out / "partial.json", result)
                print(f"{name} peer {leader} verified", flush=True)
            if name == "two":
                trial = disconnect_and_reuse(base, rows, 0, "prefill")
                before = trial["disconnected"]
                cut = before["prefill_progress"][0]
                assert not before["first_output_tokens"] and cut["cursor"] == widths[0]
                assert cut["prefill_route"] == {f'{SPLIT_PREFIX}{before["request_id"]}': 2048}
                assert trial["shared_steps"] and cut["step_id"] in trial["shared_steps"]
                for label in ("survivor", "replacement"):
                    row = trial[label]
                    assert row["output_tokens"] == expected[row["prompt_id"]]
                for label in ("drained_after_disconnect", "drained_after_replacement"):
                    assert trial[label].keys() == COUNTERS and not any(trial[label].values())
                arm["disconnect"] = trial
        samples = [json.loads(line) for line in (args.out / f"{name}-samples.jsonl").read_text().splitlines()]
        assert samples and {row["pressure"] for row in samples} == {1}
        arm["memory_samples"] = samples
        write_json(args.out / "partial.json", result)
    assert native.validate_inventory(args.flash, inventory) == manifest
    assert native.sha256(args.binary) == binary_sha
    result["status"] = "complete"
    write_json(args.out / "result.json", result)


if __name__ == "__main__":
    main()
