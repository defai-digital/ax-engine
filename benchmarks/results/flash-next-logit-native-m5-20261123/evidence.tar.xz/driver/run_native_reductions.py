"""Compare the isolated Flash Next logit-read change through the native server."""
from argparse import ArgumentParser
import json
from pathlib import Path
import platform

from compare_cost import ratio, sizes
from run_cost import ROOT, load_workloads, native, require, run_arm

PHASES = ("correction_wall_us", "bonus_wall_us", "rejection_wall_us")
DECISIONS = ("verified_steps", "accepted_steps", "emitted_tokens")


def read(path):
    return json.loads(path.read_bytes())


def raw_rows(path):
    return [json.loads(line) for line in (path / "rows-required.jsonl").read_text().splitlines()]


def compare(original, revised, panels):
    require(len(original) == len(revised), "Incomplete native comparison")
    for base, candidate in zip(original, revised, strict=True):
        for key in ("id", "panel", "budget", "prompt_sha256", "output_tokens", "finish_reason",
                    "verifier_schedule", "verified_steps"):
            require(base[key] == candidate[key], f"Native comparison changed {key}: {base['id']}")
        for key in DECISIONS:
            require(base["counters"][key] == candidate["counters"][key],
                    f"Native comparison changed canonical verifier decision count: {base['id']}")
    summary = {}
    for name in panels:
        reference = [row for row in original if row["panel"] == name]
        treatment = [row for row in revised if row["panel"] == name]
        left, right = sizes(reference), sizes(treatment)
        summary[name] = {"baseline": left, "candidate": right,
                         "decode_speedup": ratio(left["decode_tokens_per_second"], right["decode_tokens_per_second"]),
                         "target_wall_us": {
                             label: {key: sum(row["counters"][key] for row in rows) for key in PHASES}
                             for label, rows in (("baseline", reference), ("candidate", treatment))}}
    return summary


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--cache", type=Path, required=True)
    cli.add_argument("--order", choices=("baseline-first", "candidate-first"), default="baseline-first")
    args = cli.parse_args()
    workloads, panels = load_workloads()
    labels = ["baseline", "candidate"]
    if args.order == "candidate-first":
        workloads.reverse()
        labels.reverse()
    builds = {label: read(path / "build.json") for label, path in
              (("baseline", ROOT), ("candidate", ROOT / "candidate"))}
    baseline, candidate = builds["baseline"], builds["candidate"]
    require(candidate["source_base"] == baseline["commit"]
            and candidate["server_sha256"] != baseline["server_sha256"]
            and all(candidate[key] == baseline[key] for key in ("mlx", "mlx_metal", "libmlx_sha256", "profile", "rustc", "cargo"))
            and candidate["tree"] != baseline["tree"], "The candidate changed the base model runtime")
    inventory = read(ROOT / "inventory.json")
    pack = args.cache / f"models--{inventory['repo_id'].replace('/', '--')}" / "snapshots" / inventory["revision"]
    manifest = native.validate_inventory(pack, inventory, args.cache)
    require(manifest == {"model-manifest.json": "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef"},
            "The verified model manifest changed")
    servers = {"baseline": ROOT / "ax-engine-server", "candidate": ROOT / "candidate/ax-engine-server"}
    require(all(native.sha256(servers[key]) == builds[key]["server_sha256"] for key in labels),
            "A signed native server digest changed")
    receipt = {"qualification": False, "source_builds": builds, "order": labels, "workload_panels": panels,
               "inventory_sha256": native.sha256(ROOT / "inventory.json"), "native_manifest": manifest,
               "os": platform.mac_ver()[0], "request_policy": "required", "arms": {}}
    for name in labels:
        capture = ROOT / f"observed-{name}"
        capture.mkdir()
        receipt["arms"][name] = run_arm("required", servers[name], pack, capture, workloads)
        (ROOT / "partial-native.json").write_text(json.dumps(receipt, indent=2, sort_keys=True, allow_nan=False) + "\n")
    require(native.validate_inventory(pack, inventory, args.cache) == manifest
            and all(native.sha256(servers[key]) == builds[key]["server_sha256"] for key in labels),
            "Pack inventory or server changed during measurement")
    receipt["timing_eligible"] = all(arm["timing_eligible"] for arm in receipt["arms"].values())
    receipt["panels"] = compare(*(raw_rows(ROOT / f"observed-{name}") for name in ("baseline", "candidate")), panels)
    (ROOT / "result-native.json").write_text(json.dumps(receipt, indent=2, sort_keys=True, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
