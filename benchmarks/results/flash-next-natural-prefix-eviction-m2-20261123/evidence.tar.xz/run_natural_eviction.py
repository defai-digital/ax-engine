"""Prove document-prefix survival and eviction on the guarded HTTP route."""

from argparse import ArgumentParser, Namespace
import json
from pathlib import Path
from time import monotonic

from run_fixed_extension import CASES, MANIFEST, ROOT, check_case, mixed, read, require, reuse, save, workload
from run_warm_prefix import EVICTIONS, STORES, overlap

ORDER = ('first', 'replacement', 'aligned')
ENTRY_LIMITS = (2, 1)


def cache_count(reply, key):
    return sum(event['decisions'].get(key, 0) for event in reply['cache_events'] if event['event'] == 'step')


def verify(records, oracle):
    kinds = {label: (cancelled, tail) for label, _, _, cancelled, _, tail in CASES}
    for limit in ENTRY_LIMITS:
        record = records[str(limit)]
        cases, pressure = record['cases'], record['normal_pressure_samples']
        require(pressure > 0 and tuple(record['order']) == ORDER, 'Missing capacity evidence')
        for label in ORDER:
            cancelled, tail = kinds[label]
            output = check_case(cases[label], label == 'aligned' and limit == 2, cancelled, tail)
            require(output == oracle['outputs'][label], 'The capacity changed output token IDs')
        q1 = cases['first']['target']
        learner = cases['replacement']['target']
        peer = cases['aligned']['peer']
        require(cache_count(q1, STORES) == 1 and cache_count(learner, STORES) == 2
                and cache_count(learner, EVICTIONS) >= 1 and cache_count(peer, STORES) == 1
                and cache_count(peer, EVICTIONS) == 1,
                'The L1 publication and eviction sequence changed')


def run_arm(args, limit, prompts, kinds):
    label = f'entries-{limit}'
    out = args.out / label
    out.mkdir()
    env = {
        'AX_MLX_FLASH_NEXT_FIXED_PREFIX_EXTENSION': '1',
        'AX_MLX_FLASH_NEXT_LEARN_PREFIX_FORK': '1',
        'AX_ENGINE_PREFIX_REUSE_DISABLED': '0',
        'AX_MLX_PREFIX_CACHE_MAX_BYTES': '2147483648',
        'AX_MLX_PREFIX_CACHE_MAX_ENTRIES': str(limit),
        'AX_MLX_FLASH_NEXT_DIRECT_COALESCING': '0',
        'AX_MLX_FLASH_NEXT_PREFILL_SPLIT': '0',
        'AX_ENGINE_ADAPTIVE_PREFILL': '0',
    }
    flags = ('--disable-ngram-acceleration', '--total-blocks', '2048', '--max-batch-tokens', '2049',
             *mixed.RESERVE_OPTIONS)
    rows = {}
    with mixed.server(Namespace(binary=args.binary, out=out), label, mixed.MODEL, args.pack, 2,
                      env=env, options=flags, stream_experts='off', guard=True) as (base, _):
        startup = (out / f'{label}.log').read_text()
        require('model_family=qwen4_exp' in startup and 'mtp_requested=false' in startup,
                'The direct Flash Next route was not admitted')
        for name in ORDER:
            peer, target, _, tail = kinds[name]
            before = reuse(base)
            started = monotonic()
            left, right = overlap(base, prompts[peer], prompts[target])
            wall = monotonic() - started
            row = {'peer': left, 'target': right, 'reuse_before': before, 'reuse_after': reuse(base),
                   'drained': mixed.wait_drained(base), 'wall_seconds': wall}
            check_case(row, name == 'aligned' and limit == 2, False, tail)
            rows[name] = row
            save(out / 'partial.json', rows)
            print(f'{label} {name} verified', flush=True)
    mixed.native.scrub_log(out / f'{label}.log')
    samples = [json.loads(line) for line in (out / f'{label}-samples.jsonl').read_text().splitlines()]
    require(samples and all(row['pressure'] == 1 for row in samples), 'Host pressure was not normal')
    return {'cases': rows, 'order': ORDER, 'normal_pressure_samples': len(samples)}


def main():
    parser = ArgumentParser(description=__doc__)
    for field in ('binary', 'pack', 'out', 'replay'):
        parser.add_argument(f'--{field}', type=Path)
    args = parser.parse_args()
    oracle = read(ROOT / 'no-seed-cold-oracle.json')
    build = read(ROOT / 'build.json')
    if args.replay:
        result = read(args.replay)
        require(result['manifest'] == MANIFEST and result['build'] == build and not result['qualification'],
                'Runtime identity changed')
        verify(result['arms'], oracle)
        print('Verified bounded HTTP eviction and exact IDs')
        return
    require(args.binary and args.pack and args.out, 'Missing runtime inputs')
    require(mixed.digest(args.binary) == build['server_sha256'] and build['codesign_verified'] is True,
            'The signed executable changed')
    inventory = read(ROOT / 'mxfp4-inventory.json')
    require(mixed.native.validate_inventory(args.pack, inventory) == MANIFEST == oracle['manifest'],
            'The admitted publisher data changed')
    prompts = workload()
    kinds = {name: (peer, target, cancelled, tail) for name, peer, target, cancelled, _, tail in CASES}
    args.out.mkdir()
    arms = {str(limit): run_arm(args, limit, prompts, kinds) for limit in ENTRY_LIMITS}
    verify(arms, oracle)
    require(mixed.native.validate_inventory(args.pack, inventory) == MANIFEST, 'Publisher data changed')
    save(args.out / 'receipt.json', {'manifest': MANIFEST, 'build': build,
                                    'qualification': False, 'arms': arms})


if __name__ == '__main__':
    main()
