#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
native=$1
policy=$2
pin=ff2a28485eb89bb60e8fe35dd6c65c51e63ee7b3
cache="$native/cache"
pack="$cache/models--AutomatosX--AX-Qwen3.8-Flash-Next-MLX-AXQ-MXFP4-MTP/snapshots/$pin"
python="$HOME/.venvs/ax-engine/bin/python"
test "$(/usr/sbin/sysctl -n hw.model hw.memsize)" = "$(printf 'Mac17,6\n137438953472')"
test "$(/usr/sbin/sysctl -n kern.memorystatus_vm_pressure_level)" = 1
test -d "$pack"
test "$(stat -f %d "$pack")" = "$(stat -f %d .)"
if /bin/ps -axo comm= | /usr/bin/grep -Eq '/(ax-engine-server[^/]*|direct_weights|ax-ple-reader-test|ax-flash-shared-load-test)$'; then
    printf '%s\n' 'Another owned model workload is active.' >&2
    exit 2
fi
/usr/bin/shasum -a 256 -c inputs.sha256
test "$(shasum -a 256 "$pack/model-manifest.json" | awk '{print $1}')" = 62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef
lib=$("$python" -B -c 'from importlib.metadata import version,distribution; assert version("mlx") == version("mlx-metal") == "0.32.4"; print(distribution("mlx").locate_file("mlx/lib"))')
expected=$("$python" -B -c 'import json; print(json.load(open("build.json"))["libmlx_sha256"])')
test "$(shasum -a 256 "$lib/libmlx.dylib" | awk '{print $1}')" = "$expected"
mkdir "clones-$policy"
exec /usr/bin/caffeinate -dimsu /usr/bin/env -i HOME="$HOME" \
  PATH="$HOME/.venvs/ax-engine/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin" \
  DYLD_LIBRARY_PATH="$lib" PYTHONDONTWRITEBYTECODE=1 \
  "$python" -B -u run_cache_policy.py --policy "$policy" --server "$PWD/ax-engine-server" \
  --pack "$pack" --inventory "$PWD/inventory.json" --scratch-dir "$PWD/clones-$policy" \
  --build-receipt "$PWD/build.json" --output "$PWD/$policy"
