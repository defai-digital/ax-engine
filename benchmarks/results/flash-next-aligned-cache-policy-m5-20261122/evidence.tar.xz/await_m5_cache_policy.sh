#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
previous=$1
native=$2
ref=$3
deadline=$((SECONDS + 10800))
test "$(cat "$native/status.txt")" = 0
test "$(cat "$previous/required-status.txt")" = 0
test "$(cat "$previous/status.txt")" = 0
for policy in default; do
    : > "queued-$policy.txt"
    acquired=0
    while (( SECONDS < deadline )); do
        if test -s "$ref/clean-preflight.json" || test -s "$ref/headroom.jsonl"; then
            printf '%s\n' 'The ordinary independent reference acquired the device.'
            exit 4
        fi
        if /usr/bin/python3 -B - "queued-$policy.txt" "$ref/clean-capacity.jsonl" <<'PY'
from datetime import datetime
import json, sys
from pathlib import Path
mark, trace = map(Path, sys.argv[1:]); row = json.loads(trace.read_bytes().splitlines()[-1])
observed = datetime.fromisoformat(row['utc']).timestamp()
ready = (observed >= mark.stat().st_mtime and row['eligible_for_attempt'] is False
         and row['pressure'] == 1 and row['reason'] == 'background-rss-exceeds-signed-margin')
raise SystemExit(not ready)
PY
        then
            if /bin/bash run_m5_cache_policy_serialized.sh "$ref" "$native" "$policy"; then
                printf '%s\n' '0' > "$policy-status.txt"
            else
                code=$?
                printf '%s\n' "$code" > "$policy-status.txt"
                exit "$code"
            fi
            acquired=1
            break
        fi
        sleep 15
    done
    (( acquired )) || exit 5
done
