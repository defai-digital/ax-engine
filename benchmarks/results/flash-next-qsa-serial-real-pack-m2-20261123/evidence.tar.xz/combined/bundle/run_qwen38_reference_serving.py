"""Run sequential Qwen 3.8 serving experiments using local model artifacts."""

import argparse
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
import ctypes
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
from threading import Event, Thread
import time
from urllib.error import HTTPError
from urllib.request import Request, urlopen

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def write_jsonl(path, rows):
    path.write_text("".join(json.dumps(row) + "\n" for row in rows))
    return path


def run_json(url, data=None):
    request = Request(
        url,
        data=json.dumps(data).encode() if data is not None else None,
        headers={"Content-Type": "application/json"},
    )
    started = time.monotonic()
    with urlopen(request, timeout=120) as response:
        body = json.load(response)
    return time.monotonic() - started, body


@contextmanager
def server(args, name, model_id, pack, concurrency, *, env=None, options=(),
           mtp="disabled", stream_experts="off", prefill_chunk=1024, guard=False):
    log = args.out / f"{name}.log"
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        port = listener.getsockname()[1]
    command = [
        str(args.binary), "--mlx", "--mlx-model-artifacts-dir", str(pack),
        "--model-id", model_id, "--host", "127.0.0.1", "--port", str(port),
        "--max-concurrent-requests", str(concurrency), "--stream-experts", stream_experts,
        "--prefill-chunk", str(prefill_chunk), "--mlx-mtp-policy", mtp, *options,
    ]
    process_env = os.environ | {
        "AX_MLX_NATIVE_CONFIRM": "1",
        "AX_MLX_PREFIX_CACHE_DISK_DISABLED": "1",
        "AX_ENGINE_PREFIX_REUSE_DISABLED": "1",
        "AX_MLX_PREFIX_CACHE_MAX_BYTES": "0",
        "AX_MLX_PREFIX_CACHE_MAX_ENTRIES": "0",
        "RUST_LOG": "info",
    } | (env or {})
    with log.open("w") as stream:
        process = subprocess.Popen(command, env=process_env, stdout=stream, stderr=stream)
        stop = Event()
        monitor = None
        if guard:
            monitor = Thread(target=monitor_memory, args=(args.out, name, process, stop), daemon=True)
            monitor.start()
        try:
            started = time.monotonic()
            while time.monotonic() - started < 1800 and process.poll() is None:
                with log.open() as source:
                    tail = source.read()
                match = re.search(r"listening on http://127\.0\.0\.1:(\d+)", tail)
                if match:
                    yield f"http://127.0.0.1:{match[1]}", process.pid
                    break
                time.sleep(0.5)
            else:
                raise RuntimeError(f"{name} never became ready; inspect {log}")
        finally:
            stop.set()
            if monitor:
                monitor.join()
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(15)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(10)


def benchmark(args, url, name, model_id, corpus, concurrency):
    output = args.out / f"{name}.json"
    subprocess.run(
        [sys.executable, str(args.bench), "--base-url", url, "--model-id", model_id,
         "--corpus", str(corpus), "--corpus-arrivals", "--warmup-requests", "0",
         "--input-kind", "tokens", "--concurrency", str(concurrency),
         "--ignore-eos", "--record-token-ids", "--stream-gap-slo-ms", "1000",
         "--timeout", "240", "--output", str(output)],
        check=True, timeout=600, stdout=subprocess.DEVNULL,
    )
    artifact = json.loads(output.read_text())
    print(name, artifact["summary"]["ok_requests"], artifact["summary"]["error_requests"], flush=True)
    if artifact["summary"]["error_requests"]:
        raise RuntimeError(f"{name} contains failed requests; inspect {output}")
    return artifact


def timed_prompts(pack, contexts, *, decoder_count, arrival):
    from tokenizers import Tokenizer

    tokenizer = Tokenizer.from_file(str(pack / "tokenizer.json"))
    encode = lambda text: tokenizer.encode(text, add_special_tokens=False).ids
    prefix = encode("<|im_start|>user\n")
    rows = []
    for ordinal, size in enumerate(contexts):
        body = encode(
            f"Document {ordinal}. "
            + f"The inference service accounts for request {ordinal} and keeps its cache consistent. " * size
        )
        suffix = encode(
            "\nExplain ten ways to verify request isolation, with one example for each.\n"
            "<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n"
        )
        rows.append({
            "id": f"prompt-{ordinal}-{size}",
            "category": "decode" if ordinal < decoder_count else "cold-prefill",
            "input_tokens": prefix + body[:size - len(prefix) - len(suffix)] + suffix,
            "max_output_tokens": 96 if ordinal < decoder_count else 16,
            "arrival_s": 0 if ordinal < decoder_count else arrival,
        })
        assert len(rows[-1]["input_tokens"]) == size
    return rows


def matched_outputs(a, b):
    left = {row["prompt_id"]: row for row in a["observations"]}
    return sum(
        row["ok"] and left[row["prompt_id"]]["ok"]
        and row["output_token_ids"] == left[row["prompt_id"]]["output_token_ids"]
        for row in b["observations"]
    )


def disconnect_after_first_step(url, model_id, row):
    request = Request(
        url + "/v1/generate/stream",
        data=json.dumps({
            "model": model_id, "input_tokens": row["input_tokens"], "max_output_tokens": 256,
            "sampling": {"temperature": 0, "ignore_eos": True},
        }).encode(),
        headers={"Content-Type": "application/json"},
    )
    request_id = None
    with urlopen(request, timeout=120) as response:
        for line in response:
            if not line.startswith(b"data:") or line.strip() == b"data: [DONE]":
                continue
            data = json.loads(line[5:])
            if "request" in data:
                request_id = data["request"]["request_id"]
            if request_id is not None and data.get("delta_tokens"):
                return request_id
    raise RuntimeError("disconnect control did not observe a generated token")


def memory(pid):
    return int(subprocess.check_output(["ps", "-o", "rss=", "-p", str(pid)]).strip()) * 1024


class ProcessUsage(ctypes.Structure):
    _fields_ = [("uuid", ctypes.c_uint8 * 16)] + [
        (name, ctypes.c_uint64)
        for name in ("user_time", "system_time", "interrupt_wakeups", "idle_wakeups",
                     "pageins", "wired", "rss", "footprint", "started", "exited")
    ]


def monitor_memory(out, name, process, stop):
    get_usage = ctypes.CDLL("/usr/lib/libproc.dylib").proc_pid_rusage
    get_usage.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_void_p]
    get_usage.restype = ctypes.c_int
    with (out / f"{name}-samples.jsonl").open("w") as stream:
        while not stop.is_set() and process.poll() is None:
            usage = ProcessUsage()
            if get_usage(process.pid, 0, ctypes.byref(usage)) == 0:
                pressure = subprocess.check_output(
                    ["sysctl", "-n", "kern.memorystatus_vm_pressure_level"], text=True
                ).strip()
                swap = subprocess.check_output(["sysctl", "-n", "vm.swapusage"], text=True).strip()
                sample = {"footprint_bytes": usage.footprint, "rss_bytes": usage.rss,
                          "pressure": int(pressure), "swap": swap}
                print(json.dumps(sample), file=stream, flush=True)
                if usage.footprint > 96 * 2**30 or pressure in ("4", "8"):
                    process.terminate()
                    break
            stop.wait(1)


def dflash27b(args):
    model_id = "qwen3.8-27b:axq"
    short = [json.loads(line) | {"arrival_s": 0} for line in args.short.read_text().splitlines()]
    short_corpus = write_jsonl(args.out / "short.jsonl", short)
    arms = (
        ("solo1", "0", "0", 1), ("solo2", "0", "0", 2),
        ("packed2", "1", "0", 2), ("lane-head2", "1", "1", 2),
        ("packed4", "1", "0", 4), ("lane-head4", "1", "1", 4),
    )
    for name, cohort, head, concurrency in arms:
        if args.dflash_arm and name not in args.dflash_arm:
            continue
        with server(args, name, model_id, args.qwen, concurrency, mtp="auto", env={
            "AX_MLX_DFLASH2": "1",
            "AX_MLX_DFLASH2_DIR": str(args.drafter),
            "AX_MLX_DFLASH2_COHORT": cohort,
            "AX_MLX_DFLASH2_COHORT_LANE_HEAD": head,
            "AX_MLX_DFLASH2_ROUND_TRACE": "1",
            "AX_MLX_DFLASH2_LOGIT_PROBE": "3,321,271",
            "AX_MLX_TREE_VERIFY": "0",
        }) as (url, _):
            artifact = benchmark(args, url, name, model_id, short_corpus, concurrency)
            trace = (args.out / f"{name}.log").read_text()
            if "dflash2_round " not in trace:
                raise RuntimeError(f"{name} did not execute DFlash2")
            if cohort == "1" and "dflash2_cohort " not in trace:
                raise RuntimeError(f"{name} did not execute packed DFlash2")


def mixed27b(args):
    model_id = "qwen3.8-27b:axq"
    for stall in (0, 250):
        if args.stall_only is not None and stall != args.stall_only:
            continue
        arm = f"mixed-{stall}"
        with server(args, arm, model_id, args.qwen, 3, env={"AX_MLX_DFLASH2": "0"},
                    options=("--disable-ngram-acceleration", "--prefill-stall-target-ms", str(stall),
                             "--total-blocks", "2560")) as (url, _):
            for size in (8192, 16384, 32768):
                name = f"{arm}-{size}"
                corpus = write_jsonl(args.out / f"{name}.jsonl",
                                     timed_prompts(args.qwen, [384, 448, size], decoder_count=2, arrival=2))
                benchmark(args, url, name, model_id, corpus, 3)


def coload27b(args):
    model_id = "qwen3.8-27b:axq"
    with server(args, "coload", model_id, args.qwen, 3,
                env={"AX_MLX_DFLASH2": "0"},
                options=("--disable-ngram-acceleration", "--total-blocks", "2560")) as (url, pid):
        check_coload(args, url, pid, model_id)


def check_coload(args, url, pid, model_id):
    embed_id = "qwen3-embedding-0.6b"
    path = url + "/v1/model/load"
    payload = {"model_path": str(args.embedding), "load_mode": "add", "make_default": False}
    try:
        run_json(path, payload | {"model_id": "qwen3.6-27b"})
    except HTTPError as error:
        assert error.code == 422
    else:
        raise AssertionError("mismatched artifact was admitted")
    name = "coload-27b"
    rows = timed_prompts(args.qwen, [512], decoder_count=1, arrival=0)
    rows[0]["max_output_tokens"] = 256
    corpus = write_jsonl(args.out / f"{name}.jsonl", rows)
    rss_before = memory(pid)
    with ThreadPoolExecutor(max_workers=1) as workers:
        active = workers.submit(benchmark, args, url, name, model_id, corpus, 1)
        time.sleep(1)
        assert not active.done()
        load_seconds, loaded = run_json(path, payload | {"model_id": embed_id})
        assert loaded["default_model_id"] == model_id
        still_generating = not active.done()
        rss_resident = memory(pid)
        _, embedded = run_json(url + "/v1/embeddings", {"model": embed_id, "input": "An isolated stream"})
        assert embedded["data"][0]["embedding"]
        rss_embedded = memory(pid)
        _, unloaded = run_json(url + "/v1/model/unload", {"model_id": embed_id})
        assert unloaded["default_model_id"] == model_id
        write_json(args.out / "coload-responses.json", {
            "load_seconds": load_seconds, "load": loaded, "unload": unloaded,
        })
        assert active.result()["summary"]["ok_requests"] == 1
    _, memory_report = run_json(url + "/v1/memory")
    write_json(args.out / "coload.json", {
        "load_seconds": load_seconds, "embedding_dimensions": len(embedded["data"][0]["embedding"]),
        "generation_active_after_load": still_generating,
        "lifetime_peak_footprint_bytes": memory_report["lifetime_max_phys_footprint_bytes"],
        "rss_before_bytes": rss_before, "rss_resident_bytes": rss_resident,
        "rss_after_embedding_bytes": rss_embedded, "rss_after_unload_bytes": memory(pid),
    })


def flash(args):
    model_id = "qwen3.8-flash-next:axq"
    for concurrency, enabled in ((1, "0"), (2, "0"), (2, "1")):
        arm = f"flash-{concurrency}-{enabled}"
        if args.flash_arm and arm != args.flash_arm:
            continue
        with server(args, arm, model_id, args.flash, concurrency,
                    env={"AX_MLX_FLASH_NEXT_DIRECT_COALESCING": enabled},
                    options=("--disable-ngram-acceleration", "--total-blocks", "2048"),
                    stream_experts="auto", guard=True) as (url, pid):
            for size in (2048, 8192) if concurrency == 1 else (2048,):
                corpus = write_jsonl(args.out / f"flash-{size}.jsonl",
                                     timed_prompts(args.flash, [size, size], decoder_count=2, arrival=0))
                name = f"{arm}-{size}"
                artifact = benchmark(args, url, name, model_id, corpus, concurrency)
                rss = memory(pid)
                record = {"rss_after_bytes": rss}
                if concurrency == 2:
                    baseline = json.loads((args.out / f"flash-1-0-{size}.json").read_text())
                    record["exact_matches"] = matched_outputs(baseline, artifact)
                write_json(args.out / f"{name}-memory.json", record)
                if enabled == "1":
                    rows = [json.loads(line) for line in corpus.read_text().splitlines()]
                    survivor = write_jsonl(args.out / "flash-survivor.jsonl", rows[:1])
                    with ThreadPoolExecutor(max_workers=1) as workers:
                        sibling = workers.submit(benchmark, args, url, "flash-cancel-sibling",
                                                 model_id, survivor, 1)
                        disconnected = disconnect_after_first_step(url, model_id, rows[1])
                        matches = matched_outputs(baseline, sibling.result())
                    write_json(args.out / "flash-cancel.json", {
                        "surviving_output_matches": matches, "disconnected_request_id": disconnected,
                    })


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for option in ("binary", "bench", "out", "qwen", "drafter", "embedding", "flash", "short"):
        parser.add_argument(f"--{option}", type=Path, required=True)
    parser.add_argument("--arm", choices=["dflash", "mixed", "flash", "coload", "all"], default="all")
    parser.add_argument("--dflash-arm", action="append")
    parser.add_argument("--flash-arm", choices=["flash-1-0", "flash-2-0", "flash-2-1"])
    parser.add_argument("--stall-only", type=int, choices=[0, 250])
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    if args.arm in ("dflash", "all"):
        dflash27b(args)
    if args.arm in ("mixed", "all"):
        mixed27b(args)
    if args.arm in ("flash", "all"):
        flash(args)
    if args.arm in ("coload", "all"):
        coload27b(args)
