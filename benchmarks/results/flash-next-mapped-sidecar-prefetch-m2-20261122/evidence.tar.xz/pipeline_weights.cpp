#include <CommonCrypto/CommonDigest.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <memory>
#include <fstream>
#include <future>
#include <iomanip>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include <mlx/allocator.h>
#include <mlx/mlx.h>

namespace mx = mlx::core;

namespace {

struct Source {
    explicit Source(const char* path) : fd(open(path, O_RDONLY | O_CLOEXEC)) {
        if (fd < 0) {
            throw std::runtime_error("Could not open tensor shard");
        }
    }
    ~Source() { close(fd); }
    Source(const Source&) = delete;
    Source& operator=(const Source&) = delete;
    const int fd;
};

struct Mapping {
    Mapping(int fd, size_t size) : len(size), memory(mmap(nullptr, size, PROT_READ, MAP_PRIVATE, fd, 0)) {
        if (memory == MAP_FAILED) {
            throw std::runtime_error("Could not map tensor shard");
        }
    }
    ~Mapping() { munmap(memory, len); }
    Mapping(const Mapping&) = delete;
    Mapping& operator=(const Mapping&) = delete;
    const size_t len;
    void* const memory;
};

struct Tensor {
    size_t offset;
    size_t len;
    mx::Dtype dtype;
    mx::Shape shape;
};

mx::Dtype type(const std::string& code) {
    if (code == "U8") return mx::uint8;
    if (code == "U32") return mx::uint32;
    if (code == "BF16") return mx::bfloat16;
    if (code == "F32") return mx::float32;
    throw std::runtime_error("Unsupported diagnostic dtype");
}

std::vector<Tensor> geometry(const char* path, size_t file_size) {
    std::ifstream plan(path);
    if (!plan) {
        throw std::runtime_error("Could not open validated tensor geometry");
    }
    std::vector<Tensor> tensors;
    size_t offset;
    while (plan >> offset) {
        size_t len;
        size_t dims;
        std::string code;
        if (!(plan >> len >> code >> dims) || dims > 8 || len == 0 ||
            offset > file_size || len > file_size - offset) {
            throw std::runtime_error("Tensor range exceeds validated file bounds");
        }
        const auto dtype = type(code);
        const size_t itemsize = mx::size_of(dtype);
        size_t expected = itemsize;
        mx::Shape shape;
        for (size_t dim = 0; dim < dims; ++dim) {
            int extent;
            if (!(plan >> extent) || extent <= 0 || expected > len / static_cast<size_t>(extent)) {
                throw std::runtime_error("Tensor shape overflow or mismatch");
            }
            shape.push_back(extent);
            expected *= static_cast<size_t>(extent);
        }
        if (expected != len) {
            throw std::runtime_error("Tensor length differs from its shape");
        }
        tensors.push_back({offset, len, dtype, std::move(shape)});
    }
    if (!plan.eof() || tensors.empty()) {
        throw std::runtime_error("Invalid or empty tensor geometry");
    }
    return tensors;
}

void read_exact(int fd, unsigned char* out, size_t len, size_t offset) {
    const size_t max_chunk = 4 * 1024 * 1024;
    size_t finished = 0;
    while (finished < len) {
        const auto count = pread(fd, out + finished, std::min(len - finished, max_chunk),
                                 static_cast<off_t>(offset + finished));
        if (count == 0) {
            throw std::runtime_error("Tensor read ended early");
        }
        if (count < 0) {
            if (errno == EINTR) {
                continue;
            }
            throw std::runtime_error("Positional tensor read failed");
        }
        finished += static_cast<size_t>(count);
    }
}

void read_pair(int fd, unsigned char* out, size_t len, size_t offset, size_t first_size) {
    auto first = std::async(std::launch::async, read_exact, fd, out, first_size, offset);
    read_exact(fd, out + first_size, len - first_size, offset + first_size);
    first.get();
}

constexpr size_t native_page_size = 16 * 1024;
constexpr size_t staging_bytes = 4 * 1024 * 1024;

void read_aligned(int fd, unsigned char* out, size_t len, size_t offset, unsigned char* staging) {
    size_t finished = 0;
    while (finished < len) {
        const size_t position = offset + finished;
        const size_t skip = position % native_page_size;
        const size_t span_start = position - skip;
        const size_t take = std::min(len - finished, staging_bytes - skip);
        const size_t needed = skip + take;
        const size_t span = ((needed + native_page_size - 1) / native_page_size) * native_page_size;
        size_t got = 0;
        while (got < needed) {
            const auto n = pread(fd, staging + got, span - got, static_cast<off_t>(span_start + got));
            if (n < 0 && errno == EINTR) {
                continue;
            }
            if (n <= 0) {
                throw std::runtime_error("Aligned tensor read did not cover its requested payload");
            }
            got += static_cast<size_t>(n);
            if (got < needed && got % native_page_size != 0) {
                throw std::runtime_error("Aligned tensor read stopped inside a required page");
            }
        }
        std::memcpy(out + finished, staging + skip, take);
        finished += take;
    }
}

constexpr size_t parallel_threshold = 64 * 1024 * 1024;
constexpr size_t read_alignment = 4 * 1024 * 1024;

mx::array materialized(int fd, const void* base, const Tensor& tensor, bool paired,
                       unsigned char* staging = nullptr) {
    auto storage = mx::allocator::malloc(tensor.len);
    auto* destination = static_cast<unsigned char*>(storage.buffer().raw_ptr());
    if (!storage.is_owned() || destination == nullptr) {
        throw std::runtime_error("Allocator did not provide owned CPU-accessible storage");
    }
    if (base != nullptr) {
        std::memcpy(destination, static_cast<const unsigned char*>(base) + tensor.offset, tensor.len);
    } else if (staging != nullptr) {
        read_aligned(fd, destination, tensor.len, tensor.offset, staging);
    } else if (paired && tensor.len >= parallel_threshold) {
        const size_t first_size = (tensor.len / 2 / read_alignment) * read_alignment;
        read_pair(fd, destination, tensor.len, tensor.offset, first_size);
    } else {
        read_exact(fd, destination, tensor.len, tensor.offset);
    }
    mx::array result(std::move(storage), tensor.shape, tensor.dtype);
    if (result.status() != mx::array::Status::available || !result.flags().row_contiguous ||
        result.buffer_size() < tensor.len || result.data<unsigned char>() != destination) {
        throw std::runtime_error("Array did not retain available owned storage");
    }
    return result;
}

class Digest {
  public:
    Digest() { CC_SHA256_Init(&ctx_); }
    void add(const void* bytes, size_t len) {
        auto* data = static_cast<const unsigned char*>(bytes);
        constexpr size_t limit = 64 * 1024 * 1024;
        while (len != 0) {
            const size_t chunk = std::min(len, limit);
            CC_SHA256_Update(&ctx_, data, static_cast<CC_LONG>(chunk));
            data += chunk;
            len -= chunk;
        }
    }
    std::string finish() {
        unsigned char raw[CC_SHA256_DIGEST_LENGTH];
        CC_SHA256_Final(raw, &ctx_);
        std::ostringstream text;
        for (unsigned char value : raw) {
            text << std::hex << std::setfill('0') << std::setw(2) << static_cast<int>(value);
        }
        return text.str();
    }
  private:
    CC_SHA256_CTX ctx_{};
};

void metal_probe(const mx::array& values, Digest& checksum) {
    auto flat = mx::reshape(values, {-1}, mx::Device::gpu);
    const int count = static_cast<int>(std::min<size_t>(values.size(), 16));
    auto portion = mx::slice(flat, {0}, {count}, mx::Device::gpu);
    auto widened = mx::astype(portion, mx::float32, mx::Device::gpu);
    auto transformed = mx::add(widened, mx::array(1.25f), mx::Device::gpu);
    mx::eval(transformed);
    checksum.add(transformed.data<float>(), transformed.nbytes());
}


using Clock = std::chrono::steady_clock;

double elapsed(Clock::time_point start, Clock::time_point end) {
    return std::chrono::duration<double>(end - start).count();
}

struct Entry {
    Entry(const char* path, const char* plan) : source(path) {
        if (fstat(source.fd, &stamp) != 0 || stamp.st_size <= 0 || !S_ISREG(stamp.st_mode)) {
            throw std::runtime_error("Unexpected checkpoint source");
        }
        sizes = geometry(plan, static_cast<size_t>(stamp.st_size));
    }

    std::vector<mx::array> mapped_copies() const {
        const Mapping map(source.fd, static_cast<size_t>(stamp.st_size));
        std::vector<mx::array> arrays;
        arrays.reserve(sizes.size());
        for (const auto& tensor : sizes) {
            arrays.push_back(materialized(source.fd, map.memory, tensor, false));
        }
        struct stat after {};
        if (fstat(source.fd, &after) != 0 || after.st_size != stamp.st_size ||
            after.st_mtimespec.tv_sec != stamp.st_mtimespec.tv_sec ||
            after.st_mtimespec.tv_nsec != stamp.st_mtimespec.tv_nsec ||
            after.st_ctimespec.tv_sec != stamp.st_ctimespec.tv_sec ||
            after.st_ctimespec.tv_nsec != stamp.st_ctimespec.tv_nsec) {
            throw std::runtime_error("Checkpoint source changed through the measured phases");
        }
        return arrays;
    }

    Source source;
    struct stat stamp {};
    std::vector<Tensor> sizes;
};

struct Prefetch {
    size_t bytes = 0;
    Clock::time_point began;
    Clock::time_point ended;
};

Prefetch prefetch_selected(const Entry& sidecar) {
    const auto started = Clock::now();
    std::vector<std::pair<size_t, size_t>> intervals;
    for (const auto& tensor : sidecar.sizes) {
        intervals.emplace_back(tensor.offset, tensor.offset + tensor.len);
    }
    std::sort(intervals.begin(), intervals.end());
    std::vector<unsigned char> staging(staging_bytes);
    size_t bytes = 0;
    for (size_t i = 0; i < intervals.size();) {
        auto [start, end] = intervals[i++];
        while (i < intervals.size() && intervals[i].first <= end) {
            end = std::max(end, intervals[i++].second);
        }
        while (start < end) {
            const size_t count = std::min(end - start, staging.size());
            read_exact(sidecar.source.fd, staging.data(), count, start);
            start += count;
            bytes += count;
        }
    }
    return {bytes, started, Clock::now()};
}

void emit_arrays(const std::vector<mx::array>& arrays) {
    Digest weights, metal;
    size_t bytes = 0;
    size_t allocated = 0;
    for (const auto& array : arrays) {
        weights.add(array.data<unsigned char>(), array.nbytes());
        metal_probe(array, metal);
        bytes += array.nbytes();
        allocated += array.buffer_size();
    }
    std::cout << "{\"tensors\":" << arrays.size()
              << ",\"selected_bytes\":" << bytes
              << ",\"allocated_bytes\":" << allocated
              << ",\"weights_sha256\":\"" << weights.finish()
              << "\",\"metal_sha256\":\"" << metal.finish() << "\"}";
}

void run_pipeline(bool enabled, const Entry& trunk, const Entry& sidecar) {
    const auto began = Clock::now();
    std::future<Prefetch> io;
    if (enabled) {
        io = std::async(std::launch::async, prefetch_selected, std::cref(sidecar));
    }
    const auto trunk_start = Clock::now();
    const auto trunk_arrays = trunk.mapped_copies();
    const auto trunk_done = Clock::now();
    Prefetch prefetch{0, began, began};
    if (enabled) prefetch = io.get();
    const auto sidecar_start = Clock::now();
    const auto sidecar_arrays = sidecar.mapped_copies();
    const auto sidecar_done = Clock::now();
    const double overlap = enabled ? std::max(0.0, elapsed(std::max(trunk_start, prefetch.began),
                                                           std::min(trunk_done, prefetch.ended))) : 0;
    std::cout << std::setprecision(9)
              << "{\"buffered_prefetch\":" << (enabled ? "true" : "false")
              << ",\"prefetched_bytes\":" << prefetch.bytes
              << ",\"trunk_seconds\":" << elapsed(trunk_start, trunk_done)
              << ",\"prefetch_seconds\":" << elapsed(prefetch.began, prefetch.ended)
              << ",\"overlap_seconds\":" << overlap
              << ",\"join_wait_seconds\":" << elapsed(trunk_done, sidecar_start)
              << ",\"sidecar_copy_seconds\":" << elapsed(sidecar_start, sidecar_done)
              << ",\"combined_seconds\":" << elapsed(began, sidecar_done)
              << ",\"trunk\":";
    emit_arrays(trunk_arrays);
    std::cout << ",\"sidecar\":";
    emit_arrays(sidecar_arrays);
    std::cout << "}\n";
}

} // namespace

int main(int argc, char** argv) {
    try {
        if (argc != 6 || (std::string(argv[1]) != "serial" && std::string(argv[1]) != "overlap")) {
            return 2;
        }
        const Entry trunk(argv[2], argv[3]);
        const Entry sidecar(argv[4], argv[5]);
        run_pipeline(std::string(argv[1]) == "overlap", trunk, sidecar);
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
