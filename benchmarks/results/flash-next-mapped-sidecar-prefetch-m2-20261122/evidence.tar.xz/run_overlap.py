"""Compare two mapped loads with or without an overlapping bounded sidecar read."""
from argparse import ArgumentParser
from hashlib import file_digest, sha256
import json
from math import isfinite
from pathlib import Path
import platform
import subprocess
from tempfile import TemporaryDirectory

from base_probe import INVENTORY_SHA, PAGE, REVISION, clone, page_state, pressure, range_plan, source_digest, sysctl

ROOT = Path(__file__).resolve().parent
IDENTITY = ("weights_sha256", "metal_sha256", "allocated_bytes", "selected_bytes", "tensors")
SIDECAR = "mtp.safetensors"
SIDECAR_BYTES = 5_214_301_696


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def tensor_names(file):
    with file.open("rb") as stream:
        length = int.from_bytes(stream.read(8), "little")
        if not 0 < length < 100_000_000:
            raise ValueError("Invalid sidecar header length")
        entries = json.loads(stream.read(length))
    return sorted(name for name in entries if name != "__metadata__")


def save(path, data):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def geometry(path, ranges):
    path.write_text("".join(" ".join(map(str, (start, length, dtype, len(shape), *shape))) + "\n"
                            for start, length, dtype, shape in ranges))


def verify(out, mode, sidecar_bytes):
    prefetch = mode == "overlap"
    if out["buffered_prefetch"] is not prefetch or out["prefetched_bytes"] != (sidecar_bytes if prefetch else 0):
        raise ValueError("The measured source did not bind the exact selected sidecar bytes")
    fields = ("trunk_seconds", "sidecar_copy_seconds", "prefetch_seconds",
              "overlap_seconds", "join_wait_seconds", "combined_seconds")
    if not all(isfinite(out[key]) and out[key] >= 0 for key in fields):
        raise ValueError("Invalid timing in the two-stage load")
    if prefetch and not 0 < out["overlap_seconds"] <= min(out["trunk_seconds"], out["prefetch_seconds"]):
        raise ValueError("The reader did not actually overlap the trunk copy")
    if not prefetch and (out["overlap_seconds"] or out["prefetch_seconds"]):
        raise ValueError("The serial control started a prefetch")
    if abs(out["combined_seconds"] - sum(out[key] for key in
            ("trunk_seconds", "sidecar_copy_seconds", "join_wait_seconds"))) > 0.02:
        raise ValueError("The combined idle and copy time does not close")


def main(args):
    inventory_file, selection_file = ROOT/"inventory.json", ROOT/"selection.json"
    inv = json.loads(inventory_file.read_bytes())
    members = {row["name"]: row for row in inv["members"]}
    build = json.loads((ROOT/"build.json").read_bytes())
    if (digest(inventory_file) != INVENTORY_SHA or inv["revision"] != REVISION
            or digest(args.binary) != build["binary_sha256"] or pressure() != 1
            or sysctl("hw.memsize") != str(192 * 1024**3) or PAGE != 16384):
        raise ValueError("Native inputs or M2 test host conditions changed")
    sidecar = args.pack/SIDECAR
    if digest(sidecar) != members[SIDECAR]["publisher_sha256"]:
        raise ValueError("The pinned publisher sidecar differs")
    side_names = tensor_names(sidecar)
    side_ranges = range_plan(sidecar, side_names)
    side_bytes = sum(length for _,length,_,_ in side_ranges)
    if side_bytes != SIDECAR_BYTES or len(side_names) != 31:
        raise ValueError("Expected the verified 31-tensor sidecar extent")
    side_sha = source_digest(sidecar, side_ranges)
    selectors = json.loads(selection_file.read_bytes())["files"]
    result = {"status":"running", "qualification":False, "scope":"M2 overlapping mapped trunk and sidecar component",
              "hardware":{"soc":sysctl("machdep.cpu.brand_string"),"macos":platform.mac_ver()[0],"storage":"external SSD",
                          "memory_bytes":int(sysctl("hw.memsize"))},
              "inventory_sha256":INVENTORY_SHA,"selection_sha256":digest(selection_file),"pack_revision":REVISION,
              "sidecar_geometry":{"bytes":side_bytes,"names":side_names,"sha256":members[SIDECAR]["publisher_sha256"]},
              "build":build,"synthetic_sha256":digest(ROOT/"synthetic.json"),"arms":[]}
    save(args.output,result)
    if len(selectors)!=2:
        raise ValueError("Expected the two existing publisher selections")
    for index,selection in enumerate(selectors):
        name=selection["name"]; src=args.pack/name
        if digest(src)!=members[name]["publisher_sha256"]:
            raise ValueError("The resident publisher shard differs")
        trunk_ranges=range_plan(src,selection["names"])
        trunk_bytes=sum(length for _,length,_,_ in trunk_ranges)
        if trunk_bytes!=selection["selected_bytes"]:
            raise ValueError("The selected trunk payload differs")
        trunk_sha=source_digest(src,trunk_ranges)
        order=("serial","overlap","overlap","serial")
        if index%2:
            order=("overlap","serial","serial","overlap")
        identity=None
        with TemporaryDirectory(dir=args.scratch) as temporary:
            work=Path(temporary)
            geometry(work/"trunk.plan",trunk_ranges)
            geometry(work/"sidecar.plan",side_ranges)
            for trial,mode in enumerate(order,1):
                trunk_copy=work/"trunk.safetensors"
                side_copy=work/"mtp.safetensors"
                if pressure()!=1:
                    raise ValueError("Non-normal pressure before the arm")
                clone(src,trunk_copy)
                clone(sidecar,side_copy)
                starts=[page_state(file,ranges) for file,ranges in
                        ((trunk_copy,trunk_ranges),(side_copy,side_ranges))]
                if any(o["resident_pages"]!=0 for o in starts):
                    raise ValueError("A fresh clone already has selected file pages resident")
                output=json.loads(subprocess.run(
                    [args.binary,mode,trunk_copy,work/"trunk.plan",side_copy,work/"sidecar.plan"],text=True,
                    capture_output=True,check=True,timeout=600).stdout)
                ends=[page_state(file,ranges) for file,ranges in ((trunk_copy,trunk_ranges),(side_copy,side_ranges))]
                trunk_copy.unlink()
                side_copy.unlink()
                verify(output,mode,side_bytes)
                stable=tuple(tuple(entry[k] for k in IDENTITY) for entry in (output["trunk"],output["sidecar"]))
                identity=identity or stable
                if (stable!=identity or output["trunk"]["weights_sha256"]!=trunk_sha
                        or output["sidecar"]["weights_sha256"]!=side_sha or pressure()!=1):
                    raise ValueError("Owned mapped arrays, output digests or pressure changed")
                result["arms"].append({"shard":name,"trial":trial,"mode":mode,"page_state_before":starts,
                    "page_state_after":ends,"pressure":1,**output})
                save(args.output,result)
                print(name,mode,output["combined_seconds"],flush=True)
    result["status"]="complete"
    save(args.output,result)


if __name__=="__main__":
    parser=ArgumentParser(description=__doc__)
    for name in ("binary","pack","scratch","output"):
        parser.add_argument(f"--{name}",type=Path,required=True)
    main(parser.parse_args())
