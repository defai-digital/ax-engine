"""Independently recheck Flash Next generated token arrays and measured repeat cells."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path

from scripts import check_flash_next_native_support as support
from scripts import check_flash_next_release_gates as gates
from seal_native import ROOT, matrix_rows, read


def ensure(valid, message):
    if not valid:
        raise ValueError(message)


def verify(raw, build):
    result = raw / "result.json"
    repeats_file = raw / "raw-runs.json"
    data = read(result)
    repeats = read(repeats_file)
    oracle = read(ROOT / "signed-native.json")["matrix"]
    ensure(build["codesign_verified"] is True and data["server_sha256"] == build["server_sha256"]
           and data["inventory_sha256"] == sha256((ROOT / "inventory.json").read_bytes()).hexdigest()
           and support.is_target_hardware(data["hardware"]),
           "Matrix proof used a different signed server or publisher inventory")
    ensure(data["modes"] == list(gates.AX_ARMS) and data["qualification"] is False
           and data["release_ready"] is False and not data["ax_server_env"]
           and type(data["temperature"]) in (int, float) and data["temperature"] == 0
           and data["output_tokens"] == 128,
           "Default native generation contract changed")
    ensure(set(repeats) == set(oracle) and all(len(runs) == 2 and
           all(matrix_rows(run) == oracle[mode] for run in runs)
           for mode, runs in repeats.items()),
           "A measured native process changed the signed generated tokens")
    ensure(not gates.matrix_repeat_problems(data, repeats), "Repeat selection or raw roster differs")
    native = {}
    for mode, runs in repeats.items():
        ensure(all(row["verified_steps"] == row["route_errors"] == 0 for run in runs
                   for row in run["trajectories"] + run["cells"]),
               "Direct matrix activated the drafter or emitted route errors")
        native[mode] = {
            "http_ready_seconds": data["runs"][mode]["ready_seconds"],
            "cells": {
                str(length): gates.cell_stats([row for row in data["runs"][mode]["cells"]
                                               if row["length"] == length], streamed=True)
                for length in gates.LENGTHS
            },
        }
    thresholds = read(gates.THRESHOLDS)
    cpu_idle = [data["host_quiet"]["cpu_idle_percent"], data["host_idle_after"]]
    return {
        "source": build["commit"], "qualification": False, "matching_signed_arrays": 124,
        "cpu_idle": cpu_idle, "timing_eligible": all(
            thresholds["timing_host"]["min_cpu_idle_percent"] <= sample <= 100 for sample in cpu_idle),
        "native": native,
        "raw_matrix_sha256": sha256(result.read_bytes()).hexdigest(),
        "raw_repeats_sha256": sha256(repeats_file.read_bytes()).hexdigest(),
    }


if __name__ == "__main__":
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("raw", type=Path)
    cli.add_argument("build", type=Path)
    args = cli.parse_args()
    print(json.dumps(verify(args.raw, read(args.build)), indent=2, sort_keys=True, allow_nan=False))
