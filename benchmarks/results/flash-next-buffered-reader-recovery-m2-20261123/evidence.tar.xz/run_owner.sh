#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
prior=$1
trap 'code=$?; printf "%s\n" "$code" > status.txt' EXIT
test "$(cat "$prior/status.txt")" = 0
test "$(/usr/sbin/sysctl -n machdep.cpu.brand_string)" = 'Apple M2 Ultra'
test "$(/usr/sbin/sysctl -n hw.memsize)" = 206158430208
test "$(/usr/sbin/sysctl -n kern.memorystatus_vm_pressure_level)" = 1
slot="$HOME/build/.ax-flash-next-native-test-slot"
mkdir "$slot" || exit 74
printf '%s\n' "$$" > "$slot/owner.pid"
finish() {
    code=$?
    if test "$(cat "$slot/owner.pid")" = "$$"; then
        rm "$slot/owner.pid"
        rmdir "$slot"
    fi
    printf '%s\n' "$code" > status.txt
}
trap finish EXIT
if ps -axo comm= | grep -Eq '/(ax-engine-server[^/]*|mtp-audit|direct_weights|ax-flash-.*-test)$'; then exit 74; fi
/usr/bin/shasum -a 256 -c inputs.sha256 >/dev/null
for file in ax-engine-server shard_read_fault.dylib; do /usr/bin/codesign --verify --strict "$file"; done
cmp build.json "$prior/build.json"
python="$HOME/code/ax-engine/.venv/bin/python"
lib=$("$python" -B -c 'from importlib.metadata import distribution,version; assert version("mlx")==version("mlx-metal")=="0.32.4"; print(distribution("mlx").locate_file("mlx/lib"))')
expected=$("$python" -B -c 'import json; print(json.load(open("build.json"))["libmlx_sha256"])')
test "$(shasum -a 256 "$lib/libmlx.dylib" | awk '{print $1}')" = "$expected"
/usr/bin/caffeinate -i /usr/bin/env -i HOME="$HOME" PATH=/usr/bin:/bin:/usr/sbin:/sbin \
    DYLD_LIBRARY_PATH="$lib" PYTHONDONTWRITEBYTECODE=1 "$python" -B -u run_read_recovery.py \
    --pack "$(cat "$prior/pack.pointer")" --out "$PWD/observed"
/usr/bin/shasum -a 256 -c inputs.sha256 >/dev/null
