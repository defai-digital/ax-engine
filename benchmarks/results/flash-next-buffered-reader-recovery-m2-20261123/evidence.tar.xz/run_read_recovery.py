"""Verify the candidate's owned startup recovery after a selected payload read fails."""

from argparse import ArgumentParser
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import time

import check_flash_next_native_support as native
import run_flash_next_generate_matrix as matrix
from run_fixed_extension import MANIFEST, read, workload
from run_selective_mixed import wait_drained

ROOT = Path(__file__).resolve().parent
PRECEDING = "model-00001-of-00025.safetensors"
FAILED = "model-00012-of-00025.safetensors"
INJECTED = "ax_fixture selected shard pread returned EIO"
PAYLOAD_ERROR = "aligned tensor payload read failed or ended early"
LOG_READER = "Flash Next resident reader aligned_nocache=false reader=AlignedBuffered"


def pressure():
    return int(subprocess.check_output(
        ["/usr/sbin/sysctl", "-n", "kern.memorystatus_vm_pressure_level"], text=True,
    ))


def sample_pressure(samples):
    observed = pressure()
    samples.append(observed)
    if observed != 1:
        raise RuntimeError(f"Expected normal pressure, got {observed}")


def address():
    listener = socket.socket()
    listener.bind(("127.0.0.1", 0))
    port = listener.getsockname()[1]
    listener.close()
    return port


def scrub(text, pack):
    text = re.sub(r"\x1b\[[0-9;]*m", "", text)
    for old, replacement in ((str(pack), "[pack]"), (str(ROOT), "[run]"),
                             (str(Path.home()), "[home]"), ("127.0.0.1", "[loopback]")):
        text = text.replace(old, replacement)
    return text


def observe_failure(command, pack, output, port, env):
    log = output / "fault.log"
    markers = []
    next_sample = 0
    with log.open("xb") as stream:
        child = subprocess.Popen(command, env=env, stdout=stream, stderr=stream)
        deadline = time.monotonic() + 600
        try:
            while child.poll() is None:
                now = time.monotonic()
                if now >= deadline:
                    raise TimeoutError("Faulted startup did not exit")
                if now >= next_sample:
                    sample_pressure(markers)
                    next_sample = now + 3
                with socket.socket() as probe:
                    probe.settimeout(0.3)
                    if probe.connect_ex(("127.0.0.1", port)) == 0:
                        raise RuntimeError("The failed process opened the HTTP port")
                time.sleep(0.15)
            assert child.returncode == 1
        finally:
            native.stop_owned(child)
    text = scrub(log.read_text(), pack)
    log.write_text(text)
    first = next(index for index, line in enumerate(text.splitlines())
                 if "Flash Next resident shard" in line and PRECEDING in line)
    fault = next(index for index, line in enumerate(text.splitlines()) if INJECTED in line)
    assert first < fault
    assert text.count(LOG_READER) == 1 and text.count(INJECTED) == 1
    assert "ax_fixture earlier shard payload read" in text and PAYLOAD_ERROR in text
    assert "preview listening" not in text and 'phase="resident_tensors"' not in text
    with socket.socket() as probe:
        probe.bind(("127.0.0.1", port))
    return {"exit_code": child.returncode, "completed_shard_before_fault": PRECEDING,
            "failed_shard": FAILED, "reader": "AlignedBuffered",
            "read_error": PAYLOAD_ERROR, "http_listener_observed": False,
            "port_reusable": True, "pressure_samples": markers}


def observe_recovery(command, pack, output, port, env, prompt, expected):
    log = output / "recovery.log"
    base = f"http://127.0.0.1:{port}"
    markers = []
    next_sample = 0
    with log.open("xb") as stream:
        child = subprocess.Popen(command, env=env, stdout=stream, stderr=stream)
        deadline = time.monotonic() + 900
        try:
            while child.poll() is None and time.monotonic() < deadline:
                now = time.monotonic()
                if now >= next_sample:
                    sample_pressure(markers)
                    next_sample = now + 3
                try:
                    models = json.loads(native.request(base, "/v1/models"))["data"]
                    break
                except OSError:
                    time.sleep(0.5)
            else:
                raise RuntimeError("Intact recovery did not start the server")
            model = "qwen3.8-flash-next:mxfp4"
            assert len(models) == 1 and models[0]["id"] == model and models[0]["context_length"] == 32768
            before = native.metrics(native.request(base, "/metrics").decode())
            response = matrix.generate(base, prompt, max_tokens=len(expected), ignore_eos=True)
            after = native.metrics(native.request(base, "/metrics").decode())
            row = matrix.slim(response, before, after)
            assert row["output_tokens"] == expected and row["status"] == "finished"
            assert row["verified_steps"] == 0 and row["route_errors"] == 0
            drained = wait_drained(base)
            assert json.loads(native.request(base, "/health"))["status"] == "ok"
            sample_pressure(markers)
        finally:
            native.stop_owned(child)
    text = scrub(log.read_text(), pack)
    log.write_text(text)
    assert text.count(LOG_READER) == 1 and INJECTED not in text
    assert 'phase="resident_tensors"' in text
    assert child.returncode == 0
    return {"reader": "AlignedBuffered", "health_after": "ok",
            "context_length": 32768, "reused_faulted_port": True,
            "drained": drained, "pressure_samples": markers, "result": row}


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--check-inputs", action="store_true")
    cli.add_argument("--pack", type=Path)
    cli.add_argument("--out", type=Path)
    args = cli.parse_args()
    build = read(ROOT / "build.json")
    exe = ROOT / "ax-engine-server"
    inventory = read(ROOT / "mxfp4-inventory.json")
    shim = ROOT / "shard_read_fault.dylib"
    assert native.sha256(exe) == build["server_sha256"] and build["codesign_verified"] is True
    assert native.sha256(ROOT / "source.patch") == build["patch_sha256"] and len(inventory["members"]) == 49
    prompt = workload()["peer-a"]["input_tokens"]
    expected = read(ROOT / "oracle.json")["first"]["peer_ids"][:128]
    assert len(prompt) == 512 and len(expected) == 128
    if args.check_inputs:
        print("Verified the candidate executable, pinned inputs and 128-token recovery oracle.")
        return
    pack = args.pack.resolve(strict=True)
    assert native.validate_inventory(pack, inventory) == MANIFEST
    assert pack.stat().st_dev == Path("/System/Volumes/Data").stat().st_dev
    args.out.mkdir(exist_ok=False)
    port = address()
    command = [*native.server_command(exe, pack, "default", port), "--total-blocks", "2048"]
    env = native.server_env({
        "AX_MLX_FLASH_NEXT_ALIGNED_BUFFERED": "1",
        "RUST_LOG": "info,ax_engine_mlx::flash_next_startup=debug",
    })
    assert "DYLD_INSERT_LIBRARIES" not in env
    bad_env = {**env, "DYLD_INSERT_LIBRARIES": str(shim),
               "AX_TEST_EARLIER_SHARD": str(pack / PRECEDING), "AX_TEST_FAILED_SHARD": str(pack / FAILED)}
    fault = observe_failure(command, pack, args.out, port, bad_env)
    print("A completed earlier shard preceded the injected failure. The HTTP port remained reusable.", flush=True)
    recovery = observe_recovery(command, pack, args.out, port, env, prompt, expected)
    assert native.validate_inventory(pack, inventory) == MANIFEST
    hardware = {"form_factor": "Mac Studio", "soc": "Apple M2 Ultra", "memory_bytes": 206158430208,
                "os": subprocess.check_output(["/usr/bin/sw_vers", "-productVersion"], text=True).strip(),
                "storage": "internal startup SSD"}
    result = {"scope": "Forced buffered-reader startup failure and restart", "qualification": False,
              "build": build, "hardware": hardware, "pack_revision": inventory["revision"],
              "shim_sha256": native.sha256(shim), "publisher_members_rechecked": 49,
              "manifest": MANIFEST, "fault": fault, "recovery": recovery}
    (args.out / "receipt.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print("Intact restart matched all 128 signed-oracle token IDs.", flush=True)


if __name__ == "__main__":
    main()
