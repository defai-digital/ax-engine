"""Run same-binary mapped and pre-read Flash Next HTTP controls on M2 Ultra."""

from argparse import ArgumentParser
import json
from pathlib import Path
import re
import subprocess
from time import monotonic

import check_flash_next_native_support as native

FLAG = "AX_MLX_FLASH_NEXT_MTP_SIDECAR_PREFETCH"
LOG = "info,ax_engine_mlx::flash_next_startup=debug"
BYTES = 5_214_301_696
ARMS = (("default", False), ("default", True), ("required", True), ("required", False))
REQUIRED_ERRORS = ("no usable drafter was activated", "MlxMtpRequiredButUnavailable")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_prefetch(log):
    return [(int(size), float(timing)) for size, timing in re.findall(
        r'Flash Next MTP sidecar prefetch completed bytes=(\d+) elapsed_ms=([\d.]+)', log)]


def startup_trace(path):
    log = path.read_text()
    require("decision=resident" in log and "Flash Next MTP sidecar prefetch failed" not in log,
            "Unexpected expert residency or a managed prefetch fallback")
    summary = {}
    for phase in ("resident_tensors", "mtp_sidecar"):
        values = re.findall(fr'phase="{phase}" elapsed_us=(\d+)', log)
        require(len(values) == 1 and int(values[0]) > 0, f"Missing {phase} phase")
        summary[phase] = int(values[0])
    return summary, read_prefetch(log)


def signature(rows):
    return [(row["name"], row["request"], row["response"]["choices"], row["activation_delta"],
             tuple(row["response"]["usage"][key] for key in ("prompt_tokens", "completion_tokens")))
            for row in rows]


def main(args):
    folder = Path(__file__).resolve().parent
    inventory_path = folder / "inventory.json"
    inventory = json.loads(inventory_path.read_text())
    build = json.loads((folder / "build.json").read_text())
    require(native.sha256(args.binary) == build["server_sha256"]
            and build["codesign_verified"] is True and build["mlx"] == build["mlx_metal"] == "0.32.4"
            and native.sha256(inventory_path) == "97b890234af731ac6e07d2ed7dbe32b4b0fcb1f0aff01addaaa340a838b28cc6",
            "Measured server, toolchain or model data changed")
    manifest = native.validate_inventory(args.pack, inventory)
    require(manifest.get("model-manifest.json") ==
            "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef",
            "Model manifest changed")
    args.out.mkdir()
    receipt = {"status": "running", "qualification": False, "hardware": "Mac Studio M2 Ultra 192 GB",
               "build": build, "manifest": manifest, "inventory_sha256": native.sha256(inventory_path),
               "pack_revision": inventory["revision"], "arms": {}}

    def save():
        path = args.out / "receipt.json"
        temp = path.with_suffix(".tmp")
        temp.write_text(json.dumps(receipt, indent=2, allow_nan=False) + "\n")
        temp.replace(path)

    def pressure():
        return subprocess.check_output(["/usr/sbin/sysctl", "-n", "kern.memorystatus_vm_pressure_level"],
                                       text=True).strip() == "1"

    make_env = native.server_env
    try:
        for policy, enabled in ARMS:
            mode = "prefetch" if enabled else "mapped"
            name = f"{policy}-{mode}"
            require(pressure(), "Non-normal pressure before the arm")
            path = args.out / name
            path.mkdir()
            env = {FLAG: "1" if enabled else "0", "RUST_LOG": LOG}
            native.server_env = lambda explicit=None: make_env(env | (explicit or {}))
            readiness = {}
            rows = native.run_mode(args.binary, args.pack, path, policy, readiness)
            phases, read = startup_trace(path / f"server-{policy}.log")
            require(read == [] if not enabled else len(read) == 1 and read[0][0] == BYTES and read[0][1] > 0,
                    "The selected pre-read path or payload extent changed")
            verified = sum(row["activation_delta"][native.VERIFIED] for row in rows)
            require(verified == (107 if policy == "required" else 0) and pressure(),
                    "Required verification or memory pressure changed")
            receipt["arms"][name] = {"prefetch": read, "phases_us": phases, "cases": rows,
                                     "ready_seconds": readiness[policy], "verified_steps": verified}
            save()
        for policy in ("default", "required"):
            arms = receipt["arms"]
            require(signature(arms[f"{policy}-mapped"]["cases"]) == signature(arms[f"{policy}-prefetch"]["cases"]),
                    f"Native output changed with the pre-read in {policy}")

        skip = args.out / "required-skip.log"
        start = monotonic()
        with skip.open("wb") as log:
            process = subprocess.Popen(native.server_command(args.binary, args.pack, "required", 0),
                                       env=make_env({FLAG: "1", "AX_MLX_SKIP_MTP_SIDECAR": "1", "RUST_LOG": LOG}),
                                       stdout=log, stderr=log, start_new_session=True)
            try:
                code = process.wait(timeout=900)
            finally:
                native.stop_owned(process)
        skip_text = skip.read_text()
        require(code != 0 and any(error in skip_text for error in REQUIRED_ERRORS)
                and not read_prefetch(skip_text), "Explicit skip allowed the sidecar to be prefetched")
        native.scrub_log(skip)
        receipt["required_skip"] = {"exit_code": code, "activation_error": True, "seconds": monotonic() - start}
        require(native.validate_inventory(args.pack, inventory) == manifest, "The publisher inputs changed")
        receipt["status"] = "complete"
        save()
    except Exception:
        receipt["status"] = "failed"
        save()
        raise


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    for field in ("binary", "pack", "out"):
        parser.add_argument(f"--{field}", required=True, type=Path)
    main(parser.parse_args())
