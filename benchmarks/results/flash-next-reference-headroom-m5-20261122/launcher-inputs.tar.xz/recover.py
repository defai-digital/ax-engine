"""Wait for headroom, then run the frozen ordinary Flash Next reference."""

from argparse import ArgumentParser
from hashlib import sha256
from importlib.metadata import version
from importlib.util import find_spec
import json
from pathlib import Path
import platform
import subprocess
import sys
from tempfile import TemporaryDirectory
from time import monotonic, sleep

from bind_after_diagnostic import diagnostic_decision, read_lines
from capacity import recovery_capacity
from probe_flash_next_reference_progress import verify_inputs
from run_load_order import fresh_clone

ROOT = Path(__file__).resolve().parent
FROZEN = ROOT / "frozen"
sys.path.insert(0, str(FROZEN / "scripts"))
import check_flash_next_native_support as native
import run_flash_next_reference as runner
import watch_flash_next_reference as watcher

MANIFEST = "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef"
SIGNED = "2eeeb8ab3b5f329726550b675ec61d57edeab6558a582582d75287983d4a19b7"
INVENTORY = FROZEN / "benchmarks/results/qualification/2026-10-04-flash-next-mxfp4-native-support/pack-inventory.json"


def read(path):
    return json.loads(path.read_bytes())


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def preflight():
    source = verify_inputs(FROZEN)
    if native.sha256(ROOT / "signed-reference.json") != SIGNED:
        raise ValueError("The signed reference anchor changed")
    signed = read(ROOT / "signed-reference.json")
    versions = {name: version(name) for name in runner.PINNED}
    module = find_spec("mlx_vlm")
    if module is None or not module.origin:
        raise ValueError("The pinned MLX-VLM package cannot be located")
    language_path = Path(module.origin).parent / "models/qwen4_exp/language.py"
    language_sha = native.sha256(language_path)
    if versions != runner.PINNED or language_sha != runner.LANGUAGE_SHA256:
        raise ValueError("The ordinary reference runtime changed")
    if subprocess.check_output(["/usr/sbin/sysctl", "-n", "hw.model", "hw.memsize"], text=True
                               ).splitlines() != ["Mac17,6", "137438953472"]:
        raise ValueError("This recovery requires the M5 Max 128 GB release host")
    contract = json.loads(subprocess.check_output(
        [sys.executable, "-B", FROZEN / "scripts/run_flash_next_reference.py", "--dry-run"]
    ))
    if (contract["phases"] != ["qa", "matrix"] or contract["lengths"] != [512, 2048, 8192]
            or contract["qa_items"] != 105 or contract["output_tokens"] != 128
            or contract["reference"] != signed["reference"]
            or any(contract[k] != signed[k] for k in
                   ("prefill_chunk", "memory_limit_bytes", "cache_limit_bytes"))):
        raise ValueError("Unexpected ordinary reference workload or settings")
    return signed, {"source_sha256": source, "signed_reference_sha256": SIGNED,
                    "versions": versions, "language_sha256": language_sha, "macos": platform.mac_ver()[0]}


def matrix_path(native_run, signed):
    comparison = read(native_run / "observed/comparison.json")
    matrix = native_run / "observed/generate-matrix/result.json"
    data = read(matrix)
    server = native_run / "ax-engine-server"
    if (comparison["observed_sha256"]["generate-matrix"] != native.sha256(matrix)
            or data["server_sha256"] != comparison["build"]["server_sha256"]
            or native.sha256(server) != data["server_sha256"]
            or data["inventory_sha256"] != signed["inventory_sha256"]
            or data["hardware"]["os"] != platform.mac_ver()[0]
            or data["repeats_per_arm"] != 2 or set(data["runs"]) != {"disabled", "default"}
            or data["runs"]["disabled"]["prompt_id_hashes"] !=
                data["runs"]["default"]["prompt_id_hashes"]):
        raise ValueError("The current native matrix does not bind the ordinary reference")
    return matrix


def host_capacity(signed):
    sample = watcher.sample_host(diagnose_host=True)
    return sample | recovery_capacity(
        signed["hardware"]["memory_bytes"], signed["peak_mlx_memory_bytes"],
        sample["pressure"], sample["largest_other_process_rss_bytes"],
    )


def wait_capacity(signed, deadline, trace):
    while True:
        sample = host_capacity(signed)
        if sample["eligible_for_attempt"]:
            idle = native.cpu_idle_percent()
            sample = host_capacity(signed) | {"cpu_idle_percent": idle}
            if idle < 90:
                sample.update(eligible_for_attempt=False, reason="host-cpu-busy")
        print(json.dumps(sample), file=trace, flush=True)
        if sample["eligible_for_attempt"]:
            return True
        if monotonic() >= deadline:
            return False
        sleep(watcher.POLL_SECONDS)


def clone_pack(cache, pack):
    index = read(INVENTORY)
    source = cache / ("models--" + index["repo_id"].replace("/", "--")) / "snapshots" / index["revision"]
    manifest = source / "model-manifest.json"
    if native.sha256(manifest) != MANIFEST or len(index["members"]) != 49:
        raise ValueError("The existing snapshot has a different admission manifest")
    for item in index["members"]:
        name = item["name"]
        member = (source / name).resolve(strict=True)
        if not member.is_relative_to(cache.resolve()) or member.stat().st_size != item["size"]:
            raise ValueError("A snapshot member escaped its cache or changed in size")
        destination = pack / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        fresh_clone(member, destination)
    (pack / "model-manifest.json").write_bytes(manifest.read_bytes())


def real_run(args, signed):
    matrix = matrix_path(args.native_run, signed)
    save("native-matrix.json", {"sha256": native.sha256(matrix),
                                "source_commit": read(args.native_run / "build.json")["commit"]})
    deadline = monotonic() + 30 * 60
    with (ROOT / "headroom.jsonl").open("x") as samples:
        if not wait_capacity(signed, deadline, samples):
            save("outcome.json", {"phase": "capacity-wait-expired", "launched": False})
            return 2
        with TemporaryDirectory(prefix="ordinary-view-", dir=ROOT) as directory:
            pack = Path(directory)
            clone_pack(args.cache, pack)
            if not wait_capacity(signed, deadline, samples):
                save("outcome.json", {"phase": "capacity-changed-after-clone", "launched": False})
                return 2
            probe = ROOT / "heartbeat"
            child = subprocess.run([sys.executable, "-B", "-u", ROOT / "probe_flash_next_reference_progress.py",
                                    "--frozen", FROZEN, "--model-dir", pack, "--out", probe], check=False)
            if child.returncode != 0:
                save("outcome.json", {"phase": "heartbeat-stopped", "exit_code": child.returncode})
                return 1
            reason = diagnostic_decision(read(probe / "status.json"), read(probe / "reference/result.json"),
                                         signed, read_lines(probe / "token-progress.jsonl"),
                                         read_lines(probe / "samples.jsonl"))
            save("heartbeat-admission.json", {"proceed": reason is None, "reason": reason})
            if reason is not None:
                return 1
            if not wait_capacity(signed, deadline, samples):
                save("outcome.json", {"phase": "capacity-changed-after-heartbeat", "launched": False})
                return 2
            reference = ROOT / "reference"
            result = subprocess.run([
                sys.executable, "-B", "-u", FROZEN / "scripts/watch_flash_next_reference.py",
                "--diagnose-host", "--python", sys.executable,
                "--runner", FROZEN / "scripts/run_flash_next_reference.py", "--model-dir", pack,
                "--inventory", INVENTORY, "--ax-matrix", matrix, "--out", reference,
                "--monitor", ROOT / "monitor",
            ], check=False)
            save("outcome.json", {"phase": "ordinary-reference", "exit_code": result.returncode,
                                  "complete": result.returncode == 0})
            return result.returncode


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--preflight", action="store_true")
    parser.add_argument("--cache", type=Path)
    parser.add_argument("--native-run", type=Path)
    args = parser.parse_args()
    signed, note = preflight()
    if args.preflight:
        print(json.dumps(note | {"capacity": host_capacity(signed)}, indent=2, allow_nan=False))
        return 0
    if args.cache is None or args.native_run is None:
        parser.error("live recovery needs the source cache and native-run directory")
    save("reference-preflight.json", note)
    return real_run(args, signed)


if __name__ == "__main__":
    sys.exit(main())
