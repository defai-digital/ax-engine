"""Rerun the frozen ordinary reference only after the bounded monitor is clear."""

import argparse
from hashlib import sha256
import json
from pathlib import Path

LIMIT = 4
MAX_LAG_SECONDS = 600


def read(path):
    return json.loads(path.read_bytes())


def read_lines(path):
    return [json.loads(line) for line in path.read_bytes().splitlines()]


def digest(data):
    return sha256(data).hexdigest()


def diagnostic_decision(status, measured, signed, heartbeats, samples):
    if (status.get("complete") is not True or status.get("exit_code") != 0
            or status.get("completed_cases") != LIMIT or measured.get("completed") is not True):
        return "four-case diagnostic did not complete"
    for name in ("revision", "reference", "language_sha256", "versions", "inventory_sha256",
                 "prefill_chunk", "memory_limit_bytes", "cache_limit_bytes"):
        if measured[name] != signed[name]:
            return f"frozen profile mismatch at {name}"
    expected = signed["qa"]["rows"][:LIMIT]
    observed = measured["qa"]["rows"]
    if len(observed) != LIMIT:
        return "wrong number of observed QA rows"
    for row, baseline in zip(observed, expected, strict=True):
        if any(row[key] != baseline[key] for key in (
            "id", "prompt_tokens", "generated_ids", "text", "normal_stop", "terminal_eos_id"
        )):
            return f"reference token or stop mismatch for {baseline['id']}"
    sequence = [(e["case"], e["tokens"]) for e in heartbeats]
    wanted = {case: len(row["generated_ids"]) for case, row in enumerate(observed, start=1)}
    if any(a >= b for a, b in zip(sequence, sequence[1:])) or {a for a, _ in sequence} != wanted.keys():
        return "diagnostic heartbeat is incomplete or out of order"
    if any(max(count for ordinal, count in sequence if ordinal == case) < minimum
           for case, minimum in wanted.items()):
        return "diagnostic did not account for all emitted token positions"
    delays = [s["seconds_since_progress"] for s in samples if "seconds_since_progress" in s]
    if not delays or max(delays) >= MAX_LAG_SECONDS:
        return "diagnostic showed an extended token-progress gap"
    if any(s["pressure"] != 1 for s in samples):
        return "diagnostic showed elevated memory pressure"
    return None


def bind(root, native):
    diagnostic = native / "reference-diagnostic"
    status_path = diagnostic / "status.json"
    receipt_path = diagnostic / "reference/result.json"
    signed = read(root / "signed-reference.json")
    try:
        reason = diagnostic_decision(read(status_path), read(receipt_path), signed,
                                     read_lines(diagnostic / "token-progress.jsonl"),
                                     read_lines(diagnostic / "samples.jsonl"))
    except (FileNotFoundError, ValueError, KeyError) as error:
        reason = f"missing or invalid diagnostic evidence ({type(error).__name__})"
    if reason:
        record = {"proceed": False, "reason": reason}
    else:
        matrix = (native / "evidence/generate-matrix/result.json").read_bytes()
        result = json.loads(matrix)
        build = read(native / "build.json")
        binary = "ax-engine-server-release-refresh"
        expected_sha = build["binaries_sha256"][binary]
        if (result["server_sha256"] != expected_sha
                or digest((native / binary).read_bytes()) != expected_sha
                or result["repeats_per_arm"] != 2
                or result["hardware"]["os"] != read(receipt_path)["hardware"]["os"]
                or set(result["runs"]) != {"disabled", "default"}):
            raise ValueError("Native matrix identity is incompatible with the ordinary repeat")
        sources = read(root / "source.json")
        for name, fingerprint in sources.items():
            if digest((root / name).read_bytes()) != fingerprint:
                raise ValueError(f"Original source changed: {name}")
        sources["ax-matrix.json"] = digest(matrix)
        (root / "ax-matrix.json").write_bytes(matrix)
        (root / "source.json").write_text(json.dumps(sources, indent=2, sort_keys=True) + "\n")
        record = {"proceed": True, "matrix_sha256": digest(matrix), "native_server_sha256": expected_sha,
                  "diagnostic_status_sha256": digest(status_path.read_bytes()),
                  "diagnostic_result_sha256": digest(receipt_path.read_bytes())}
    (root / "admission.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record), flush=True)
    return 0 if record["proceed"] else 2


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("native", type=Path)
    args = parser.parse_args()
    raise SystemExit(bind(args.root, args.native))
