"""Classify a host sample before retrying the ordinary Flash Next reference."""

def recovery_capacity(physical_bytes, signed_peak_bytes, pressure, largest_other_rss_bytes):
    if (type(physical_bytes) is not int or type(signed_peak_bytes) is not int
            or not 0 < signed_peak_bytes < physical_bytes):
        raise ValueError("Signed allocator peak must fit inside the physical memory of the target")
    margin = physical_bytes - signed_peak_bytes
    if type(pressure) is not int or pressure != 1:
        reason = "host-pressure"
    elif type(largest_other_rss_bytes) is not int or largest_other_rss_bytes < 0:
        reason = "background-rss-unavailable"
    elif largest_other_rss_bytes >= margin:
        reason = "background-rss-exceeds-signed-margin"
    else:
        reason = "can-attempt"
    return {"reason": reason, "eligible_for_attempt": reason == "can-attempt",
            "physical_bytes": physical_bytes, "signed_peak_mlx_bytes": signed_peak_bytes,
            "observed_signed_margin_bytes": margin, "pressure": pressure,
            "largest_background_rss_bytes": largest_other_rss_bytes}
