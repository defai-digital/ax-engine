#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
previous="$1"
native_run="$2"
cache="$3"
deadline=$((SECONDS + 32400))
echo waiting-for-owned-resident-reader-holdout
until test -s "$previous/status.txt"; do
    kill -0 "$(cat "$previous/owner.pid")" 2>/dev/null && (( SECONDS < deadline )) || exit 2
    sleep 15
done
[[ -s "$native_run/status.txt" && $(cat "$native_run/status.txt") = 0 ]]
if /bin/ps -axo comm= | /usr/bin/grep -E '/(ax-engine-server[^/]*|direct_weights|ax-flash-shared-load-test)$'; then exit 1; fi
/usr/bin/shasum -a 256 -c inputs.sha256
[[ $(stat -f %d "$cache") = "$(stat -f %d .)" ]]
ref_python="$HOME/build/flash-next-official-20260923/launch-reference-env/bin/python"
export PATH="/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export PYTHONDONTWRITEBYTECODE=1
exec /usr/bin/caffeinate -dimsu "$ref_python" -B -u recover.py --cache "$cache" --native-run "$native_run"
