"""Check Flash Next early arrivals and held cancellation on the primary tier."""

from argparse import ArgumentParser
import json
from pathlib import Path
from unittest.mock import patch

import run_early as early
import run_held_cancel as cancel
from run_server_tail import ROOT, client, layer, mixed, require

SERVER = "primary-tail-holdout"


def emit(path, value):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def read_inputs():
    _, cases, expected = layer.files()["ending-decoder"]
    archived = json.loads((ROOT / "solo-reference.json").read_bytes())["observations"]
    by_id = {row["prompt_id"]: row for row in archived if row["phase"] == "measured"}
    oracle = [by_id[case.id] for case in cases]
    require(all(row["ok"] and row["output_token_ids"] == expected[case.id] and len(expected[case.id]) == 96
                for case, row in zip(cases, oracle, strict=True)), "The archived oracle changed")
    build = json.loads((ROOT / "build.json").read_bytes())
    inventory = json.loads((ROOT / "mxfp4-inventory.json").read_bytes())
    require(build["runtime_commit"] == "14235e84b01456cfcb40ba6fcb717ae4798fa8f7"
            and build["codesign_verified"] is True
            and inventory["revision"] == "ff2a28485eb89bb60e8fe35dd6c65c51e63ee7b3",
            "The tested runtime or pack pin changed")
    return cases, expected, oracle, build, inventory


def main():
    parser = ArgumentParser(description=__doc__)
    for name in ("binary", "pack", "link-root", "out"):
        parser.add_argument(f"--{name}", type=Path)
    parser.add_argument("--check-inputs", action="store_true")
    args = parser.parse_args()
    cases, expected, oracle, build, inventory = read_inputs()
    if args.check_inputs:
        print("Verified the archived M5 solo outputs for both frozen prompts.", flush=True)
        return
    require(mixed.digest(args.binary) == build["server_sha256"], "The active executable changed")
    manifest = mixed.native.validate_inventory(args.pack, inventory, args.link_root)
    require(manifest.get("model-manifest.json") ==
            "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef",
            "The delivered manifest changed")
    args.out.mkdir()
    receipt = {
        "scope": "M5 early-arrival and cancellation holdouts", "qualification": False,
        "build": build, "pack_revision": inventory["revision"], "manifest": manifest,
        "inventory_sha256": mixed.digest(ROOT / "mxfp4-inventory.json"), "runs": {},
    }
    dest = args.out / "receipt.json"
    options = ("--disable-ngram-acceleration", "--total-blocks", "2048", "--max-batch-tokens", "2049",
               *mixed.RESERVE_OPTIONS)
    env = {"AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0", "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": "1",
           "AX_MLX_FLASH_NEXT_PREFILL_TAIL_DEFERRAL": "1", "RUST_LOG": "info,ax_engine_core::engine=trace"}
    emit(dest, receipt | {"status": "starting"})
    receipt["cpu_idle_before_percent"] = mixed.native.wait_for_quiet()["cpu_idle_percent"]

    def record(name, raw, checked):
        path = args.out / f"{name}.json"
        emit(path, raw)
        receipt["runs"][name] = {"sha256": mixed.digest(path), "checks": checked}
        emit(dest, receipt | {"status": f"{name}-complete"})
        print(f"{name} complete.", flush=True)

    try:
        with mixed.server(args, SERVER, mixed.MODEL, args.pack, 2, env=env, options=options,
                          stream_experts="auto", guard=True) as (base, _):
            require("decision=resident" in (args.out / f"{SERVER}.log").read_text(), "Resident experts required")
            for at in early.EARLY_TRIGGERS:
                label = f"trigger-{at}"
                print(f"Starting {label}.", flush=True)
                with (patch.object(client, "TRIGGER_TOKEN", at),
                      patch.object(client.capture, "trace_stream", early.capture_tail),
                      patch.object(client, "verify_deferral", lambda raw, _: early.verify(raw, at, cases, oracle))):
                    data = client.burst(base, cases, expected, False, args.out / f"{label}.partial.json")
                require(data["drained"] == dict.fromkeys(mixed.COUNTERS, 0), "Requests did not drain")
                record(label, data, early.verify(data, at, cases, oracle))
            raw = cancel.run_control(base, *cases, args.out / "pre-cancel-trace.json")
            record("held-cancel", raw, cancel.verify(raw, cases, oracle))
            require(json.loads(mixed.native.request(base, "/health"))["status"] == "ok", "Health declined")
        receipt["cpu_idle_after_percent"] = mixed.native.cpu_idle_percent()
        pressure = args.out / f"{SERVER}-samples.jsonl"
        samples = [json.loads(line) for line in pressure.read_text().splitlines()]
        require(samples and all(row["pressure"] == 1 for row in samples), "Non-normal memory pressure")
        receipt.update(pressure_samples=len(samples), pressure_sha256=mixed.digest(pressure))
        require(mixed.native.validate_inventory(args.pack, inventory, args.link_root) == manifest, "Pack changed")
        emit(dest, receipt | {"status": "complete"})
    except Exception:
        emit(dest, receipt | {"status": "failed"})
        raise


if __name__ == "__main__":
    main()
