"""Compare resident and bounded PLE storage using the same M2 reference runtime."""

import argparse
from hashlib import sha256
import json
from pathlib import Path


QA_FIELDS = ("id", "prompt_tokens", "generated_ids", "text", "normal_stop",
             "terminal_eos_id", "generated_tokens")
MATRIX_FIELDS = ("length", "run", "warmup", "generated_ids", "normal_stop",
                 "terminal_eos_id", "generated_tokens")


def read(path):
    return json.loads(path.read_bytes())


def replay(root):
    source = read(root/"source.json")
    resident = read(root/"resident/result.json")
    bounded = read(root/"bounded/result.json")
    for key in ("schema", "reference", "pack_revision", "inventory_sha256", "versions",
                "language_sha256", "backend", "hardware", "prefill_chunk", "output_tokens",
                "workload", "workload_hashes", "runtime_files_bound"):
        assert resident[key] == bounded[key], key
    assert resident["versions"] == {"mlx":"0.32.2","mlx-metal":"0.32.2","mlx-vlm":"0.7.0rc0",
                                    "transformers":"5.18.0.dev0","tokenizers":"0.23.2"}
    assert resident["reference"]["commit"] == "6102cb4ad1a5b3cc38d8dc7e6cbe2aca395596cb"
    assert resident["hardware"] == {"soc":"Apple M2 Ultra","memory_bytes":192 << 30,"os":"27.2.1"}
    assert resident["workload_hashes"]["ax_matrix_sha256"] == source["matrix_sha256"]
    assert resident["pack_revision"] == "ff2a28485eb89bb60e8fe35dd6c65c51e63ee7b3"
    report={}
    for mode,result in (("resident",resident),("bounded",bounded)):
        status=read(root/f"{mode}-status.json")
        assert status=={"completed":True,"exit_code":0,"matrix_rows":15,"phase":"complete",
                        "qa_rows":105,"stop_reason":None}
        assert result["mode"] == mode and result["completed"] is True
        assert result["phase"]=="complete" and result["qualification"] is result["release_ready"] is False
        samples=[json.loads(line) for line in (root/f"{mode}-samples.jsonl").read_bytes().splitlines()]
        assert samples and all(row["pressure"]==1 for row in samples)
        report[mode]={"receipt_sha256":sha256((root/mode/"result.json").read_bytes()).hexdigest(),
                      "peak_mlx_memory_bytes":result["peak_mlx_memory_bytes"],
                      "peak_process_rss_bytes":result["peak_process_rss_bytes"],
                      "weights_materialized":result["weights_materialized"],
                      "normal_pressure_samples":len(samples),
                      "cpu_idle_percent":[result["host_quiet"]["cpu_idle_percent"],result["host_idle_after"]]}
    assert bounded["row_reads"] > 0
    assert resident["weights_materialized"] > bounded["weights_materialized"]
    assert resident["matrix"]["prompt_id_hashes"] == bounded["matrix"]["prompt_id_hashes"]
    qa_a,qa_b = (model["qa"] for model in (resident,bounded))
    ma_a,ma_b = (model["matrix"] for model in (resident,bounded))
    assert len(qa_a["rows"])==len(qa_b["rows"])==105
    assert len(ma_a["cells"])==len(ma_b["cells"])==15
    assert all(len(row["generated_ids"])==128 for model in (ma_a,ma_b) for row in model["cells"])
    qa_diffs = [a["id"] for a,b in zip(qa_a["rows"],qa_b["rows"],strict=True)
                if any(a[key] != b[key] for key in QA_FIELDS)]
    matrix_diffs = [[a["length"],a["run"]] for a,b in zip(ma_a["cells"],ma_b["cells"],strict=True)
                    if any(a[key] != b[key] for key in MATRIX_FIELDS)]
    grades_equal = qa_a["grades"]==qa_b["grades"] and qa_a["failures"]==qa_b["failures"]
    return {"scope":"Same-host reference PLE storage-only diagnostic","qualification":False,
            "source":source,"arms":report,"qa_rows_exact":105-len(qa_diffs),
            "matrix_rows_exact":15-len(matrix_diffs),"matching_qa_grades":grades_equal,
            "resident_only_qa_failures":sorted(set(qa_a["failures"])-set(qa_b["failures"])),
            "bounded_only_qa_failures":sorted(set(qa_b["failures"])-set(qa_a["failures"])),
            "qa_differences":qa_diffs,"matrix_differences":matrix_diffs}


if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("root", type=Path, nargs="?", default=Path(__file__).resolve().parent)
    ns=cli.parse_args()
    print(json.dumps(replay(ns.root),indent=2,sort_keys=True,allow_nan=False))
