"""Supervise same-environment resident and bounded storage diagnostics on M2."""
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys

import watch

python, runner, pack, matrix, work = map(Path, sys.argv[1:])
env = {key: value for key,value in os.environ.items()
       if not key.startswith(("AX_", "MLX_", "DYLD_")) and key != "PYTHONPATH"}
env.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
           HF_HUB_DISABLE_TELEMETRY="1", PYTHONDONTWRITEBYTECODE="1")
assert watch.sample_host()["pressure"] == 1
assert int(subprocess.check_output(["/usr/sbin/sysctl", "-n", "hw.memsize"])) == 192 << 30
assert "M2 Ultra" in subprocess.check_output(["/usr/sbin/sysctl", "-n", "machdep.cpu.brand_string"], text=True)
assert not any(Path(row.strip()).name == "ax-engine-server" for row in
               subprocess.check_output(["/bin/ps","-axo","comm="],text=True).splitlines())
watch.CRITICAL_PRESSURE = (2, 4, 8)
watch.POLL_SECONDS = 10

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

source = {"runner_sha256": digest(runner), "matrix_sha256": digest(matrix),
          "watch_sha256": digest(Path(watch.__file__))}
(work/"source.json").write_text(json.dumps(source, indent=2, sort_keys=True)+"\n")
for mode in ("resident", "bounded"):
    output = work/mode
    receipt = output/"result.json"
    command = [str(python), "-B", "-u", str(runner), "--mode", mode, "--model-dir", str(pack),
               "--ax-matrix", str(matrix), "--output", str(output)]
    with (work/f"{mode}.log").open("x") as log, (work/f"{mode}-samples.jsonl").open("x") as samples:
        print(f"{mode} started", flush=True)
        process = subprocess.Popen(command, env=env, stdout=log, stderr=log)
        (work/f"{mode}-child.pid").write_text(str(process.pid)+"\n")
        try:
            stop = watch.wait_for_reference(process, receipt, samples, stop_after=1200)
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=15)
        print(json.dumps(watch.sample_host()), file=samples, flush=True)
    result = json.loads(receipt.read_bytes()) if receipt.exists() else {}
    status = {"completed": result.get("completed") is True and process.returncode == 0,
              "phase": result.get("phase"), "qa_rows": len(result.get("qa", {}).get("rows", [])),
              "matrix_rows": len(result.get("matrix", {}).get("cells", [])),
              "exit_code": process.returncode, "stop_reason": stop}
    (work/f"{mode}-status.json").write_text(json.dumps(status, indent=2, sort_keys=True)+"\n")
    print(mode, json.dumps(status), flush=True)
    if not status["completed"]:
        raise SystemExit(1)
