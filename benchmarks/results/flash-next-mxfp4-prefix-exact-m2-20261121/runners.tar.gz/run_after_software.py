"""Run the real-pack warm prefix diagnostic after local verification releases the device."""

import importlib.metadata as modules
import os
from pathlib import Path
import subprocess
import sys
import time

stage, repo = map(Path, sys.argv[1:3])
gate_pid = int(sys.argv[3])

def identity(pid):
    result = subprocess.run(["/bin/ps", "-p", str(pid), "-o", "lstart="],
                            text=True, capture_output=True, check=False)
    return result.stdout.strip()

start = identity(gate_pid)
deadline = time.monotonic() + 4 * 3600
if start:
    print("Waiting for the local software gate before taking the test device.", flush=True)
    while identity(gate_pid) == start:
        if time.monotonic() >= deadline:
            raise TimeoutError("The software gate still owns the test device")
        time.sleep(20)

devices = subprocess.check_output(["/usr/sbin/sysctl", "-n", "machdep.cpu.brand_string",
                                   "hw.memsize"], text=True).splitlines()
assert devices == ["Apple M2 Ultra", "206158430208"]
assert modules.version("mlx") == modules.version("mlx-metal") == "0.32.4"
commands = subprocess.check_output(["/bin/ps", "-axo", "comm="], text=True).splitlines()
if any(Path(line.strip()).name.startswith("ax-engine-server") for line in commands):
    raise RuntimeError("An existing native model process owns the test device")
subprocess.run(["/usr/bin/shasum", "-a", "256", "-c", "inputs.sha256"], check=True, cwd=stage)
pack = Path((stage / "pack-path.txt").read_text().strip())
environment = {key: value for key, value in os.environ.items() if not key.startswith(("AX_", "MLX_"))}
environment.update(
    DYLD_LIBRARY_PATH=str(modules.distribution("mlx").locate_file("mlx/lib")),
    PYTHONPATH=f"{stage}:{repo / 'scripts'}",
)
subprocess.run(
    ["/usr/bin/caffeinate", "-dimsu", sys.executable, "-B", "-u",
     str(stage / "run_warm_prefix.py"), "--binary", str(stage / "ax-engine-server-prefill-split-admission"),
     "--pack", str(pack), "--inventory", str(stage / "mxfp4-inventory.json"),
     "--build-receipt", str(stage / "build.json"), "--corpus", str(stage / "mixed-corpus.jsonl"),
     "--corpus-sha256", "2c0c205d803207df6316dbd0076eef97451a55c80c0413fdc6b3bee5ffef7e9a",
     "--out", str(stage / "result")],
    env=environment, cwd=stage, check=True,
)
print("Completed the real-pack functional warm-route diagnostic.", flush=True)
