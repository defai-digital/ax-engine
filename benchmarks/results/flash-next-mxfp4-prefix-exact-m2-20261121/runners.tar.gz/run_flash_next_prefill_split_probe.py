"""Replay the archived Flash Next pair with controlled prefill partitions."""

import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import subprocess
from threading import Barrier, Event
import time
from urllib.request import Request, urlopen

from run_qwen38_reference_serving import server, write_json, write_jsonl


MODEL = "qwen3.8-flash-next:axq"
PROMPT_IDS = ("prompt-0-2048", "prompt-1-2048")
PROMPT_SHA256 = "849f8af3077f89be0a49d9b86bd1032eed1513e54a53bac242285cd0d2076032"
REQUEST_DEADLINE_SECONDS = 90
ARMS = (
    ("solo-default", 1, 2048, 1024, ("serial",)),
    ("solo-split", 1, 2047, 1024, ("serial",)),
    ("pair-default", 2, 2048, 1024, ("serial", "simultaneous", "decode-arrival")),
    ("pair-wide", 2, 4096, 1024, ("serial", "simultaneous", "decode-arrival")),
)
ALIGNMENT_ARMS = (
    ARMS[0],
    ("solo-split-2047-chunk512", 1, 2047, 512, ("serial",)),
    ("solo-aligned-1536-chunk512", 1, 1536, 512, ("serial",)),
    ("solo-aligned-1536-chunk1024", 1, 1536, 1024, ("serial",)),
)
RESERVE_ARMS = (
    ARMS[0],
    ("pair-reserve-decode", 2, 2049, 1024, ("serial", "simultaneous", "decode-arrival")),
)
COALESCING_ARMS = (ARMS[0],) + tuple(
    (f"pair-coalescing-{mode}-{repeat}", *RESERVE_ARMS[1][1:])
    for mode, repeat in (("off", 1), ("on", 1), ("on", 2), ("off", 2))
)
PREFILL_SPLIT_ARMS = (ARMS[0],) + tuple(
    (f"pair-prefill-split-{mode}", *RESERVE_ARMS[1][1:]) for mode in ("off", "on")
)
RESERVE_OPTIONS = (
    "--multi-prefill-fair",
    "--max-prefill-tokens-per-request-per-step", "2048",
    "--max-inflight-prefill-requests", "1",
)
HOLDOUT_LENGTHS = (2049, 2050, 8192)


def extend_prompts(rows, length):
    extended = []
    for row in rows:
        tokens = row["input_tokens"]
        extra = length - len(tokens)
        body = tokens[128:512]
        repeats = (extra + len(body) - 1) // len(body)
        extended.append({
            **row,
            "id": f'{row["id"]}-holdout-{length}',
            "input_tokens": tokens[:-64] + (body * repeats)[:extra] + tokens[-64:],
        })
    return extended


def read_stream(lines, row, started, on_first_output, disconnect_at=None):
    event_name = None
    request_id = None
    terminal = None
    cursor = 0
    ttft = None
    progress = []
    scheduled_work = []
    streamed_tokens = []
    prompt_len = len(row["input_tokens"])
    for line in lines:
        received_seconds = time.monotonic() - started
        if received_seconds >= REQUEST_DEADLINE_SECONDS:
            raise TimeoutError("the partition probe exceeded its request deadline")
        if not line.strip():
            event_name = None
        elif line.startswith(b"event:"):
            event_name = line.partition(b":")[2].strip().decode()
        elif line.startswith(b"data:"):
            data = line.partition(b":")[2].strip()
            if terminal is not None:
                if data == b"[DONE]":
                    continue
                raise RuntimeError("native stream sent data after its terminal response")
            payload = json.loads(data)
            if event_name == "request":
                if request_id is not None:
                    raise RuntimeError("native stream sent more than one opening event")
                request_id = payload["request"]["request_id"]
                if payload["request"]["prompt_tokens"] != row["input_tokens"]:
                    raise RuntimeError("request event changed the input tokens")
            elif event_name == "step":
                request = payload["request"]
                current = request["processed_prompt_tokens"]
                if request_id is None or request["request_id"] != request_id or not cursor <= current <= prompt_len:
                    raise RuntimeError("invalid per-request prompt progress")
                delta = payload.get("delta_tokens", [])
                step = payload["step"]
                observation = {
                    "cursor": current,
                    "step_id": step["step_id"],
                    "scheduled_requests": step["scheduled_requests"],
                    "scheduled_tokens": step["scheduled_tokens"],
                    "delta_token_count": len(delta),
                    "received_seconds": received_seconds,
                }
                scheduled_work.append(observation)
                advanced_prompt = current > cursor
                if advanced_prompt:
                    decisions = request.get("route", {}).get("crossover_decisions", {})
                    progress.append({
                        **observation,
                        "advanced_prompt_tokens": current - cursor,
                        "prefill_route": {key: value for key, value in decisions.items()
                                          if "prefill" in key},
                    })
                    cursor = current
                if delta and ttft is None:
                    ttft = received_seconds
                    on_first_output()
                if ((disconnect_at == "output" and delta)
                        or (disconnect_at == "prefill" and advanced_prompt and current < prompt_len and not delta)):
                    return {"prompt_id": row["id"], "request_id": request_id,
                            "disconnect_at": disconnect_at, "first_output_tokens": delta,
                            "prefill_progress": progress, "scheduled_work": scheduled_work}
                streamed_tokens.extend(delta)
            elif event_name == "response":
                terminal = payload["response"]
            else:
                raise RuntimeError(f"unexpected generate event {event_name!r}: {payload}")

    if disconnect_at is not None:
        raise RuntimeError(f"stream did not reach the {disconnect_at} disconnect point")
    if not (ttft is not None and cursor == prompt_len and terminal):
        raise RuntimeError("stream ended without a token, complete prefill or terminal response")
    if (terminal["request_id"] != request_id or terminal["model_id"] != MODEL
            or terminal["status"] != "finished"
            or terminal["finish_reason"] != "max_output_tokens"
            or terminal["prompt_tokens"] != row["input_tokens"]
            or terminal["output_tokens"] != streamed_tokens
            or len(streamed_tokens) != row["max_output_tokens"]):
        raise RuntimeError("terminal response disagrees with the frozen stream contract")
    decisions = terminal["route"].get("crossover_decisions", {})
    return {
        "prompt_id": row["id"], "output_tokens": streamed_tokens, "prefill_progress": progress,
        "scheduled_work": scheduled_work,
        "ttft_seconds": ttft, "elapsed_seconds": time.monotonic() - started,
        "prefill_route": {key: value for key, value in decisions.items() if "prefill" in key},
        "coalescing_route": {key: value for key, value in decisions.items()
                             if "row_exact_coalesced_decode" in key},
    }


def generate(url, row, *, on_first_output=lambda: None, disconnect_at=None):
    request = Request(
        url + "/v1/generate/stream",
        data=json.dumps({
            "model": MODEL, "input_tokens": row["input_tokens"],
            "max_output_tokens": row["max_output_tokens"],
            "sampling": {"temperature": 0, "ignore_eos": True},
        }).encode(),
        headers={"Content-Type": "application/json"},
    )
    started = time.monotonic()
    with urlopen(request, timeout=20) as response:
        return read_stream(response, row, started, on_first_output, disconnect_at)


def replay(url, rows, arrival, leader, disconnect_index=None, disconnect_at="output"):
    if arrival == "serial":
        return [generate(url, row) for row in rows]
    simultaneous = Barrier(2)
    decoding = Event()

    def client(index):
        if arrival == "simultaneous":
            simultaneous.wait(timeout=10)
        elif index != leader and not decoding.wait(timeout=30):
            raise RuntimeError("the first client did not reach decode")
        return generate(url, rows[index], on_first_output=decoding.set if index == leader else lambda: None,
                        disconnect_at=disconnect_at if index == disconnect_index else None)

    with ThreadPoolExecutor(max_workers=2) as workers:
        return list(workers.map(client, range(2)))


def compare_observations(results):
    baseline = {observation["repeat"]: {
        row["prompt_id"]: row["output_tokens"] for row in observation["requests"]
    } for observation in results["arms"][0]["observations"]}
    for arm in results["arms"]:
        for observation in arm["observations"]:
            for row in observation["requests"]:
                expected = baseline[observation["repeat"]][row["prompt_id"]]
                row["first_difference_vs_solo"] = next(
                    (index for index, (left, right) in enumerate(zip(expected, row["output_tokens"], strict=True))
                     if left != right), None)
        for trial in arm.get("disconnect_trials", []):
            expected = baseline[trial["survivor_index"]]
            survivor, replacement = trial["survivor"], trial["replacement"]
            disconnected = trial["disconnected"]
            trial["survivor_matches"] = survivor["output_tokens"] == expected[survivor["prompt_id"]]
            trial["replacement_matches"] = replacement["output_tokens"] == expected[replacement["prompt_id"]]
            partial = disconnected["first_output_tokens"]
            trial["disconnected_prefix_matches"] = partial == expected[disconnected["prompt_id"]][:len(partial)]


def disconnect_and_reuse(url, rows, survivor_index, disconnect_at="output"):
    from run_flash_next_lifecycle import wait_drained

    disconnected_index = 1 - survivor_index
    replies = replay(url, rows, "decode-arrival", survivor_index, disconnected_index, disconnect_at)
    survivor = replies[survivor_index]
    disconnected = replies[disconnected_index]
    survivor_steps = {step["step_id"] for step in survivor["scheduled_work"]
                      if step["scheduled_requests"] == 2 and step["delta_token_count"] > 0}
    shared_steps = [step["step_id"] for step in disconnected["scheduled_work"]
                    if step["step_id"] in survivor_steps and step["scheduled_requests"] == 2]
    drained_after_disconnect = wait_drained(url)
    replacement = generate(url, rows[disconnected_index])
    return {"survivor_index": survivor_index, "survivor": survivor, "disconnected": disconnected,
            "replacement": replacement, "shared_steps": shared_steps,
            "drained_after_disconnect": drained_after_disconnect,
            "drained_after_replacement": wait_drained(url)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for option in ("binary", "flash", "prompts", "inventory", "out"):
        parser.add_argument(f"--{option}", type=Path, required=True)
    experiment = parser.add_mutually_exclusive_group()
    experiment.add_argument("--alignment-probe", action="store_true",
                            help="vary an aligned scheduler cut and the inner prefill chunk separately")
    experiment.add_argument("--reserve-decode-probe", action="store_true",
                            help="reserve one decode token and limit each step to one 2048-token prefill")
    experiment.add_argument("--coalescing-probe", action="store_true",
                            help="compare row-exact decode coalescing on the decode-reservation schedule")
    experiment.add_argument("--prefill-split-probe", action="store_true",
                            help="compare physical prefill turns on the decode-reservation schedule")
    parser.add_argument("--holdout-length", type=int, choices=HOLDOUT_LENGTHS,
                        help="extend both token arrays in the decode-reservation experiment")
    args = parser.parse_args()
    reservation = args.reserve_decode_probe or args.coalescing_probe or args.prefill_split_probe
    if args.holdout_length is not None and not reservation:
        parser.error("--holdout-length requires a decode-reservation experiment")
    import check_flash_next_native_support as native

    commands = subprocess.check_output(["ps", "-axo", "comm="], text=True)
    if any(Path(command.strip()).name.startswith("ax-engine-server")
           for command in commands.splitlines()):
        raise RuntimeError("another AX server is still using the inference device")
    rows = [json.loads(line) for line in args.prompts.read_text().splitlines()]
    if ([row["id"] for row in rows] != list(PROMPT_IDS)
            or any(len(row["input_tokens"]) != 2048 or row["max_output_tokens"] != 96 for row in rows)):
        raise ValueError("expected the archived two 2048-token prompts with 96 output tokens each")
    if native.sha256(args.prompts) != PROMPT_SHA256:
        raise ValueError("archived prompt SHA-256 does not match")
    clean = native.server_env()
    os.environ.clear()
    os.environ.update(clean)
    args.out.mkdir(parents=True, exist_ok=False)
    results = {"pack_revision": native.PACK_REVISION,
               "binary_sha256": native.sha256(args.binary),
               "prompts_sha256": native.sha256(args.prompts), "arms": []}
    if args.holdout_length is not None:
        rows = extend_prompts(rows, args.holdout_length)
        holdout = write_jsonl(args.out / "holdout-prompts.jsonl", rows)
        results["holdout_prompts_sha256"] = native.sha256(holdout)
        results["holdout_prompt_tokens"] = args.holdout_length
    inventory = json.loads(args.inventory.read_text())
    results["inventory_sha256"] = native.sha256(args.inventory)
    manifest_before = native.validate_inventory(args.flash, inventory)

    arms = ARMS
    if args.alignment_probe:
        arms = ALIGNMENT_ARMS
    elif args.reserve_decode_probe:
        arms = RESERVE_ARMS
    elif args.coalescing_probe:
        arms = COALESCING_ARMS
    elif args.prefill_split_probe:
        arms = PREFILL_SPLIT_ARMS
    for arm, concurrency, budget, prefill_chunk, arrivals in arms:
        reserved = concurrency == 2 and reservation
        reservation_options = RESERVE_OPTIONS if reserved else ()
        coalescing = arm.startswith("pair-coalescing-on-")
        server_overrides = {"AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "1" if coalescing else "0"}
        if args.prefill_split_probe:
            server_overrides["AX_MLX_FLASH_NEXT_PREFILL_SPLIT"] = "1" if arm == "pair-prefill-split-on" else "0"
        with server(args, arm, MODEL, args.flash, concurrency,
                    env=server_overrides,
                    options=("--disable-ngram-acceleration", "--total-blocks", "2048",
                             "--max-batch-tokens", str(budget), *reservation_options),
                    stream_experts="auto", prefill_chunk=prefill_chunk, guard=True) as (url, _):
            metadata = (args.out / f"{arm}.log").read_text()
            if "decision=resident" not in metadata:
                raise RuntimeError(f"{arm}: Flash Next did not select resident experts")
            observations = []
            disconnect_trials = []
            for repeat in range(2):
                for arrival in arrivals if repeat == 0 else reversed(arrivals):
                    trial_started = time.monotonic()
                    requests = replay(url, rows, arrival, repeat)
                    observations.append({
                        "arrival": arrival, "repeat": repeat,
                        "decoder_first": rows[repeat]["id"] if arrival == "decode-arrival" else None,
                        "requests": requests,
                        "client_wall_seconds": time.monotonic() - trial_started,
                    })
                    write_json(args.out / f"{arm}-observations.json", observations)
                    print(f"{arm} repeat={repeat} arrival={arrival} complete", flush=True)
                if (args.coalescing_probe or args.prefill_split_probe) and reserved:
                    disconnect_trials.append(disconnect_and_reuse(url, rows, repeat))
                    if arm == "pair-prefill-split-on":
                        disconnect_trials.append(disconnect_and_reuse(url, rows, repeat, "prefill"))
                    write_json(args.out / f"{arm}-disconnect.json", disconnect_trials)
                    print(f"{arm} repeat={repeat} disconnect and reuse complete", flush=True)
        samples = [json.loads(line) for line in (args.out / f"{arm}-samples.jsonl").read_text().splitlines()]
        if not samples or any(sample["pressure"] not in (1, 2) for sample in samples):
            raise RuntimeError(f"{arm}: missing memory observations or high memory pressure")
        results["arms"].append({"arm": arm, "concurrency": concurrency, "max_batch_tokens": budget,
                                "configured_prefill_chunk": prefill_chunk, "observations": observations,
                                "scheduler_options": list(reservation_options),
                                "server_overrides": server_overrides,
                                "disconnect_trials": disconnect_trials,
                                "memory_samples": samples})
        write_json(args.out / "partial.json", results)
    results["local_inputs"] = native.validate_inventory(args.flash, inventory)
    if manifest_before and manifest_before != results["local_inputs"]:
        raise ValueError("native manifest changed during the probe")
    if (results["inventory_sha256"] != native.sha256(args.inventory)
            or results["binary_sha256"] != native.sha256(args.binary)):
        raise ValueError("inventory or server changed during the probe")
    compare_observations(results)
    write_json(args.out / "result.json", results)


if __name__ == "__main__":
    main()
