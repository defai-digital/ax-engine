"""Compare stock and grouped Flash Next admission and native HTTP execution."""
from argparse import ArgumentParser
from importlib.metadata import version
import json
from pathlib import Path
import re
from socket import socket
from subprocess import Popen
from threading import Event, Thread
import time
from urllib.request import Request, urlopen

import check_flash_next_native_support as native
import observe_workload_cpu as cpu
import run_flash_next_generate_matrix as matrix
import run_flash_next_lifecycle as lifecycle
import run_flash_next_qa_cohort as qa
from run_qwen38_reference_serving import monitor_memory

HERE = Path(__file__).resolve().parent
SWITCH = "AX_MLX_FLASH_NEXT_QSA_GROUPED_EVAL"
BUDGET = 64
MARKER = re.compile(r"evaluated grouped QSA prefill.*?queries=(\d+) history=(\d+) tiles=(\d+)")
MAX_FOOTPRINT = 96 * 2**30


def log_grouping(log_file, offset):
    with log_file.open("rb") as stream:
        stream.seek(offset)
        log = stream.read().decode(errors="replace")
        return [list(map(int, values)) for values in MARKER.findall(log)]


def memory(base):
    return json.loads(native.request(base, "/v1/memory"))


def counters(base):
    values = native.metrics(native.request(base, "/metrics").decode())
    return {key: int(values[key]) for key in (native.VERIFIED, *native.ERRORS)}


def validate_grouping(rows, expected):
    assert bool(rows) == expected, rows
    assert all(width in (2047, 2048) and width < history <= 32768 and tiles > 1
               for width, history, tiles in rows), rows


def run_request(base, prompt, label, log_file, read_cpu, grouping):
    assert not any(lifecycle.wait_drained(base).values())
    before = counters(base)
    log_start = log_file.stat().st_size
    start = read_cpu()
    response = matrix.generate(base, prompt, BUDGET, ignore_eos=True)
    end = read_cpu()
    drained = lifecycle.wait_drained(base)
    after = counters(base)
    assert response["prompt_tokens"] == prompt
    assert len(response["output_tokens"]) == BUDGET
    assert response["finish_reason"] == "max_output_tokens"
    assert not any(drained.values()) and after == before
    measure = memory(base)
    assert measure["lifetime_max_phys_footprint_bytes"] <= MAX_FOOTPRINT
    rows = log_grouping(log_file, log_start)
    validate_grouping(rows, grouping)
    ticks = cpu.tick_delta(start, end)
    assert sum(ticks.values()) > 0
    return {"action": label, "prompt_length": len(prompt),
            "prompt_sha256": matrix.ids_sha(prompt), "output_ids": response["output_tokens"],
            "finish_reason": response["finish_reason"], "resources_after": drained,
            "route_error_and_mtp_delta": {key: after[key] - before[key] for key in before},
            "grouped_forwards": rows, "client_timing": response["client_timing"],
            "request_host_idle_percent": 100 * ticks["idle"] / sum(ticks.values()),
            "host_ticks_begin": start, "host_ticks_end": end, "memory": measure}


def disconnect(base, prompt, log_file, grouping):
    before = counters(base)
    start = log_file.stat().st_size
    req = Request(base + "/v1/generate/stream", data=json.dumps({
        "input_tokens": prompt, "max_output_tokens": 512,
        "sampling": {"temperature": 0, "ignore_eos": True},
    }).encode(), headers={"Content-Type": "application/json"})
    with urlopen(req, timeout=600) as stream:
        for raw in stream:
            if raw.startswith(b"data:") and raw.strip() != b"data: [DONE]":
                data = json.loads(raw[5:])
                if data.get("delta_tokens"):
                    ids = data["delta_tokens"]
                    active = lifecycle.counters(base)["ax_engine_generation_active_streams"]
                    assert active == 1, active
                    break
        else:
            raise RuntimeError("No native delta was seen before disconnect")
    drained = lifecycle.wait_drained(base)
    rows = log_grouping(log_file, start)
    validate_grouping(rows, grouping)
    assert not any(drained.values()) and counters(base) == before
    return {"action": "disconnect", "output_prefix_ids": ids, "active_while_open": active,
            "resources_after": drained, "grouped_forwards": rows}


def run(args, prompts, outcomes):
    grouped = args.arm.startswith("grouped")
    chunk = 512 if args.arm.endswith("fallback") else 2048
    flags = {
        "AX_MLX_PREFIX_CACHE_DISK_DISABLED": "1",
        "AX_ENGINE_PREFIX_REUSE_DISABLED": "1",
        "AX_MLX_PREFIX_CACHE_MAX_BYTES": "0",
        "AX_MLX_PREFIX_CACHE_MAX_ENTRIES": "0",
        "AX_MLX_FLASH_NEXT_QSA_PAIRED_GATHER": "0",
        "AX_MLX_LONG_PROMPT_PREFILL_CHUNK": str(chunk),
        SWITCH: str(int(grouped)),
        "RUST_LOG": "info,ax_engine_mlx::model::shared::qwen4_exp_attention=debug",
    }
    with socket() as listener:
        listener.bind(("127.0.0.1", 0))
        port = listener.getsockname()[1]
    base = f"http://127.0.0.1:{port}"
    log_file = args.out / "server.log"
    read_cpu = cpu.clock_ticks()
    cmd = qa.server_command(HERE / "ax-engine-server", args.pack, "default", port,
                            ordinary_launch=True)
    cmd.extend(("--prefill-chunk", str(chunk), "--max-concurrent-requests", "1"))
    started = time.monotonic()
    outcomes.write_text("")
    with log_file.open("w") as log:
        proc = Popen(cmd, stdout=log, stderr=log, env=native.server_env(flags),
                     start_new_session=True)
        stop = Event()
        monitor = Thread(target=monitor_memory, args=(args.out, "server", proc, stop), daemon=True)
        monitor.start()
        try:
            while True:
                if proc.poll() is not None or time.monotonic() - started > qa.READY_TIMEOUT:
                    raise RuntimeError("Owned server failed to become ready")
                try:
                    models = json.loads(native.request(base, "/v1/models"))
                    break
                except (OSError, ValueError):
                    time.sleep(1)
            model = qa.check_standard_model(models, qa.ORDINARY_MODEL_ID)
            readiness = time.monotonic() - started
            initial = memory(base)
            assert initial["models"] == [{"id": model["id"], "expert_streaming_active": False}]
            assert initial["memory_plan"]["live_sequence_cap"] in (None, 1)
            assert initial["memory_plan"]["wired_shortfall_bytes"] == 0
            labels = ["long"] if chunk == 512 else ["short", "long", "maximum"]
            if args.arm.endswith("second"):
                labels = list(reversed(labels))
            can_group = grouped and chunk == 2048
            results = {}
            with outcomes.open("a") as stream:
                def record(result):
                    print(json.dumps(result), file=stream, flush=True)
                    print(result["action"], len(result["grouped_forwards"]), flush=True)

                for label in labels:
                    results[label] = run_request(base, prompts[label], label, log_file, read_cpu,
                                                 can_group and label != "short")
                    record(results[label])
                if chunk == 2048:
                    stopped = disconnect(base, prompts["long"], log_file, grouped)
                    assert results["long"]["output_ids"][:len(stopped["output_prefix_ids"])] == (
                        stopped["output_prefix_ids"])
                    record(stopped)
                    recovery = run_request(base, prompts["long"], "recovery", log_file, read_cpu,
                                           grouped)
                    assert recovery["output_ids"] == results["long"]["output_ids"]
                    record(recovery)
        finally:
            stop.set()
            monitor.join(timeout=4)
            native.stop_owned(proc)
    samples = [json.loads(line) for line in (args.out / "server-samples.jsonl").read_text().splitlines()]
    assert samples and all(r["pressure"] == 1 and r["footprint_bytes"] <= MAX_FOOTPRINT
                           for r in samples)
    native.scrub_log(log_file)
    return {"mode": args.arm, "chunk": chunk, "flags": flags, "model": model,
            "ready_seconds": readiness, "startup_memory": initial, "pressure_samples": len(samples),
            "peak_sampled_footprint_bytes": max(row["footprint_bytes"] for row in samples)}


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--arm", required=True, choices=("stock-first", "grouped-first",
                     "grouped-second", "stock-second", "stock-fallback", "grouped-fallback"))
    cli.add_argument("--pack", type=Path, required=True)
    cli.add_argument("--link-root", type=Path)
    cli.add_argument("--out", type=Path, required=True)
    args = cli.parse_args()
    build = json.loads((HERE / "build.json").read_text())
    assert version("mlx") == version("mlx-metal") == build["mlx"] == "0.32.4"
    assert native.sha256(HERE / "ax-engine-server") == build["binary_sha256"]
    assert native.sha256(HERE / "source.patch") == build["patch_sha256"]
    inventory = json.loads((HERE / "mxfp4-inventory.json").read_text())
    verified = native.validate_inventory(args.pack, inventory, args.link_root)
    assert len(inventory["members"]) == 49
    assert verified["model-manifest.json"] == build["manifest_sha256"]
    prompts = json.loads((HERE / "prompts.json").read_text())
    assert len(prompts["maximum"]) + BUDGET == 32768
    args.out.mkdir()
    outcomes = args.out / "requests.jsonl"
    result = run(args, prompts, outcomes)
    assert native.validate_inventory(args.pack, inventory, args.link_root) == verified
    receipt = result | {"build": build, "pack_sha256": verified, "qualification": False,
                        "input_sha256": native.sha256(HERE / "prompts.json"),
                        "requests_sha256": native.sha256(outcomes)}
    temporary = args.out / "receipt.tmp"
    temporary.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    temporary.rename(args.out / "receipt.json")


if __name__ == "__main__":
    main()
