#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
pack=$1
root=$2
reference=$3
previous=$4
slot="$HOME/build/.ax-flash-next-native-test-slot"
export PATH="$HOME/.venvs/ax-engine/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
python="$HOME/.venvs/ax-engine/bin/python"
ref_python="$HOME/build/flash-next-official-20260923/launch-reference-env/bin/python"
owned=0
release() {
    if (( owned )) && test "$(cat "$slot/owner.pid")" = "$$"; then
        rm "$slot/owner.pid"
        rmdir "$slot"
    fi
    owned=0
}
finish() {
    code=$?
    release
    printf '%s\n' "$code" > status.txt
}
trap finish EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
test "$(sysctl -n hw.model hw.memsize)" = "$(printf 'Mac17,6\n137438953472')"
shasum -a 256 -c inputs.sha256 >/dev/null
codesign --verify --strict ax-engine-server
lib=$("$python" -B -c 'from importlib.metadata import distribution,version; assert version("mlx")==version("mlx-metal")=="0.32.4"; print(distribution("mlx").locate_file("mlx/lib"))')
expected=$("$python" -B -c 'import json; print(json.load(open("build.json"))["libmlx_sha256"])')
test "$(shasum -a 256 "$lib/libmlx.dylib" | awk '{print $1}')" = "$expected"
deadline=$((SECONDS+7200))
while ! test -s "$previous/status.txt"; do
    (( SECONDS < deadline )) || exit 75
    kill -0 "$(cat "$previous/owner.pid")"
    sleep 15
done
test "$(cat "$previous/status.txt")" = 0
mkdir observed
for arm in stock-first grouped-first grouped-second stock-second stock-fallback grouped-fallback; do
    while (( SECONDS < deadline )); do
        if test "$(sysctl -n kern.memorystatus_vm_pressure_level)" = 1 && mkdir "$slot" 2>/dev/null; then
            printf '%s\n' "$$" > "$slot/owner.pid"
            owned=1
            if ! ps -axo comm= | grep -E '/(ax-engine-server[^/]*|mtp-audit|direct_weights|ax-flash-.*-test)$' >/dev/null; then
                if test -s "$reference/status.txt"; then break; fi
                kill -0 "$(cat "$reference/owner.pid")"
                if ! test -s "$reference/headroom.jsonl"; then
                    (cd "$reference" && "$ref_python" -B recover.py --preflight) > capacity.json
                    if "$python" -B -c 'import json,sys; r=json.load(open("capacity.json"))["capacity"]; sys.exit(not (r["reason"]=="background-rss-exceeds-signed-margin" and r["pressure"]==1))'; then break; fi
                fi
            fi
            release
        fi
        sleep 15
    done
    test "$owned" = 1
    printf '%s starting\n' "$arm"
    /usr/bin/caffeinate -i /usr/bin/env -i HOME="$HOME" PATH="$PATH" DYLD_LIBRARY_PATH="$lib" \
        PYTHONDONTWRITEBYTECODE=1 "$python" -B -u run_http.py --arm "$arm" --pack "$pack" \
            --link-root "$root" --out "$PWD/observed/$arm"
    printf '%s complete\n' "$arm"
    release
done
shasum -a 256 -c inputs.sha256 >/dev/null
