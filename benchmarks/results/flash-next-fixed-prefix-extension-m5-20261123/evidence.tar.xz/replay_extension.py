"""Reconcile the fixed-prefix serving receipt with its independent raw traces."""

from argparse import ArgumentParser
import hashlib
import json
import math
from pathlib import Path

from run_fixed_extension import CASES, CORPUS, MANIFEST, check_case, read, require, workload
from run_fixed_extension_crossover import ARMS, summarize, timing

IDENTITY = "ff2a28485eb89bb60e8fe35dd6c65c51e63ee7b3"


def pressure_summary(path, expected):
    samples = [json.loads(line) for line in path.read_bytes().splitlines()]
    require(len(samples) == expected > 0, f"Pressure sample count changed for {path.name}")
    require(all(s["pressure"] == 1 and type(s["rss_bytes"]) is int and s["rss_bytes"] > 0
                and type(s["footprint_bytes"]) is int and s["footprint_bytes"] > 0 for s in samples),
            f"Non-normal or malformed pressure observation for {path.name}")
    return {"samples": len(samples), "peak_rss_bytes": max(s["rss_bytes"] for s in samples),
            "peak_footprint_bytes": max(s["footprint_bytes"] for s in samples)}


def peer_latency(row):
    output = [step for step in row["peer"]["scheduled_work"] if step["delta_token_count"]]
    latencies = [after["received_seconds"] - before["received_seconds"]
                 for before, after in zip(output, output[1:])]
    prefix_step = row["target"]["prefill_progress"][0]["step_id"]
    index, = [i for i, step in enumerate(output) if step["step_id"] == prefix_step]
    require(0 < index < len(output) - 1 and all(math.isfinite(gap) and gap >= 0 for gap in latencies),
            "The peer lacks one observable gap across the matched prefix step")
    return timing(row) | {"peer_p95_gap_seconds": sorted(latencies)[math.ceil(0.95 * len(latencies)) - 1],
                          "peer_prefix_step_gap_seconds": latencies[index - 1]}


def verify_arm(root, name, record, enabled, prompts):
    observed = root / "observed"
    seed = read(observed / f"{name}-seed.json")
    raw = read(observed / f"{name}-partial.json")
    require(record["seed"] == seed and record["cases"] == raw and len(seed["output_tokens"]) == 1
            and seed["prompt_id"] == prompts["seed"]["id"], "Per-arm raw seed or case data changed")
    seed_items = seed["prefill_progress"]
    require(len(seed_items) == 1 and seed_items[0]["advanced_prompt_tokens"] == 2048
            and seed_items[0]["scheduled_tokens"] == 2048 and seed_items[0]["scheduled_requests"] == 1
            and seed_items[0]["delta_token_count"] == 1
            and seed["prefill_route"]["ax_mlx_prefill_chunk_selected"] == 512,
            "Standalone seed lost its observed 2,048-token item or 512-token width")
    outputs = {}
    requests = {seed["request_id"]}
    require(set(raw) == {label for label, *_ in CASES}, "Missing or extra serving controls")
    for label, peer, target, cancelled, eligible, tail in CASES:
        row = raw[label]
        for role, identity in (("peer", peer), ("target", target)):
            reply = row[role]
            require(reply["prompt_id"] == prompts[identity]["id"] and reply["request_id"] not in requests,
                    "A response changed prompt identity or reused a request ID")
            requests.add(reply["request_id"])
        outputs[label] = check_case(row, enabled and eligible, cancelled, tail)
    require(outputs == record["outputs"] and outputs["first"]["target_ids"] != outputs["replacement"]["target_ids"],
            "Raw token arrays or the distinct suffix control changed")
    result = pressure_summary(observed / f"{name}-samples.jsonl", record["normal_pressure_samples"])
    return result | {"latency": {label: peer_latency(row) for label, row in raw.items()}}


def throughput_for_completed_pairs(arms, comparison):
    complete_hits = [label for label, _, _, cancelled, eligible, _ in CASES if eligible and not cancelled]
    rates = {}
    for name, arm in arms.items():
        tokens = sum(len(ids) for label in complete_hits for ids in arm["outputs"][label].values())
        wall = sum(arm["cases"][label]["wall_seconds"] for label in complete_hits)
        require(tokens > 0 and math.isfinite(wall) and wall > 0, "Invalid complete-pair timing")
        rates[name] = {"generated_token_ids":tokens, "summed_wall_seconds":wall,
                      "tokens_per_second":tokens/wall}
    eligible = comparison["performance_comparison_eligible"]
    ratios = [rates[pair["on"]]["tokens_per_second"] / rates[pair["off"]]["tokens_per_second"]
              for pair in comparison["paired_differences"] if pair["timing_eligible"]]
    return {"cases":complete_hits, "arms":rates, "comparison_eligible":eligible,
            "on_over_off_by_process_order":ratios if eligible else []}


def replay(root, expected_build, patch, mode):
    receipt = read(root / "observed/receipt.json")
    build = read(root / "build.json")
    require((root / "status.txt").read_bytes() == b"0\n" and receipt["qualification"] is False,
            "The serving run did not reach its terminal nonqualification receipt")
    require(build == expected_build == receipt["build"] and build["codesign_verified"] is True
            and build["profile"] == "release-server" and build["mlx"] == build["mlx_metal"] == "0.32.4"
            and hashlib.sha256(patch.read_bytes()).hexdigest() == build["patch_sha256"],
            "The signed executable, runtime, or exact source patch changed")
    require(receipt["corpus_sha256"] == CORPUS and receipt["manifest"] == MANIFEST,
            "The frozen input corpus or pack manifest changed")
    prompts = workload()
    if mode == "m2":
        arms = {"off": receipt["baseline"], "on": receipt["candidate"]}
        switches = (("off", False), ("on", True))
        require(arms["off"]["outputs"] == arms["on"]["outputs"]
                and arms["off"]["seed"]["output_tokens"] == arms["on"]["seed"]["output_tokens"],
                "The experimental switch changed any greedy output ID")
        ids = 1 + sum(len(ids) for row in arms["off"]["outputs"].values() for ids in row.values())
        comparison = {"tokens_per_process": ids, "performance_comparison_eligible": False}
    else:
        switches, arms = ARMS, receipt["arms"]
        comparison = summarize(arms)
        require(receipt["comparison"] == comparison, "The retained crossover summary no longer reconciles")
        require(all(read(root / "observed" / f"{name}-arm.json") == arms[name] for name, _ in switches),
                "The retained per-process observations changed")
    require(comparison["tokens_per_process"] == 1346, "The output coverage changed")
    summary = {name: verify_arm(root, name, arms[name], enabled, prompts) for name, enabled in switches}
    result = {"qualification": False, "pack_revision": IDENTITY, "server_sha256": build["server_sha256"],
              "patch_sha256": build["patch_sha256"], "comparison": comparison, "raw_arm_checks": summary}
    if mode == "m5":
        result["throughput_for_completed_pairs"] = throughput_for_completed_pairs(arms, comparison)
    return result


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("m2", "m5"))
    parser.add_argument("observations", type=Path)
    parser.add_argument("--expected-build", type=Path, required=True)
    parser.add_argument("--patch", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(replay(args.observations, read(args.expected_build), args.patch, args.mode),
                     indent=2, sort_keys=True, allow_nan=False))
