"""Compare the guarded Flash Next extension route with cold execution."""

from argparse import ArgumentParser
import json
from pathlib import Path
from time import monotonic

import run_selective_mixed as mixed
from run_warm_prefix import REUSED, STORES, build_prompts, generate, overlap, restored_l1

ROOT = Path(__file__).resolve().parent
CORPUS = "2c0c205d803207df6316dbd0076eef97451a55c80c0413fdc6b3bee5ffef7e9a"
MANIFEST = {"model-manifest.json": "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef"}
COUNTERS = ("ax_engine_mlx_prefix_cache_reused_tokens_total", "ax_engine_mlx_prefix_cache_hits_total")
CASES = (
    ("first", "peer-a", "extension-a", False, True, 64),
    ("cancel", "peer-b", "extension-b", True, True, 64),
    ("replacement", "peer-c", "extension-c", False, True, 64),
    ("unseeded", "peer-d", "unseeded", False, False, 64),
    ("different-length", "peer-e", "different-length", False, False, 65),
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def save(path, value):
    target = path.with_suffix(".tmp")
    target.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    target.replace(path)


def workload():
    corpus = ROOT / "mixed-corpus.jsonl"
    require(mixed.digest(corpus) == CORPUS, "Frozen source corpus changed")
    prior = build_prompts(corpus)
    seed = prior["seed-a"]["input_tokens"]
    a = prior["target"]["input_tokens"][2048:]
    b = prior["cancelled"]["input_tokens"][2048:]
    c = prior["replacement"]["input_tokens"][2048:]
    other = prior["seed-b"]["input_tokens"]
    short = [row["input_tokens"] for row in map(json.loads, corpus.read_text().splitlines())
             if len(row["input_tokens"]) == 512]
    inputs = {"seed": seed, "extension-a": seed + a, "extension-b": seed + b, "extension-c": seed + c,
              "unseeded": other + b, "different-length": seed + a + b[:1]}
    inputs.update({f"peer-{letter}": short[index] for index, letter in enumerate("abcde", start=3)})
    require(len(seed) == len(other) == 2048 and len(a) == len(b) == len(c) == 64 and len({tuple(a), tuple(b), tuple(c)}) == 3
            and len({tokens[0] for name, tokens in inputs.items()
                     if name.startswith("peer-") or name in ("seed", "unseeded")}) == 7,
            "The seeded, unseeded, suffix, or peer prompts are no longer distinct")
    return {name: {"id":name, "input_tokens":tokens, "max_output_tokens":
                   1 if name=="seed" else 192 if name.startswith("peer-") else 96}
            for name,tokens in inputs.items()}


def reuse(base):
    values = mixed.native.metrics(mixed.native.request(base, "/metrics").decode())
    return [values.get(key, 0) for key in COUNTERS]


def check_case(record, reuse_expected, cancelled, tail):
    peer, target = record["peer"], record["target"]
    advances = target["prefill_progress"]
    require([item["advanced_prompt_tokens"] for item in advances] == [2048, tail]
            and [item["delta_token_count"] for item in advances] == [0, 1]
            and [item["scheduled_tokens"] for item in advances] == [2049, tail + 1]
            and all(item["scheduled_requests"] == 2 for item in advances),
            "The shared logical prefill boundary or first-output position changed")
    decoding = [event["step_id"] for event in peer["scheduled_work"] if event["delta_token_count"]]
    require(all(item["step_id"] in decoding[1:-1] for item in advances),
            "The independent peer did not decode on both prefill items")
    delta = [b-a for a,b in zip(record["reuse_before"],record["reuse_after"],strict=True)]
    require(delta == ([2048,1] if reuse_expected else [0,0]), "Unexpected physical restore counter change")
    peer_events = peer["cache_events"]
    require(all(not event["decisions"].get(REUSED, 0) for event in peer_events),
            "The independent peer observed a reuse event")
    if not cancelled:
        require(restored_l1(target) is reuse_expected
                and all(event["request_id"] == target["request_id"] for event in target["cache_events"]
                        if event["decisions"].get(REUSED)), "Request-owned restore telemetry changed")
    target_ids = target["first_output_tokens"] if cancelled else target["output_tokens"]
    require(len(target_ids) == (1 if cancelled else 96) and len(peer["output_tokens"]) == 192
            and record["drained"] == dict.fromkeys(mixed.COUNTERS, 0),
            "Output budget, cancellation, or work drainage changed")
    return {"target_ids": target_ids, "peer_ids":peer["output_tokens"]}


def run_arm(args, pack, prompts, name, enabled):
    flags = ("--disable-ngram-acceleration", "--total-blocks", "2048", "--max-batch-tokens", "2049",
             *mixed.RESERVE_OPTIONS)
    env = {"AX_MLX_FLASH_NEXT_FIXED_PREFIX_EXTENSION": "1" if enabled else "0",
           "AX_ENGINE_PREFIX_REUSE_DISABLED": "0", "AX_MLX_PREFIX_CACHE_MAX_BYTES": "2147483648",
           "AX_MLX_PREFIX_CACHE_MAX_ENTRIES": "8", "AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0",
           "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": "0", "AX_ENGINE_ADAPTIVE_PREFILL": "0"}
    runs, outputs = {}, {}
    with mixed.server(args, name, mixed.MODEL, pack, 2, env=env, options=flags,
                      stream_experts="auto", guard=True) as (base, _):
        require("decision=resident" in (args.out / f"{name}.log").read_text(), "Resident experts required")
        seed = generate(base, prompts["seed"])
        require(any(event["decisions"].get(STORES) for event in seed["cache_events"]),
                "The standalone seed did not enter the L1 tier")
        mixed.wait_drained(base)
        save(args.out / f"{name}-seed.json", seed)
        for label, peer_case, target_case, cancelled, eligible, tail in CASES:
            before = reuse(base)
            started = monotonic()
            peer, target = overlap(base, prompts[peer_case], prompts[target_case], disconnect=cancelled)
            wall = monotonic() - started
            drained = mixed.wait_drained(base)
            row={"peer":peer, "target":target, "reuse_before":before, "reuse_after":reuse(base),
                 "drained":drained, "wall_seconds":wall}
            runs[label] = row
            save(args.out / f"{name}-partial.json", runs)
            outputs[label] = check_case(row, enabled and eligible, cancelled, tail)
            print(f"{name} {label} verified", flush=True)
        require(outputs["first"]["target_ids"] != outputs["replacement"]["target_ids"]
                and json.loads(mixed.native.request(base, "/health"))["status"] == "ok",
                "Cancellation or suffix distinction was not observed")
    mixed.native.scrub_log(args.out / f"{name}.log")
    samples = [json.loads(line) for line in (args.out / f"{name}-samples.jsonl").read_text().splitlines()]
    require(samples and all(row["pressure"] == 1 for row in samples), "Host pressure was not normal")
    return {"seed":seed,"cases":runs,"outputs":outputs,"normal_pressure_samples":len(samples)}


def main():
    parser=ArgumentParser(description=__doc__)
    for field in ("binary","pack","cache","out"):
        parser.add_argument(f"--{field}",type=Path)
    parser.add_argument("--check-inputs",action="store_true")
    args=parser.parse_args()
    prompts=workload()
    if args.check_inputs:
        print(json.dumps({name:len(row["input_tokens"]) for name,row in prompts.items()},sort_keys=True))
        return
    require(args.binary is not None and args.pack is not None and args.out is not None, "Missing run input")
    build=read(ROOT/"build.json")
    inventory=read(ROOT/"mxfp4-inventory.json")
    require(mixed.digest(args.binary)==build["server_sha256"] and build["codesign_verified"] is True,
            "Signed executable changed")
    require(mixed.native.validate_inventory(args.pack,inventory,args.cache)==MANIFEST,"Delivered model manifest changed")
    args.out.mkdir()
    baseline=run_arm(args,args.pack,prompts,"off",False)
    candidate=run_arm(args,args.pack,prompts,"on",True)
    require(baseline["outputs"]==candidate["outputs"]
            and baseline["seed"]["output_tokens"]==candidate["seed"]["output_tokens"],
            "Exact output IDs changed across the feature switch")
    require(mixed.native.validate_inventory(args.pack,inventory,args.cache)==MANIFEST,"Publisher data changed")
    save(args.out/"receipt.json",{"qualification":False,"build":build,"manifest":MANIFEST,
                                  "corpus_sha256":CORPUS,"baseline":baseline,"candidate":candidate})


if __name__=="__main__":
    main()
