"""Replay the sealed natural fork workload with a candidate reader observation."""

from contextlib import contextmanager
from pathlib import Path
import os
import shutil
import sys

import run_natural_fork as replay


@contextmanager
def observed_server(original, reader, *args, env=None, **kwargs):
    experiment = dict(env or {})
    overrides = ("AX_MLX_FLASH_NEXT_ALIGNED_BUFFERED", "AX_MLX_FLASH_NEXT_ALIGNED_NOCACHE")
    assert all(name not in experiment and name not in os.environ for name in overrides)
    experiment["RUST_LOG"] = "info,ax_engine_mlx::flash_next_startup=debug"
    if reader == "explicit":
        experiment["AX_MLX_FLASH_NEXT_ALIGNED_BUFFERED"] = "1"
    with original(*args, env=experiment, **kwargs) as server:
        yield server


def stage_pack(root, destination):
    inventory = replay.read(Path("mxfp4-inventory.json"))
    ensure_root = root.resolve(strict=True)
    assert len(inventory["members"]) == 49
    for row in inventory["members"]:
        key = Path(row["name"])
        assert not key.is_absolute() and ".." not in key.parts
        source = (ensure_root / key).resolve(strict=True)
        assert source.is_relative_to(ensure_root) and source.stat().st_size == row["size"]
        target = destination / key
        target.parent.mkdir(exist_ok=True, parents=True)
        os.link(source, target)
    shutil.copy2("model-manifest.json", destination / "model-manifest.json")


def main():
    action = sys.argv.pop(1)
    if action == "stage":
        stage_pack(*map(Path, sys.argv[1:]))
        return
    expected = {"ordinary": "Mapped", "explicit": "AlignedBuffered"}
    assert action in expected
    original = replay.mixed.server
    replay.mixed.server = lambda *args, **options: observed_server(original, action, *args, **options)
    replay.main()
    if "--check-inputs" in sys.argv:
        return
    root = Path(sys.argv[sys.argv.index("--out") + 1])
    log = root / "natural.log"
    raw = log.read_text().replace(str(Path.cwd()), "[run]")
    log.write_text(raw)
    readers = [line for line in raw.splitlines() if "Flash Next resident reader" in line]
    assert len(readers) == 1 and f"reader={expected[action]}" in readers[0], readers


if __name__ == "__main__":
    main()
