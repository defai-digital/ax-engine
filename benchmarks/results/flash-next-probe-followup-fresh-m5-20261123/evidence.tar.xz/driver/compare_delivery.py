"""Compare mapped and opt-in sidecar readiness after two independent pinned downloads."""

from argparse import ArgumentParser
from importlib.metadata import distribution, version
import json
from math import ceil, isfinite
from pathlib import Path
import re
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory
from unittest.mock import patch

from scripts import check_flash_next_native_support as native
from scripts import check_flash_next_release_gates as gate
from scripts import run_flash_next_delivery as delivery

ROOT = Path(__file__).resolve().parent
THRESHOLDS = ROOT / "scripts" / "flash_next_release_thresholds.json"
FLAG = "AX_MLX_FLASH_NEXT_MTP_SIDECAR_PREFETCH"
BYTE_COUNT = 5_214_301_696
MINIMUM_FREE_BYTES = ceil(delivery.PUBLISHED_BYTES * delivery.SPACE_MARGIN)
ARMS = ("mapped", "prefetch")


def require(valid, message):
    if not valid:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def save(path, data):
    pending = path.with_suffix(".tmp")
    pending.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")
    pending.replace(path)


def pressure():
    return int(subprocess.check_output(
        ["/usr/sbin/sysctl", "-n", "kern.memorystatus_vm_pressure_level"], text=True))


def stable_usage(response):
    ordinary = dict(response["usage"])
    if "ax_engine" in ordinary:
        ordinary["ax_engine"] = {
            key: value for key, value in ordinary["ax_engine"].items()
            if key not in ("prefill_time_us", "decode_time_us")
        }
    return ordinary


def verify_controls(raw, stock):
    require(raw["modes"] == stock["modes"] == list(delivery.CONTROL_MODES)
            and raw["functional_controls_passed"] is True
            and raw["negative_control_result"]["activation_error_observed"] is True
            and all(raw[f"native_manifest_{phase}"] == stock[f"native_manifest_{phase}"]
                    for phase in ("before", "ready", "after"))
            and raw["revision"] == stock["revision"]
            and raw["inventory_sha256"] == stock["inventory_sha256"],
            "The ordinary control contract or pinned manifest changed")
    activations = {}
    for mode in delivery.CONTROL_MODES:
        observed, expected = (row["results"][mode] for row in (raw, stock))
        require([row["name"] for row in observed] == [name for name, _, _ in native.CASES],
                f"Wrong control roster in {mode}")
        count = 0
        for response, oracle in zip(observed, expected, strict=True):
            body = response["response"]
            native.check_answer(response["name"], body)
            delta = native.check_activation(
                response["metrics_before"], response["metrics_after"], mode == "required",
                body["usage"]["completion_tokens"], response["request"]["max_tokens"],
            )
            require(response["request"] == oracle["request"]
                    and body["choices"] == oracle["response"]["choices"]
                    and stable_usage(body) == stable_usage(oracle["response"])
                    and delta == response["activation_delta"] == oracle["activation_delta"],
                    f"Output, usage, or activation drift in {mode}/{response['name']}")
            count += delta[native.VERIFIED]
        activations[mode] = int(count)
    return activations


def verify_route(root, enabled):
    def events(path):
        log = re.sub(r"\x1b\[[0-9;]*m", "", path.read_text())
        require("Flash Next MTP sidecar prefetch failed" not in log,
                "The enabled payload reader fell back to mapped loading")
        return re.findall(r"Flash Next MTP sidecar prefetch completed bytes=(\d+) elapsed_ms=([\d.]+)", log)

    require(not events(root / "server-required-kill-switch.log"),
            "Required kill-switch control entered sidecar payload loading")
    result = {}
    for mode in delivery.CONTROL_MODES:
        found = events(root / f"server-{mode}.log")
        require(len(found) == int(enabled)
                and all(int(size) == BYTE_COUNT and 0 < float(value) < float("inf") for size, value in found),
                f"Invalid read-ahead route or byte count in {mode}")
        result[mode] = float(found[0][1]) / 1000 if found else 0
    return result


def assess_arm(path, enabled, host, build, thresholds, stock):
    outer = read(path / "result.json")
    controls_path = path / "native-support" / "result.json"
    native_raw = controls_path.read_bytes()
    raw = json.loads(native_raw)
    require(outer["server_sha256"] == raw["server_sha256"] == build["server_sha256"]
            and outer["download"]["ax_engine_sha256"] == build["cli_sha256"]
            and outer["hardware"] == raw["hardware"]
            and outer["metadata_preflight_passed"] is True
            and outer["resumed"] is False and outer["previous_attempts"] == []
            and not gate.delivery_control_problems(outer, native_raw),
            "Fresh delivery and native controls do not bind the tested binaries")
    activations = verify_controls(raw, stock)
    require(activations == {"disabled": 0, "required": 107, "default": 0}, "MTP activation changed")
    require(set(host) == set(delivery.CONTROL_MODES)
            and all(len(mode["cpu_idle_percent"]) == len(mode["pressure"]) == 2
                    and all(isfinite(x) and 0 <= x <= 100 for x in mode["cpu_idle_percent"])
                    for mode in host.values()), "Missing or invalid host measurements")
    idle = thresholds["timing_host"]["min_cpu_idle_percent"]
    timing_eligible = all(mode["pressure"] == [1, 1] and min(mode["cpu_idle_percent"]) >= idle
                          for mode in host.values())
    delivered, = gate.gate_delivery(outer, thresholds)
    require(delivered["passed"], "Original delivery gate rejected the run")
    readiness, = gate.gate_readiness(outer, [], thresholds)
    return {"qualification": False, "delivery": delivered, "delivery_readiness": readiness,
            "timing_eligible": timing_eligible, "observed_host": host, "verifier_steps": activations,
            "prefetch_seconds": verify_route(controls_path.parent, enabled),
            "raw_delivery_sha256": native.sha256(path / "result.json"),
            "raw_native_sha256": native.sha256(controls_path)}


def observe_native(args, snapshot, output, enabled, host):
    original_mode = native.run_mode
    original_env = native.server_env

    def measured(server, root, folder, mode, readiness):
        idle = native.wait_for_quiet()["cpu_idle_percent"]
        before = pressure()
        require(before == 1, "Memory pressure exceeded normal before native startup")
        rows = original_mode(server, root, folder, mode, readiness)
        host[mode] = {"cpu_idle_percent": [idle, native.cpu_idle_percent()], "pressure": [before, pressure()]}
        save(folder / "host-samples.json", host)
        return rows

    argv = [sys.argv[0], "--model-dir", str(snapshot), "--link-root", str(args.cache_root),
            "--inventory", str(args.inventory), "--server-bin", str(args.server_bin),
            "--output", str(output), "--modes", *delivery.CONTROL_MODES]
    with (patch.object(sys, "argv", argv), patch.object(native, "run_mode", measured),
          patch.object(native, "server_env", lambda explicit=None: original_env(
              {FLAG: str(int(enabled)), **(explicit or {})}))):
        require(native.main() == 0, "The original native functional controls failed")
    path = output / "result.json"
    result = read(path)
    return {"passed": result["functional_controls_passed"], "modes": result["modes"],
            "readiness_seconds": result["readiness_seconds"], "page_cache": result["page_cache"],
            "result_sha256": native.sha256(path)}


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--runtime", type=Path)
    parser.add_argument("--scratch", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--preflight", action="store_true")
    options = parser.parse_args()
    thresholds = read(THRESHOLDS)
    contract = {
        "scope": "same-executable sidecar pre-read and mapped fresh delivery",
        "qualification": False, "arms": list(ARMS), "modes": list(delivery.CONTROL_MODES),
        "pack_revision": native.PACK_REVISION, "ordinary_log_level": "info",
        "publisher_members": delivery.PUBLISHED_MEMBERS, "publisher_bytes": delivery.PUBLISHED_BYTES,
        "minimum_free_bytes_per_delivery": MINIMUM_FREE_BYTES,
        "cache_lifetime": "one isolated application cache per arm, removed after recording",
        "frozen_readiness": thresholds["readiness"], "frozen_host": thresholds["timing_host"],
    }
    if options.dry_run:
        print(json.dumps(contract, indent=2))
        return 0
    if not options.scratch:
        parser.error("preflight and live execution require --scratch")
    scratch = options.scratch.resolve(strict=True)
    model = subprocess.check_output(["/usr/sbin/sysctl", "-n", "hw.model", "hw.memsize"], text=True).splitlines()
    require(model == ["Mac17,6", "137438953472"], "The frozen M5 Max host is required")
    disk = native.storage_info(scratch)
    free = shutil.disk_usage(scratch).free
    eligible = free >= MINIMUM_FREE_BYTES
    if options.preflight:
        print(json.dumps({**contract, "storage": disk, "free_bytes": free, "eligible": eligible}, indent=2))
        return 0 if eligible else 75
    if not all((options.runtime, options.output)):
        parser.error("live execution requires --runtime and --output")
    if not eligible:
        raise SystemExit(75)
    runtime = options.runtime.resolve(strict=True)
    build = read(runtime / "build.json")
    ax_engine = runtime / "ax-engine"
    server = runtime / "ax-engine-server"
    require(build["codesign_verified"] is True and build["profile"] == "release-server"
            and build["mlx"] == build["mlx_metal"] == version("mlx") == version("mlx-metal") == "0.32.4"
            and native.sha256(distribution("mlx").locate_file("mlx/lib/libmlx.dylib")) == build["libmlx_sha256"]
            and native.sha256(ax_engine) == build["cli_sha256"]
            and native.sha256(server) == build["server_sha256"], "Pinned release runtime changed")
    for binary in (ax_engine, server):
        subprocess.run(["/usr/bin/codesign", "--verify", "--strict", binary], check=True)
    names = subprocess.check_output(["/bin/ps", "-axo", "comm="], text=True).splitlines()
    require(not any(Path(name.strip()).name.startswith("ax-engine-server") for name in names),
            "The primary device already has an inference server")
    out = options.output.resolve()
    out.mkdir()
    stock = read(ROOT / "stock-native.json")
    report = {**contract, "build": build, "phase": "starting", "results": {}}
    save(out / "pair.json", report)
    for label in ARMS:
        arm = out / label
        with TemporaryDirectory(prefix="flash-next-fresh-", dir=scratch) as cache:
            host = {}
            enabled = label == "prefetch"
            argv = [sys.argv[0], "--ax-engine", str(ax_engine), "--cache-root", cache,
                    "--inventory", str(ROOT / "inventory.json"), "--server-bin", str(server),
                    "--output", str(arm)]
            with (patch.object(sys, "argv", argv), patch.object(delivery, "run_control",
                  lambda args, snapshot, folder: observe_native(args, snapshot, folder, enabled, host))):
                require(delivery.main() == 0, f"Actual fresh delivery failed in {label}")
            report["results"][label] = assess_arm(arm, enabled, host, build, thresholds, stock)
            report["phase"] = f"{label}-complete"
            save(out / "pair.json", report)
    report["phase"] = "complete"
    report["timing_eligible"] = all(arm["timing_eligible"] for arm in report["results"].values())
    timing = [report["results"][label]["delivery_readiness"]["delivered"] for label in ARMS]
    if report["timing_eligible"] and all(
        gate.positive_measurement(values.get(mode)) for mode in delivery.CONTROL_MODES for values in timing
    ):
        before, after = timing
        report["prefetch_minus_mapped_ready_seconds"] = {
            mode: round(after[mode] - before[mode], 3) for mode in delivery.CONTROL_MODES
        }
    save(out / "pair.json", report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
