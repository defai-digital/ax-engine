#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
retained=$1
comparison=$2
reference=$3
trap 'code=$?; printf "%s\n" "$code" > status.txt' EXIT
deadline=$((SECONDS+43200))
for dependency in "$retained" "$comparison"; do
    until test -s "$dependency/status.txt"; do
        kill -0 "$(cat "$dependency/owner.pid")" 2>/dev/null &&
            (( SECONDS < deadline )) || exit 75
        sleep 40
    done
    test "$(cat "$dependency/status.txt")" = 0
done
echo cache-comparison-terminal
while (( SECONDS < deadline )); do
    code=0
    /bin/bash run_delivery.sh "$retained" "$reference" || code=$?
    if [[ "$code" != 74 && "$code" != 75 ]] || test -e cache; then exit "$code"; fi
    echo cold-delivery-waiting-for-eligible-host-and-storage
    sleep 60
done
exit 75
