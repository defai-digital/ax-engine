#!/usr/bin/env python3
"""Verify immutable fresh-cache delivery of the pinned Flash Next MXFP4 MTP pack.

Downloads the pinned revision with the native product downloader (`ax-engine download
qwen3.8-flash-next:mxfp4`) into an empty cache root, binds every published
member by size and SHA-256 against the staging inventory, requires the generated
native manifest to be runtime ready, and then runs the functional controls
(MTP disabled, required and the product default) on the delivered copy. The
first server start after delivery records its own readiness time; the page
cache is not controlled.

Dry-run is weight-free. Live execution needs network access and about 125 GiB
of internal-SSD space. This is delivery evidence for one revision/SKU, not
quality, performance, MTP-S/P/D or release qualification.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import stat
import subprocess
import sys
import time
from typing import Any, Iterator

try:
    import check_flash_next_native_support as native
except ImportError:
    from scripts import check_flash_next_native_support as native

REPO_DIR = "models--" + native.PRIMARY_REPO.replace("/", "--")
PUBLISHED_MEMBERS = 49
PUBLISHED_BYTES = 132_261_877_478
ALIAS = "qwen3.8-flash-next:mxfp4"
CONTROL_MODES = ("disabled", "required", "default")
SPACE_MARGIN = 1.1
SCRIPTS = Path(__file__).resolve().parent
SCHEMA = "ax-engine.flash-next.fresh-delivery.v2"


def sha256_file(path: Path) -> str:
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def scrub(value: Any) -> Any:
    """Remove the user's home path and loopback addresses from recorded text."""
    if isinstance(value, str):
        return value.replace(str(Path.home()), "[home]").replace("127.0.0.1", "[loopback]")
    if isinstance(value, list):
        return [scrub(item) for item in value]
    if isinstance(value, dict):
        return {key: scrub(item) for key, item in value.items()}
    return value


def check_fresh(cache_root: Path, resume: bool) -> bool:
    """True when the cache starts empty; a non-empty cache is refused unless resuming."""
    if cache_root.exists() and not cache_root.is_dir():
        raise ValueError("cache root exists and is not a directory")
    empty = not cache_root.exists() or not any(cache_root.iterdir())
    if not empty and not resume:
        raise ValueError("fresh delivery requires an empty cache root (use --previous-attempt to resume)")
    return empty


@contextmanager
def lock_cache(cache_root: Path) -> Iterator[int]:
    """Keep two delivery harnesses from claiming the same cache concurrently."""
    descriptor = os.open(cache_root, os.O_RDONLY | os.O_DIRECTORY)
    try:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("another delivery is using the cache root") from error
        yield descriptor
    finally:
        os.close(descriptor)


def check_cache_directory(cache_root: Path, descriptor: int) -> None:
    if not os.path.samestat(cache_root.stat(), os.fstat(descriptor)):
        raise ValueError("cache root changed during delivery")


def cache_resume_state(cache_root: Path, descriptor: int) -> str:
    """Fingerprint actual local cache entries without reading large partial blobs."""
    check_cache_directory(cache_root, descriptor)
    digest = hashlib.sha256()

    def record(path: Path) -> None:
        info = path.lstat()
        if path.name == ".DS_Store" and stat.S_ISREG(info.st_mode):
            return
        fields = (str(path.relative_to(cache_root)), info.st_dev, info.st_ino, info.st_mode)
        # Directory entries are fingerprinted separately. Ignore Finder
        # metadata changes without ignoring changes to the downloaded files.
        if not stat.S_ISDIR(info.st_mode):
            fields += (info.st_size, info.st_mtime_ns, info.st_ctime_ns)
        digest.update(json.dumps(fields).encode())
        digest.update(b"\n")

    def fail(error: OSError) -> None:
        raise error

    record(cache_root)
    for directory, dirs, files in cache_root.walk(on_error=fail):
        dirs.sort()
        for name in sorted(dirs + files):
            record(directory / name)
    check_cache_directory(cache_root, descriptor)
    return digest.hexdigest()


def load_previous_attempts(directory: Path, cache_state: str,
                           inventory_sha256: str) -> tuple[bool, list[dict[str, Any]]]:
    """Carry forward failed attempts only from the same unchanged local cache."""
    previous = json.loads((directory / "result.json").read_text())
    if previous.get("completed") or (previous.get("download") or {}).get("exit_code") in (0, None):
        raise ValueError("the previous attempt did not fail; there is nothing to resume")
    if previous.get("schema") != SCHEMA:
        raise ValueError("the previous attempt is not a v2 delivery record")
    if (previous.get("repo_id") != native.PRIMARY_REPO
            or previous.get("revision") != native.PACK_REVISION
            or previous.get("inventory_sha256") != inventory_sha256):
        raise ValueError("the previous attempt used a different pack inventory")
    if previous.get("resume_cache_sha256") != cache_state:
        raise ValueError("the previous attempt does not bind this unchanged cache root")
    stderr = directory / "download.stderr.log"
    tail = stderr.read_text(errors="replace").splitlines()[-12:] if stderr.is_file() else []
    summary = {"exit_code": previous["download"]["exit_code"],
               "elapsed_seconds": previous["download"]["elapsed_seconds"],
               "stderr_tail": scrub(tail)}
    return previous.get("fresh_cache") is True, [*previous.get("previous_attempts", []), summary]


def snapshot_dir(cache_root: Path) -> Path:
    """The single pinned snapshot directory; any other revision is a failure."""
    snapshots = cache_root / REPO_DIR / "snapshots"
    found = sorted(path.name for path in snapshots.iterdir()) if snapshots.is_dir() else []
    if found != [native.PACK_REVISION]:
        raise ValueError(f"cache must hold exactly the pinned revision, found {found}")
    return snapshots / native.PACK_REVISION


def clean_env(cache_root: Path) -> dict[str, str]:
    """Run the native downloader without inherited AX, Hub, or MLX overrides."""
    kept = {name: value for name, value in os.environ.items()
            if not name.startswith(("AX_", "HF_", "MLX_", "XDG_CACHE"))}
    return {**kept, "HF_HUB_CACHE": str(cache_root)}


def terminal_record(stdout: str, snapshot: Path) -> dict[str, Any]:
    """Require native success for the expected pack and cache destination."""
    try:
        record = json.loads(stdout.rstrip().rsplit("\n", 1)[-1])
    except json.JSONDecodeError as error:
        raise ValueError("downloader printed no JSON terminal record") from error
    expected = {"schema_version": "ax.download_model.v1", "status": "ready",
                "repo_id": native.PRIMARY_REPO, "revision": native.PACK_REVISION,
                "resolved_revision": native.PACK_REVISION, "errors": []}
    if (not isinstance(record, dict)
            or any(record.get(key) != value for key, value in expected.items())
            or record.get("manifest_present") is not True or record.get("config_present") is not True):
        raise ValueError("downloader terminal record does not match the pinned native download")
    dest = record.get("dest")
    if not isinstance(dest, str) or Path(dest).resolve() != snapshot.resolve():
        raise ValueError("downloader terminal record points outside the pinned snapshot")
    return record


def verify_delivery(snapshot: Path, cache_root: Path, inventory: dict[str, Any]) -> dict[str, Any]:
    derived = native.validate_inventory(snapshot, inventory, cache_root)
    members = inventory["members"]
    total = sum(member["size"] for member in members)
    if len(members) != PUBLISHED_MEMBERS or total != PUBLISHED_BYTES:
        raise ValueError(f"inventory is not the published pack: {len(members)} members, {total} bytes")
    manifest = snapshot / "model-manifest.json"
    if not manifest.is_file():
        raise ValueError("delivery produced no native model manifest")
    status = json.loads(manifest.read_text()).get("runtime_status") or {}
    if status.get("ready") is not True or status.get("blockers"):
        raise ValueError(f"delivered native manifest is not runtime ready: {status}")
    return {"members_verified": len(members), "bytes_verified": total,
            "all_sizes_and_sha256_match": True, "native_manifest_runtime_ready": True,
            "native_manifest_sha256": derived.get("model-manifest.json")}


def run_control(args: argparse.Namespace, snapshot: Path, output: Path) -> dict[str, Any]:
    command = [sys.executable, str(SCRIPTS / "check_flash_next_native_support.py"),
               "--model-dir", str(snapshot), "--link-root", str(args.cache_root),
               "--inventory", str(args.inventory), "--server-bin", str(args.server_bin),
               "--output", str(output), "--modes", *CONTROL_MODES]
    done = subprocess.run(command, capture_output=True, text=True)
    (output.parent / "native-support.log").write_text(scrub(done.stdout + done.stderr))
    if done.returncode != 0:
        raise RuntimeError(f"functional controls on the delivered copy failed ({done.returncode})")
    result = json.loads((output / "result.json").read_text())
    return {"passed": result["functional_controls_passed"], "modes": result["modes"],
            "readiness_seconds": result["readiness_seconds"], "page_cache": result["page_cache"],
            "result_sha256": sha256_file(output / "result.json")}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--ax-engine", type=Path, help="product CLI used to download")
    parser.add_argument("--cache-root", type=Path, help="empty Hugging Face cache root on the internal SSD")
    parser.add_argument("--inventory", type=Path)
    parser.add_argument("--server-bin", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--previous-attempt", type=Path,
                        help="output directory of a failed attempt on this same cache root; "
                             "this run resumes it and records the failed attempt(s)")
    args = parser.parse_args()
    contract = {"schema": SCHEMA, "repo_id": native.PRIMARY_REPO,
                "revision": native.PACK_REVISION, "alias": ALIAS, "published_members": PUBLISHED_MEMBERS,
                "published_bytes": PUBLISHED_BYTES, "control_modes": list(CONTROL_MODES),
                "downloader": "ax-engine download <alias> --progress-json (native product CLI)",
                "page_cache": "not controlled", "qualification": False, "release_ready": False,
                "scope": "delivery integrity and functional controls on the delivered copy; "
                         "quality, performance and MTP-S/P/D not assessed"}
    if args.dry_run:
        print(json.dumps(contract, indent=2))
        return 0
    required = (args.ax_engine, args.cache_root, args.inventory, args.server_bin, args.output)
    if not all(required):
        parser.error("live run requires ax-engine, cache-root, inventory, server-bin and output")
    if platform.system() != "Darwin":
        parser.error("live run requires macOS on the Flash Next standard host")
    memory = int(subprocess.check_output(["sysctl", "-n", "hw.memsize"], text=True))
    chip = subprocess.check_output(["sysctl", "-n", "machdep.cpu.brand_string"], text=True).strip()
    if not native.is_target_host(chip, memory):
        parser.error(f"live run requires the Flash Next standard host ({native.TARGET_DESCRIPTION})")
    args.cache_root = args.cache_root.resolve()
    if args.output.resolve().is_relative_to(args.cache_root):
        raise ValueError("delivery output must be outside the download cache")
    if args.cache_root.exists() and not args.cache_root.is_dir():
        raise ValueError("cache root exists and is not a directory")
    args.cache_root.mkdir(parents=True, exist_ok=True)
    with lock_cache(args.cache_root) as descriptor:
        return run_delivery(args, contract, memory, chip, descriptor)


def run_delivery(args: argparse.Namespace, contract: dict[str, Any],
                 memory: int, chip: str, descriptor: int) -> int:
    inventory_bytes = args.inventory.read_bytes()
    inventory = json.loads(inventory_bytes)
    inventory_sha256 = hashlib.sha256(inventory_bytes).hexdigest()
    resuming = args.previous_attempt is not None
    started_empty = check_fresh(args.cache_root, resuming)
    fresh, attempts = started_empty, []
    cache_state = None
    if resuming:
        cache_state = cache_resume_state(args.cache_root, descriptor)
        fresh, attempts = load_previous_attempts(args.previous_attempt, cache_state, inventory_sha256)
    storage = native.storage_info(args.cache_root)
    free = shutil.disk_usage(args.cache_root).free
    if free < PUBLISHED_BYTES * SPACE_MARGIN:
        raise ValueError(f"cache volume has {free} bytes free; need {int(PUBLISHED_BYTES * SPACE_MARGIN)}")
    ax_engine_sha256 = sha256_file(args.ax_engine)
    server_sha256 = sha256_file(args.server_bin)
    args.output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    with (args.output / "download.ndjson").open("wb") as out, \
            (args.output / "download.stderr.log").open("wb") as err:
        check_cache_directory(args.cache_root, descriptor)
        if cache_state is None:
            check_fresh(args.cache_root, False)
        elif cache_resume_state(args.cache_root, descriptor) != cache_state:
            raise ValueError("cache contents changed before resuming delivery")
        done = subprocess.run([str(args.ax_engine), "download", ALIAS, "--progress-json"],
                              stdout=out, stderr=err, env=clean_env(args.cache_root))
    elapsed = round(time.monotonic() - started, 3)
    stdout_path = args.output / "download.ndjson"
    stdout = stdout_path.read_text(errors="replace")
    stdout_path.write_text(scrub(stdout))
    stderr_path = args.output / "download.stderr.log"
    stderr_path.write_text(scrub(stderr_path.read_text(errors="replace")))
    record: dict[str, Any] = {
        **contract, "completed": False, "fresh_cache": fresh, "previous_attempts": attempts,
        "resumed": resuming,
        "download": {"exit_code": done.returncode, "elapsed_seconds": elapsed,
                     "ax_engine_sha256": ax_engine_sha256},
        "hardware": {"form_factor": native.form_factor(), "soc": chip, "memory_bytes": memory,
                     "storage": {"declared": inventory["storage"], **storage},
                     "os": platform.mac_ver()[0]},
        "server_sha256": server_sha256, "inventory_sha256": inventory_sha256}
    check_cache_directory(args.cache_root, descriptor)
    if done.returncode != 0:
        record["resume_cache_sha256"] = cache_resume_state(args.cache_root, descriptor)
    (args.output / "result.json").write_text(json.dumps(record, indent=2) + "\n")
    if done.returncode != 0:
        raise RuntimeError(f"downloader exited with {done.returncode}; see download.stderr.log")
    if ax_engine_sha256 != sha256_file(args.ax_engine):
        raise ValueError("product CLI changed during delivery")
    snapshot = snapshot_dir(args.cache_root)
    record["download"]["terminal"] = scrub(terminal_record(stdout, snapshot))
    record["verification"] = verify_delivery(snapshot, args.cache_root, inventory)
    preflight = subprocess.run([sys.executable, str(SCRIPTS / "qualify_qwen38_flash_next.py"),
                                "--model-dir", str(snapshot)], capture_output=True, text=True)
    if preflight.returncode != 0:
        raise RuntimeError(f"metadata preflight failed: {scrub(preflight.stderr)}")
    record["metadata_preflight_passed"] = True
    record["native_support"] = run_control(args, snapshot, args.output / "native-support")
    if record["server_sha256"] != sha256_file(args.server_bin):
        raise ValueError("server binary changed during delivery controls")
    native.validate_inventory(snapshot, inventory, args.cache_root)
    check_cache_directory(args.cache_root, descriptor)
    record["completed"] = True
    (args.output / "result.json").write_text(json.dumps(record, indent=2) + "\n")
    print("Fresh delivery verified; qualification and MTP-S/P/D remain unassessed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
