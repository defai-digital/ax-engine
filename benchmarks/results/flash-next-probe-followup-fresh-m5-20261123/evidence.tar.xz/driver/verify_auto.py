"""Independently verify the signed automatic-reader candidate checkpoints."""

from argparse import ArgumentParser
import importlib.util
import json
from pathlib import Path

from compare_delivery import ROOT, THRESHOLDS, assess_arm, delivery, native, read, require, stable_usage
import seal_native


def transfer_checker(repo):
    old = repo / "benchmarks/results/flash-next-fresh-delivery-38c90b27a-m5-20261122/replay.py"
    spec = importlib.util.spec_from_file_location("flash_next_signed_transfer", old)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.check_transfer


def ordinary(raw, book, build, repo):
    out = raw / "delivery"
    controls = out / "native-support"
    host = read(controls / "host-samples.json")
    require(set(host) == set(delivery.CONTROL_MODES)
            and all(all(type(n) in (int,float) for n in row["cpu_idle_percent"])
                    and all(type(n) is int for n in row["pressure"])
                    for row in host.values()), "Malformed automatic host observation")
    thresholds = read(THRESHOLDS)
    result = assess_arm(out,True,host,build,thresholds,read(ROOT/"stock-native.json"))
    require(book["ordinary"] == result, "Automatic delivery receipt changed")
    transfers = transfer_checker(repo)((out/"download.ndjson").read_bytes(),
                                      read(out/"result.json"), thresholds["target"]["published_bytes"])
    return {**result, "verified_transfer_progress_events": transfers}


def opt_out(raw, book):
    original = read(raw/"delivery/native-support/result.json")["results"]["default"]
    rows = raw/"opt-out"
    log = rows/"server-default.log"
    reported = book["opt_out"]
    require(native.sha256(log) == reported["log_sha256"]
            and "Flash Next MTP sidecar prefetch" not in log.read_text()
            and "preview listening bind_address=" in log.read_text(),
            "The opt-out did not complete through the mapped reader")
    cases = tuple(name for name,_,_ in native.CASES)
    files = {path.name for path in rows.glob("default-*.json")}
    require(files == {f"default-{case}.json" for case in cases}
            and [row["name"] for row in original] == list(cases), "Incomplete opt-out roster")
    for index, name in enumerate(cases):
        row = read(rows/f"default-{name}.json")
        prior = original[index]
        response = row["response"]
        native.check_answer(name,response)
        delta = native.check_activation(
            row["metrics_before"],row["metrics_after"],False,
            response["usage"]["completion_tokens"],row["request"]["max_tokens"])
        require(row["name"] == name and row["request"] == prior["request"]
                and response["choices"] == prior["response"]["choices"]
                and stable_usage(response) == stable_usage(prior["response"])
                and delta == row["activation_delta"] == prior["activation_delta"],
                "Explicit opt-out changed the native result")
    require(reported["matched_http_controls"] == len(cases), "Opt-out count differs")
    return reported


def verify(raw, build, repo):
    book = read(raw / "auto-delivery.json")
    require(book["qualification"] is False and book["build"] == build
            and book["pack_revision"] == native.PACK_REVISION
            and book["native_modes"] == list(delivery.CONTROL_MODES)
            and book["automatic_override"] == "absent"
            and book["opt_out_override"] == "0"
            and book["opt_out_mode"] == "default", "The signed automatic test scope changed")
    result = {"scope":book["scope"],"qualification":False,"build": build,
              "automatic": ordinary(raw,book,build,repo)}
    if "opt_out" in book:
        result["opt_out"] = opt_out(raw,book)
    full = raw / "observed"
    summary_path = full / "comparison.json"
    if summary_path.is_file():
        summary = seal_native.validate(full,read(ROOT/"signed-native.json"))
        require(read(summary_path) == summary and (raw/"status.txt").read_text() == "0\n",
                "The final native result differs from the raw evidence")
        result["full_native"]=summary
    return result


if __name__ == "__main__":
    cli=ArgumentParser(description=__doc__)
    cli.add_argument("raw",type=Path)
    cli.add_argument("build",type=Path)
    cli.add_argument("--repo",type=Path,required=True)
    args=cli.parse_args()
    print(json.dumps(verify(args.raw,read(args.build),args.repo),indent=2,allow_nan=False))
