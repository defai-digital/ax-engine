"""Verify only the built-in reader on an independent native delivery."""

from argparse import ArgumentParser
from contextlib import contextmanager
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch

from compare_delivery import FLAG, ROOT, THRESHOLDS, assess_arm, delivery, native, pressure, read, require, save, stable_usage


@contextmanager
def arguments(*values):
    with patch.object(sys, "argv", [sys.argv[0], *(str(value) for value in values)]):
        yield


def ordinary_native(args, snapshot, output):
    host = {}
    original_mode = native.run_mode

    def measured(server, root, folder, mode, readiness):
        idle = native.wait_for_quiet()["cpu_idle_percent"]
        before = pressure()
        require(before == 1, "Unexpected memory pressure before loading")
        rows = original_mode(server, root, folder, mode, readiness)
        host[mode] = {"cpu_idle_percent":[idle,native.cpu_idle_percent()],"pressure":[before,pressure()]}
        save(folder/"host-samples.json",host)
        return rows

    with (arguments("--model-dir",snapshot,"--link-root",args.cache_root,"--inventory",args.inventory,
                    "--server-bin",args.server_bin,"--output",output,"--modes",*delivery.CONTROL_MODES),
          patch.object(native, "run_mode", measured)):
        require(native.main()==0, "The ordinary native controls failed")
    support = output/"result.json"
    result = read(support)
    return {"passed":result["functional_controls_passed"],"modes":result["modes"],
            "readiness_seconds":result["readiness_seconds"],"page_cache":result["page_cache"],
            "result_sha256":native.sha256(support)}


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--cache",type=Path)
    parser.add_argument("--dry-run",action="store_true")
    options=parser.parse_args()
    contract = {"qualification":False,"scope":"automatic reader on the signed native build",
                "pack_revision":native.PACK_REVISION,"native_modes":list(delivery.CONTROL_MODES),
                "automatic_override":"absent","opt_out_override":"0","opt_out_mode":"default"}
    if options.dry_run:
        print(json.dumps({**contract, "execution_legs": ["empty-cache-delivery", "ordinary-native-support"]}, indent=2))
        return
    if options.cache is None:
        parser.error("live run requires an empty cache")
    exe,download=ROOT/"ax-engine-server",ROOT/"ax-engine"
    build=read(ROOT/"build.json")
    require(native.sha256(download)==build["cli_sha256"] and
            native.sha256(exe)==build["server_sha256"] and build["codesign_verified"] is True,
            "Signed auto-candidate binaries changed")
    require(FLAG not in native.server_env(), "The ordinary environment carried an override")
    output=ROOT/"delivery"
    inventory=ROOT/"inventory.json"
    with (arguments("--ax-engine",download,"--cache-root",options.cache,"--inventory",inventory,
                    "--server-bin",exe,"--output",output),
          patch.object(delivery,"run_control",ordinary_native)):
        require(delivery.main()==0, "Fresh automatic delivery failed")
    control=output/"native-support"
    thresholds=read(THRESHOLDS)
    stock=read(ROOT/"stock-native.json")
    auto=assess_arm(output,True,read(control/"host-samples.json"),build,thresholds,stock)
    save(ROOT/"auto-delivery.json",{**contract,"build":build,"ordinary":auto})


if __name__ == "__main__":
    main()
