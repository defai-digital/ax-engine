#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
cache=$1
reference=$2
arm=$3
python="$HOME/.venvs/ax-engine/bin/python"
export PATH="$HOME/.venvs/ax-engine/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export PYTHONDONTWRITEBYTECODE=1
test "$(/usr/sbin/sysctl -n hw.model)" = Mac17,6
/usr/bin/shasum -a 256 -c inputs.sha256 >/dev/null
/usr/bin/codesign --verify --strict ax-engine-server
lib=$("$python" -B -c 'from importlib.metadata import version, distribution; assert version("mlx") == version("mlx-metal") == "0.32.4"; print(distribution("mlx").locate_file("mlx/lib"))')
expected=$("$python" -B -c 'import json; print(json.load(open("build.json"))["libmlx_sha256"])')
test "$(shasum -a 256 "$lib/libmlx.dylib" | awk '{print $1}')" = "$expected"
pack=$("$python" -B - "$cache" <<'PYTHON'
import json
from pathlib import Path
import sys
from check_flash_next_native_support import storage_info
cache = Path(sys.argv[1])
manifest = json.loads(Path("mxfp4-inventory.json").read_bytes())
pack = cache / ("models--" + manifest["repo_id"].replace("/", "--")) / "snapshots" / manifest["revision"]
assert pack.is_dir() and storage_info(cache)["internal"]
print(pack)
PYTHON
)
slot="$HOME/build/.ax-flash-next-native-test-slot"
mkdir "$slot" 2>/dev/null || exit 74
printf '%s\n' "$$" > "$slot/owner.pid"
observer=
release() {
    if [[ -n "$observer" && "$(ps -p "$observer" -o command= 2>/dev/null)" == *"wait_clean_window.sh "* ]]; then
        /bin/kill -CONT "$observer" || true
    fi
    if [[ "$(cat "$slot/owner.pid")" == "$$" ]]; then
        rm "$slot/owner.pid"
        rmdir "$slot"
    fi
}
trap release EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
if /bin/ps -axo comm= | /usr/bin/grep -Eq '/(ax-engine-server[^/]*|mtp-audit|ax-flash-shared-load-test|ax-ple-reader-test|direct_weights)$'; then exit 74; fi
test "$(/usr/sbin/sysctl -n kern.memorystatus_vm_pressure_level)" = 1
if ! test -s "$reference/status.txt"; then
    if test -s "$reference/clean-preflight.json" || test -s "$reference/headroom.jsonl"; then exit 74; fi
    owner=$(cat "$reference/owner.pid")
    candidate=$(pgrep -P "$owner")
    [[ "$candidate" =~ ^[0-9]+$ ]]
    [[ "$(ps -p "$candidate" -o command=)" == *"wait_clean_window.sh "* ]]
    /bin/kill -STOP "$candidate"
    observer=$candidate
    [[ "$(ps -p "$observer" -o state=)" == T* ]]
    children=$(ps -axo ppid=,comm= | awk -v p="$observer" '$1 == p {sub(/^.*\//,"",$2); print $2}')
    [[ "$children" == "" || "$children" == sleep ]]
    if test -s "$reference/clean-preflight.json" || test -s "$reference/headroom.jsonl"; then exit 74; fi
    (
        cd "$reference"
        exec "$HOME/build/flash-next-official-20260923/launch-reference-env/bin/python" -B recover.py --preflight
    ) > "capacity-before-$arm.json"
    "$python" -B - "$arm" <<'PY'
import json
import sys
from pathlib import Path
capacity = json.loads(Path(f"capacity-before-{sys.argv[1]}.json").read_bytes())["capacity"]
if (capacity["eligible_for_attempt"] or capacity["pressure"] != 1
        or capacity["reason"] != "background-rss-exceeds-signed-margin"):
    print("Preserving the eligible or unresolved independent reference window.")
    raise SystemExit(74)
PY
fi
printf '%s\n' "Primary-tier startup comparison arm admitted: $arm."
/usr/bin/caffeinate -dimsu /usr/bin/env -i HOME="$HOME" PATH="$PATH" \
    PYTHONDONTWRITEBYTECODE=1 DYLD_LIBRARY_PATH="$lib" "$python" -B -u compare_startup_arm.py \
    "$arm" "$pack" "$cache" "$PWD/arms/$arm"
test "$(/usr/sbin/sysctl -n kern.memorystatus_vm_pressure_level)" = 1
/usr/bin/shasum -a 256 -c inputs.sha256 >/dev/null
