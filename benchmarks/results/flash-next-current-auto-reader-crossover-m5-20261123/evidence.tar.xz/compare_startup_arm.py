"""Collect one resident startup arm with independent reference priority between arms."""
from hashlib import file_digest
import json
from pathlib import Path
import re
import sys
from unittest.mock import patch

import run_flash_next_lifecycle as lifecycle

OVERRIDE = "AX_MLX_FLASH_NEXT_MTP_SIDECAR_PREFETCH"
MANIFEST = "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef"
PREFETCH = re.compile(r"Flash Next MTP sidecar prefetch completed.*?bytes=5214301696\b")


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def main():
    arm = sys.argv[1]
    require(arm in {"auto-1", "auto-2", "mapped-1", "mapped-2"}, "Unknown comparison arm")
    pack, cache, output = map(Path, sys.argv[2:])
    inventory_path = Path("mxfp4-inventory.json")
    inventory = json.loads(inventory_path.read_text())
    expected = {"model-manifest.json": MANIFEST}
    require(len(inventory["members"]) == 49, "Expected 49 publisher members")
    binary = Path("ax-engine-server").resolve()
    native = lifecycle.native
    server_sha = digest(binary)
    inventory_sha = digest(inventory_path)
    before = native.validate_inventory(pack, inventory, cache)
    require(before == expected, "Retained manifest mismatch")
    output.mkdir(parents=True, exist_ok=False)
    idle_before = native.wait_for_quiet()
    server_env = native.server_env
    automatic = arm.startswith("auto-")
    override = {} if automatic else {OVERRIDE: "0"}
    with patch.object(native, "server_env", lambda: server_env(override)):
        run = lifecycle.run_mode(binary, pack, output, "default")
    idle_after = native.cpu_idle_percent()
    after = native.validate_inventory(pack, inventory, cache)
    require(after == before and digest(binary) == server_sha and digest(inventory_path) == inventory_sha,
            "Input digest changed during serving")
    log_path = output / "server-default.log"
    log = log_path.read_text().replace(str(Path.cwd()), "[run]")
    log_path.write_text(log)
    require("decision=resident" in log and run["final_verified_steps"] == 0 and run["exit_code_after_stop"] == 0,
            "Expected resident direct decoding and clean shutdown")
    require(bool(PREFETCH.search(log)) == automatic and "sidecar prefetch failed" not in log,
            "Observed sidecar read route disagrees with the arm")
    data = {"arm": arm, "override": override, "manifest_before": before, "manifest_after": after,
            "server_sha256": server_sha, "inventory_sha256": inventory_sha, "publisher_members": 49,
            "cpu_idle_before": idle_before["cpu_idle_percent"], "cpu_idle_after": idle_after,
            "ready_seconds": run["ready_seconds"], "run": run, "automatic_prefetch_observed": automatic}
    (output / "result.json").write_text(json.dumps(data, indent=2) + "\n")


if __name__ == "__main__":
    main()
