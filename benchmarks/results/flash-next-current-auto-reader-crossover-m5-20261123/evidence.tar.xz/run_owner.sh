#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
trap 'code=$?; printf "%s\n" "$code" > status.txt' EXIT
deadline=$((SECONDS+14400))
for arm in mapped-1 auto-1 auto-2 mapped-2; do
    while :; do
        (( SECONDS < deadline )) || exit 75
        result=0
        /bin/bash run_guarded.sh "$(cat cache.pointer)" "$1" "$arm" || result=$?
        case "$result" in
            0) break;;
            74) sleep 30;;
            *) exit "$result";;
        esac
    done
    sleep 4
done
