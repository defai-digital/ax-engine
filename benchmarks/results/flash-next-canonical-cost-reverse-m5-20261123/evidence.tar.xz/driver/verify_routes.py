"""Check the selected reader in the frozen native matrix's server logs."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from math import isfinite
from pathlib import Path
import re

PREFETCH = re.compile(r"Flash Next MTP sidecar prefetch completed bytes=(\d+) elapsed_ms=([\d.]+)")
BYTES = 5_214_301_696
LOG_NAMES = {
    "server-warm.log", "server-disabled-1.log", "server-default-1.log",
    "server-disabled-2.log", "server-default-2.log",
}


def route(raw, name):
    log = raw.decode()
    markers = list(PREFETCH.finditer(log))
    start = log.find("preview listening bind_address=")
    if (len(markers) != 1 or log.count("preview listening bind_address=") != 1
            or log.count("decision=resident") != 1
            or log.count("effective_sequence_cap=Some(1)") != 1
            or "Flash Next MTP sidecar prefetch failed" in log or "positional read lab" in log):
        raise ValueError(f"Unexpected startup route in {name}")
    prefetch = markers[0]
    size, elapsed_ms = int(prefetch[1]), float(prefetch[2])
    if not (size == BYTES and isfinite(elapsed_ms) and elapsed_ms > 0
            and log.index("decision=resident") < prefetch.start() < start):
        raise ValueError(f"Incorrect startup pre-read in {name}")
    return {"prefetched_bytes": size, "elapsed_ms": elapsed_ms, "sha256": sha256(raw).hexdigest()}


def verify(logs, *, partial=False):
    found = {item.name: item for item in logs.glob("server-*.log")}
    if not found or found.keys() - LOG_NAMES or (not partial and found.keys() != LOG_NAMES):
        raise ValueError("Unexpected native matrix log roster")
    return {name: route(path.read_bytes(), name) for name, path in sorted(found.items())}


if __name__ == "__main__":
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("logs", type=Path)
    cli.add_argument("--partial", action="store_true")
    args = cli.parse_args()
    print(json.dumps(verify(args.logs, partial=args.partial), indent=2, sort_keys=True, allow_nan=False))
