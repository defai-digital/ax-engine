"""Recompute the native canonical-cost comparison from raw stream results."""
from argparse import ArgumentParser
import json
from math import isfinite
from pathlib import Path
from statistics import median

from run_cost import PANELS, ROOT, load_workloads, require
from verify_routes import route


def read(path):
    return json.loads(path.read_bytes())


def elapsed(row):
    t = row["timing"]
    n = len(row["output_tokens"])
    require(t["first_event_tokens"] + t["decode_tokens"] == n and n <= row["budget"]
            and 0 < t["ttft_seconds"] <= t["total_seconds"] < float("inf"), "Inconsistent stream timing")
    duration = t["decode_seconds"]
    if t["decode_tokens"]:
        require(duration is not None and 0 < duration < float("inf")
                and duration <= t["total_seconds"], "Missing positive decode interval")
    else:
        require(duration is None, "Unexpected decode interval for a single event")
    return t["decode_tokens"], duration or 0.0


def sizes(rows):
    intervals = [elapsed(row) for row in rows]
    counts = sum(n for n, _ in intervals)
    duration = sum(time for _, time in intervals)
    return {"generated_tokens": sum(len(row["output_tokens"]) for row in rows),
            "decode_tokens": counts, "decode_seconds": duration,
            "decode_tokens_per_second": counts / duration if duration else None,
            "median_total_seconds": median(row["timing"]["total_seconds"] for row in rows),
            "median_ttft_seconds": median(row["timing"]["ttft_seconds"] for row in rows)}


def ratio(left, right):
    if left is None or right is None:
        return None
    require(isfinite(left) and isfinite(right) and left > 0 and right > 0, "Invalid throughput ratio")
    return right / left


def panel_summary(direct, required, *, allow_inactive=False):
    a, b = sizes(direct), sizes(required)
    diffs, paired = {}, []
    for left, right in zip(direct, required, strict=True):
        require(left["id"] == right["id"] and left["prompt_sha256"] == right["prompt_sha256"]
                and left["budget"] == right["budget"], "Repeated pair received different inputs")
        left_ids, right_ids = left["output_tokens"], right["output_tokens"]
        indices = [i for i in range(max(len(left_ids), len(right_ids)))
                   if left_ids[i:i+1] != right_ids[i:i+1]]
        diffs[left["id"]] = {"indices": indices, "finish_reason": [left["finish_reason"], right["finish_reason"]]}
        n1, t1 = elapsed(left)
        n2, t2 = elapsed(right)
        if t1 and t2:
            paired.append(ratio(n1 / t1, n2 / t2))
    counters = {key: sum(row["counters"][key] for row in required) for key in required[0]["counters"]}
    verified, accepted = counters["verified_steps"], counters["accepted_steps"]
    require((allow_inactive or verified > 0) and 0 <= accepted <= verified
            and (not verified or counters["correction_wall_us"] > 0)
            and (not accepted or counters["bonus_wall_us"] > 0), "Required arm did not measure canonical verification")
    target_seconds = sum(counters[key] for key in ("correction_wall_us", "bonus_wall_us", "rejection_wall_us")) / 1e6
    return {"direct": a, "required": b, "target_wall_seconds": target_seconds,
            "decode_speedup_weighted": ratio(a["decode_tokens_per_second"], b["decode_tokens_per_second"]),
            "decode_speedup_prompt_median": median(paired) if paired else None,
            "mismatches": sum(bool(value["indices"]) for value in diffs.values()), "paired_outputs": diffs,
            "required_counters": counters, "correction_us_per_verification": counters["correction_wall_us"] / verified if verified else None,
            "bonus_us_per_acceptance": counters["bonus_wall_us"] / accepted if accepted else None}


def replay(capture, *, partial=False):
    rows, panels = load_workloads()
    result = read(capture / ("partial-result.json" if partial else "result.json"))
    build = read(ROOT / "build.json")
    contract = read(ROOT / ("contract.json" if result["mode_order"][0] == "disabled" else "contract-reverse.json"))
    require(result["build"] == build and result["workload_panels"] == panels
            and all(result[key] == value for key, value in contract.items()), "Result changed the signed benchmark contract")
    modes = result["mode_order"]
    reported = [arm["mode"] for arm in result["arms"]]
    require(reported == modes[:len(reported)] and (partial or reported == modes), "Incomplete or duplicated arm roster")
    records = {}
    for arm in result["arms"]:
        mode = arm["mode"]
        samples = arm["host_cpu_idle_percent"]
        require(len(samples) == 2 and all(0 <= value <= 100 for value in samples)
                and arm["timing_eligible"] == all(90 <= value <= 100 for value in samples), "Invalid endpoint CPU sample")
        log = capture / f"server-{mode}.log"
        require(route(log.read_bytes(), log.name) == arm["startup_route"], "Startup route evidence changed")
        raw = (capture / f"rows-{mode}.jsonl").read_bytes()
        runs = [json.loads(line) for line in raw.splitlines()]
        require([row["id"] for row in runs] == contract["case_order"], "Unexpected or incomplete workload roster")
        mapping = {name: (panel, budget) for panel, name, _, budget in rows}
        for row in runs:
            require((row["panel"], row["budget"]) == mapping[row["id"]]
                    and row["pressure"] == [1, 1] and row["route_errors"] == 0
                    and row["verified_steps"] == row["counters"]["verified_steps"]
                    and (mode == "required" or row["verified_steps"] == 0), "Execution route changed")
            elapsed(row)
        records[mode] = runs
    report = {"source": build["commit"], "qualification": False, "mode_order": modes,
              "arm_cpu_idle_percent": {a["mode"]: a["host_cpu_idle_percent"] for a in result["arms"]},
              "timing_eligible": len(reported) == 2 and all(a["timing_eligible"] for a in result["arms"])}
    if len(reported) == 2:
        report["panels"] = {}
        for name in PANELS:
            direct = [row for row in records["disabled"] if row["panel"] == name]
            required = [row for row in records["required"] if row["panel"] == name]
            report["panels"][name] = panel_summary(direct, required, allow_inactive=name == "short-answer")
    return report


if __name__ == "__main__":
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("capture", type=Path)
    cli.add_argument("--partial", action="store_true")
    args = cli.parse_args()
    print(json.dumps(replay(args.capture, partial=args.partial), indent=2, sort_keys=True, allow_nan=False))
