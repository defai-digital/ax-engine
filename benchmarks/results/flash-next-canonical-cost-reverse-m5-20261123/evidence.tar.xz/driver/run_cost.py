"""Measure the signed canonical Flash Next verifier on frozen natural workloads."""
from argparse import ArgumentParser
import json
from pathlib import Path
import platform
import socket
import subprocess
import time

import check_flash_next_native_support as native
import run_flash_next_generate_matrix as matrix
from verify_routes import route

ROOT = Path(__file__).resolve().parent
PANELS = {"agent-coding": 3, "general-long": 6, "short-answer": 1}
ENV = {
    "AX_ENGINE_PREFIX_REUSE_DISABLED": "1", "AX_MLX_PREFIX_CACHE_MAX_BYTES": "0",
    "AX_MLX_PREFIX_CACHE_MAX_ENTRIES": "0", "AX_MLX_PREFIX_CACHE_DISK_DISABLED": "1",
    "AX_MLX_DFLASH2": "0",
}
ROUTE = "ax_mlx_flash_next_mtp_"
DETAIL = ("verified_steps", "accepted_steps", "correction_wall_us", "bonus_wall_us",
          "rejection_wall_us", "cost_parks", "cost_would_parks", "emitted_tokens")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load_workloads():
    rows = []
    panels = {}
    for name, count in PANELS.items():
        path = ROOT / "panels" / f"{name}.jsonl"
        inputs = [json.loads(line) for line in path.read_text().splitlines()]
        require(len(inputs) == count and len({row["id"] for row in inputs}) == count,
                f"Frozen panel roster changed: {name}")
        panels[name] = {"members": count, "sha256": native.sha256(path)}
        for row in inputs:
            require(type(row["max_tokens"]) is int and 0 < row["max_tokens"] <= 1280
                    and isinstance(row["prompt"], str) and row["prompt"].strip(), "Invalid prompt row")
            rows.append((name, row["id"], row["prompt"], row["max_tokens"]))
    return rows, panels


def pressure():
    current = int(subprocess.check_output(["/usr/sbin/sysctl", "-n", "kern.memorystatus_vm_pressure_level"]))
    require(current == 1, "The native comparison requires normal system memory pressure")
    return current


def sample(base, mode, panel, identity, ids, budget, *, warmup=False):
    before_pressure = pressure()
    before = native.metrics(native.request(base, "/metrics").decode())
    raw = matrix.generate(base, ids, max_tokens=budget, ignore_eos=warmup)
    after = native.metrics(native.request(base, "/metrics").decode())
    row = matrix.slim(raw, before, after)
    matrix.check_verifier_schedule(row, mode, "canonical")
    require(row["status"] == "finished" and row["route_errors"] == 0
            and raw["prompt_tokens"] == ids and 0 < len(row["output_tokens"]) <= budget
            and (mode == "required" or row["verified_steps"] == 0),
            f"Unexpected generation contract or verifier counters: {identity}")
    require(row["mtp"]["requested"] is (mode == "required"), "Wrong MTP request policy")
    typed = (raw.get("route") or {}).get("crossover_decisions") or {}
    counters = {name: typed.get(ROUTE + name, 0) for name in DETAIL}
    require(counters["verified_steps"] == row["verified_steps"]
            and counters["accepted_steps"] <= counters["verified_steps"], "Verifier telemetry disagrees")
    return {**row, "panel": panel, "id": identity, "budget": budget,
            "prompt_sha256": matrix.ids_sha(ids), "counters": counters,
            "pressure": [before_pressure, pressure()]}


def run_arm(mode, server, pack, path, workloads):
    pre = native.wait_for_quiet()
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        port = listener.getsockname()[1]
    base = f"http://127.0.0.1:{port}"
    logfile = path / f"server-{mode}.log"
    started = time.monotonic()
    with logfile.open("xb") as log:
        command = [*native.server_command(server, pack, mode, port), "--total-blocks", str(matrix.TOTAL_BLOCKS)]
        process = subprocess.Popen(command, stdout=log, stderr=log, env=native.server_env(ENV),
                                   start_new_session=True)
        try:
            while True:
                require(process.poll() is None, f"The {mode} server exited before readiness")
                try:
                    native.request(base, "/v1/models")
                    break
                except (OSError, ValueError):
                    require(time.monotonic() - started < matrix.READY_TIMEOUT, f"{mode} readiness timed out")
                    time.sleep(1)
            startup = round(time.monotonic() - started, 3)
            print(f"{mode}: ready in {startup}s", flush=True)
            warmup = sample(base, mode, "warmup", "fixed-512", matrix.workload_ids(matrix.pack_vocab_size(pack), 512, 98),
                            64, warmup=True)
            with (path / f"rows-{mode}.jsonl").open("x") as trace:
                for panel, identity, prompt, budget in workloads:
                    ids = matrix.chat_prompt_ids(base, prompt)
                    row = sample(base, mode, panel, identity, ids, budget)
                    print(json.dumps(row, sort_keys=True, allow_nan=False), file=trace, flush=True)
                    print(f"{mode}/{identity}: {len(row['output_tokens'])} tokens, {row['verified_steps']} verifier steps", flush=True)
        finally:
            native.stop_owned(process)
    verified_startup = route(logfile.read_bytes(), logfile.name)
    native.scrub_log(logfile)
    verified_startup["sha256"] = native.sha256(logfile)
    end = native.cpu_idle_percent()
    return {"mode": mode, "host_cpu_idle_percent": [pre["cpu_idle_percent"], end],
            "timing_eligible": 90 <= end <= 100, "http_ready_seconds": startup,
            "startup_route": verified_startup, "warmup": warmup}


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path)
    parser.add_argument("--order", choices=("direct-first", "required-first"), default="direct-first")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    cases, panels = load_workloads()
    modes = ["disabled", "required"]
    if args.order == "required-first":
        modes.reverse()
        cases.reverse()
    contract = {"qualification": False, "workload_panels": panels, "mode_order": modes,
                "case_order": [row[1] for row in cases], "server_env": ENV, "temperature": 0,
                "ignore_eos": False, "context_tokens": 32768, "concurrency": 1, "target_verifier": "canonical"}
    if args.dry_run:
        print(json.dumps(contract, indent=2, sort_keys=True))
        return
    if args.cache is None:
        parser.error("live comparison requires the verified cache")
    build = json.loads((ROOT / "build.json").read_bytes())
    server = ROOT / "ax-engine-server"
    inventory_path = ROOT / "inventory.json"
    inventory = json.loads(inventory_path.read_bytes())
    pack = args.cache / f"models--{inventory['repo_id'].replace('/', '--')}" / "snapshots" / inventory["revision"]
    require(build.get("codesign_verified") is True and native.sha256(server) == build["server_sha256"],
            "Signed server does not match its receipt")
    manifest = native.validate_inventory(pack, inventory, args.cache)
    require(manifest == {"model-manifest.json": "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef"},
            "Derived model manifest changed")
    result = {**contract, "build": build, "inventory_sha256": native.sha256(inventory_path),
              "manifest": manifest, "os": platform.mac_ver()[0], "arms": []}
    for mode in modes:
        result["arms"].append(run_arm(mode, server, pack, ROOT, cases))
        (ROOT / "partial-result.json").write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    require(native.validate_inventory(pack, inventory, args.cache) == manifest
            and native.sha256(server) == build["server_sha256"] and load_workloads()[1] == panels,
            "Pack, executable or prompt source changed during measurement")
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
