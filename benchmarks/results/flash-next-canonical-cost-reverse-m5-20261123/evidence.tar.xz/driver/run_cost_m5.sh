#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
previous=$1
reference=$2
matrix=$3
order=$4
python="$HOME/.venvs/ax-engine/bin/python"
export PATH="$HOME/.venvs/ax-engine/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export PYTHONDONTWRITEBYTECODE=1
cache="$previous/cache"
test "$(cat "$previous/status.txt")" = 0
test "$(cat "$matrix/status.txt")" = 0
test "$(/usr/sbin/sysctl -n hw.model)" = Mac17,6
/usr/bin/shasum -a 256 -c inputs.sha256 >/dev/null
/usr/bin/codesign --verify --strict ax-engine-server
lib="$("$python" -B -c 'from importlib.metadata import version, distribution; assert version("mlx") == version("mlx-metal") == "0.32.4"; print(distribution("mlx").locate_file("mlx/lib"))')"
test "$(shasum -a 256 "$lib/libmlx.dylib" | awk '{print $1}')" = d8c9393d584e781393c3effccfccd8ba85ad0c70264edaf9f897dca9875375c6
"$python" -B - "$previous/delivery/result.json" "$matrix/observed/comparison.json" <<'PY'
from hashlib import sha256
import json
from pathlib import Path
import sys
from check_flash_next_native_support import is_target_hardware

def read(name):
    return json.loads(Path(name).read_bytes())

def digest(name):
    return sha256(Path(name).read_bytes()).hexdigest()

delivery, matrix = map(read, sys.argv[1:])
build = read('build.json')
assert delivery['completed'] is True and delivery['metadata_preflight_passed'] is True
assert is_target_hardware(delivery['hardware']) and matrix['timing_eligible'] is True
assert matrix['matching_signed_arrays'] == 124 and matrix['source'] == build['commit']
assert build['codesign_verified'] and build['server_sha256'] == digest('ax-engine-server')
PY
slot="$HOME/build/.ax-flash-next-native-test-slot"
mkdir "$slot" 2>/dev/null || exit 74
printf '%s\n' "$$" > "$slot/owner.pid"
paused=0
observer=
release() {
    if (( paused )) && [[ "$(ps -p "$observer" -o command= 2>/dev/null)" == *"wait_clean_window.sh "* ]]; then
        /bin/kill -CONT "$observer" || true
    fi
    if [[ "$(cat "$slot/owner.pid")" == "$$" ]]; then
        rm "$slot/owner.pid"
        rmdir "$slot"
    fi
}
trap release EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
if /bin/ps -axo comm= | /usr/bin/grep -Eq '/(ax-engine-server[^/]*|mtp-audit|ax-flash-shared-load-test|ax-ple-reader-test|direct_weights)$'; then exit 74; fi
test "$(/usr/sbin/sysctl -n kern.memorystatus_vm_pressure_level)" = 1
if ! test -s "$reference/status.txt"; then
    if test -s "$reference/clean-preflight.json" || test -s "$reference/headroom.jsonl"; then exit 74; fi
    owner=$(cat "$reference/owner.pid")
    observer=$(pgrep -P "$owner")
    [[ "$observer" =~ ^[0-9]+$ ]]
    [[ "$(ps -p "$observer" -o command=)" == *"wait_clean_window.sh "* ]]
    /bin/kill -STOP "$observer"
    paused=1
    [[ "$(ps -p "$observer" -o state=)" == T* ]]
    children=$(ps -axo ppid=,comm= | awk -v p="$observer" '$1 == p {sub(/^.*\//,"",$2); print $2}')
    [[ "$children" == "" || "$children" == sleep ]]
    if test -s "$reference/clean-preflight.json" || test -s "$reference/headroom.jsonl"; then exit 74; fi
    (
        cd "$reference"
        exec "$HOME/build/flash-next-official-20260923/launch-reference-env/bin/python" -B recover.py --preflight
    ) > reference-capacity-before-audit.json
    "$python" -B - <<'PY'
import json
from pathlib import Path
capacity = json.loads(Path('reference-capacity-before-audit.json').read_bytes())['capacity']
if (capacity['eligible_for_attempt'] or capacity['pressure'] != 1
        or capacity['reason'] != 'background-rss-exceeds-signed-margin'):
    print('Preserving the eligible or unresolved independent reference window.')
    raise SystemExit(74)
PY
fi
printf '%s\n' 'Primary-tier canonical-cost diagnostic admitted.'
/usr/bin/caffeinate -dimsu /usr/bin/env -i HOME="$HOME" PATH="$PATH" \
    PYTHONDONTWRITEBYTECODE=1 DYLD_LIBRARY_PATH="$lib" "$python" -B -u run_cost.py --cache "$cache" --order "$order"
