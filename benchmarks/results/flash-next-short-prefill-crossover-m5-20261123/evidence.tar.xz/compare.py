"""Replay the two ordered comparisons when all four short-first arms finish."""

from argparse import ArgumentParser
import json
from pathlib import Path
import sys


WORK = Path(__file__).resolve().parent
sys.path.insert(0, str(WORK / "bundle"))
import run_short_first_crossover as test


def run(capture):
    assert (capture / "status.txt").read_text().strip() == "0"
    build = test.read(capture / "build.json")
    assert build["codesign_verified"] and test.mixed.digest(WORK / "bundle/source.patch") == build["patch_sha256"]
    assert (capture / "inputs.sha256").read_bytes() == (WORK / "bundle/inputs.sha256").read_bytes()
    pairs, values = test.corpus_inputs()
    prompts = {value["id"]: value for value in values}
    oracle = test.read(WORK / "bundle/prior-output.json")
    results = {}
    for arm, enabled in test.ARMS.items():
        directory = capture / "observed" / arm
        receipt = test.read(directory / "receipt.json")
        assert receipt["arm"] == arm and receipt["build"] == build and receipt["qualification"] is False
        assert receipt["flags"]["AX_MLX_FLASH_NEXT_SHORT_PREFILL_FIRST"] == str(int(enabled))
        thresholds = receipt["cpu_idle_percent"]
        assert len(thresholds) == 2 and all(0 <= sample <= 100 for sample in thresholds)
        assert (min(thresholds) >= 90) is receipt["timing_eligible"]
        assert not any(receipt["drained"].values()) and set(receipt["drained"]) == set(test.mixed.COUNTERS)
        corpus = directory / "bursts.jsonl"
        assert test.mixed.digest(corpus) == receipt["corpus_sha256"]
        assert list(map(json.loads, corpus.read_bytes().splitlines())) == values
        raw, traces = (test.read(directory / f"{arm}{suffix}.json") for suffix in ("", "-steps"))
        actual = test.examine(arm, pairs, {row.id: row for row in test.mixed.bench.load_corpus(corpus)},
                              oracle, raw, traces)
        assert actual == receipt["summary"]
        pressure = [json.loads(row) for row in (directory / f"{arm}-samples.jsonl").read_bytes().splitlines()]
        assert len(pressure) == receipt["normal_pressure_samples"] > 0
        assert all(row["pressure"] == 1 for row in pressure)
        assert max(row["footprint_bytes"] for row in pressure) == receipt["max_footprint_bytes"] <= 96 << 30
        assert len(prompts) * 96 == actual["matched_output_ids"]
        results[arm] = {"cpu_idle_percent": thresholds, "timing_eligible": receipt["timing_eligible"], **actual}
    comparisons = {}
    for order, labels in (("first", ("fifo-first", "short-first")), ("second", ("fifo-second", "short-second"))):
        baseline, candidate = [results[arm] for arm in labels]
        eligible = baseline["timing_eligible"] and candidate["timing_eligible"]
        row = {"timing_eligible": eligible, "candidate_pairs_activated": candidate["activated_pairs"]}
        if eligible:
            measurements = []
            for before, after in zip(baseline["pair_receipts"], candidate["pair_receipts"], strict=True):
                for actor in ("short", "long"):
                    assert before[actor]["prompt_id"] == after[actor]["prompt_id"]
                measurements.append({
                    "short_prompt_id": before["short"]["prompt_id"],
                    "long_prompt_id": before["long"]["prompt_id"],
                    "short_offered_ttft_change_ms": after["short"]["offered_ttft_ms"] - before["short"]["offered_ttft_ms"],
                    "short_maximum_gap_change_ms": after["short"]["maximum_gap_ms"] - before["short"]["maximum_gap_ms"],
                    "long_offered_ttft_change_ms": after["long"]["offered_ttft_ms"] - before["long"]["offered_ttft_ms"],
                    "long_offered_completion_change_ms": after["long"]["offered_completion_ms"] - before["long"]["offered_completion_ms"],
                    "burst_output_tps_ratio": after["burst_output_tps"] / before["burst_output_tps"],
                })
            row["pairs"] = measurements
        comparisons[order] = row
    return {"qualification": False, "build": build, "arms": results, "comparisons": comparisons}


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("capture", type=Path)
    args = parser.parse_args()
    print(json.dumps(run(args.capture), indent=2, sort_keys=True, allow_nan=False))
