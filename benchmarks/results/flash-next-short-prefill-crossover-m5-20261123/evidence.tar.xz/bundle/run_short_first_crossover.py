"""Measure actual short-first placement during four real 8K prefills."""

from argparse import ArgumentParser
import json
from pathlib import Path
from statistics import median

import audit_flash_next_mixed_serving as audit
import check_openai_concurrency as frozen
import run_selective_mixed as mixed


ROOT = Path(__file__).resolve().parent
ARMS = {"fifo-first": False, "short-first": True, "short-second": True, "fifo-second": False}
MARKER = "ax_scheduler_resident_short_prefill_first"


def read(path):
    return json.loads(path.read_bytes())


def corpus_inputs():
    original = ROOT / "mixed-corpus.jsonl"
    assert mixed.digest(original) == frozen.CORPUS
    data = [json.loads(line) for line in original.read_bytes().splitlines()]
    long_indexes = [index for index, row in enumerate(data) if len(row["input_tokens"]) == 8192]
    assert len(long_indexes) == 22
    pairs = []
    values = []
    for index, n in enumerate((0, 5, 10, 15)):
        left, right = data[long_indexes[n]:long_indexes[n]+2]
        assert len(right["input_tokens"]) == 512
        assert left["max_output_tokens"] == right["max_output_tokens"] == 96
        pairs.append((left["id"], right["id"]))
        values.extend((dict(left, arrival_s=24 * index), dict(right, arrival_s=24 * index + 0.5)))
    return pairs, values


def examine(arm, pairs, prompts, oracle, raw, traces):
    enabled = ARMS[arm]
    rows, outputs, _ = audit.streams(raw, traces, prompts, 2, True, 96, arm)
    assert outputs == {name: oracle[name] for name in prompts}
    source = {r["prompt_id"]: r for r in raw["observations"] if r["phase"] == "measured"}
    by_id = {trace["request_id"]: trace for trace in traces}
    report = []
    for long_id, short_id in pairs:
        long, short = source[long_id], source[short_id]
        long_trace, short_trace = by_id[long["request_id"]], by_id[short["request_id"]]
        prefill = long_trace["prefill"]
        step = short_trace["prefill"][0]["step_id"]
        assert short_trace["prefill"][0]["width"] == 512 and len(short_trace["prefill"]) == 1
        assert prefill[0]["cursor"] == 2048 and prefill[0]["step_id"] < step
        assert (prefill[-1]["step_id"] > step) is enabled
        prior_cuts = [event for event in prefill if event["step_id"] < step]
        if enabled:
            assert all(cut["width"] == 2048 for cut in prior_cuts)
            assert prefill[len(prior_cuts)]["width"] == 512
        else:
            assert all(slot["width"] == 2048 for slot in prefill)
        assert bool(short["route_decisions"].get(MARKER, 0)) is enabled
        assert long["started_at_s"] < short["started_at_s"] < long["started_at_s"] + long["ttft_ms"] / 1000
        pair = {}
        for label, row in (("long", long), ("short", short)):
            gaps = row["stream_step_interval_ms"]
            pair[label] = {
                "prompt_id": row["prompt_id"],
                "dispatch_ttft_ms": row["ttft_ms"],
                "offered_ttft_ms": row["queue_delay_ms"] + row["ttft_ms"],
                "offered_completion_ms": row["queue_delay_ms"] + row["e2e_latency_ms"],
                "maximum_gap_ms": max(gaps),
                "gaps_at_least_100_ms": rows[row["prompt_id"]]["gaps_at_least_100ms"],
            }
        early = min(long["scheduled_at_s"], short["scheduled_at_s"])
        end = max(row["started_at_s"] + row["e2e_latency_ms"] / 1000 for row in (long, short))
        pair["burst_output_tps"] = 192 / (end - early)
        pair["delivered_ids"] = 192
        pair["long_prefill_widths"] = [slot["width"] for slot in prefill]
        pair["long_tokens_before_short"] = prior_cuts[-1]["cursor"]
        report.append(pair)

    return {
        "matched_output_ids": sum(map(len, outputs.values())),
        "activated_pairs": len(report) if enabled else 0,
        "pair_receipts": report,
        "median_short_offered_ttft_ms": median(r["short"]["offered_ttft_ms"] for r in report),
        "median_long_offered_ttft_ms": median(r["long"]["offered_ttft_ms"] for r in report),
        "median_short_maximum_gap_ms": median(r["short"]["maximum_gap_ms"] for r in report),
        "median_burst_output_tps": median(r["burst_output_tps"] for r in report),
    }


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--arm", choices=tuple(ARMS))
    for key in ("binary", "pack", "link-root", "out"):
        cli.add_argument("--" + key, type=Path)
    cli.add_argument("--check-inputs", action="store_true")
    args = cli.parse_args()

    pairs, values = corpus_inputs()
    oracle = read(ROOT / "prior-output.json")
    assert all(len(oracle[v["id"]]) == 96 for v in values)
    if args.check_inputs:
        print("Verified four 8K and 512-token pairs with a fixed half-second arrival offset.")
        return
    assert args.arm is not None
    enabled = ARMS[args.arm]
    build = read(ROOT / "build.json")
    assert build["codesign_verified"] and mixed.digest(args.binary) == build["server_sha256"]
    assert mixed.digest(ROOT / "source.patch") == build["patch_sha256"]
    inventory = read(ROOT / "mxfp4-inventory.json")
    before = mixed.native.validate_inventory(args.pack, inventory, args.link_root)
    assert before["model-manifest.json"] == frozen.MANIFEST
    args.out.mkdir()
    corpus = args.out / "bursts.jsonl"
    corpus.write_text("".join(json.dumps(v, separators=(",", ":")) + "\n" for v in values))
    prompts = {row.id: row for row in mixed.bench.load_corpus(corpus)}
    env = {"AX_MLX_FLASH_NEXT_ALIGNED_BUFFERED": "0", "AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0",
           "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": "1", "AX_MLX_FLASH_NEXT_SHORT_PREFILL_FIRST": str(int(enabled)),
           "RUST_LOG": "info,ax_engine_mlx::flash_next_startup=debug"}
    options = ("--disable-ngram-acceleration", "--total-blocks", "2048", "--max-batch-tokens", "2049",
               *mixed.RESERVE_OPTIONS)
    cpu = [mixed.native.wait_for_quiet()["cpu_idle_percent"]]
    label = args.arm
    with mixed.server(args, label, mixed.MODEL, args.pack, 2, env=env, options=options,
                      stream_experts="auto", guard=True) as (base, owner):
        result, trace = mixed.run_workload(args, base, owner, label, 2, corpus)
        drained = mixed.wait_drained(base)
        assert json.loads(mixed.native.request(base, "/health"))["status"] == "ok"
    cpu.append(mixed.native.cpu_idle_percent())
    trace_data = read(trace)
    (args.out / "capture-metadata.json").write_text(json.dumps(
        {"cpu_idle_percent": cpu, "drained": drained, "manifest": before, "flags": env},
        indent=2, allow_nan=False,
    ) + "\n")
    summary = examine(label, pairs, prompts, oracle, result, trace_data)
    log = args.out / f"{label}.log"
    text = log.read_text()
    assert "decision=resident" in text and "reader=Mapped" in text
    for old, new in ((str(args.pack), "[pack]"), (str(ROOT), "[run]"), (str(Path.home()), "[home]"),
                     ("127.0.0.1", "[loopback]")):
        text = text.replace(old, new)
    log.write_text(text)
    samples = [json.loads(row) for row in (args.out / f"{label}-samples.jsonl").read_text().splitlines()]
    assert samples and all(item["pressure"] == 1 for item in samples)
    assert mixed.native.validate_inventory(args.pack, inventory, args.link_root) == before
    record = {"arm": label, "build": build, "scope": "Guarded two-slot crossover at scheduled burst arrivals",
              "qualification": False, "flags": env, "cpu_idle_percent": cpu,
              "timing_eligible": min(cpu) >= 90, "summary": summary, "drained": drained, "manifest": before,
              "normal_pressure_samples": len(samples), "corpus_sha256": mixed.digest(corpus),
              "max_footprint_bytes": max(item["footprint_bytes"] for item in samples)}
    (args.out / "receipt.json").write_text(json.dumps(record, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
