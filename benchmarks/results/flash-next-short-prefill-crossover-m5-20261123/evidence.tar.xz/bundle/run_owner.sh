#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
natural=$1
reference=$2
fresh=$3
required=$4
slot="$HOME/build/.ax-flash-next-native-test-slot"
export PATH="$HOME/.venvs/ax-engine/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
owned=0

release_slot() {
    if (( owned )) && test "$(cat "$slot/owner.pid" 2>/dev/null)" = "$$"; then
        rm "$slot/owner.pid"
        rmdir "$slot"
    fi
    owned=0
}

finish() {
    code=$?
    release_slot
    printf '%s\n' "$code" > status.txt
}
trap finish EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM

shasum -a 256 -c inputs.sha256 >/dev/null
codesign --verify --strict ax-engine-server
test "$(sysctl -n hw.model hw.memsize)" = "$(printf 'Mac17,6\n137438953472')"
test "$(cat "$fresh/status.txt")" = 0
cache="$fresh/fresh-cache/models--AutomatosX--AX-Qwen3.8-Flash-Next-MLX-AXQ-MXFP4-MTP"
pack="$cache/snapshots/ff2a28485eb89bb60e8fe35dd6c65c51e63ee7b3"
test -d "$pack"
python="$HOME/.venvs/ax-engine/bin/python"
ref_python="$HOME/build/flash-next-official-20260923/launch-reference-env/bin/python"
lib=$("$python" -B -c 'from importlib.metadata import distribution,version; assert version("mlx")==version("mlx-metal")=="0.32.4"; print(distribution("mlx").locate_file("mlx/lib"))')
expected=$("$python" -B -c 'import json; print(json.load(open("build.json"))["libmlx_sha256"])')
test "$(shasum -a 256 "$lib/libmlx.dylib" | awk '{print $1}')" = "$expected"
deadline=$((SECONDS+57600))
for prerequisite in "$natural" "$required"; do
    until test -s "$prerequisite/status.txt"; do
        (( SECONDS < deadline )) || exit 75
        kill -0 "$(cat "$prerequisite/owner.pid")"
        sleep 30
    done
done
mkdir observed
for arm in fifo-first short-first short-second fifo-second; do
    while (( SECONDS < deadline )); do
        if test "$(sysctl -n kern.memorystatus_vm_pressure_level)" = 1 && mkdir "$slot" 2>/dev/null; then
            printf '%s\n' "$$" > "$slot/owner.pid"
            owned=1
            if ! ps -axo comm= | grep -Eq '/(ax-engine-server[^/]*|mtp-audit|direct_weights|ax-flash-shared-load-test|ax-ple-reader-test)$'; then
                if test -s "$reference/status.txt"; then break; fi
                kill -0 "$(cat "$reference/owner.pid")"
                if ! test -s "$reference/headroom.jsonl"; then
                    (cd "$reference" && "$ref_python" -B recover.py --preflight) > "capacity-$arm.json"
                    if "$python" -B -c 'import json,sys; r=json.load(open(sys.argv[1]))["capacity"]; sys.exit(not (r["reason"]=="background-rss-exceeds-signed-margin" and r["pressure"]==1))' "capacity-$arm.json"; then break; fi
                fi
            fi
            release_slot
        fi
        sleep 30
    done
    test "$owned" = 1
    printf '%s starting\n' "$arm"
    /usr/bin/caffeinate -i /usr/bin/env -i HOME="$HOME" PATH="$PATH" DYLD_LIBRARY_PATH="$lib" \
        PYTHONDONTWRITEBYTECODE=1 "$python" -B -u run_short_first_crossover.py --arm "$arm" \
        --binary "$PWD/ax-engine-server" --pack "$pack" --link-root "$cache" --out "$PWD/observed/$arm"
    printf '%s complete\n' "$arm"
    release_slot
done
shasum -a 256 -c inputs.sha256 >/dev/null
