"""Read cumulative Darwin host CPU ticks around the native diagnostic."""
import ctypes
import json
import time

CPU_STATES = ("user", "system", "idle", "nice")
HOST_CPU_LOAD_INFO = 3


def host_reader():
    mach = ctypes.CDLL(None)
    mach.mach_host_self.argtypes = ()
    mach.mach_host_self.restype = ctypes.c_uint
    mach.host_statistics.argtypes = (ctypes.c_uint, ctypes.c_int, ctypes.c_void_p,
                                      ctypes.POINTER(ctypes.c_uint))
    mach.host_statistics.restype = ctypes.c_int
    host = mach.mach_host_self()

    def read(kind):
        ticks = (ctypes.c_uint32 * len(CPU_STATES))()
        count = ctypes.c_uint(len(ticks))
        status = mach.host_statistics(host, HOST_CPU_LOAD_INFO, ctypes.byref(ticks), ctypes.byref(count))
        if status != 0 or count.value != len(ticks):
            raise RuntimeError("Darwin HOST_CPU_LOAD_INFO failed")
        return {"kind": kind, "monotonic_ns": time.monotonic_ns(),
                "ticks": dict(zip(CPU_STATES, ticks, strict=True))}
    return read


def record(output, stop, read):
    with output.open("x") as stream:
        def sample(kind):
            stream.write(json.dumps(read(kind), separators=(",", ":")) + "\n")
            stream.flush()

        sample("start")
        while not stop.wait(1):
            sample("sample")
        sample("end")
