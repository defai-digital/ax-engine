"""Collect one resident startup arm with independent reference priority between arms."""
from hashlib import file_digest
import json
from pathlib import Path
import re
import subprocess
import time
import sys
from unittest.mock import patch

import run_flash_next_lifecycle as lifecycle

OVERRIDE = "AX_MLX_FLASH_NEXT_MTP_SIDECAR_PREFETCH"
MANIFEST = "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef"
PREFETCH = re.compile(r"Flash Next MTP sidecar prefetch completed.*?bytes=5214301696\b")


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def sample_vm():
    raw = subprocess.check_output(["/usr/bin/vm_stat"], text=True)
    match = re.search(r"page size of ([0-9]+) bytes", raw)
    require(match is not None, "Missing VM page size")
    counters = {key.lower(): int(value) for key, value in
                re.findall(r"^([^:\n]+): +([0-9]+)\.?$", raw, re.MULTILINE)}
    keys = ("pageins", "pageouts", "compressions", "decompressions", "swapins", "swapouts")
    require(all(key in counters for key in keys), "Missing expected VM counters")
    return {"monotonic": time.monotonic(), "page_size": int(match[1]),
            **{key: counters[key] for key in keys}}


def main():
    arm = sys.argv[1]
    require(arm in {"traced-auto"}, "Unknown comparison arm")
    pack, cache, output = map(Path, sys.argv[2:])
    inventory_path = Path("mxfp4-inventory.json")
    inventory = json.loads(inventory_path.read_text())
    expected = {"model-manifest.json": MANIFEST}
    require(len(inventory["members"]) == 49, "Expected 49 publisher members")
    binary = Path("ax-engine-server").resolve()
    native = lifecycle.native
    server_sha = digest(binary)
    inventory_sha = digest(inventory_path)
    before = native.validate_inventory(pack, inventory, cache)
    require(before == expected, "Retained manifest mismatch")
    output.mkdir(parents=True, exist_ok=False)
    idle_before = native.wait_for_quiet()
    server_env = native.server_env
    automatic = True
    override = {"RUST_LOG": "info,ax_engine_mlx::flash_next_startup=debug"}
    vm_before = sample_vm()
    with patch.object(native, "server_env", lambda: server_env(override)):
        run = lifecycle.run_mode(binary, pack, output, "default")
    vm_after = sample_vm()
    idle_after = native.cpu_idle_percent()
    after = native.validate_inventory(pack, inventory, cache)
    require(after == before and digest(binary) == server_sha and digest(inventory_path) == inventory_sha,
            "Input digest changed during serving")
    log_path = output / "server-default.log"
    log = log_path.read_text().replace(str(Path.cwd()), "[run]")
    log_path.write_text(log)
    plain = re.sub(r"\x1b\[[0-9;]*m", "", log)
    phases = {}
    for match in re.finditer(
        r'Flash Next startup phase phase="([a-z_]+)" elapsed_us=([0-9]+)', plain
    ):
        phase, duration = match.groups()
        require(phase not in phases, f"Duplicate startup phase: {phase}")
        phases[phase] = int(duration)
    require({"resident_tensors", "mtp_sidecar", "trunk_assembly"}.issubset(phases),
            "Required launch phase traces are missing")
    require("decision=resident" in log and run["final_verified_steps"] == 0 and run["exit_code_after_stop"] == 0,
            "Expected resident direct decoding and clean shutdown")
    require(bool(PREFETCH.search(log)) == automatic and "sidecar prefetch failed" not in log,
            "Observed sidecar read route disagrees with the arm")
    data = {"arm": arm, "override": override, "manifest_before": before, "manifest_after": after,
            "server_sha256": server_sha, "inventory_sha256": inventory_sha, "publisher_members": 49,
            "cpu_idle_before": idle_before["cpu_idle_percent"], "cpu_idle_after": idle_after,
            "ready_seconds": run["ready_seconds"], "run": run, "automatic_prefetch_observed": automatic}
    data["startup_phases_microseconds"] = phases
    data["vm_counters"] = {"before": vm_before, "after": vm_after}
    (output / "result.json").write_text(json.dumps(data, indent=2) + "\n")


if __name__ == "__main__":
    main()
