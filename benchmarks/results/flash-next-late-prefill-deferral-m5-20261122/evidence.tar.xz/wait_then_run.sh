#!/bin/bash
set -euo pipefail
source="$1"
binary_hash="$2"
cache="$3"
half="$4"
deadline=$((SECONDS + 14400))
echo waiting-for-half-rate-comparison
while test ! -s "$half/status.txt"; do
    kill -0 "$(cat "$half/owner.pid")" 2>/dev/null && (( SECONDS < deadline )) || exit 2
    sleep 15
done
test "$(cat "$source/status.txt")" = 0
cp "$source/ax-engine-server-layer-http" .
test "$(shasum -a 256 ax-engine-server-layer-http | awk '{print $1}')" = "$binary_hash"
exec bash run_m5.sh "$cache"
