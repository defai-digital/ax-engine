"""Measure waiting for the last twelve short decode tokens before long prefill."""

from argparse import ArgumentParser
from concurrent.futures import ThreadPoolExecutor
import json
from math import isclose
from pathlib import Path
from threading import Event
from time import perf_counter

import capture_layer_steps as capture
import run_layer_http as layer

mixed = layer.mixed
bench = mixed.bench
require = layer.require
ROOT = Path(__file__).resolve().parent
TRIGGER_TOKEN = 84
LOGICAL = 2048
SPLIT_WIDTHS = [512, 512, 512, 511, 1]
ARMS = (("physical-1", False), ("deferred-1", True), ("deferred-2", True), ("physical-2", False))


def burst(base, cases, expected, deferred, raw_path):
    short, long = cases
    begin = perf_counter()
    ready = Event()
    short_finished = Event()
    trigger = []

    def stream(case):
        if case is long:
            if not ready.wait(timeout=20):
                raise TimeoutError("Short stream did not reach the trigger token")
            if deferred and not short_finished.wait(timeout=90):
                raise TimeoutError("The short stream did not finish")
        started = perf_counter()
        scheduled = begin + trigger[0]["seconds"] if case is long else started
        payload = {"model": mixed.MODEL, "input_tokens": case.input_tokens,
                   "max_output_tokens": case.max_output_tokens,
                   "sampling": {"temperature": 0, "ignore_eos": True}}
        events = []
        visible = 0
        for kind, data, elapsed in bench.http_sse_events(
                f"{base}/v1/generate/stream", payload, 90, started=started):
            events.append((kind, data, elapsed))
            visible += bench.delta_token_count(kind, data)
            if case is short and not ready.is_set() and visible >= TRIGGER_TOKEN:
                require(visible == TRIGGER_TOKEN, "Short stream skipped the trigger token")
                trigger.append({"seconds": started + elapsed - begin, "step_id": data["step"]["step_id"]})
                ready.set()
        done = perf_counter()
        if case is short:
            short_finished.set()
        result = bench.observe_stream(events, prompt=case, scheduled_at_s=scheduled,
                                      started_at_s=started, completed_at_s=done, record_token_ids=True)
        require(result["ok"] and result["output_token_ids"] == expected[case.id]
                and result["prompt_token_ids"] == case.input_tokens, "Stream token identity changed")
        result["started_at_s"] = started - begin
        result["scheduled_at_s"] = scheduled - begin
        return result, capture.trace_stream(events)

    with ThreadPoolExecutor(max_workers=2) as workers:
        first, second = workers.submit(stream, short), workers.submit(stream, long)
        short_result, short_trace = first.result()
        long_result, long_trace = second.result()
    raw = {"trigger": trigger, "trigger_token": TRIGGER_TOKEN,
           "observations": [short_result, long_result], "traces": [short_trace, long_trace]}
    raw_path.write_text(json.dumps(raw, indent=2, allow_nan=False) + "\n")
    return raw | verify_deferral(raw, deferred) | {"drained": mixed.wait_drained(base)}


def verify_deferral(raw, deferred):
    from run_late import verify_late_trace

    short, long = raw["traces"]
    short_result, long_result = raw["observations"]
    offered = raw["trigger"][0]["seconds"]
    started = long_result["started_at_s"]
    short_done = short_result["started_at_s"] + short_result["e2e_latency_ms"] / 1000
    require(isclose(long_result["scheduled_at_s"], offered, abs_tol=1e-9)
            and isclose(long_result["queue_delay_ms"], (started - offered) * 1000, abs_tol=0.001),
            "Client wait was omitted from long-request timing")
    if deferred:
        require(offered < short_done <= started,
                "The deferred long request dispatched before short completion")
        require(raw["trigger_token"] == TRIGGER_TOKEN
                and short["decode_step_ids"][TRIGGER_TOKEN - 1] == raw["trigger"][0]["step_id"]
                and len(short["decode_step_ids"]) == len(long["decode_step_ids"]) == 96
                and short["cursor"] == 512 and long["cursor"] == 8192,
                "The deferred arm changed request or token geometry")
        require(not short["partial"] and not long["partial"]
                and len(long["prefill"]) == 4
                and all(row["scheduled"] == 1 and row["split_end"] is None and row["width"] == LOGICAL
                        and row["step_id"] > short["decode_step_ids"][-1]
                        for row in long["prefill"])
                and [row["cursor"] for row in long["prefill"]] == [2048, 4096, 6144, 8192],
                "The delayed long request overlapped or changed native boundaries")
    else:
        verify_late_trace(raw, False)

    tail = short_result["stream_step_interval_ms"][TRIGGER_TOKEN - 1:]
    require(len(tail) == 96 - TRIGGER_TOKEN, "Short tail samples do not match the trigger")
    return {
        "deferral": deferred,
        "short_tail_gap_p95_ms": bench.percentile(tail, 0.95),
        "short_tail_max_gap_ms": max(tail),
        "long_dispatch_wait_ms": long_result["queue_delay_ms"],
        "long_call_ttft_ms": long_result["ttft_ms"],
        "long_offered_ttft_ms": long_result["queue_delay_ms"] + long_result["ttft_ms"],
        "long_scheduled_widths": [row["width"] for row in long["prefill"]],
    }


def main():
    parser = ArgumentParser(description=__doc__)
    for name in ("binary", "pack", "link-root", "out"):
        parser.add_argument(f"--{name}", type=Path)
    parser.add_argument("--check-inputs", action="store_true")
    args = parser.parse_args()
    _, cases, expected = layer.files()["ending-decoder"]
    require(cases[0].max_output_tokens == cases[1].max_output_tokens == 96, "Unexpected token budget")
    if args.check_inputs:
        print("Verified the late-arrival prompts and all 192 solo output IDs.")
        return
    build = json.loads((ROOT / "build.json").read_bytes())
    inventory = json.loads((ROOT / "mxfp4-inventory.json").read_bytes())
    require(mixed.digest(args.binary) == build["server_sha256"], "Binary differs from build receipt")
    manifest = mixed.native.validate_inventory(args.pack, inventory, args.link_root)
    require(manifest.get("model-manifest.json") ==
            "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef",
            "The delivered manifest changed")
    args.out.mkdir()
    record = {"qualification": False, "build": build, "pack_revision": inventory["revision"], "manifest": manifest,
              "inventory_sha256": mixed.digest(ROOT / "mxfp4-inventory.json"), "arms": {}}

    def save(status):
        record["status"] = status
        temporary = args.out / "receipt.tmp"
        temporary.write_text(json.dumps(record, indent=2, allow_nan=False) + "\n")
        temporary.replace(args.out / "receipt.json")
        print(status, flush=True)

    options = ("--disable-ngram-acceleration", "--total-blocks", "2048", "--max-batch-tokens", "2049",
               *mixed.RESERVE_OPTIONS)
    try:
        for name, deferred in ARMS:
            save(f"{name}-starting")
            quiet = mixed.native.wait_for_quiet()
            env = {"AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0", "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": "1",
                   "AX_MLX_FLASH_NEXT_PREFILL_LAYER_YIELD": "0"}
            with mixed.server(args, name, mixed.MODEL, args.pack, 2, env=env, options=options,
                              stream_experts="auto", guard=True) as (base, _):
                require("decision=resident" in (args.out / f"{name}.log").read_text(), "Resident experts required")
                data = burst(base, cases, expected, deferred, args.out / f"{name}.partial.json")
                require(json.loads(mixed.native.request(base, "/health"))["status"] == "ok", "Health declined")
            path = args.out / f"{name}.json"
            path.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")
            samples = [json.loads(line) for line in (args.out / f"{name}-samples.jsonl").read_text().splitlines()]
            require(samples and all(row["pressure"] == 1 for row in samples), "Memory pressure exceeded normal")
            record["arms"][name] = {
                "deferral": deferred,
                "cpu_idle_before_percent": quiet["cpu_idle_percent"], "cpu_idle_after_percent": mixed.native.cpu_idle_percent(),
                "sample_count": len(samples), "data_sha256": mixed.digest(path),
            }
            save(f"{name}-complete")
        require(mixed.native.validate_inventory(args.pack, inventory, args.link_root) == manifest, "Pack changed")
        save("complete")
    except Exception:
        save("failed")
        raise


if __name__ == "__main__":
    main()
