"""Replay the six-arm fixed-geometry selective prefill experiment."""
import json
from pathlib import Path

import audit_flash_next_mixed_serving as audit
import run_selective_mixed as measure


def main(original_solo_sha256=None):
    root = Path(__file__).resolve().parent
    result = root / 'mixed-result'
    receipt = audit.read_json(result / 'receipt.json')
    workload, corpus, case_list = measure.workload()
    prompts = {case.id: case for case in case_list}
    solo = root / 'solo-reference.json'
    protocol = audit.read_json(root / 'protocol.json')
    audit.require(receipt['status'] == 'complete' and receipt['split_activation_confirmed'] is True
                  and tuple(receipt['arms']) == tuple(arm for arm, _ in measure.ARMS), 'incomplete mixed campaign')
    audit.require(receipt['protocol_sha256'] == measure.digest(root / 'protocol.json')
                  and receipt['driver_sha256'] == measure.digest(root / 'run_selective_mixed.py')
                  and receipt['capture_sha256'] == measure.digest(root / 'capture_mixed_steps.py')
                  and receipt['binary_sha256'] == audit.read_json(root / 'build.json')['server_sha256']
                  and receipt['workload'] == workload
                  and protocol['solo_sha256'] == (original_solo_sha256 or measure.digest(solo)),
                  'mixed campaign source binding')
    original = measure.verify_rows(audit.read_json(solo), case_list)
    audit.ARMS = {name: (2, policy != 'off') for name, policy in measure.ARMS}
    arms = {}
    measurements = {}
    for name, policy in measure.ARMS:
        metadata = receipt['arms'][name]
        audit.require(metadata['policy'] == policy, f'{name}: treatment label')
        measure.verify_treatment(policy, metadata['split_activation'])
        floor = measure.MIN_PROMPT if policy == "long" else audit.PREFILL_ITEM
        arms[name], outputs, measurements[name] = audit.audit_arm(
            result, name, metadata, workload, prompts, split_min_prompt_tokens=floor,
        )
        artifact = audit.read_json(result / f"{name}.json")
        trace = audit.read_json(result / f"{name}-steps.json")
        activation = measure.capture.summarize_activation(trace, artifact["observations"])
        audit.require(activation == metadata["split_activation"], f"{name}: split activation differs from raw traces")
        audit.require(outputs == original, f'{name}: output differs from original solo reference')
    phases = (("long-1", "off-1"), ("long-1", "all-1"), ("long-2", "all-2"), ("long-2", "off-2"))
    print(json.dumps({
        'source_sha256': measure.digest(result / 'receipt.json'),
        'binary_sha256': receipt['binary_sha256'],
        'arms': arms,
        'paired_deltas_ms': {f'{current}_vs_{prior}': audit.compare(measurements[current], measurements[prior])
                            for current, prior in phases},
    }, indent=2, allow_nan=False))


if __name__ == '__main__':
    main()
