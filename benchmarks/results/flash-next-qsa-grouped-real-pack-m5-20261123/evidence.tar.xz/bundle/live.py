"""Compare guarded QSA tile evaluation in a fresh process for each arm."""

import argparse
from importlib.metadata import version
import json
import os
from pathlib import Path
import plistlib
import signal
import subprocess
from threading import Event, Thread

import check_flash_next_native_support as native
from run_qwen38_reference_serving import monitor_memory

ROOT = Path(__file__).resolve().parent
TEST = "model::qwen4_exp::profiling::flash_next_grouped_qsa_tile_eval_exactness_and_memory"
CAP_BYTES = 96 << 30
ARMS = ((2048, 0), (2048, 2), (2048, 2), (2048, 0))


def publish(path, data):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(data, indent=2, sort_keys=True, allow_nan=False) + "\n")
    temporary.replace(path)


def run_arm(out, binary, pack, width, group, position):
    name = f"{position:02d}-width{width}-group{group}"
    case = out / name
    case.mkdir()
    print(f"{name} starting", flush=True)
    environment = os.environ | {
        "AX_MLX_NATIVE_CONFIRM": "1",
        "AX_FLASH_NEXT_PROFILE_PACK": str(pack),
        "AX_FLASH_NEXT_PROMPT_IDS_FILE": str(ROOT / "prompt.json"),
        "AX_FLASH_NEXT_PROFILE_OUTPUT": str(case / "result.json"),
        "AX_FLASH_NEXT_SERIAL_QSA_WIDTH": str(width),
        "AX_FLASH_NEXT_QSA_EVAL_GROUP": str(group),
    }
    idle_before = native.cpu_idle_percent()
    timed_out = False
    with (case / "native.log").open("w") as log:
        child = subprocess.Popen(
            [binary, "--ignored", "--exact", TEST, "--nocapture"],
            env=environment,
            stdout=log,
            stderr=log,
        )
        stop = Event()
        monitor = Thread(target=monitor_memory, args=(case, "native", child, stop))
        monitor.start()
        try:
            exit_code = child.wait(timeout=600)
        except subprocess.TimeoutExpired:
            timed_out = True
            child.terminate()
            try:
                exit_code = child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                child.kill()
                exit_code = child.wait()
        finally:
            stop.set()
            monitor.join()
    idle_after = native.cpu_idle_percent()
    samples = [
        json.loads(line)
        for line in (case / "native-samples.jsonl").read_text().splitlines()
    ]
    assert samples
    peak = max(row["footprint_bytes"] for row in samples)
    pressure_normal = all(row["pressure"] == 1 for row in samples)
    guard = peak > CAP_BYTES or any(row["pressure"] in (4, 8) for row in samples)
    result = None
    result_digest = None
    if exit_code == 0:
        assert "1 passed" in (case / "native.log").read_text()
        result_path = case / "result.json"
        result = json.loads(result_path.read_bytes())
        result_digest = native.sha256(result_path)
        assert result["width"] == width and result["evaluation_group"] == group
        assert (result["completed_tiles"] > 0) == (group > 0)
        fences = result["evaluation_fences"]
        tiles = result["completed_tiles"]
        if group == 2:
            assert 0 < fences < tiles <= 2 * fences
        else:
            assert (fences, tiles) == (0, 0)
        assert result["qualification"] is False
    elif guard:
        assert exit_code == -signal.SIGTERM
    receipt = {
        "arm": name, "width": width, "evaluation_group": group,
        "cpu_idle_percent": [idle_before, idle_after],
        "exit_code": exit_code, "timeout": timed_out, "guard_triggered": guard,
        "peak_physical_bytes": peak, "pressure_samples": len(samples),
        "all_pressure_normal": pressure_normal, "result_sha256": result_digest,
        "passed": exit_code == 0 and pressure_normal and not guard,
    }
    publish(case / "receipt.json", receipt)
    print(f"{name} finished exit={exit_code} guard={guard}", flush=True)
    return receipt, result


def storage_info(pack):
    device = subprocess.check_output(["df", "-P", pack], text=True).splitlines()[-1].split()[0]
    info = plistlib.loads(subprocess.check_output(["diskutil", "info", "-plist", device]))
    assert info["SolidState"] is True
    return {"internal": info["Internal"], "solid_state": True, "bus_protocol": info["BusProtocol"]}


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--pack", type=Path, required=True)
    cli.add_argument("--link-root", type=Path)
    cli.add_argument("--out", type=Path, required=True)
    args = cli.parse_args()
    inventory = json.loads((ROOT / "mxfp4-inventory.json").read_bytes())
    assert len(inventory["members"]) == 49 and version("mlx") == version("mlx-metal") == "0.32.4"
    before = native.validate_inventory(args.pack, inventory, args.link_root)
    build = json.loads((ROOT / "build.json").read_bytes())
    binary = ROOT / "ax-flash-grouped-qsa-test"
    assert before["model-manifest.json"] == build["manifest_sha256"]
    for filename, key in (
        (binary.name, "binary_sha256"),
        ("prompt.json", "prompt_sha256"),
        ("source.patch", "patch_sha256"),
    ):
        assert native.sha256(ROOT / filename) == build[key]
    args.out.mkdir()
    native.wait_for_quiet()
    cases = [run_arm(args.out, binary, args.pack, width, group, position)
             for position, (width, group) in enumerate(ARMS)]
    assert native.validate_inventory(args.pack, inventory, args.link_root) == before
    fields = ("logits_sha256", "logit_count", "state_sha256", "state_bytes")
    finished = [result for receipt, result in cases if receipt["passed"]]
    exact = None
    if len(finished) == len(ARMS):
        original = finished[0]
        assert all([row[:2] for row in result["chunks"]] == [row[:2] for row in original["chunks"]]
                   for result in finished)
        exact = all(all(result[key] == original[key] for key in fields) for result in finished)
    publish(args.out / "receipt.json", {
        "qualification": False, "build": build, "manifest": before,
        "execution_arm_order": [case[0]["arm"] for case in cases],
        "identical_state_and_logits": exact,
        "soc": subprocess.check_output(["sysctl", "-n", "machdep.cpu.brand_string"], text=True).strip(),
        "memory_bytes": int(subprocess.check_output(["sysctl", "-n", "hw.memsize"], text=True)),
        "macos": subprocess.check_output(["sw_vers", "-productVersion"], text=True).strip(),
        "storage": storage_info(args.pack),
        "physical_cap_bytes": CAP_BYTES,
    })
    assert exact is not False


if __name__ == "__main__":
    main()
