#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
natural=$1
reference=$2
test "$(cat "$natural/status.txt")" = 0
slot="$HOME/build/.ax-flash-next-native-test-slot"
mkdir "$slot" 2>/dev/null || exit 74
printf '%s\n' "$$" > "$slot/owner.pid"
paused=0
observer=
release() {
    if (( paused )) && [[ "$(ps -p "$observer" -o command= 2>/dev/null)" == *"wait_clean_window.sh "* ]]; then
        /bin/kill -CONT "$observer" || true
    fi
    if [[ "$(cat "$slot/owner.pid")" == "$$" ]]; then
        rm "$slot/owner.pid"
        rmdir "$slot"
    fi
}
trap release EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
/usr/bin/shasum -a 256 -c harness-inputs.sha256 >/dev/null
/usr/bin/shasum -a 256 -c runtime-inputs.sha256 >/dev/null
python="$HOME/.venvs/ax-engine/bin/python"
"$python" -B compare_delivery.py --preflight --scratch "$PWD"
if /bin/ps -axo comm= | /usr/bin/grep -Eq '/(ax-engine-server[^/]*|ax-flash-shared-load-test|ax-ple-reader-test|direct_weights)$'; then
    exit 74
fi
if [[ "$(/usr/sbin/sysctl -n kern.memorystatus_vm_pressure_level)" != 1 ]]; then
    exit 74
fi
if ! test -s "$reference/status.txt"; then
    if test -s "$reference/clean-preflight.json" || test -s "$reference/headroom.jsonl"; then
        exit 74
    fi
    owner=$(cat "$reference/owner.pid")
    observer=$(pgrep -P "$owner")
    [[ "$observer" =~ ^[0-9]+$ ]]
    [[ "$(ps -p "$observer" -o command=)" == *"wait_clean_window.sh "* ]]
    /bin/kill -STOP "$observer"
    paused=1
    [[ "$(ps -p "$observer" -o state=)" == T* ]]
    children=$(ps -axo ppid=,comm= | awk -v p="$observer" '$1 == p {sub(/^.*\//,"",$2); print $2}')
    [[ "$children" == "" || "$children" == sleep ]]
    if test -s "$reference/clean-preflight.json" || test -s "$reference/headroom.jsonl"; then
        exit 74
    fi
    (
        cd "$reference"
        export PATH="/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
        exec "$HOME/build/flash-next-official-20260923/launch-reference-env/bin/python" -B recover.py --preflight
    ) > reference-capacity-before-pair.json
    "$python" -B - <<'PROBE'
import json
from pathlib import Path
reading=json.loads(Path("reference-capacity-before-pair.json").read_bytes())["capacity"]
if (reading["eligible_for_attempt"] or reading["pressure"] != 1
        or reading["reason"] != "background-rss-exceeds-signed-margin"):
    print("Reserve the standard device for the independent reference run.", flush=True)
    raise SystemExit(74)
PROBE
fi
test ! -e cache
/usr/bin/codesign --verify --strict ./ax-engine
/usr/bin/codesign --verify --strict ./ax-engine-server
mlx=$("$python" -B -c 'from importlib.metadata import distribution,version; assert version("mlx")==version("mlx-metal")=="0.32.4"; print(distribution("mlx").locate_file("mlx/lib"))')
expected=$("$python" -B -c 'import json; print(json.load(open("build.json"))["libmlx_sha256"])')
test "$(shasum -a 256 "$mlx/libmlx.dylib" | awk '{print $1}')" = "$expected"
/usr/bin/caffeinate -dimsu /usr/bin/env -i HOME="$HOME" \
    PATH="$HOME/.venvs/ax-engine/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin" \
    DYLD_LIBRARY_PATH="$mlx" PYTHONDONTWRITEBYTECODE=1 \
    "$python" -B -u run_auto.py --cache "$PWD/cache"
