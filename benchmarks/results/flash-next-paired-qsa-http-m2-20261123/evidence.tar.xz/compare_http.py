"""Recompute the paired QSA serving comparison from sealed request records."""

from argparse import ArgumentParser
import json
from pathlib import Path

from run_http import BUDGET, FORWARD, SWITCH, TILES, cpu, matrix, native, qa


def read(path):
    return json.loads(path.read_bytes())


def comparisons(capture, arms):
    prompts = read(capture / "prompts.json")
    build = read(capture / "build.json")
    inventory = read(capture / "mxfp4-inventory.json")
    all_rows = {}
    expected_output = {}
    treatment_tiles = {}
    result = {}
    for arm in arms:
        folder = capture / "observed" / arm
        receipt = read(folder / "receipt.json")
        paired = arm.startswith("paired")
        assert receipt["build"] == build and receipt["mode"] == arm and not receipt["qualification"]
        assert receipt["flags"].get(SWITCH) == ("1" if paired else None)
        assert receipt["input_sha256"] == native.sha256(capture / "prompts.json")
        assert len(inventory["members"]) == 49
        assert receipt["pack_sha256"]["model-manifest.json"] == (
            "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef")
        assert receipt["model"] == {"id": qa.ORDINARY_MODEL_ID, "context_length": 32768}
        source = folder / "requests.jsonl"
        assert receipt["requests_sha256"] == native.sha256(source)
        rows = [json.loads(line) for line in source.read_text().splitlines()]
        all_rows[arm] = {r["prompt"]: r for r in rows if not r["warmup"]}
        assert set(all_rows[arm]) == set(prompts)
        assert len(rows) == len(prompts) + (len(arms) == 4)
        for row in rows:
            key = row["prompt"]
            ids = prompts[key]
            assert row["prompt_sha256"] == matrix.ids_sha(ids) and row["prompt_length"] == len(ids)
            assert row["finish_reason"] == "max_output_tokens" and len(row["output_tokens"]) == BUDGET
            expected = expected_output.setdefault(key, row["output_tokens"])
            assert row["output_tokens"] == expected, (arm, key)
            metrics = row["metrics_delta"]
            engaged = paired and len(ids) == 8192
            assert (metrics[TILES] > 0 if engaged else metrics[TILES] == 0), (arm, key)
            if engaged:
                assert metrics[TILES] == treatment_tiles.setdefault(key, metrics[TILES]), (arm, key)
            assert metrics[FORWARD] > 0 and not any(metrics[name] for name in (native.VERIFIED, *native.ERRORS))
            assert not any(row["resources_after"].values())
            ticks = cpu.tick_delta(row["host_ticks_before"], row["host_ticks_after"])
            assert 100 * ticks["idle"] / sum(ticks.values()) == row["request_host_idle_percent"]
        samples = [json.loads(line) for line in (folder / "server-samples.jsonl").read_text().splitlines()]
        assert len(samples) == receipt["pressure_samples"] > 0
        assert all(row["pressure"] == 1 for row in samples)
        assert receipt["peak_footprint_bytes"] == max(row["footprint_bytes"] for row in samples) <= 96 << 30
        result[arm] = {name: receipt[name] for name in ("peak_footprint_bytes", "peak_rss_bytes",
                                                        "pressure_samples", "ready_seconds")}

    orders = ("first", "second") if len(arms) == 4 else ("first",)
    paired_results = {}
    for order in orders:
        cells = {}
        for key in prompts:
            stock, paired = [all_rows[f"{mode}-{order}"][key] for mode in ("stock", "paired")]
            idle = [row["idle_percent_endpoints"] for row in (stock, paired)]
            eligible = all(v is not None and v >= 90 for bounds in idle for v in bounds)
            ttft = [row["client_timing"]["ttft_seconds"] for row in (stock, paired)]
            decode = [matrix.decode_rate(row["client_timing"]) for row in (stock, paired)]
            cells[key] = {
                "eligible_endpoints": eligible,
                "ttft_seconds": ttft,
                "paired_over_stock_ttft": ttft[1] / ttft[0],
                "decode_tokens_per_second": decode,
                "idle_endpoints": idle,
                "request_window_idle": [row["request_host_idle_percent"] for row in (stock, paired)],
                "prefill_forward_us": [row["metrics_delta"][FORWARD] for row in (stock, paired)],
                "paired_tiles": [row["metrics_delta"][TILES] for row in (stock, paired)],
            }
        paired_results[order] = cells

    return {
        "paired_output_ids": sum(map(len, expected_output.values())) * len(orders),
        "qualification": False, "paired_tiles": treatment_tiles, "orders": paired_results,
        "arms": result, "binary_sha256": build["binary_sha256"],
    }


if __name__ == "__main__":
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("capture", type=Path)
    cli.add_argument("--m5", action="store_true")
    args = cli.parse_args()
    arms = ("stock-first", "paired-first", "paired-second", "stock-second") if args.m5 else (
        "stock-first", "paired-first")
    result = comparisons(args.capture, arms)
    print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))
