"""Replay both native Flash Next prefill geometries from the signed HTTP suite."""
from argparse import ArgumentParser
from importlib.metadata import version
import json
import os
from pathlib import Path
from subprocess import Popen
from threading import Event, Thread

from check_flash_next_native_support import sha256, validate_inventory, stop_owned
from run_qwen38_reference_serving import monitor_memory

HERE = Path(__file__).resolve().parent
TEST = "runner::flash_next_tests::aligned_state_tests::flash_next_real_runner_prefill_geometry_witnesses"
BINARY = HERE / "ax-flash-prefill-geometry-test"


def one_arm(width, tiled, trace, pack, prompt, ids, output):
    output.mkdir()
    result = output / "result"
    flags = {
        "AX_FLASH_NEXT_DUMP_LAYER": "0",
        "AX_FLASH_NEXT_DUMP_POSITIONS": "0,457,458,459,1333,1334,1335,1900,1901,1902,2046",
        "AX_FLASH_NEXT_DUMP_STAGES": (
            "embedding,ple_operator,attention_hc_read,gdn_query_input,gdn_key_input,"
            "gdn_value_input,gdn_log_decay,gdn_beta,gdn_core_output,gdn_gated_output,gdn,"
            "qsa_normalized_query,qsa_normalized_key,qsa_attention_before_gate,qsa,"
            "attention_hc_write,mlp_hc_read,moe_router_logits,moe_indices,"
            "moe_down,moe_routed,"
            "moe_shared_gate,moe_shared_up,moe_shared_activation,moe_shared_input,"
            "moe_shared_down,moe_shared_router,moe_shared_score,moe_shared_output,"
            "moe_delta,moe_compute,mlp_hc_write"
        ),
        "AX_FLASH_NEXT_GDN_GEOMETRY_REPLAY": str(int(trace)),
        "AX_FLASH_NEXT_TRIAL_TILE_GDN_DECAY": str(int(tiled)),
        "AX_FLASH_NEXT_RECORD_GDN_TILING": "1",
        "AX_MLX_FLASH_NEXT_GDN_PREFILL_MLX": "1",
        "AX_MLX_FLASH_NEXT_QSA_GROUPED_EVAL": "0",
        "AX_MLX_FLASH_NEXT_QSA_PAIRED_GATHER": "0",
        "AX_MLX_FLASH_NEXT_QSA_INDEXED_PREFILL": "0",
        "AX_MLX_LONG_PROMPT_PREFILL_CHUNK": str(width),
        "AX_MLX_PREFIX_CACHE_DISK_DISABLED": "1",
        "AX_ENGINE_PREFIX_REUSE_DISABLED": "1",
        "AX_MLX_PREFIX_CACHE_MAX_BYTES": "0",
        "AX_MLX_PREFIX_CACHE_MAX_ENTRIES": "0",
    }
    environment = os.environ | flags | {
        "AX_FLASH_NEXT_FIRST_LAYER_DUMP": str(output / "operator"),
        "AX_FLASH_NEXT_REAL_PACK": str(pack),
        "AX_FLASH_NEXT_ALIGNED_RESULT_DIR": str(result),
        "AX_FLASH_NEXT_PROMPT_IDS": prompt,
        "AX_FLASH_NEXT_EXPECTED_IDS": json.dumps(ids),
        "AX_FLASH_NEXT_GEOMETRY_WIDTH": str(width),
    }
    with (output / "test.log").open("w") as log:
        proc = Popen([BINARY, TEST, "--exact", "--ignored", "--nocapture"],
                     env=environment, stdout=log, stderr=log, start_new_session=True)
        stop = Event()
        monitor = Thread(target=monitor_memory, args=(output, "native", proc, stop), daemon=True)
        monitor.start()
        try:
            status = proc.wait(timeout=720)
        finally:
            stop_owned(proc)
            stop.set()
            monitor.join(timeout=4)
    assert status == 0, (output / "test.log").read_text()[-4500:]
    assert "1 passed; 0 failed" in (output / "test.log").read_text(errors="replace")
    samples_path = output / "native-samples.jsonl"
    samples = [json.loads(line) for line in samples_path.read_text().splitlines()]
    assert samples and all(s["pressure"] == 1 and s["footprint_bytes"] <= 96 * 2**30 for s in samples)
    return {"flags": flags, "sample_count": len(samples), "samples_sha256": sha256(samples_path),
            "original_test_log_sha256": sha256(output / "test.log"),
            "result_sha256": sha256(result / "result.json"),
            "tiling_sha256": sha256(result / "tiling.json"),
            "operator_sha256": {
                file.name: sha256(file) for file in sorted((output / "operator").iterdir())
            },
            "recurrence_sha256": sha256(result / "recurrence.json") if trace else None,
            "sampled_footprint_peak_bytes": max(s["footprint_bytes"] for s in samples)}


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--pack", type=Path, required=True)
    cli.add_argument("--link-root", type=Path)
    cli.add_argument("--out", type=Path, required=True)
    args = cli.parse_args()
    build = json.loads((HERE / "build.json").read_text())
    assert version("mlx") == version("mlx-metal") == build["mlx"] == "0.32.4"
    assert sha256(BINARY) == build["binary_sha256"]
    assert sha256(HERE / "source.patch") == build["patch_sha256"]
    inventory = json.loads((HERE / "mxfp4-inventory.json").read_text())
    assert len(inventory["members"]) == 49
    verified = validate_inventory(args.pack, inventory, args.link_root)
    assert verified["model-manifest.json"] == build["manifest_sha256"]
    expected = json.loads((HERE / "prior-ids.json").read_text())
    prompt = (HERE / "prompt.json").read_text().strip()
    assert len(json.loads(prompt)) == 8192
    args.out.mkdir()
    arms = [("narrow-incoming-bridge", 512, False, False),
            ("wide-tiling-incoming-bridge", 2048, True, False)]
    for name, width, tiled, trace in arms:
        print(f"Starting {name}", flush=True)
        output = args.out / name
        arm = one_arm(width, tiled, trace, args.pack, prompt, expected[str(width)], output)
        (output / "receipt.json").write_text(json.dumps(arm, indent=2, sort_keys=True) + "\n")
        print(f"{name} passed", flush=True)
    assert validate_inventory(args.pack, inventory, args.link_root) == verified
    result = {"build": build, "test": TEST, "qualification": False, "manifest": verified,
              "prompt_sha256": sha256(HERE / "prompt.json"),
              "prior_ids_sha256": sha256(HERE / "prior-ids.json")}
    (args.out / "receipt.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
