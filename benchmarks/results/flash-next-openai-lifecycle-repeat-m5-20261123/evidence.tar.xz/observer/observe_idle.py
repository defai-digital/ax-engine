"""Sample cumulative engine steps and drained gauges during the owned idle interval."""

from pathlib import Path
from time import monotonic, sleep
import json
import re

from check_openai_concurrency import STEPS, mixed

root = Path("observed")
deadline = monotonic() + 900
while monotonic() < deadline and not Path("status.txt").exists():
    if (root / "round-4.json").is_file() and (root / "openai.log").is_file():
        break
    sleep(0.25)
else:
    raise RuntimeError("The owned server did not reach its idle interval")
if (root / "idle.json").exists():
    raise RuntimeError("The owned idle interval already ended")
log = (root / "openai.log").read_text()
url = re.search(r"listening on http://127\.0\.0\.1:(\d+)", log)
if not url:
    raise RuntimeError("The owned server did not report its loopback port")
base = f"http://127.0.0.1:{url[1]}"
started = monotonic()
with Path("idle-engine-samples.jsonl").open("x") as output:
    while not (root / "idle.json").exists():
        if monotonic() - started > 45 or Path("status.txt").exists():
            raise RuntimeError("The owned server did not finish its idle interval")
        metrics = mixed.native.metrics(mixed.native.request(base, "/metrics").decode())
        if (root / "idle.json").exists():
            break
        row = {"elapsed_seconds": monotonic() - started, "steps": metrics[STEPS],
               "work": {key: metrics[key] for key in mixed.COUNTERS},
               "health": json.loads(mixed.native.request(base, "/health"))["status"]}
        print(json.dumps(row, sort_keys=True, allow_nan=False), file=output, flush=True)
        sleep(0.5)
