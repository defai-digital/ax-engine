"""Repeat the guarded Flash Next OpenAI capacity test in one server process."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import platform
from time import monotonic, sleep

from check_openai_concurrency import (
    CHAT, COMPLETIONS, COMMIT, JOBS, MANIFEST, SCHEDULED, STEPS, STREAMS, WAITING,
    burst, chat, completed, completion, inputs, mixed, normalized, open_stream, require,
)

ROOT = Path(__file__).resolve().parent
ROUNDS = 8
IDLE_SECONDS = 30
COMPLETION_USAGE = {"prompt_tokens": 8192, "completion_tokens": 96, "total_tokens": 8288}
REPLY_ROLES = ("disconnected", "survivor", "replacement")


def read(path):
    return json.loads(path.read_bytes())


def save(path, result):
    path.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")


def sha(path):
    return sha256(path.read_bytes()).hexdigest()


def round_cases(pair, index):
    return pair if index % 2 == 0 else pair[::-1]


def check_round(record, earlier_steps, case_ids, prior_ids, baseline, index):
    victim, survivor = round_cases(case_ids, index)
    require(record["index"] == index + 1 and record["victim"] == victim
            and record["survivor"] == survivor and record["elapsed_seconds"] > 0
            and record["health"] == "ok", "Request order, duration, or health changed")
    observed = record["observed"]
    initial, queued, before, after = (observed[name] for name in
                                      ("initial", "observed_queue", "before_disconnect", "after_disconnect"))
    require(initial[JOBS] == initial[STREAMS] == 1 and initial[STEPS] > earlier_steps
            and queued[JOBS] == queued[STREAMS] == before[JOBS] == before[STREAMS] == 2
            and queued[WAITING] == queued[SCHEDULED] == 1
            and initial[STEPS] < queued[STEPS] <= before[STEPS] <= after[STEPS]
            and after[JOBS] == after[STREAMS] == 1,
            "A repeat failed to observe a waiting request, saturation or prompt slot release")
    require(observed["overload"] == {"status": 429, "code": "concurrency_limit"}
            and observed["disconnected"]["closed_after_first_content_event"] is True
            and observed["drained"] == dict.fromkeys(mixed.COUNTERS, 0),
            "Overload, disconnect or resource drain changed")
    require(normalized(observed["survivor"]) == normalized(baseline[survivor])
            and normalized(observed["replacement"]) == normalized(baseline["chat"]),
            "A surviving or replacement client changed its text, finish, or usage")
    ids = {observed[role]["request_id"] for role in REPLY_ROLES}
    require(len(ids) == len(REPLY_ROLES) and all(ids) and not ids & prior_ids,
            "An admitted request reused a prior SSE request ID")
    prior_ids.update(ids)
    return after[STEPS]


def idle(base):
    before = mixed.wait_drained(base)
    started = monotonic()
    sleep(IDLE_SECONDS)
    return {"before": before, "after": mixed.wait_drained(base),
            "health": json.loads(mixed.native.request(base, "/health"))["status"],
            "elapsed_seconds": monotonic() - started}


def health(base):
    return json.loads(mixed.native.request(base, "/health"))["status"]


def collect(base, cases, out):
    baseline = {}
    for case in cases:
        with open_stream(base, COMPLETIONS, completion(case)) as reply:
            result = completed(reply)
        require(result["finish_reason"] == "length" and result["usage"] == COMPLETION_USAGE,
                "Solo completion changed the frozen token budget")
        baseline[case.id] = result
        mixed.wait_drained(base)
    with open_stream(base, CHAT, chat()) as reply:
        baseline["chat"] = completed(reply)
    mixed.wait_drained(base)
    save(out / "baseline.json", baseline)

    case_ids = tuple(case.id for case in cases)
    ids = {value["request_id"] for value in baseline.values()}
    require(len(ids) == len(baseline) and all(ids), "Solo response IDs overlap")
    observed, earlier_steps, paused = [], -1, None
    for index in range(ROUNDS):
        if index == ROUNDS // 2:
            paused = idle(base)
            save(out / "idle.json", paused)
            require(paused["before"] == paused["after"] == dict.fromkeys(mixed.COUNTERS, 0)
                    and paused["health"] == "ok" and paused["elapsed_seconds"] >= IDLE_SECONDS,
                    "Server did not remain healthy and drained during the idle interval")
        pair = round_cases(cases, index)
        victim, survivor = (case.id for case in pair)
        started = monotonic()
        raw = burst(base, pair, {"completion": baseline[survivor], "chat": baseline["chat"]},
                    out / f"progress-{index+1}.json")
        record = {"index": index + 1, "victim": victim, "survivor": survivor, "observed": raw,
                  "elapsed_seconds": monotonic() - started, "health": health(base)}
        save(out / f"round-{index+1}.json", record)
        earlier_steps = check_round(record, earlier_steps, case_ids, ids, baseline, index)
        observed.append(record)
        print(f"OpenAI round {index+1}: overload, close, survival, replacement and drain verified.",
              flush=True)
    return baseline, observed, paused


def main():
    parser = ArgumentParser(description=__doc__)
    for field in ("binary", "cache", "out"):
        parser.add_argument(f"--{field}", type=Path)
    parser.add_argument("--check-inputs", action="store_true")
    args = parser.parse_args()

    cases = inputs()
    build = read(ROOT / "candidate-build.json")
    inventory = read(ROOT / "mxfp4-inventory.json")
    require(build["runtime_commit"] == COMMIT and build["codesign_verified"] is True
            and sha(ROOT / "gauge-fix.patch") == build["stream_gauge_patch_sha256"],
            "Guarded executable receipt or patch changed")
    if args.check_inputs:
        print(json.dumps({"requests": [case.id for case in cases], "rounds": ROUNDS, "idle_seconds": IDLE_SECONDS}))
        return

    require(args.binary is not None and args.cache is not None and args.out is not None,
            "Binary, delivered cache, and output directory are required")
    require(sha(args.binary) == build["server_sha256"], "Signed server bytes changed")
    pack = args.cache / f"models--{inventory['repo_id'].replace('/', '--')}" / "snapshots" / inventory["revision"]
    manifest = mixed.native.validate_inventory(pack, inventory, args.cache)
    require(manifest.get("model-manifest.json") == MANIFEST, "The delivered manifest changed")
    args.out.mkdir()
    flags = ("--disable-ngram-acceleration", "--total-blocks", "2048", "--max-batch-tokens", "2049",
             *mixed.RESERVE_OPTIONS)
    env = {"AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0", "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": "1",
           "AX_MLX_FLASH_NEXT_PREFILL_TAIL_DEFERRAL": "0"}
    with mixed.server(args, "openai", mixed.MODEL, pack, 2, env=env, options=flags,
                      stream_experts="auto", guard=True) as (base, _):
        require("decision=resident" in (args.out / "openai.log").read_text(), "Resident execution required")
        baseline, records, paused = collect(base, cases, args.out)
    mixed.native.scrub_log(args.out / "openai.log")
    samples = [json.loads(line) for line in (args.out / "openai-samples.jsonl").read_text().splitlines()]
    require(samples and {row["pressure"] for row in samples} == {1}, "Memory pressure exceeded normal")
    require(mixed.native.validate_inventory(pack, inventory, args.cache) == manifest
            and sha(args.binary) == build["server_sha256"], "Publisher bytes or executable changed")
    result = {"qualification": False, "hardware": "MacBook Pro M5 Max 128 GB", "os": platform.mac_ver()[0],
              "build": build, "pack_revision": inventory["revision"], "manifest": manifest,
              "case_ids": [case.id for case in cases], "baseline": baseline, "rounds": records,
              "idle": paused, "normal_pressure_samples": len(samples)}
    save(args.out / "receipt.json", result)


if __name__ == "__main__":
    main()
