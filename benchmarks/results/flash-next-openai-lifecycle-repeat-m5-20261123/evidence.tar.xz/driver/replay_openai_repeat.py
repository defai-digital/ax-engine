"""Replay ordered OpenAI lifecycle receipts against the frozen two-slot contract."""

from argparse import ArgumentParser
import json
from pathlib import Path

from run_openai_repeat import (
    COMPLETION_USAGE, IDLE_SECONDS, ROOT, ROUNDS, check_round, inputs, mixed, read, require, sha,
)


def replay(capture):
    cases = tuple(case.id for case in inputs())
    receipt = read(capture / "receipt.json")
    build = read(ROOT / "candidate-build.json")
    inventory = read(ROOT / "mxfp4-inventory.json")
    require(receipt["qualification"] is False and receipt["hardware"] == "MacBook Pro M5 Max 128 GB"
            and receipt["case_ids"] == list(cases) and receipt["build"] == build
            and receipt["pack_revision"] == inventory["revision"]
            and receipt["manifest"] == {"model-manifest.json":
                                        "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef"},
            "Scope, workload, signed executable, or publisher pin changed")
    baseline = read(capture / "baseline.json")
    require(baseline == receipt["baseline"] and set(baseline) == {*cases, "chat"},
            "Solo baseline roster changed")
    request_ids = {row["request_id"] for row in baseline.values()}
    require(len(request_ids) == 3 and all(request_ids)
            and all(baseline[key]["finish_reason"] == "length" and baseline[key]["usage"] == COMPLETION_USAGE
                    for key in cases), "Solo completion budget or identity changed")
    for row in baseline.values():
        usage = row["usage"]
        require(row["text"] and row["finish_reason"] in {"length", "stop"}
                and usage["prompt_tokens"] + usage["completion_tokens"] == usage["total_tokens"],
                "Solo SSE content, finish or usage evidence changed")
    paused = read(capture / "idle.json")
    require(paused == receipt["idle"] and paused["elapsed_seconds"] >= IDLE_SECONDS
            and paused["before"] == paused["after"] == dict.fromkeys(mixed.COUNTERS, 0)
            and paused["health"] == "ok", "Drained idle interval changed")
    require(len(receipt["rounds"]) == ROUNDS, "Incomplete repeat roster")
    previous_steps = -1
    for index, record in enumerate(receipt["rounds"]):
        require(record == read(capture / f"round-{index+1}.json"), "Recorded round changed")
        progress = read(capture / f"progress-{index+1}.json")
        require(progress == {key: record["observed"][key] for key in ("initial", "observed_queue")},
                "In-flight scheduler observation changed")
        previous_steps = check_round(record, previous_steps, cases, request_ids, baseline, index)
    resources = capture / "openai-samples.jsonl"
    samples = list(map(json.loads, resources.read_text().splitlines()))
    require(len(samples) == receipt["normal_pressure_samples"] > 0
            and all(row["pressure"] == 1 and 0 < row["footprint_bytes"] <= 96 * 2**30
                    for row in samples), "The pressure trace is incomplete or exceeds its guard")
    return {"scope": "guarded two-slot OpenAI lifecycle", "qualification": False,
            "build": build, "rounds": ROUNDS, "overload_responses": ROUNDS,
            "closed_streams": ROUNDS, "matching_completed_sse_replies": ROUNDS * 2,
            "rounds_drained": ROUNDS, "distinct_request_ids_including_solo": len(request_ids),
            "idle_seconds": paused["elapsed_seconds"], "normal_pressure_samples": len(samples),
            "peak_footprint_bytes": max(row["footprint_bytes"] for row in samples),
            "pressure_trace_sha256": sha(resources)}


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("capture", type=Path)
    print(json.dumps(replay(parser.parse_args().capture), indent=2, sort_keys=True, allow_nan=False))
