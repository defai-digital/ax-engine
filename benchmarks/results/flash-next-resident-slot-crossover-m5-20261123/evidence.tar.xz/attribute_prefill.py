"""Join every natural-load SSE output gap to peer prefill and decode steps."""

from bisect import bisect_right
from collections import Counter, defaultdict
from hashlib import sha256
import json
import math
from pathlib import Path
from statistics import median
import sys


def describe(gaps):
    ordered = sorted(gaps)
    return {
        "gaps": len(ordered),
        "at_least_ms": {str(limit): sum(gap >= limit for gap in ordered)
                        for limit in (50, 100, 250, 500)},
        "median_ms": median(ordered), "p95_ms": ordered[math.ceil(0.95 * len(ordered)) - 1],
        "max_ms": ordered[-1],
    }


LATE_BUDGETS = (4, 8, 12, 24, 48)


def analyze(folder):
    arm = folder.name
    client = (folder / f"{arm}.json").read_bytes()
    engine = (folder / f"{arm}-steps.json").read_bytes()
    campaign = json.loads(client)
    traces = {trace["request_id"]: trace for trace in json.loads(engine)}
    rows = [row for row in campaign["observations"] if row["phase"] == "measured"]
    assert len(rows) == 220 and len({r["prompt_id"] for r in rows}) == 220
    prefill, decode = defaultdict(list), defaultdict(set)
    for row in rows:
        ident = row["request_id"]
        trace = traces[ident]
        for event in trace["prefill"]:
            prefill[event["step_id"]].append((ident, row["input_tokens"], event["width"],
                                             event["split_end"] is not None))
        for step in trace["decode_step_ids"][1:]:
            decode[step].add(ident)
    prefill_steps = sorted(prefill)
    output = {}
    for width in (512, 2048, 8192):
        by_kind = defaultdict(list)
        max_kind = Counter()
        non_adjacent = 0
        gaps_with_peer = 0
        remaining_on_large_peer_gaps = Counter()
        remaining_on_peer_maxima = Counter()
        hold_request_max = defaultdict(list)
        example = None
        for row in rows:
            if row["input_tokens"] != width:
                continue
            ident = row["request_id"]
            steps = traces[ident]["decode_step_ids"]
            gaps = row["stream_step_interval_ms"]
            assert len(gaps) == 95 and len(steps) == 96 and len(row["output_token_ids"]) == 96
            hold = bool(row["route_decisions"].get("ax_scheduler_resident_short_decode_hold"))
            kinds = []
            for index, (previous, end, gap) in enumerate(zip(steps[:-1], steps[1:], gaps, strict=True)):
                assert previous < end and math.isfinite(gap) and gap >= 0
                lo, hi = bisect_right(prefill_steps, previous), bisect_right(prefill_steps, end)
                peer_prefills = [(step, prompt, length, split)
                                 for step in prefill_steps[lo:hi]
                                 for peer, prompt, length, split in prefill[step] if peer != ident]
                end_prefill = [(prompt, length, split) for step, prompt, length, split in peer_prefills
                               if step == end]
                if end > previous + 1:
                    kind = "multiple_steps_with_peer_prefill" if peer_prefills else "multiple_steps"
                    non_adjacent += 1
                elif end_prefill:
                    ((prompt, length, split),) = end_prefill
                    kind = f"peer_{prompt}_prefill_{length}_{'split' if split else 'whole'}"
                else:
                    kind = "peer_decode" if decode[end] - {ident} else "own_decode_only"
                by_kind[kind].append(gap)
                kinds.append(kind)
                gaps_with_peer += bool(peer_prefills)
                if end_prefill and gap >= 100:
                    remaining_on_large_peer_gaps[len(steps) - index - 1] += 1
            assert len(kinds) == len(gaps)
            largest = gaps.index(max(gaps))
            max_kind[kinds[largest]] += 1
            if kinds[largest].startswith("peer_") and "_prefill_" in kinds[largest]:
                remaining_on_peer_maxima[len(steps) - largest - 1] += 1
            hold_request_max[str(hold).lower()].append(gaps[largest])
            if example is None or gaps[largest] > example["gap_ms"]:
                example = {"gap_ms": gaps[largest], "kind": kinds[largest],
                           "prompt_id": row["prompt_id"], "emitted_index_start": largest,
                           "prior_step": steps[largest], "ending_step": steps[largest + 1],
                           "priority_hold": hold}
        output[str(width)] = {
            "by_kind": {kind: describe(gaps) for kind, gaps in by_kind.items()},
            "largest_gap_kind_by_request": dict(max_kind),
            "non_adjacent_intervals": non_adjacent, "intervals_with_peer_prefill": gaps_with_peer,
            "request_maxima_by_priority_hold": {role: describe(values) for role, values in hold_request_max.items()},
            "largest_gap": example,
            "late_window": {
                "definition": "Output budget still available immediately before the prefill gap.",
                "all_peer_prefill_gaps_at_least_100_ms": remaining_on_large_peer_gaps.total(),
                "all_request_maxima_on_peer_prefill": remaining_on_peer_maxima.total(),
                "eligible": {
                    str(budget): {
                        "peer_prefill_gaps_at_least_100_ms": sum(
                            count for left, count in remaining_on_large_peer_gaps.items() if left <= budget
                        ),
                        "request_maxima_on_peer_prefill": sum(
                            count for left, count in remaining_on_peer_maxima.items() if left <= budget
                        ),
                    }
                    for budget in LATE_BUDGETS
                },
            },
        }
    return {"client_sha256": sha256(client).hexdigest(), "step_trace_sha256": sha256(engine).hexdigest(),
            "widths": output}


if __name__ == "__main__":
    root = Path(sys.argv[1]) / "observed"
    print(json.dumps({p.name: analyze(p) for p in sorted(root.iterdir()) if p.is_dir()},
                     sort_keys=True, indent=2, allow_nan=False))
