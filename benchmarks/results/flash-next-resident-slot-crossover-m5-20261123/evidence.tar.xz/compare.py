"""Recompute the held-out one-slot versus two-slot natural-load comparison."""
import argparse
from hashlib import sha256
import json
from pathlib import Path

from repeat_compare import campaign, delta, read, verify_arm


def report(root):
    assert (root / "status.txt").read_text().strip() == "0"
    corpus, prompts, oracle = campaign.inputs()
    build = read(root / "build.json")
    arms = {arm: verify_arm(root, arm, build, prompts, oracle) for arm in campaign.ARMS}
    pairs = {}
    for order in ("first", "second"):
        single = arms[f"drain-single-{order}"]
        paired = arms[f"drain-paired-{order}"]
        assert not single["summary"]["shared_step_prompt_pairs"]
        assert single["summary"]["priority"]["priority_turns"] == 0
        priority = paired["summary"]["priority"]
        assert priority["observed_full_holds"] + priority["observed_holds_with_long_progress"] > 0
        pairs[order] = {
            "endpoint_timing_eligible": single["timing_eligible"] and paired["timing_eligible"],
            "both_full_windows_90_percent_idle": all(
                arm["serving_and_client_cpu"]["host_idle_percent"] >= 90
                for arm in (single, paired)
            ),
            "two_slots_over_one_measured": delta(single["summary"], paired["summary"]),
        }
    return {"qualification": False, "corpus_sha256": sha256(corpus.read_bytes()).hexdigest(),
            "server_sha256": build["server_sha256"], "arms": arms, "pairs": pairs}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capture", type=Path)
    print(json.dumps(report(parser.parse_args().capture), indent=2, sort_keys=True, allow_nan=False))
