"""Exercise one and two Flash Next slots with the same scheduling flags."""

import run_pair_natural as campaign

ARMS = {"drain-single-first": 1, "drain-paired-first": 2,
        "drain-paired-second": 2, "drain-single-second": 1}
campaign.ARMS = ARMS

if __name__ == "__main__":
    campaign.main()
