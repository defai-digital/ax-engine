"""Replay the frozen natural arrivals with and without a priority-short decode hold."""

from argparse import ArgumentParser
from collections import Counter, defaultdict
import json
from pathlib import Path

import audit_flash_next_mixed_serving as audit
import check_openai_concurrency as frozen
import observe_serving_cpu as process_probe
import observe_workload_cpu as cpu
import run_selective_mixed as mixed

ROOT = Path(__file__).resolve().parent
ARMS = {"mixed-first": 2, "drain-first": 2, "drain-second": 2, "mixed-second": 2}
PRIORITY_MARKER = "ax_scheduler_resident_short_prefill_first"
HOLD_MARKER = "ax_scheduler_resident_short_decode_hold"
DRAIN = "AX_MLX_FLASH_NEXT_DRAIN_PRIORITY_SHORT"
LENGTHS = {512: 132, 2048: 66, 8192: 22}


def read(path):
    return json.loads(path.read_bytes())


def inputs():
    frozen.inputs()
    corpus = ROOT / "mixed-corpus.jsonl"
    prompts = {row.id: row for row in mixed.bench.load_corpus(corpus)}
    assert len(prompts) == 220 and Counter(len(row.input_tokens) for row in prompts.values()) == LENGTHS
    assert all(row.max_output_tokens == 96 for row in prompts.values())
    oracle = read(ROOT / "prior-output.json")
    assert oracle.keys() == prompts.keys() and all(len(ids) == 96 for ids in oracle.values())
    return corpus, prompts, oracle


def shared_pairs(data, traces, lanes):
    measured = {row["request_id"]: row["input_tokens"] for row in data["observations"] if row["phase"] == "measured"}
    routes = defaultdict(dict)
    for trace in traces:
        ident = trace["request_id"]
        if ident not in measured:
            continue
        for step in {row["step_id"] for row in trace["prefill"]}.union(trace["decode_step_ids"]):
            routes[step][ident] = measured[ident]
    observed = Counter()
    for owners in routes.values():
        assert 1 <= len(owners) <= lanes
        if len(owners) == 2:
            pair = sorted(owners.values())
            assert pair[0] == 512 and pair[1] in LENGTHS, pair
            observed[f"{pair[0]}/{pair[1]}"] += 1
    return dict(sorted(observed.items()))


def flags_for(arm):
    assert arm in ARMS
    return {
        "AX_MLX_FLASH_NEXT_ALIGNED_BUFFERED": "0",
        "AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0",
        "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": "1",
        "AX_MLX_FLASH_NEXT_SHORT_PREFILL_FIRST": "1",
        DRAIN: str(int(arm.startswith("drain-"))),
        "RUST_LOG": "info,ax_engine_mlx::flash_next_startup=debug",
    }


def priority_observations(arm, artifact, traces):
    measured = [row for row in artifact["observations"] if row["phase"] == "measured"]
    steps_by_request = {trace["request_id"]: trace for trace in traces}
    longs = [(row, steps_by_request[row["request_id"]]["prefill"]) for row in measured
             if row["input_tokens"] > 512]
    result = []
    for short in measured:
        markers = short["route_decisions"]
        priority = bool(markers.get(PRIORITY_MARKER))
        hold = bool(markers.get(HOLD_MARKER))
        assert not hold or priority and arm.startswith("drain-")
        if not priority:
            continue
        assert short["input_tokens"] == 512
        trace = steps_by_request[short["request_id"]]
        prefill, = trace["prefill"]
        assert prefill["width"] == 512
        emitted = trace["decode_step_ids"]
        first, last = emitted[0], emitted[-1]
        assert prefill["step_id"] == first
        peers = [(row, cuts) for row, cuts in longs
                 if cuts[0]["step_id"] < first < cuts[-1]["step_id"]]
        (long, cuts), = peers
        cut = next(event for event in reversed(cuts) if event["step_id"] < first)
        cursor = cut["cursor"]
        assert cursor % 2048 == 0 and long["input_tokens"] - cursor >= 2048
        during = [event["step_id"] for event in cuts if first < event["step_id"] <= last]
        emitted_steps = set(emitted[1:])
        result.append({
            "short_id": short["prompt_id"], "long_id": long["prompt_id"],
            "long_cursor_at_priority": cursor, "hold_marker": hold,
            "long_prefill_steps_during_short_decode": len(during),
            "shared_long_prefill_steps": sum(step in emitted_steps for step in during),
        })
    return {"priority_turns": len(result),
            "observed_full_holds": sum(row["hold_marker"] and not row["long_prefill_steps_during_short_decode"]
                                       for row in result),
            "observed_holds_with_long_progress": sum(row["hold_marker"] and bool(row["long_prefill_steps_during_short_decode"])
                                                     for row in result),
            "pairs": result}


def examine(arm, artifact, traces, prompts, oracle):
    lanes = ARMS[arm]
    assert artifact["corpus"]["sha256"] == mixed.digest(ROOT / "mixed-corpus.jsonl")
    assert artifact["load"] == {
        "concurrency": lanes, "corpus_arrivals": True, "measured_requests": len(prompts),
        "request_rate_rps": None, "warmup_requests": 2,
    }
    assert artifact["sampling"] == {
        "ignore_eos": True, "seed": 0, "temperature": 0.0, "top_k": 0, "top_p": 1.0,
    }
    scoped, output, split_count = audit.streams(artifact, traces, prompts, lanes, True, 96, arm)
    assert output == oracle
    pairs = shared_pairs(artifact, traces, lanes)
    groups = {str(length): audit.summarize([item for item in scoped.values() if item["prompt_tokens"] == length])
              for length in LENGTHS}
    measured = [row for row in artifact["observations"] if row["phase"] == "measured"]
    # The benchmark's end-to-end clock starts at dispatch. Adding its duration
    # to relative dispatch yields the completion offset on the arrival clock.
    last = max(row["started_at_s"] + row["e2e_latency_ms"] / 1000 for row in measured)
    first = min(row["scheduled_at_s"] for row in measured)
    assert last > first
    return {"matched_output_ids": sum(map(len, output.values())), "shared_split_requests": split_count,
            "shared_step_prompt_pairs": pairs, "observed_8192_with_short_peer": pairs.get("512/8192", 0) > 0,
            "priority": priority_observations(arm, artifact, traces),
            "by_prompt_tokens": groups,
            "all": audit.summarize(list(scoped.values())), "delivered_tokens_per_second": 96 * len(output) / (last-first)}


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--arm", choices=tuple(ARMS))
    for field in ("binary", "pack", "link-root", "out"):
        cli.add_argument(f"--{field}", type=Path)
    cli.add_argument("--check-inputs", action="store_true")
    args = cli.parse_args()
    corpus, prompts, oracle = inputs()
    if args.check_inputs:
        print("Bound the 220 measured frozen prompts and 21,120 prior solo output IDs.")
        return
    lanes = ARMS[args.arm]
    build = read(ROOT / "build.json")
    inventory = read(ROOT / "mxfp4-inventory.json")
    assert build["codesign_verified"] and build["server_sha256"] == mixed.digest(args.binary)
    assert build["experiment_commit"] == "71f891b255a4e943a2bb924221ebe62cf6b3fa6e"
    assert build["patch_sha256"] == mixed.digest(ROOT / "source.patch")
    manifest = mixed.native.validate_inventory(args.pack, inventory, args.link_root)
    assert manifest["model-manifest.json"] == frozen.MANIFEST
    args.out.mkdir()
    options = ("--disable-ngram-acceleration", "--total-blocks", "2048", "--max-batch-tokens", "2049",
               *mixed.RESERVE_OPTIONS)
    flags = flags_for(args.arm)
    before = mixed.native.wait_for_quiet()["cpu_idle_percent"]
    with mixed.server(args, args.arm, mixed.MODEL, args.pack, lanes, env=flags, options=options,
                      stream_experts="auto", guard=True) as (base, owner):
        cpu_trace = args.out / f"{args.arm}-cpu.jsonl"
        process_trace = args.out / f"{args.arm}-process-cpu.jsonl"
        with cpu_trace.open("x") as output:
            result, traces = mixed.run_workload(
                args, base, owner, args.arm, lanes, corpus,
                observe_cpu=cpu.WorkloadCpu(output).sample, process_cpu=process_trace,
            )
        drained = mixed.wait_drained(base)
        assert json.loads(mixed.native.request(base, "/health"))["status"] == "ok"
    after = mixed.native.cpu_idle_percent()
    log = args.out / f"{args.arm}.log"
    text = log.read_text()
    assert "decision=resident" in text and "reader=Mapped" in text
    for old, new in ((str(args.pack), "[pack]"), (str(ROOT), "[run]"), (str(Path.home()), "[home]"),
                     ("127.0.0.1", "[loopback]")):
        text = text.replace(old, new)
    log.write_text(text)
    samples = [json.loads(line) for line in (args.out/f"{args.arm}-samples.jsonl").read_text().splitlines()]
    assert samples and all(row["pressure"] == 1 and row["footprint_bytes"] <= 96 * (1 << 30) for row in samples)
    assert mixed.native.validate_inventory(args.pack, inventory, args.link_root) == manifest
    summary = examine(args.arm, result, read(traces), prompts, oracle)
    receipt = {"arm": args.arm, "lanes": lanes, "build": build, "flags": flags,
               "manifest": manifest, "summary": summary, "normal_pressure_samples": len(samples),
               "max_footprint_bytes": max(row["footprint_bytes"] for row in samples), "drained": drained,
               "cpu_idle_percent": [before, after], "timing_eligible": min(before, after) >= 90,
               "client_cpu_ticks": cpu.summarize(cpu_trace),
               "serving_and_client_cpu": process_probe.summarize(process_trace),
               "scope": "Experimental natural offered-load comparison", "qualification": False}
    (args.out / "receipt.json").write_text(json.dumps(receipt, indent=2, allow_nan=False)+"\n")


if __name__ == "__main__":
    main()
