"""Compare both ordered natural-load pairs from their original measured rows."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from statistics import median
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "bundle"))
import observe_serving_cpu as process_probe
import observe_workload_cpu as cpu
from run_slot_holdout import campaign


def read(path):
    return json.loads(path.read_bytes())


def delta(base, treatment):
    metrics = dict(throughput_ratio=treatment["delivered_tokens_per_second"] / base["delivered_tokens_per_second"])
    for length in ("512", "2048", "8192"):
        old, new = (case["by_prompt_tokens"][length] for case in (base, treatment))
        metrics[length] = {field + "_p95_ratio": new[field]["p95"] / old[field]["p95"]
                           for field in ("arrival_to_first_token_ms", "arrival_to_completion_ms", "client_ttft_ms",
                                         "per_request_gap_p95_ms", "per_request_gap_max_ms")}
        for field in ("arrival_to_first_token_ms", "client_lane_wait_ms", "client_ttft_ms"):
            for rank in ("p50", "p95"):
                metrics[length][f"{field}_{rank}_change_ms"] = new[field][rank] - old[field][rank]
    return metrics


def explain_short_tails(artifact, summary):
    rows = [row for row in artifact["observations"]
            if row["phase"] == "measured" and row["input_tokens"] == 512]
    priority = {pair["short_id"] for pair in summary["priority"]["pairs"]}
    assert len(rows) == campaign.LENGTHS[512] and len(priority) == summary["priority"]["priority_turns"]

    # These are descriptive top-five-percent sets from the same measured arm.
    # Prompt ID gives an unambiguous ordering if latency values tie.
    tail_count = (len(rows) + 19) // 20
    def offered_ttft(row):
        return row["queue_delay_ms"] + row["ttft_ms"]

    arrival_tail = sorted(rows, key=lambda row: (-offered_ttft(row), row["prompt_id"]))[:tail_count]
    gap_tail = sorted(rows, key=lambda row: (-max(row["stream_step_interval_ms"]), row["prompt_id"]))[:tail_count]
    arrival_total = sum(offered_ttft(row) for row in arrival_tail)
    assert arrival_total > 0
    return {
        "tail_requests": tail_count,
        "arrival_tail_client_lane_wait_share": sum(row["queue_delay_ms"] for row in arrival_tail) / arrival_total,
        "arrival_tail_priority_turns": sum(row["prompt_id"] in priority for row in arrival_tail),
        "gap_tail_priority_turns": sum(row["prompt_id"] in priority for row in gap_tail),
        "arrival_p95_floor_at_observed_client_dispatch_ms": summary["by_prompt_tokens"]["512"]["client_lane_wait_ms"]["p95"],
    }


def priority_short_gaps(artifact, pairs):
    short = {row["prompt_id"]: row for row in artifact["observations"]
             if row["phase"] == "measured" and row["input_tokens"] == 512}
    return {
        pair["short_id"]: max(short[pair["short_id"]]["stream_step_interval_ms"])
        for pair in pairs
    }


def matched_short_gaps(control, treatment, common):
    if not common:
        return {"matching_priority_turns": 0}
    mixed = [control["priority_short_gaps_ms"][short] for short, _, _ in common]
    drain = [treatment["priority_short_gaps_ms"][short] for short, _, _ in common]
    return {
        "matching_priority_turns": len(common),
        "mixed_median_max_gap_ms": median(mixed),
        "drain_median_max_gap_ms": median(drain),
        "median_paired_gap_change_ms": median(new - old for old, new in zip(mixed, drain, strict=True)),
        "turns_with_smaller_max_gap": sum(new < old for old, new in zip(mixed, drain, strict=True)),
    }


def completion_at(row):
    return row["started_at_s"] + row["e2e_latency_ms"] / 1000.0


def explain_medium_admission(artifact, traces, priority):
    rows = {row["prompt_id"]: row for row in artifact["observations"] if row["phase"] == "measured"}
    by_request = {trace["request_id"]: trace for trace in traces}
    ordered = sorted(rows.values(), key=lambda row: (row["scheduled_at_s"], row["prompt_id"]))
    following = {a["prompt_id"]: b for a, b in zip(ordered, ordered[1:])}
    medium = {}
    for row in rows.values():
        if row["input_tokens"] != 2048:
            continue
        start = row["started_at_s"]
        peers = [peer for peer in rows.values() if peer is not row
                 and peer["started_at_s"] < start < completion_at(peer)]
        assert len(peers) <= 1, row["prompt_id"]
        peer = peers[0] if peers else None
        peer_e2e_remaining_ms = None
        step_delta = None
        if peer is not None:
            first_prefill = by_request[row["request_id"]]["prefill"][0]["step_id"]
            peer_last_token = by_request[peer["request_id"]]["decode_step_ids"][-1]
            step_delta = first_prefill - peer_last_token
            peer_e2e_remaining_ms = 1000 * (completion_at(peer) - start)
        medium[row["prompt_id"]] = {
            "active_peer_at_dispatch": peer["prompt_id"] if peer else None,
            "active_peer_prompt_tokens": peer["input_tokens"] if peer else None,
            "first_prefill_minus_peer_final_decode_step": step_delta,
            "peer_e2e_remaining_ms_at_dispatch": peer_e2e_remaining_ms,
            "client_lane_wait_ms": row["queue_delay_ms"],
            "dispatch_ttft_ms": row["ttft_ms"],
            "offered_ttft_ms": row["queue_delay_ms"] + row["ttft_ms"],
        }
    assert len(medium) == campaign.LENGTHS[2048]

    handoffs = []
    for prompt in priority:
        short_id, long_id = prompt["short_id"], prompt["long_id"]
        next_row = following.get(short_id)
        if next_row is None or next_row["input_tokens"] != 2048:
            continue
        medium_id = next_row["prompt_id"]
        observation = medium[medium_id]
        if observation["active_peer_at_dispatch"] != long_id:
            continue
        short_end = completion_at(rows[short_id])
        if not next_row["scheduled_at_s"] <= short_end <= next_row["started_at_s"]:
            continue
        handoffs.append({
            "short_id": short_id, "long_id": long_id,
            "long_cursor_at_priority": prompt["long_cursor_at_priority"],
            "medium_id": medium_id,
            "dispatch_ms_after_short_completion": 1000 * (next_row["started_at_s"] - short_end),
            **observation,
        })
    return {"rows": medium, "observed_short_to_medium_handoffs": handoffs}


def summarize_matched_handoffs(control, treatment):
    def index(arm):
        return {
            (row["short_id"], row["long_id"], row["long_cursor_at_priority"], row["medium_id"]): row
            for row in arm["medium_admission"]["observed_short_to_medium_handoffs"]
        }

    mixed, drain = index(control), index(treatment)
    common = sorted(mixed.keys() & drain.keys())
    if not common:
        return {"matching_handoffs": 0}
    summary = {"matching_handoffs": len(common)}
    for label, source in (("mixed", mixed), ("drain", drain)):
        prefix = [source[key] for key in common]
        summary[label] = {
            "prefill_immediately_after_long_final_decode": sum(
                row["first_prefill_minus_peer_final_decode_step"] == 1 for row in prefix
            ),
            "medians_ms": {name: median(row[name] for row in prefix) for name in (
                "dispatch_ms_after_short_completion", "peer_e2e_remaining_ms_at_dispatch",
                "client_lane_wait_ms", "dispatch_ttft_ms", "offered_ttft_ms",
            )},
        }
    return summary


def role_cpu_windows(artifact, process, offered_span, tick_hz):
    measured = [row for row in artifact["observations"] if row["phase"] == "measured"]
    assert min(row["scheduled_at_s"] for row in measured) == 0
    offset = process["client_window_seconds"] - offered_span
    cursor = 0
    timed = []
    for interval in process["intervals"]:
        earliest = cursor / 1e9 - offset
        cursor += interval["wall_ns"]
        latest = cursor / 1e9
        timed.append((earliest, latest, interval))

    windows = []
    complete_minutes = int(max(row["scheduled_at_s"] for row in measured) // 60)
    for minute in range(complete_minutes):
        start, end = minute * 60, (minute + 1) * 60
        arrivals = [row for row in measured if start <= row["scheduled_at_s"] < end]
        inside = [row for earliest, latest, row in timed if start <= earliest and latest <= end]
        assert arrivals
        item = {"minute": minute + 1, "sample_intervals": len(inside),
                "client_lane_wait_median_seconds": median(row["queue_delay_ms"] for row in arrivals) / 1000}
        total_ticks = sum(row["host_total_ticks"] for row in inside)
        if total_ticks:
            wall_ns = sum(row["wall_ns"] for row in inside)
            idle_ticks = sum(row["host_idle_ticks"] for row in inside)
            busy_cores = (total_ticks - idle_ticks) * 1e9 / (tick_hz * wall_ns)
            server_cores = sum(row["server_cpu_ns"] for row in inside) / wall_ns
            client_cores = sum(row["client_cpu_ns"] for row in inside) / wall_ns
            item.update({
                "sampled_seconds": wall_ns / 1e9, "host_idle_percent": 100 * idle_ticks / total_ticks,
                "host_busy_core_equivalents": busy_cores,
                "serving_core_equivalents": server_cores, "client_core_equivalents": client_cores,
                "unassigned_core_equivalents": busy_cores - server_cores - client_cores,
            })
        windows.append(item)
    return {"clock_offset_upper_bound_s": offset, "minutes": windows}


def verify_arm(capture, arm, build, prompts, oracle):
    lanes = campaign.ARMS[arm]
    path = capture / "observed" / arm
    receipt = read(path / "receipt.json")
    assert receipt["lanes"] == lanes and receipt["arm"] == arm and receipt["build"] == build
    assert receipt["qualification"] is False
    assert set(receipt["drained"]) == set(campaign.mixed.COUNTERS)
    assert not any(receipt["drained"].values())
    assert receipt["flags"] == campaign.flags_for(arm)
    assert receipt["manifest"] == {"model-manifest.json": campaign.frozen.MANIFEST}
    artifact = read(path / f"{arm}.json")
    traces = read(path / f"{arm}-steps.json")
    summary = campaign.examine(arm, artifact, traces, prompts, oracle)
    assert summary == receipt["summary"]
    samples = [json.loads(line) for line in (path / f"{arm}-samples.jsonl").read_text().splitlines()]
    assert len(samples) == receipt["normal_pressure_samples"] > 0
    assert all(row["pressure"] == 1 for row in samples)
    assert max(row["footprint_bytes"] for row in samples) == receipt["max_footprint_bytes"] <= 96 << 30
    idle = receipt["cpu_idle_percent"]
    assert len(idle) == 2 and all(0 <= value <= 100 for value in idle)
    eligible = all(value >= 90 for value in idle)
    assert eligible == receipt["timing_eligible"]
    client_ticks = cpu.summarize(path / f"{arm}-cpu.jsonl")
    assert client_ticks == receipt["client_cpu_ticks"]
    offered_span = summary["matched_output_ids"] / summary["delivered_tokens_per_second"]
    assert client_ticks["client_window_seconds"] >= offered_span, arm
    process_trace = path / f"{arm}-process-cpu.jsonl"
    process = process_probe.summarize(process_trace)
    with process_trace.open() as lines:
        tick_hz = json.loads(next(lines))["host_ticks_per_second"]
    assert process == receipt["serving_and_client_cpu"], arm
    assert process["client_window_seconds"] >= offered_span, arm
    assert process["client_window_seconds"] <= client_ticks["client_window_seconds"] + 0.025, arm
    return {
        "serving_and_client_cpu": process,
        "serving_and_client_cpu_minutes": role_cpu_windows(artifact, process, offered_span, tick_hz),
        "client_cpu_window_extra_seconds": client_ticks["client_window_seconds"] - offered_span,
        "timing_eligible": eligible, "idle_percent": idle, "summary": summary,
        "short_tails": explain_short_tails(artifact, summary),
        "priority_short_gaps_ms": priority_short_gaps(artifact, summary["priority"]["pairs"]),
        "medium_admission": explain_medium_admission(artifact, traces, summary["priority"]["pairs"]),
        "client_cpu_ticks": client_ticks, "normal_pressure_samples": len(samples),
        "max_footprint_bytes": receipt["max_footprint_bytes"],
    }


def compare_order(control, treatment):
    eligible = control["timing_eligible"] and treatment["timing_eligible"]
    baseline_priority, treatment_priority = (arm["summary"]["priority"] for arm in (control, treatment))

    def grants(rows):
        return {(row["short_id"], row["long_id"], row["long_cursor_at_priority"])
                for row in rows["pairs"]}

    matched = sorted(grants(baseline_priority) & grants(treatment_priority))
    result = {
        "timing_eligible": eligible,
        "client_window_90_percent_idle_in_both_arms": all(
            arm["serving_and_client_cpu"]["host_idle_percent"] >= 90 for arm in (control, treatment)
        ),
        "hold_path_exercised": (treatment_priority["observed_full_holds"]
                                + treatment_priority["observed_holds_with_long_progress"] > 0),
        "matched_priority_turns": matched,
        "matched_priority_short_gap": matched_short_gaps(control, treatment, matched),
        "matched_short_to_medium_handoffs": summarize_matched_handoffs(control, treatment),
    }
    if eligible:
        # Use every scheduled row, including runs with no hold activation.
        result["whole_workload_flag_setting"] = delta(control["summary"], treatment["summary"])
    return result


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("capture", type=Path)
    cli.add_argument("--arm", choices=tuple(campaign.ARMS))
    args = cli.parse_args()
    cohort, prompts, oracle = campaign.inputs()
    build = read(args.capture / "build.json")
    if args.arm:
        arm = verify_arm(args.capture, args.arm, build, prompts, oracle)
        print(json.dumps({"arm": args.arm, "capture_complete": False, **arm},
                         sort_keys=True, indent=2, allow_nan=False))
        return
    assert (args.capture / "status.txt").read_bytes() == b"0\n"
    dossier = {arm: verify_arm(args.capture, arm, build, prompts, oracle) for arm in campaign.ARMS}
    comparisons = {
        order: compare_order(dossier[f"mixed-{order}"], dossier[f"drain-{order}"])
        for order in ("first", "second")
    }
    print(json.dumps({"scope":"Experimental natural offered-load comparison", "qualification":False,
                      "server_sha256": build["server_sha256"], "corpus_sha256": sha256(cohort.read_bytes()).hexdigest(),
                      "arms": dossier, "comparison": comparisons}, sort_keys=True, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
