"""Compare the same resident Flash Next server with and without layered prefill."""

from argparse import ArgumentParser
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import subprocess
import sys
from threading import Event
from urllib.request import Request, urlopen

import run_selective_mixed as mixed
from capture_layer_steps import PREFIX

ROOT = Path(__file__).resolve().parent
LABELS = ("early-decoder", "ending-decoder")
SOLO_SHA256 = "8366fc79691fa4946ad62efe6a7c47020f702f2446c5a21d5c4640a3a75e00ac"


def require(valid, message):
    if not valid:
        raise ValueError(message)


def files():
    receipt = json.loads((ROOT / "burst-inputs.json").read_bytes())
    require(set(receipt) == set(LABELS), "Wrong frozen arrival conditions")
    reference = ROOT / "solo-reference.json"
    require(mixed.digest(reference) == SOLO_SHA256, "Solo reference bytes changed")
    baseline = {r["prompt_id"]: r for r in json.loads(reference.read_bytes())["observations"]
                if r["phase"] == "measured"}
    data = {}
    for label in LABELS:
        corpus = ROOT / f"{label}.jsonl"
        require(mixed.digest(corpus) == receipt[label]["corpus_sha256"], "Frozen burst corpus changed")
        cases = sorted(mixed.bench.load_corpus(corpus), key=lambda case: len(case.input_tokens))
        require([len(case.input_tokens) for case in cases] == [512, 8192], "Unexpected prompt lengths")
        tokens = {}
        for case in cases:
            control = baseline[case.id]
            require(case.input_tokens == control["prompt_token_ids"], "Solo prompt changed")
            tokens[case.id] = control["output_token_ids"][:case.max_output_tokens]
        data[label] = (corpus, cases, tokens)
    return data


def check_trace(traces, candidate, label):
    short, long = sorted(traces, key=lambda row: row["cursor"])
    require((short["cursor"], long["cursor"]) == (512, 8192) and not short["partial"],
            "Incomplete prompt or suspension on the short stream")
    require(candidate or not long["partial"], "Control unexpectedly suspended")
    if candidate and label == "early-decoder":
        require(long["partial"], "The early-decoder experiment did not exercise the layer route")
    pending = {}
    for row in long["partial"]:
        cursor = row["cursor"]
        previous = pending.get(cursor, 0)
        require(row["scheduled"] == 2 and row["step_id"] in short["decode_step_ids"][1:]
                and row["previous"] == previous and row["completed"] == previous + 8
                and row["completed"] <= 40 and row["runner_time_us"] > 0
                and cursor < row["logical_end"] == ((cursor // 2048) + 1) * 2048,
                "Layer advance lacks its peer output, exact cursor or valid logical range")
        pending[cursor] = row["completed"]
    completed = {row["cursor"] - row["width"]: row for row in long["prefill"]}
    for cursor in pending:
        require(completed[cursor]["width"] in (511, 512)
                and completed[cursor]["step_id"] > max(r["step_id"] for r in long["partial"]
                                                    if r["cursor"] == cursor),
                "Suspension did not reach its original physical boundary")
    return {"layer_progress_steps": len(long["partial"]),
            "long_widths": [row["width"] for row in long["prefill"]]}


def cancellation(base, cases, expected, cancel_long):
    short, long = cases
    first_short = Event()
    suspended = Event()

    def stream(case):
        is_long = case == long
        canceled = is_long == cancel_long
        if is_long and not first_short.wait(timeout=20):
            raise TimeoutError("Short stream never emitted its first token")
        payload = {"model": mixed.MODEL, "input_tokens": case.input_tokens,
                   "max_output_tokens": case.max_output_tokens,
                   "sampling": {"temperature": 0, "ignore_eos": True}}
        request = Request(f"{base}/v1/generate/stream", data=json.dumps(payload).encode(),
                          headers={"Content-Type": "application/json"})
        identity = None
        evidence = []
        with urlopen(request, timeout=90) as response:
            for line in response:
                if not line.startswith(b"data:") or line.strip() == b"data: [DONE]":
                    continue
                data = json.loads(line[5:])
                if "request" in data:
                    identity = data["request"]["request_id"]
                if "step" in data:
                    step = data["step"]
                    keys = ((step.get("route") or {}).get("crossover_decisions") or {})
                    marks = [value for name, value in keys.items() if name.startswith(PREFIX)]
                    if marks:
                        evidence.append(step["step_id"])
                        suspended.set()
                    if not is_long and data.get("delta_tokens"):
                        first_short.set()
                    if canceled and suspended.is_set():
                        return {"closed": True, "request_id": identity, "seen_layer_steps": evidence}
                if "response" in data:
                    require(not canceled and data["response"]["output_tokens"] == expected[case.id],
                            "The remaining stream changed output or the target finished before cancellation")
                    return {"closed": False, "request_id": identity, "seen_layer_steps": evidence,
                            "matched_output_ids": len(expected[case.id])}
        raise ValueError("No terminal response or exercised socket close")

    with ThreadPoolExecutor(max_workers=2) as pool:
        a, b = pool.submit(stream, short), pool.submit(stream, long)
        results = [a.result(), b.result()]
    require(suspended.is_set(), "Cancellation did not interrupt an exercised layer split")
    return {"canceled": "long" if cancel_long else "short",
            "requests": results, "drained": mixed.wait_drained(base)}


def main():
    parser = ArgumentParser(description=__doc__)
    for name in ("binary", "pack", "link-root", "out"):
        parser.add_argument(f"--{name}", type=Path)
    parser.add_argument("--check-inputs", action="store_true")
    parser.add_argument("--repeat", action="store_true")
    args = parser.parse_args()
    data = files()
    if args.check_inputs:
        return
    build = json.loads((ROOT / "build.json").read_bytes())
    require(mixed.digest(args.binary) == build["server_sha256"], "Binary differs from build receipt")
    inventory = json.loads((ROOT / "mxfp4-inventory.json").read_bytes())
    pack = mixed.native.validate_inventory(args.pack, inventory, args.link_root)
    require(pack.get("model-manifest.json") ==
            "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef",
            "The delivered pack differs from the model-layer proof")
    args.out.mkdir()
    arms = [("split-1", False), ("layers-1", True)]
    if args.repeat:
        arms += [("layers-2", True), ("split-2", False)]
    record = {"scope": "Native HTTP two-user diagnostic on MacBook Pro M5 Max 128 GB",
              "qualification": False, "build": build, "pack_revision": inventory["revision"],
              "inventory_sha256": mixed.digest(ROOT / "mxfp4-inventory.json"), "manifest": pack, "arms": {}}

    def save(status):
        record["status"] = status
        (args.out / "receipt.json").write_text(json.dumps(record, indent=2, allow_nan=False) + "\n")
        print(status, flush=True)

    for arm, candidate in arms:
        save(f"{arm}-starting")
        quiet = mixed.native.wait_for_quiet()
        env = {"AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0", "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": "1",
               "AX_MLX_FLASH_NEXT_PREFILL_LAYER_YIELD": str(int(candidate))}
        options = ("--disable-ngram-acceleration", "--total-blocks", "2048", "--max-batch-tokens", "2049",
                   *mixed.RESERVE_OPTIONS)
        results = {}
        with mixed.server(args, arm, mixed.MODEL, args.pack, 2, env=env, options=options,
                          stream_experts="auto", guard=True) as (base, _):
            require("decision=resident" in (args.out / f"{arm}.log").read_text(), "Resident experts are required")
            for label, (corpus, cases, expected) in data.items():
                label_root = args.out / f"{arm}-{label}"
                client = label_root.with_suffix(".json")
                trace = label_root.with_suffix(".trace.json")
                with label_root.with_suffix(".client.log").open("x") as output:
                    subprocess.run([sys.executable, str(ROOT / "capture_layer_steps.py"), str(trace),
                                    "--base-url", base, "--model-id", mixed.MODEL, "--input-kind", "tokens",
                                    "--corpus", str(corpus), "--corpus-arrivals", "--warmup-requests", "0",
                                    "--concurrency", "2", "--ignore-eos", "--record-token-ids", "--timeout", "120",
                                    "--output", str(client)], stdout=output, stderr=output, check=True, timeout=180)
                observed = json.loads(client.read_bytes())
                require(mixed.verify_rows(observed, cases) == expected, "HTTP output differs from isolated greedy")
                results[label] = check_trace(json.loads(trace.read_bytes()), candidate, label) | {
                    "client_sha256": mixed.digest(client), "trace_sha256": mixed.digest(trace),
                    "drained": mixed.wait_drained(base)}
            if candidate and arm == "layers-1":
                _, cases, expected = data["early-decoder"]
                results["cancellations"] = [cancellation(base, cases, expected, cancel_long)
                                            for cancel_long in (True, False)]
            require(json.loads(mixed.native.request(base, "/health"))["status"] == "ok", "Health declined")
        samples = [json.loads(line) for line in (args.out / f"{arm}-samples.jsonl").read_text().splitlines()]
        require(samples and all(row["pressure"] == 1 for row in samples), "Memory pressure exceeded normal")
        record["arms"][arm] = {"layer_yield": candidate, "quiet_before_percent": quiet["cpu_idle_percent"],
                              "idle_after_percent": mixed.native.cpu_idle_percent(), "outcomes": results,
                              "pressure_samples": len(samples)}
        save(f"{arm}-complete")
    require(mixed.native.validate_inventory(args.pack, inventory, args.link_root) == pack, "Pack changed")
    save("complete")


if __name__ == "__main__":
    main()
