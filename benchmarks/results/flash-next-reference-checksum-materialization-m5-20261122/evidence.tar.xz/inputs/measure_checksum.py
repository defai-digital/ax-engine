"""Measure pinned materialization after controlled publisher checksums."""

import argparse
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time
from unittest.mock import patch

from checksum_ledger import host_vm, payloads, record_checksums
from frozen_progress import verify_inputs
from process_footprint import footprint_reader
from ple_batches import GRAPH_SHA256, ReachedMaterializationBoundary, graph, run_materialization, verify_phase_order


def observer(events, mx):
    footprint = footprint_reader(Path(__file__).with_name('loader_footprint.dylib'))

    def mark(phase, **details):
        record = {
            'phase': phase,
            'monotonic_seconds': time.monotonic(),
            'rss_high_water_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            'mlx_active_bytes': mx.get_active_memory(),
            'mlx_cache_bytes': mx.get_cache_memory(),
            'mlx_peak_bytes': mx.get_peak_memory(),
            **footprint(os.getpid()),
            **details,
        }
        print(json.dumps(record), file=events, flush=True)

    return mark


def instrument(reference, utils, mark, expected):
    load_model = utils.load_model
    materialize = reference.materialize

    def observed_load(*args, **kwargs):
        mark('lazy_load_start')
        model = load_model(*args, **kwargs)
        mark('lazy_load_end')
        return model

    def observed_materialize(model, mx):
        mark('materialize_start')
        return run_materialization(materialize, model, mx, mark, expected)

    def stop_at_prefill(model, mx, prompt, chunk=1024):
        raise ValueError('The batch diagnostic entered first prefill')

    utils.load_model = observed_load
    reference.materialize = observed_materialize
    reference.token_stream = stop_at_prefill


def child(args):
    import mlx.core as mx
    import mlx_vlm.utils as utils
    import run_flash_next_reference as reference

    sys.argv[1:] = [
        '--model-dir', str(args.model_dir), '--output', str(args.out / 'reference'),
        '--inventory', str(args.frozen / 'benchmarks/results/qualification/2026-10-04-flash-next-mxfp4-native-support/pack-inventory.json'),
        '--phases', 'qa', '--limit-items', '1',
    ]
    model_dir = args.model_dir.resolve()
    inventory = args.frozen / 'benchmarks/results/qualification/2026-10-04-flash-next-mxfp4-native-support/pack-inventory.json'
    members = payloads(inventory)
    with ((args.out / 'phase-events.jsonl').open('x') as events,
          (args.out / 'checksum-events.jsonl').open('x') as checks):
        mark = observer(events, mx)
        phases = []

        def record(phase, **details):
            if phase == 'lazy_load_start' and hashed != members.keys():
                raise ValueError('Materialization started before all payload checksums')
            mark(phase, **details)
            phases.append(phase)

        instrument(reference, utils, record, graph())
        observed, hashed = record_checksums(reference.native.sha256, model_dir, members,
                                             args.checksum_mode, checks)
        try:
            with patch.object(reference.native, 'sha256', observed):
                reference.main()
        except ReachedMaterializationBoundary:
            verify_phase_order(phases)
            if hashed != members.keys():
                raise ValueError('Incomplete publisher checksums')
            return 0
    raise RuntimeError('Reference did not reach the guarded complete materialization boundary')


def run(args, source_sha):
    import watch_flash_next_reference as watcher

    args.out.mkdir(exist_ok=False)
    footprint = footprint_reader(Path(__file__).with_name('loader_footprint.dylib'))
    env = {key: value for key, value in os.environ.items()
           if not key.startswith(('AX_', 'MLX_', 'DYLD_'))}
    with (args.out / 'runner.log').open('x') as log, (args.out / 'samples.jsonl').open('x') as samples:
        initial = watcher.sample_host(diagnose_host=True)
        print(json.dumps(initial), file=samples, flush=True)
        reason = 'prelaunch pressure'
        exit_code = None
        if initial['pressure'] == 1:
            with subprocess.Popen([sys.executable, '-B', '-u', __file__, *sys.argv[1:], '--child'],
                                  env=env, stdout=log, stderr=log) as process:
                deadline = time.monotonic() + 600
                reason = None
                try:
                    while process.poll() is None:
                        sample = watcher.sample_host(process.pid, diagnose_host=True) | footprint(process.pid)
                        sample['vm_memory_bytes'] = host_vm()
                        sample['monotonic_seconds'] = time.monotonic()
                        print(json.dumps(sample), file=samples, flush=True)
                        if sample['pressure'] != 1:
                            reason = 'memory pressure above normal'
                            break
                        if time.monotonic() >= deadline:
                            reason = 'diagnostic wall limit'
                            break
                        try:
                            process.wait(timeout=2)
                        except subprocess.TimeoutExpired:
                            pass
                finally:
                    if process.poll() is None:
                        process.terminate()
                        try:
                            process.wait(timeout=15)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait(timeout=15)
                exit_code = process.returncode
    if verify_inputs(args.frozen) != source_sha:
        raise ValueError('Frozen source manifest changed during the diagnostic')
    status = {'scope': 'Controlled checksum caching before pinned Flash Next materialization',
              'checksum_mode': args.checksum_mode,
              'graph_sha256': GRAPH_SHA256, 'wired_override': False,
              'ordinary_qualification': False, 'frozen_sha256': source_sha,
              'exit_code': exit_code, 'stop_reason': reason}
    (args.out / 'status.json').write_text(json.dumps(status, indent=2) + '\n')
    return 0 if exit_code == 0 and reason is None else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('frozen', 'model-dir', 'out'):
        parser.add_argument(f'--{name}', required=True, type=Path)
    parser.add_argument('--checksum-mode', choices=('buffered', 'no-cache'), required=True)
    parser.add_argument('--child', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    source = verify_inputs(args.frozen)
    sys.path.insert(0, str(args.frozen / 'scripts'))
    return child(args) if args.child else run(args, source)


if __name__ == '__main__':
    sys.exit(main())
