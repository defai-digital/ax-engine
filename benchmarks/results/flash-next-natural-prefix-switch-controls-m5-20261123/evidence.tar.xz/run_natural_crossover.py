"""Compare one signed Flash Next build with document-prefix learning off and on."""

from argparse import ArgumentParser, Namespace
import ctypes
import json
from pathlib import Path
from time import monotonic

from run_fixed_extension import CASES, CORPUS, MANIFEST, ROOT, check_case, mixed, read, require, reuse, save, workload
from run_fixed_extension_crossover import ARMS, IDLE_FLOOR, timing
from run_natural_fork import LEARNED_HITS, ORDER
from run_qwen38_reference_serving import ProcessUsage
from run_warm_prefix import overlap


def process_memory(pid):
    usage = ProcessUsage()
    measure = ctypes.CDLL('/usr/lib/libproc.dylib').proc_pid_rusage
    measure.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_void_p]
    measure.restype = ctypes.c_int
    require(measure(pid, 0, ctypes.byref(usage)) == 0, 'Cannot read server memory')
    return {'footprint_bytes': usage.footprint, 'rss_bytes': usage.rss}


def run_arm(binary, pack, out, enabled, prompts, *, extension=True):
    out.mkdir()
    flags = ('--disable-ngram-acceleration', '--total-blocks', '2048', '--max-batch-tokens', '2049',
             *mixed.RESERVE_OPTIONS)
    env = {
        'AX_MLX_FLASH_NEXT_FIXED_PREFIX_EXTENSION': '1' if extension else '0',
        'AX_MLX_FLASH_NEXT_LEARN_PREFIX_FORK': '1' if enabled else '0',
        'AX_ENGINE_PREFIX_REUSE_DISABLED': '0',
        'AX_MLX_PREFIX_CACHE_MAX_BYTES': '2147483648',
        'AX_MLX_PREFIX_CACHE_MAX_ENTRIES': '8',
        'AX_MLX_FLASH_NEXT_DIRECT_COALESCING': '0',
        'AX_MLX_FLASH_NEXT_PREFILL_SPLIT': '0',
        'AX_ENGINE_ADAPTIVE_PREFILL': '0',
    }
    cases, outputs = {}, {}
    kinds = {name: (peer, target, cancelled, tail) for name, peer, target, cancelled, _, tail in CASES}
    require(set(ORDER) == set(kinds), 'The request order changed')
    with mixed.server(Namespace(binary=binary, out=out), 'natural', mixed.MODEL, pack, 2, env=env,
                      options=flags, stream_experts='off', guard=True) as (base, pid):
        startup = (out / 'natural.log').read_text()
        require('model_family=qwen4_exp' in startup and 'mtp_requested=false' in startup,
                'The direct Flash Next route was not admitted')
        for name in ORDER:
            peer, target, cancelled, tail = kinds[name]
            before = reuse(base)
            memory_before = process_memory(pid)
            started = monotonic()
            peer_row, target_row = overlap(base, prompts[peer], prompts[target], disconnect=cancelled)
            wall_seconds = monotonic() - started
            drained = mixed.wait_drained(base)
            row = {
                'peer': peer_row, 'target': target_row, 'wall_seconds': wall_seconds,
                'reuse_before': before, 'reuse_after': reuse(base), 'drained': drained,
                'memory_before': memory_before, 'memory_drained': process_memory(pid),
            }
            cases[name] = row
            save(out / 'partial.json', cases)
            outputs[name] = check_case(row, extension and enabled and name in LEARNED_HITS, cancelled, tail)
            print(f'{out.name} {name} verified', flush=True)
    mixed.native.scrub_log(out / 'natural.log')
    return {'cases': cases, 'outputs': outputs, 'learning_enabled': enabled, 'explicit_seed_requests': 0}


def samples_from(directory):
    return [json.loads(row) for row in (directory / 'natural-samples.jsonl').read_text().splitlines()]


def pair_cost(rows, off, on):
    costs = {}
    for name in ('first', 'unseeded', 'replacement', 'aligned', 'boundary'):
        control, learned = rows[off][name], rows[on][name]
        costs[name] = {
            'target_ttft_on_minus_off_seconds': learned['target_ttft_seconds'] - control['target_ttft_seconds'],
            'pair_wall_on_minus_off_seconds': learned['pair_wall_seconds'] - control['pair_wall_seconds'],
            'peer_max_gap_on_minus_off_seconds': learned['peer_max_gap_seconds'] - control['peer_max_gap_seconds'],
        }
    costs['questions_2_and_3_ttft_on_minus_off_seconds'] = sum(
        costs[name]['target_ttft_on_minus_off_seconds'] for name in ('replacement', 'aligned')
    )
    return costs


def summarize(arms, out):
    require(set(arms) == {name for name, _ in ARMS}, 'Missing a crossover arm')
    baseline = arms['off-1']['outputs']
    result = {}
    for name, enabled in ARMS:
        record = arms[name]
        cases = read(out / name / 'partial.json')
        require(cases == record['cases'] and record['explicit_seed_requests'] == 0
                and record['learning_enabled'] is enabled, 'The no-seed route contract changed')
        checked = {label: check_case(cases[label], enabled and label in LEARNED_HITS, cancelled, tail)
                   for label, _, _, cancelled, _, tail in CASES}
        require(checked == record['outputs'] == baseline, 'The switch changed output token IDs')
        samples = samples_from(out / name)
        require(samples and all(sample['pressure'] == 1 for sample in samples), 'Host pressure changed')
        result[name] = {
            'eligible': min(record['idle_before'], record['idle_after']) >= IDLE_FLOOR,
            'idle_before': record['idle_before'], 'idle_after': record['idle_after'],
            'normal_pressure_samples': len(samples),
            'peak_footprint_bytes': max(sample['footprint_bytes'] for sample in samples),
            'peak_rss_bytes': max(sample['rss_bytes'] for sample in samples),
            'cases': {label: timing(row) | {
                'memory_before': row['memory_before'], 'memory_drained': row['memory_drained'],
                'physical_reuse': dict(zip(('tokens', 'hits'), (
                    after - before for before, after in zip(row['reuse_before'], row['reuse_after'], strict=True)
                ), strict=True)),
            } for label, row in cases.items()},
        }
    count = sum(len(ids) for pair in baseline.values() for ids in pair.values())
    require(count == 1921, 'The exact output comparison length changed')
    rows = {name: record['cases'] for name, record in result.items()}
    pairs = [
        {'off': off, 'on': on, 'cost': pair_cost(rows, off, on)
         if result[off]['eligible'] and result[on]['eligible'] else None}
        for off, on in (('off-1', 'on-1'), ('off-2', 'on-2'))
    ]
    return {
        'timing_eligible': all(pair['cost'] is not None for pair in pairs),
        'cpu_idle_floor_percent': IDLE_FLOOR,
        'tokens_per_arm': count, 'arms': result, 'pairs': pairs,
    }


def main():
    parser = ArgumentParser(description=__doc__)
    for key in ('binary', 'cache', 'pack', 'out', 'replay'):
        parser.add_argument(f'--{key}', type=Path)
    args = parser.parse_args()
    build = read(ROOT / 'build.json')
    if args.replay:
        receipt = read(args.replay)
        require(receipt['build'] == build and receipt['manifest'] == MANIFEST
                and receipt['corpus_sha256'] == CORPUS and receipt['qualification'] is False,
                'The replay input identity changed')
        require(summarize(receipt['arms'], args.replay.parent) == receipt['comparison'],
                'The merged comparison no longer agrees with the arms')
        print(json.dumps(receipt['comparison'], indent=2, sort_keys=True, allow_nan=False))
        return
    require(all((args.binary, args.cache, args.pack, args.out)), 'Missing campaign input')
    require(mixed.digest(args.binary) == build['server_sha256'] and build['codesign_verified'] is True,
            'The signed executable changed')
    inventory = read(ROOT / 'mxfp4-inventory.json')
    require(mixed.native.validate_inventory(args.pack, inventory, args.cache) == MANIFEST,
            'The admitted publisher data changed')
    args.out.mkdir()
    arms, prompts = {}, workload()
    require(mixed.digest(ROOT / 'mixed-corpus.jsonl') == CORPUS, 'Input corpus changed')
    for name, enabled in ARMS:
        before = mixed.native.wait_for_quiet(IDLE_FLOOR, timeout=900)
        arm = run_arm(args.binary, args.pack, args.out / name, enabled, prompts)
        arm['idle_before'] = before['cpu_idle_percent']
        arm['idle_after'] = mixed.native.cpu_idle_percent()
        arms[name] = arm
        save(args.out / name / 'arm.json', arm)
    require(mixed.native.validate_inventory(args.pack, inventory, args.cache) == MANIFEST,
            'The final publisher data changed')
    save(args.out / 'receipt.json', {
        'build': build, 'manifest': MANIFEST, 'corpus_sha256': CORPUS, 'qualification': False,
        'arms': arms, 'comparison': summarize(arms, args.out),
    })


if __name__ == '__main__':
    main()
