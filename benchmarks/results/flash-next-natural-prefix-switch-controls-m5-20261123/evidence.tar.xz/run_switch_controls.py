"""Verify Flash Next switch isolation on the signed server and seven-case cold oracle."""

from argparse import ArgumentParser
import json
from pathlib import Path

from run_fixed_extension import CASES, CORPUS, MANIFEST, ROOT, check_case, mixed, read, require, save, workload
from run_natural_crossover import run_arm, samples_from

CONTROLS = (('both-off', False), ('child-only', True))


def summarize(arms, out):
    require(set(arms) == {name for name, _ in CONTROLS}, 'A switch control is missing')
    expected = read(ROOT / 'switch-cold-oracle.json')['outputs']
    count = sum(len(ids) for row in expected.values() for ids in row.values())
    require(count == 1921, 'The same-host cold oracle length changed')
    summary = {}
    for name, child in CONTROLS:
        arm = arms[name]
        cases = read(out / name / 'partial.json')
        require(cases == arm['cases'] and arm['explicit_seed_requests'] == 0
                and arm['learning_enabled'] is child, 'Control switch metadata changed')
        checked = {label: check_case(cases[label], False, cancelled, tail)
                   for label, _, _, cancelled, _, tail in CASES}
        require(checked == arm['outputs'] == expected,
                'A disabled parent changed IDs, route or physical reuse')
        samples = samples_from(out / name)
        require(samples and all(sample['pressure'] == 1 for sample in samples), 'Host pressure changed')
        summary[name] = {'parent_enabled': False, 'child_enabled': child,
                         'compared_token_ids': count, 'physical_reuse_hits': 0,
                         'normal_pressure_samples': len(samples)}
    return summary


def main():
    cli = ArgumentParser(description=__doc__)
    for field in ('binary','pack','cache','out','replay'):
        cli.add_argument(f'--{field}', type=Path)
    args = cli.parse_args()
    build = read(ROOT / 'build.json')
    if args.replay:
        saved = read(args.replay)
        require(saved['build'] == build and saved['manifest'] == MANIFEST and saved['corpus_sha256'] == CORPUS
                and saved['qualification'] is False, 'The signed runtime bind changed')
        require(all(read(args.replay.parent / name / 'arm.json') == saved['arms'][name]
                    for name,_ in CONTROLS), 'A stored control changed')
        comparison = summarize(saved['arms'], args.replay.parent)
        require(comparison == saved['comparison'], 'The switch reports changed')
        print(json.dumps(comparison, sort_keys=True, indent=2, allow_nan=False))
        return
    require(all((args.binary,args.pack,args.cache,args.out)), 'Missing signed input')
    require(mixed.digest(args.binary) == build['server_sha256'] and build['codesign_verified'] is True,
            'The signed server changed')
    inventory = read(ROOT / 'mxfp4-inventory.json')
    require(mixed.native.validate_inventory(args.pack, inventory, args.cache) == MANIFEST,
            'The initial pack verification changed')
    args.out.mkdir()
    prompts = workload()
    require(mixed.digest(ROOT / 'mixed-corpus.jsonl') == CORPUS, 'The workload corpus changed')
    arms = {}
    for name, child in CONTROLS:
        arms[name] = run_arm(args.binary, args.pack, args.out / name, child, prompts, extension=False)
        save(args.out / name / 'arm.json', arms[name])
    require(mixed.native.validate_inventory(args.pack, inventory, args.cache) == MANIFEST,
            'The final pack verification changed')
    save(args.out / 'receipt.json', {
        'build': build, 'manifest': MANIFEST, 'corpus_sha256': CORPUS, 'qualification': False,
        'arms': arms, 'comparison': summarize(arms,args.out),
    })


if __name__ == '__main__':
    main()
