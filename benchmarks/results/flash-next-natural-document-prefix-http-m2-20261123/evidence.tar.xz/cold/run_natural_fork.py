"""Measure the pre-learning path for repeated documents with different questions."""

from argparse import ArgumentParser
import json
from pathlib import Path
from time import monotonic

from run_fixed_extension import CASES, MANIFEST, ROOT, check_case, mixed, read, require, reuse, save, workload
from run_warm_prefix import overlap

ORDER = ('first', 'unseeded', 'replacement', 'aligned', 'cancel', 'boundary', 'outside')


def main():
    parser = ArgumentParser(description=__doc__)
    for field in ('binary', 'pack', 'out'):
        parser.add_argument(f'--{field}', type=Path)
    parser.add_argument('--check-inputs', action='store_true')
    args=parser.parse_args()
    prompts=workload()
    kinds={name:(peer,target,cancel,tail) for name,peer,target,cancel,_,tail in CASES}
    require(set(ORDER)==set(kinds), 'The natural fork controls changed')
    cold=prompts[kinds['first'][1]]['input_tokens'][:2048]
    require(cold != prompts[kinds['unseeded'][1]]['input_tokens'][:2048], 'Missing independent document')
    require(all(prompts[kinds[name][1]]['input_tokens'][:2048]==cold for name in ORDER if name!='unseeded'),
            'The related questions no longer share the served prefix')
    questions=[prompts[kinds[name][1]]['input_tokens'][2048:] for name in ORDER if name not in ('unseeded','outside')]
    require(len({q[0] for q in questions})==len(questions), 'Two questions no longer fork at the checked boundary')
    if args.check_inputs:
        print(json.dumps({'order':ORDER,'explicit_seed_requests':0,'question_lengths':[len(q) for q in questions]}))
        return
    require(args.binary is not None and args.pack is not None and args.out is not None, 'Missing run input')
    build=read(ROOT/'build.json'); inventory=read(ROOT/'mxfp4-inventory.json')
    require(mixed.digest(args.binary)==build['server_sha256'] and build['codesign_verified'] is True,
            'The signed variable-suffix executable changed')
    require(mixed.native.validate_inventory(args.pack,inventory)==MANIFEST, 'The publisher input changed')
    args.out.mkdir()
    flags=('--disable-ngram-acceleration','--total-blocks','2048','--max-batch-tokens','2049',*mixed.RESERVE_OPTIONS)
    env={'AX_MLX_FLASH_NEXT_FIXED_PREFIX_EXTENSION':'1','AX_ENGINE_PREFIX_REUSE_DISABLED':'0',
         'AX_MLX_PREFIX_CACHE_MAX_BYTES':'2147483648','AX_MLX_PREFIX_CACHE_MAX_ENTRIES':'8',
         'AX_MLX_FLASH_NEXT_DIRECT_COALESCING':'0','AX_MLX_FLASH_NEXT_PREFILL_SPLIT':'0',
         'AX_ENGINE_ADAPTIVE_PREFILL':'0'}
    cases,outputs={},{}
    with mixed.server(args,'natural',mixed.MODEL,args.pack,2,env=env,options=flags,stream_experts='auto',guard=True) as (base,_):
        require('decision=resident' in (args.out/'natural.log').read_text(), 'Resident experts required')
        for label in ORDER:
            peer,target,cancel,tail=kinds[label]
            before=reuse(base)
            started=monotonic()
            p,t=overlap(base,prompts[peer],prompts[target],disconnect=cancel)
            wall=monotonic()-started
            row={'peer':p,'target':t,'reuse_before':before,'reuse_after':reuse(base),
                 'drained':mixed.wait_drained(base),'wall_seconds':wall}
            cases[label]=row
            save(args.out/'partial.json',cases)
            outputs[label]=check_case(row,False,cancel,tail)
            print(f'natural {label} verified',flush=True)
    mixed.native.scrub_log(args.out/'natural.log')
    pressure=[json.loads(row) for row in (args.out/'natural-samples.jsonl').read_text().splitlines()]
    require(pressure and all(row['pressure']==1 for row in pressure),'Host pressure was not normal')
    require(outputs['first']['target_ids']!=outputs['replacement']['target_ids'],'Related questions lost their distinction')
    require(mixed.native.validate_inventory(args.pack,inventory)==MANIFEST,'Publisher data changed')
    save(args.out/'receipt.json',{'qualification':False,'build':build,'order':ORDER,'explicit_seed_requests':0,
                                 'cases':cases,'outputs':outputs,'normal_pressure_samples':len(pressure),'manifest':MANIFEST})


if __name__=='__main__':
    main()
