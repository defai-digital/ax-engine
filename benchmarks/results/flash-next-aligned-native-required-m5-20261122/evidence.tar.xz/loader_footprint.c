#include <errno.h>
#include <libproc.h>
#include <stdint.h>
#include <sys/resource.h>

int ax_lab_read_footprint(int pid, uint64_t *current, uint64_t *lifetime_peak) {
    struct rusage_info_v4 stats = {0};
    if (proc_pid_rusage(pid, RUSAGE_INFO_V4, (rusage_info_t *)&stats) != 0) {
        return errno ? errno : EIO;
    }
    *current = stats.ri_phys_footprint;
    *lifetime_peak = stats.ri_lifetime_max_phys_footprint;
    return 0;
}
