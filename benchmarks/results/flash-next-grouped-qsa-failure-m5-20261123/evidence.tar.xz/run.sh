#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
mode="$1"
pack="$2"
reference="$3"
link_root="$4"
previous="$5"
slot="$HOME/build/.ax-flash-next-native-test-slot"
export PATH="$HOME/.venvs/ax-engine/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
owned=0
release() {
    if (( owned )) && test "$(cat "$slot/owner.pid")" = "$$"; then
        rm "$slot/owner.pid"
        rmdir "$slot"
    fi
    owned=0
}
finish() {
    code=$?
    release
    printf '%s\n' "$code" > status.txt
}
trap finish EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
args=(--pack "$pack" --out "$PWD/observed")
case "$mode" in
    m5)
        test "$(sysctl -n hw.model hw.memsize)" = "$(printf 'Mac17,6\n137438953472')"
        python="$HOME/.venvs/ax-engine/bin/python"
        ref_python="$HOME/build/flash-next-official-20260923/launch-reference-env/bin/python"
        args+=(--link-root "$link_root")
        ;;
    m2)
        test "$(sysctl -n machdep.cpu.brand_string hw.memsize)" = "$(printf 'Apple M2 Ultra\n206158430208')"
        python="$HOME/code/ax-engine/.venv/bin/python"
        ;;
    *) exit 64;;
esac
shasum -a 256 -c inputs.sha256 >/dev/null
codesign --verify --strict ax-flash-grouped-qsa-fault-test
lib=$("$python" -B -c 'from importlib.metadata import distribution,version; assert version("mlx")==version("mlx-metal")=="0.32.4"; print(distribution("mlx").locate_file("mlx/lib"))')
expected=$("$python" -B -c 'import json; print(json.load(open("build.json"))["libmlx_sha256"])')
test "$(shasum -a 256 "$lib/libmlx.dylib" | awk '{print $1}')" = "$expected"
deadline=$((SECONDS+57600))
while test -n "$previous" && ! test -s "$previous/status.txt"; do
    (( SECONDS < deadline )) || exit 75
    kill -0 "$(cat "$previous/owner.pid")"
    sleep 30
done
while (( SECONDS < deadline )); do
    if test "$(sysctl -n kern.memorystatus_vm_pressure_level)" = 1 && mkdir "$slot" 2>/dev/null; then
        printf '%s\n' "$$" > "$slot/owner.pid"
        owned=1
        if ! ps -axo comm= | grep -Eq '/(ax-engine-server[^/]*|mtp-audit|direct_weights|ax-flash-.*-test)$'; then
            if [[ "$mode" == m2 ]] || test -s "$reference/status.txt"; then break; fi
            kill -0 "$(cat "$reference/owner.pid")"
            if ! test -s "$reference/headroom.jsonl"; then
                (cd "$reference" && "$ref_python" -B recover.py --preflight) > capacity.json
                if "$python" -B -c 'import json,sys; r=json.load(open("capacity.json"))["capacity"]; sys.exit(not (r["reason"]=="background-rss-exceeds-signed-margin" and r["pressure"]==1))'; then break; fi
            fi
        fi
        release
    fi
    sleep 30
done
test "$owned" = 1
/usr/bin/caffeinate -i /usr/bin/env -i HOME="$HOME" PATH="$PATH" DYLD_LIBRARY_PATH="$lib" \
    PYTHONDONTWRITEBYTECODE=1 "$python" -B -u live.py "${args[@]}"
shasum -a 256 -c inputs.sha256 >/dev/null
