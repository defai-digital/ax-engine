"""Exercise one failing QSA tile in a committed real-model prefill."""
from argparse import ArgumentParser
from importlib.metadata import version
import json
import os
from pathlib import Path
from subprocess import Popen
from threading import Event, Thread

from check_flash_next_native_support import sha256, validate_inventory, stop_owned
from run_qwen38_reference_serving import monitor_memory

HERE = Path(__file__).resolve().parent
BINARY = HERE / "ax-flash-grouped-qsa-fault-test"
TEST = "model::qwen4_exp_integration_tests::flash_next_grouped_eval_compile_failure_preserves_committed_prefix"


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--pack", type=Path, required=True)
    cli.add_argument("--link-root", type=Path)
    cli.add_argument("--out", type=Path, required=True)
    args = cli.parse_args()
    assert version("mlx") == version("mlx-metal") == "0.32.4"
    build = json.loads((HERE / "build.json").read_text())
    assert sha256(BINARY) == build["binary_sha256"]
    assert sha256(HERE / "source.patch") == build["patch_sha256"]
    inventory = json.loads((HERE / "mxfp4-inventory.json").read_text())
    assert len(inventory["members"]) == 49
    verified = validate_inventory(args.pack, inventory, args.link_root)
    assert verified["model-manifest.json"] == build["manifest_sha256"]
    prompt = (HERE / "prompt.json").read_text().strip()
    assert len(json.loads(prompt)) == 4095
    args.out.mkdir()
    row = args.out / "fault.json"
    flags = {
        "AX_MLX_FLASH_NEXT_QSA_GROUPED_EVAL": "1",
        "AX_MLX_FLASH_NEXT_QSA_PAIRED_GATHER": "0",
        "AX_MLX_FLASH_NEXT_QSA_INDEXED_PREFILL": "0",
        "AX_STREAM_EXPERTS": "off",
    }
    environment = os.environ | flags | {
        "AX_FLASH_NEXT_CANDIDATE_PACK_DIR": str(args.pack),
        "AX_FLASH_NEXT_PROMPT_IDS": prompt,
        "AX_FLASH_NEXT_SMOKE_OUTPUT": str(row),
    }
    with (args.out / "test.log").open("w") as log:
        proc = Popen([BINARY, TEST, "--exact", "--ignored", "--nocapture"],
                     env=environment, stdout=log, stderr=log, start_new_session=True)
        stop = Event()
        monitor = Thread(target=monitor_memory, args=(args.out, "native", proc, stop), daemon=True)
        monitor.start()
        try:
            status = proc.wait(timeout=720)
        finally:
            stop_owned(proc)
            stop.set()
            monitor.join(timeout=4)
    assert status == 0, (args.out / "test.log").read_text()[-1800:]
    text = (args.out / "test.log").read_text(errors="replace")
    assert "1 passed; 0 failed" in text
    assert "grouped prefill attention" in text and "ax_grouped_qsa_missing_symbol" in text
    samples = [json.loads(line) for line in (args.out / "native-samples.jsonl").read_text().splitlines()]
    assert samples and all(s["pressure"] == 1 and s["footprint_bytes"] <= 96 * 2**30 for s in samples)
    assert validate_inventory(args.pack, inventory, args.link_root) == verified
    result = {"build": build, "test": TEST, "flags": flags, "qualification": False,
              "manifest": verified, "prompt_sha256": sha256(HERE / "prompt.json"),
              "fault_sha256": sha256(row), "sample_count": len(samples),
              "samples_sha256": sha256(args.out / "native-samples.jsonl"),
              "original_test_log_sha256": sha256(args.out / "test.log"),
              "sampled_footprint_peak_bytes": max(s["footprint_bytes"] for s in samples)}
    (args.out / "receipt.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
