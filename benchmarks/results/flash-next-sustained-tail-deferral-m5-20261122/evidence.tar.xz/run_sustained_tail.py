"""Replay repeated mixed-length arrivals against both tail scheduling policies."""

from argparse import ArgumentParser
import json
from math import isclose
from pathlib import Path
from statistics import median
from unittest.mock import patch

from run_server_tail import ARMS, TRIGGER, capture_tail, client, mixed, require

ROOT = Path(__file__).resolve().parent
TRIGGERS = (48, 84, 86, 65, 88, 92, 48, 84, 86, 65, 88, 92)


def inputs():
    selected = mixed.bench.load_corpus(ROOT / "mixed-corpus.jsonl")
    oracle_path = ROOT / "solo-reference.json"
    oracle = json.loads(oracle_path.read_bytes())
    all_expected = mixed.verify_rows(oracle, selected)
    require(len(selected) == 220, "The original served workload changed")
    short = [case for case in selected if len(case.input_tokens) == 512]
    long = [case for case in selected if len(case.input_tokens) == 8192]
    pairs = [(short[index * 11], long[index * 2 - index // 11], trigger)
             for index, trigger in enumerate(TRIGGERS)]
    ids = [case.id for pair in pairs for case in pair[:2]]
    require(len(ids) == len(set(ids)) == 24, "The selected bursts repeat an input")
    return pairs, {key: all_expected[key] for key in ids}


def verify(raw, cases, expected, at, enabled):
    short, long = raw["traces"]
    short_row, long_row = raw["observations"]
    observed = raw["observations"]
    reports = raw["traces"]
    require(raw["trigger_token"] == at and len(raw["trigger"]) == 1
            and all(row["ok"] and row["prompt_id"] == case.id
                    and row["request_id"] == trace["request_id"]
                    and row["prompt_token_ids"] == case.input_tokens and row["output_token_ids"] == expected[case.id]
                    and len(trace["decode_step_ids"]) == len(expected[case.id]) == 96
                    and trace["initial_cursor"] == 0 and trace["cursor"] == len(case.input_tokens)
                    and not trace["partial"]
                    for row, trace, case in zip(observed, reports, cases, strict=True))
            and short["request_id"] != long["request_id"], "A request changed its frozen route or output")
    trigger = raw["trigger"][0]
    after = short["decode_step_ids"][at:]
    offered, sent = trigger["seconds"], long_row["started_at_s"]
    require(short["decode_step_ids"][at - 1] == trigger["step_id"]
            and offered <= sent < short_row["started_at_s"] + short_row["e2e_latency_ms"] / 1000
            and isclose(offered, long_row["scheduled_at_s"], abs_tol=1e-9)
            and isclose((sent - offered) * 1000, long_row["queue_delay_ms"], abs_tol=0.001),
            "The long request was not sent at the expected short token")
    held = short["held"]
    require(not long["held"] and (not held or enabled and at >= TRIGGER and held[0] in after),
            "The scheduler held an ineligible request")
    if held:
        index = after.index(held[0])
        require(held == after[index:index + len(held)], "The scheduler prolonged or restarted the hold")
    previous = 0
    last_step = trigger["step_id"]
    cuts = {}
    for row in long["prefill"]:
        end = (previous // client.LOGICAL + 1) * client.LOGICAL
        require(row["step_id"] > last_step and row["step_id"] not in held
                and previous < row["cursor"] <= end and row["cursor"] == previous + row["width"]
                and row["scheduled"] == (2 if row["step_id"] in after else 1),
                "The long request changed its prefill cursor, hold or peer ownership")
        cuts.setdefault(end, []).append(row)
        previous = row["cursor"]
        last_step = row["step_id"]
    require(previous == 8192 and len(cuts) == 4, "The long request did not finish its four logical prefills")
    overlapped = 0
    for end, rows in cuts.items():
        widths = [row["width"] for row in rows]
        markers = {row["split_end"] for row in rows}
        first = rows[0]["step_id"]
        if markers == {end}:
            require(widths == client.SPLIT_WIDTHS and first in after, "A mixed prefill cut changed geometry")
            overlapped += 1
        else:
            require(markers == {None} and widths == [client.LOGICAL] and first > after[-1],
                    "A solo prefill cut changed geometry")
    gap = short_row["stream_step_interval_ms"][at - 1:]
    require(len(gap) == 96 - at and len(short_row["stream_step_interval_ms"]) == 95, "Missing gap data")
    return {
        "hold_steps": len(held), "first_prefill_overlaps": long["prefill"][0]["step_id"] in after,
        "shared_prefill_groups": overlapped, "short_max_gap_ms": max(gap),
        "long_trigger_ttft_ms": long_row["ttft_ms"] + (sent - offered) * 1000,
    }


def main():
    parser = ArgumentParser(description=__doc__)
    for key in ("binary", "pack", "link-root", "out"):
        parser.add_argument(f"--{key}", type=Path)
    parser.add_argument("--check-inputs", action="store_true")
    args = parser.parse_args()
    cases, expected = inputs()
    if args.check_inputs:
        print(f"Verified {len(cases)} ordered arrivals and {sum(map(len, expected.values()))} frozen output IDs.")
        return
    build = json.loads((ROOT / "build.json").read_bytes())
    inventory_path = ROOT / "mxfp4-inventory.json"
    inventory = json.loads(inventory_path.read_bytes())
    require(mixed.digest(args.binary) == build["server_sha256"]
            and build["runtime_commit"] == "14235e84b01456cfcb40ba6fcb717ae4798fa8f7",
            "The tested binary differs from the primary holdout")
    manifest = mixed.native.validate_inventory(args.pack, inventory, args.link_root)
    require(manifest.get("model-manifest.json") ==
            "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef", "The delivered manifest changed")
    args.out.mkdir()
    receipt = {
        "scope": "M5 repeated early and late mixed-length arrivals",
        "qualification": False, "build": build, "manifest": manifest,
        "revision": inventory["revision"], "inventory_sha256": mixed.digest(inventory_path),
        "observed_workload": [{"short": short.id, "long": long.id, "at": at}
                              for short, long, at in cases],
        "arms": {},
    }

    def emit(path, value):
        temporary = path.with_suffix(".tmp")
        temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
        temporary.replace(path)

    def save(status):
        emit(args.out / "receipt.json", receipt | {"status": status})
        print(status, flush=True)

    options = ("--disable-ngram-acceleration", "--total-blocks", "2048", "--max-batch-tokens", "2049",
               *mixed.RESERVE_OPTIONS)
    try:
        for label, enabled in ARMS:
            save(f"{label}-starting")
            idle_before = mixed.native.wait_for_quiet()["cpu_idle_percent"]
            env = {"AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0", "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": "1",
                   "AX_MLX_FLASH_NEXT_PREFILL_TAIL_DEFERRAL": "1" if enabled else "0"}
            arm = args.out / label
            arm.mkdir()
            trials = []
            with mixed.server(args, label, mixed.MODEL, args.pack, 2, env=env, options=options,
                              stream_experts="auto", guard=True) as (base, _):
                require("decision=resident" in (args.out / f"{label}.log").read_text(), "Resident experts required")
                for index, (short, long, at) in enumerate(cases, 1):
                    pair = (short, long)
                    path = arm / f"burst-{index:02d}.json"
                    def check(raw, _):
                        return verify(raw, pair, expected, at, enabled)
                    with (patch.object(client, "TRIGGER_TOKEN", at),
                          patch.object(client.capture, "trace_stream", capture_tail),
                          patch.object(client, "verify_deferral", check)):
                        raw = client.burst(base, pair, expected, False, path.with_suffix(".partial.json"))
                    require(raw["drained"] == dict.fromkeys(mixed.COUNTERS, 0), "A burst did not drain")
                    emit(path, raw)
                    trials.append(check(raw, False) | {"sha256": mixed.digest(path), "trigger": at})
                    print(label, index, trials[-1]["hold_steps"], flush=True)
                require(json.loads(mixed.native.request(base, "/health"))["status"] == "ok", "Health declined")
            samples = [json.loads(line) for line in (args.out / f"{label}-samples.jsonl").read_text().splitlines()]
            late = [trial for trial in trials if trial["trigger"] >= TRIGGER]
            hold_count = sum(trial["hold_steps"] > 0 for trial in late)
            require(samples and {row["pressure"] for row in samples} == {1}
                    and (hold_count > 0 if enabled else hold_count == 0),
                    "Normal pressure or exposure requirement failed")
            receipt["arms"][label] = {
                "cpu_idle_percent": [idle_before, mixed.native.cpu_idle_percent()],
                "normal_pressure_samples": len(samples), "trials": trials,
                "late_with_holds": hold_count, "matching_output_ids": len(trials) * 192,
                "late_median_short_max_gap_ms": median(trial["short_max_gap_ms"] for trial in late),
                "late_median_long_trigger_ttft_ms": median(trial["long_trigger_ttft_ms"] for trial in late),
            }
            save(f"{label}-complete")
        require(mixed.native.validate_inventory(args.pack, inventory, args.link_root) == manifest, "Pack changed")
        save("complete")
    except Exception:
        save("failed")
        raise


if __name__ == "__main__":
    main()
