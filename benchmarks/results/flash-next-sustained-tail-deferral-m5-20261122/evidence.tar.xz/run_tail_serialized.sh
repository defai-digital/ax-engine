#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
observer="$1"
test -f "$observer/clean-capacity.jsonl"
test ! -e "$observer/clean-preflight.json"
test ! -e "$observer/headroom.jsonl"
test ! -e "$observer/status.txt"
owner=$(cat "$observer/owner.pid")
child=$(pgrep -P "$owner")
[[ "$child" =~ ^[0-9]+$ ]]
[[ "$(ps -p "$child" -o command=)" == *"wait_clean_window.sh "* ]]
paused=0
resume_observer() {
    if (( paused )) && [[ "$(ps -p "$child" -o command= 2>/dev/null)" == *"wait_clean_window.sh "* ]]; then
        /bin/kill -CONT "$child"
        echo capacity-observer-resumed
    fi
}
trap resume_observer EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
/bin/kill -STOP "$child"
paused=1
[[ "$(ps -p "$child" -o state=)" == T* ]]
[[ "$(ps -p "$child" -o command=)" == *"wait_clean_window.sh "* ]]
children=$(ps -axo ppid=,comm= | awk -v p="$child" '$1 == p {sub(/^.*\//,"",$2); print $2}')
[[ "$children" == "" || "$children" == sleep ]]
test ! -e "$observer/clean-preflight.json"
test ! -e "$observer/headroom.jsonl"
(
    cd "$observer"
    export PATH="/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
    exec "$HOME/build/flash-next-official-20260923/launch-reference-env/bin/python" -B recover.py --preflight
) > "dispatch-capacity.json"
"$HOME/.venvs/ax-engine/bin/python" -B - <<'PY'
import json, sys
r=json.load(open("dispatch-capacity.json"))["capacity"]
if (r["eligible_for_attempt"] or r["pressure"] != 1
        or r["reason"] != "background-rss-exceeds-signed-margin"):
    raise SystemExit("Retain the independent reference window.")
PY
echo two-slot-tail-acquired-primary
/bin/bash run_m5.sh "$2" "$3"
