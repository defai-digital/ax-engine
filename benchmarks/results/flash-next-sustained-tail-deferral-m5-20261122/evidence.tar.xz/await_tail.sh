#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
previous=$1
cache=$2
reference=$3
test "$(cat "$previous/status.txt")" = 0
test -d "$cache"
test -s "$reference/clean-capacity.jsonl"
deadline=$((SECONDS + 3600))
: > queued.txt
while (( SECONDS < deadline )); do
    if test -s "$reference/clean-preflight.json" || test -s "$reference/headroom.jsonl"; then
        printf '%s\n' 'The ordinary independent reference acquired the device.'
        exit 4
    fi
    if test -s "$reference/status.txt"; then
        printf '%s\n' 'The passive reference owner became terminal.'
        exit 5
    fi
    if /usr/bin/python3 -B - "$reference/clean-capacity.jsonl" <<'PY'
from datetime import datetime
import json,sys
from pathlib import Path
mark=Path('queued.txt')
line=Path(sys.argv[1]).read_bytes().splitlines()[-1]
sample=json.loads(line)
time=datetime.fromisoformat(sample['utc']).timestamp()
valid=(time >= mark.stat().st_mtime and sample.get('eligible_for_attempt') is False
    and sample.get('pressure')==1 and sample.get('reason')=='background-rss-exceeds-signed-margin')
raise SystemExit(not valid)
PY
    then
        /bin/bash run_tail_serialized.sh "$reference" "$previous" "$cache/cache"
        exit 0
    fi
    sleep 15
done
exit 75
