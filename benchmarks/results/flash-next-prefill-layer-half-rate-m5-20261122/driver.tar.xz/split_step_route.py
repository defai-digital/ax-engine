"""Read the request-keyed prefill cut published on the current SSE step."""

SPLIT_PREFIX = "ax_scheduler_prefill_split_end."


def split_decisions(step):
    route = step.get("route") or {}
    decisions = route.get("crossover_decisions") or {}
    return {key: value for key, value in decisions.items() if key.startswith(SPLIT_PREFIX)}
