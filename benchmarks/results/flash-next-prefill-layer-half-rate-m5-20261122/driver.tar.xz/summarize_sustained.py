"""Recompute mixed-serving metrics from the request streams and validate treatment."""
import argparse
from collections import defaultdict
import json
from math import isclose
from pathlib import Path
from statistics import median

import run_sustained as run

mixed = run.mixed
require = run.require


def summarize(client, traces, cases, expected, candidate):
    observations = client["observations"]
    outputs = mixed.verify_rows(client, cases)
    require(outputs == expected, "Greedy output differs from the single-slot trace")
    progress = run.validate_progress(traces, observations, candidate)
    rows = [row for row in observations if row["phase"] == "measured"]
    groups = defaultdict(list)
    for row in rows:
        groups[len(row["prompt_token_ids"])].append(row)

    def p95(values):
        return mixed.bench.summarize_values(values)["p95"]

    by_prompt = {}
    for length, cohort in groups.items():
        gaps = [row["stream_step_interval_ms"] for row in cohort]
        for row, intervals in zip(cohort, gaps, strict=True):
            require(len(intervals) == len(row["output_token_ids"]) - 1 and all(gap >= 0 for gap in intervals),
                    "Measured token interval count does not match the stream")
        arrival = [row["ttft_ms"] + (row["started_at_s"] - row["scheduled_at_s"]) * 1000 for row in cohort]
        by_prompt[str(length)] = {
            "requests": len(cohort),
            "p95_of_request_p95_token_gaps_ms": p95([p95(gap) for gap in gaps]),
            "p95_of_request_max_token_gaps_ms": p95([max(gap) for gap in gaps]),
            "max_token_gap_ms": max(map(max, gaps)),
            "arrival_ttft_p95_ms": p95(arrival),
            "server_call_ttft_p95_ms": p95([row["ttft_ms"] for row in cohort]),
            "client_lane_wait_p95_ms": p95([(row["started_at_s"] - row["scheduled_at_s"]) * 1000 for row in cohort]),
        }
    elapsed = max(row["started_at_s"] + row["e2e_latency_ms"] / 1000 for row in rows)
    generated = sum(map(len, outputs.values()))
    throughput = generated / elapsed
    require(isclose(client["summary"]["output_token_throughput_tok_s"], throughput, rel_tol=1e-9),
            "Client throughput disagrees with stream timing")
    return {"requests": len(rows), "matched_output_ids": generated, "output_tokens_per_second": throughput,
            "after_final_offered_arrival_seconds": elapsed - max(row["scheduled_at_s"] for row in rows),
            "arrival_ttft_p95_ms": p95([row["ttft_ms"] + (row["started_at_s"] - row["scheduled_at_s"]) * 1000
                                        for row in rows]),
            "client_lane_wait_p95_ms": p95([(row["started_at_s"] - row["scheduled_at_s"]) * 1000
                                          for row in rows]),
            "layer_requests": progress, "by_prompt_tokens": by_prompt}


def request_effects(rows):
    return {row["prompt_id"]: (
        len(row["prompt_token_ids"]),
        mixed.bench.summarize_values(row["stream_step_interval_ms"])["p95"],
        row["ttft_ms"],
        (row["started_at_s"] - row["scheduled_at_s"]) * 1000,
    ) for row in rows if row["phase"] == "measured"}


def matched_effects(before, after):
    require(before.keys() == after.keys(), "Paired prompt identities differ")
    cohorts = defaultdict(list)
    for ident, (length, gap, ttft, queued) in before.items():
        other_length, other_gap, other_ttft, other_queued = after[ident]
        require(length == other_length, "Paired prompt geometry differs")
        cohorts[str(length)].append((other_gap - gap, other_ttft - ttft, other_queued - queued))
    return {length: {
        "requests": len(rows),
        "shorter_p95_gap_requests": sum(gap < 0 for gap, _, _ in rows),
        "longer_p95_gap_requests": sum(gap > 0 for gap, _, _ in rows),
        "median_p95_gap_delta_ms": median(gap for gap, _, _ in rows),
        "median_call_ttft_delta_ms": median(ttft for _, ttft, _ in rows),
        "median_client_lane_wait_delta_ms": median(queued for _, _, queued in rows),
    } for length, rows in cohorts.items()}


def summarize_pairs(arms, requests):
    pairs = []
    for control, candidate in (("physical-1", "layers-1"), ("physical-2", "layers-2")):
        if control not in arms or candidate not in arms:
            continue
        baseline, treatment = arms[control], arms[candidate]

        def delta(now, before):
            return (now / before - 1) * 100

        duration = "arrival_ttft_p95_ms"
        gap = "p95_of_request_p95_token_gaps_ms"
        max_gap = "p95_of_request_max_token_gaps_ms"
        dispatch = "server_call_ttft_p95_ms"
        bc, tc = baseline["by_prompt_tokens"], treatment["by_prompt_tokens"]
        pairs.append({
            "control": control,
            "candidate": candidate,
            "timing_eligible": baseline["timing_eligible"] and treatment["timing_eligible"],
            "short_gap_p95_change_percent": delta(tc["512"][gap], bc["512"][gap]),
            "short_gap_p95_of_max_change_percent": delta(tc["512"][max_gap], bc["512"][max_gap]),
            "short_dispatched_ttft_p95_change_percent": delta(tc["512"][dispatch], bc["512"][dispatch]),
            "long_dispatched_ttft_p95_change_percent": delta(tc["8192"][dispatch], bc["8192"][dispatch]),
            "short_max_gap_change_percent": delta(tc["512"]["max_token_gap_ms"], bc["512"]["max_token_gap_ms"]),
            "long_arrival_ttft_p95_change_percent": delta(tc["8192"][duration], bc["8192"][duration]),
            "matched_request_effects_by_prompt_tokens": matched_effects(requests[control], requests[candidate]),
            "total_throughput_change_percent": delta(treatment["output_tokens_per_second"],
                                                      baseline["output_tokens_per_second"]),
        })
    return pairs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("live_dir", type=Path)
    parser.add_argument("--allow-partial", action="store_true")
    args = parser.parse_args()
    root = args.live_dir
    workload, _, cases, expected, solo = run.inputs()
    receipt_path = root / "receipt.json"
    receipt = json.loads(receipt_path.read_bytes())
    source_path = root / "portable-sources.json"
    portable = json.loads(source_path.read_bytes()) if source_path.is_file() else None
    if portable:
        require(portable["receipt_sha256"] == mixed.digest(receipt_path)
                and portable["arms"].keys() == receipt["arms"].keys()
                and portable["client_redaction"] == ["target.base_url", "corpus.path"],
                "Portable observation identity changed")
    require(receipt["workload"] == workload and receipt["solo_sha256"] == solo
            and receipt["qualification"] is False, "The terminal receipt binds different inputs")
    if not args.allow_partial:
        require(receipt["status"] == "complete" and list(receipt["arms"]) == [name for name, _ in run.ARMS],
                "Complete ABBA required")
    arms, requests = {}, {}
    for name, candidate in run.ARMS:
        if name not in receipt["arms"]:
            continue
        meta = receipt["arms"][name]
        pending_client, pending_trace = root / f"{name}.json", root / f"{name}.trace.json"
        expected_client = meta["client_sha256"]
        samples_path = root / f"{name}-samples.jsonl"
        if portable:
            source = portable["arms"][name]
            require(source["client_sha256"] == expected_client and source["trace_sha256"] == meta["trace_sha256"]
                    and source["samples_sha256"] == mixed.digest(samples_path), "Portable source binding changed")
            expected_client = source["cleaned_client_sha256"]
        require(expected_client == mixed.digest(pending_client) and meta["trace_sha256"] == mixed.digest(pending_trace),
                "Client or step checksum changed")
        client, trace = (json.loads(path.read_bytes()) for path in (pending_client, pending_trace))
        if portable:
            require("base_url" not in client["target"] and "path" not in client["corpus"],
                    "Portable client contains a local path or endpoint")
        values = summarize(client, trace, cases, expected, candidate)
        activation = mixed.capture.summarize_activation(trace, client["observations"])
        require(activation == meta["split_activation"]
                and activation["split_groups"] == activation["split_groups_with_published_end"] > 0,
                "The physical split receipt disagrees with the captured boundaries")
        requests[name] = request_effects(client["observations"])
        require(meta["matched_requests"] == values["requests"] and meta["matched_output_ids"] == values["matched_output_ids"]
                and meta["layer_requests"] == values["layer_requests"]
                and meta["drained"] == dict.fromkeys(mixed.COUNTERS, 0), "Receipt disagrees with stream or shutdown")
        samples = [json.loads(line) for line in samples_path.read_text().splitlines()]
        require(samples and len(samples) == meta["pressure_samples"] and all(row["pressure"] == 1 for row in samples),
                "System memory pressure exceeded normal")
        before, after = meta["cpu_idle_before_percent"], meta["cpu_idle_after_percent"]
        arms[name] = values | {"cpu_idle_before_percent": before, "cpu_idle_after_percent": after,
                              "timing_eligible": min(before, after) >= 90,
                              "peak_footprint_bytes": max(row["footprint_bytes"] for row in samples)}
    print(json.dumps({"qualification": False, "status": receipt["status"], "arms": arms,
                      "pairs": summarize_pairs(arms, requests)}, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
