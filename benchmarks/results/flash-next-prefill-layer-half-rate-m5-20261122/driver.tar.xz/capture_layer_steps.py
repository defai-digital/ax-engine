"""Record suspended prefill steps after the timed SSE client drains its socket."""

import sys

import capture_mixed_steps as capture

PREFIX = "ax_runner_prefill_layers_completed."
RESUME = "ax_scheduler_prefill_layers_completed."
original = capture.trace_stream


def trace_stream(events):
    summary = original(events)
    if summary is None:
        return None
    request_id = summary["request_id"]
    partial = []
    for name, payload, _ in events:
        if name != "step":
            continue
        step = payload["step"]
        decisions = (step.get("route") or {}).get("crossover_decisions") or {}
        key = f"{PREFIX}{request_id}"
        if key not in decisions:
            continue
        if payload.get("delta_tokens"):
            raise ValueError("A paused prefill emitted visible output")
        partial.append({
            "step_id": step["step_id"],
            "cursor": payload["request"]["processed_prompt_tokens"],
            "logical_end": capture.split_decisions(step)[f"{capture.SPLIT_PREFIX}{request_id}"],
            "completed": decisions[key],
            "previous": decisions.get(f"{RESUME}{request_id}", 0),
            "scheduled": step["scheduled_requests"],
            "runner_time_us": step["runner_time_us"],
        })
    return summary | {"partial": partial}


if __name__ == "__main__":
    capture.trace_stream = trace_stream
    raise SystemExit(capture.main(sys.argv[1:]))
