"""Preserve exact mixed-serving observations with local request metadata removed."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path

from run_sustained import ARMS, require

PRIVATE = (b"127.0.0.1:", b"localhost:", b"/Users/", b"/private/tmp/", b"df-macbook", b"um-macstudio")


def digest(data):
    return sha256(data).hexdigest()


def verify_private(data):
    require(not any(item in data for item in PRIVATE), "An observation contains host-specific metadata")


def seal(raw, dest, complete=True):
    receipt = (raw / "receipt.json").read_bytes()
    verified = json.loads(receipt)
    names = list(verified["arms"])
    if complete:
        require(verified["status"] == "complete" and names == [name for name, _ in ARMS],
                "The mixed-serving run has not completed ABBA")
    verify_private(receipt)
    dest.mkdir()
    source = {"receipt_sha256": digest(receipt), "client_redaction": ["target.base_url", "corpus.path"], "arms": {}}
    (dest / "receipt.json").write_bytes(receipt)
    for name in names:
        row = verified["arms"][name]
        client_path, trace_path, samples_path = (
            raw / f"{name}{suffix}" for suffix in (".json", ".trace.json", "-samples.jsonl"))
        client_raw, trace, samples = (path.read_bytes() for path in (client_path, trace_path, samples_path))
        require(digest(client_raw) == row["client_sha256"] and digest(trace) == row["trace_sha256"],
                "The received client and trace data are not the ones committed in the live receipt")
        client = json.loads(client_raw)
        require("base_url" in client["target"] and "path" in client["corpus"],
                "Expected raw client path and endpoint")
        client["target"].pop("base_url")
        client["corpus"].pop("path")
        cleaned = (json.dumps(client, separators=(",", ":"), allow_nan=False) + "\n").encode()
        for path, data in ((client_path, cleaned), (trace_path, trace), (samples_path, samples)):
            verify_private(data)
            (dest / path.name).write_bytes(data)
        source["arms"][name] = {
            "client_sha256": row["client_sha256"],
            "cleaned_client_sha256": digest(cleaned),
            "trace_sha256": row["trace_sha256"],
            "samples_sha256": digest(samples),
        }
    (dest / "portable-sources.json").write_text(json.dumps(source, indent=2, allow_nan=False) + "\n")


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("raw", type=Path)
    parser.add_argument("destination", type=Path)
    options = parser.parse_args()
    seal(options.raw, options.destination)


if __name__ == "__main__":
    main()
