"""Keep the work and prefill boundaries that terminal SSE summaries omit."""

import json
from pathlib import Path
import sys
import time

import bench_ax_serving as bench

from split_step_route import SPLIT_PREFIX, split_decisions
PHYSICAL_WIDTHS = (512, 512, 512, 511, 1)
LOGICAL_WIDTH = sum(PHYSICAL_WIDTHS)


def trace_stream(events):
    request_id = None
    initial_cursor = 0
    cursor = 0
    prefill = []
    observed_step = None
    decoding = []
    result = None
    for name, payload, _ in events:
        if name == "request":
            request = payload["request"]
            request_id = request["request_id"]
            initial_cursor = cursor = request["processed_prompt_tokens"]
        elif name == "step":
            request = payload["request"]
            step = payload["step"]
            advanced = request["processed_prompt_tokens"] - cursor
            step_id = step.get("step_id")
            scheduled = step["scheduled_requests"]
            if request_id != request["request_id"] or advanced < 0:
                raise RuntimeError("Streaming step changed request or regressed its prompt cursor")
            has_output = bool(payload.get("delta_tokens"))
            if advanced or has_output:
                if type(step_id) is not int or (observed_step is not None and step_id <= observed_step):
                    raise RuntimeError("Measured progress lacks a strictly advancing engine step ID")
                observed_step = step_id
            if advanced:
                cursor = request["processed_prompt_tokens"]
                decisions = split_decisions(step)
                if any(key != f"{SPLIT_PREFIX}{request_id}" for key in decisions):
                    raise RuntimeError("Prefill step published another request's split boundary")
                prefill.append({
                    "step_id": step_id, "cursor": cursor, "width": advanced,
                    "scheduled": scheduled, "split_end": decisions.get(f"{SPLIT_PREFIX}{request_id}"),
                })
            if has_output:
                decoding.append(step_id)
        elif name == "response":
            response = payload["response"]
            if response["request_id"] != request_id:
                raise RuntimeError("Terminal SSE request identity changed")
            result = {
                "request_id": request_id, "initial_cursor": initial_cursor,
                "cursor": cursor, "prefill": prefill, "decode_step_ids": decoding,
            }
    return result


def summarize_activation(traces, observations):
    requests = {row["request_id"]: row for row in traces}
    measured = [row for row in observations if row["phase"] == "measured"]
    ids = {row["request_id"] for row in measured}
    if (len(requests) != len(traces) or len(ids) != len(measured)
            or not ids.issubset(requests)):
        raise RuntimeError("Missing or repeated request identities in mixed SSE traces")
    decoder_by_step = {}
    for ident in ids:
        steps = tuple(dict.fromkeys(requests[ident]["decode_step_ids"]))
        for step_id in steps[1:]:
            decoder_by_step.setdefault(step_id, set()).add(ident)

    split_requests = 0
    split_groups = 0
    groups_with_route = 0
    requests_with_shared_decode = 0
    requests_with_confirmed_shared_decode = 0
    per_length = {}
    for measured_row in measured:
        ident = measured_row["request_id"]
        trace = requests[ident]
        prompt_tokens = len(measured_row["prompt_token_ids"])
        if trace["cursor"] != prompt_tokens or not trace["decode_step_ids"]:
            raise RuntimeError("Measured stream lacks complete prefill or decode progress")
        prefill = trace["prefill"]
        widths = [step["width"] for step in prefill]
        sizes = per_length.setdefault(str(prompt_tokens), {"requests": 0, "split": 0, "shared": 0})
        sizes["requests"] += 1
        split = shared = confirmed_shared = False
        for start in range(len(prefill) - len(PHYSICAL_WIDTHS) + 1):
            end = start + len(PHYSICAL_WIDTHS)
            cursor_before = prefill[start]["cursor"] - widths[start]
            if cursor_before % LOGICAL_WIDTH or tuple(widths[start:end]) != PHYSICAL_WIDTHS:
                continue
            group = prefill[start:end]
            logical_end = cursor_before + LOGICAL_WIDTH
            markers = {step["split_end"] for step in group if step["split_end"] is not None}
            if markers and markers != {logical_end}:
                raise RuntimeError("Published split boundary disagrees with physical prefill")
            published = all(step["split_end"] == logical_end for step in group)
            split = True
            split_groups += 1
            groups_with_route += published
            group_shared = any(
                step["width"] == 512 and step["scheduled"] == 2
                and any(sibling != ident for sibling in decoder_by_step.get(step["step_id"], ()))
                for step in group
            )
            shared |= group_shared
            confirmed_shared |= group_shared and published
        split_requests += split
        requests_with_shared_decode += shared
        requests_with_confirmed_shared_decode += confirmed_shared
        sizes["split"] += split
        sizes["shared"] += shared
    return {
        "split_requests": split_requests, "split_groups": split_groups,
        "split_groups_with_published_end": groups_with_route,
        "split_requests_with_shared_decode": requests_with_shared_decode,
        "split_requests_with_route_and_shared_decode": requests_with_confirmed_shared_decode,
        "capture_processing_ms": bench.summarize_values(requests[ident]["capture_processing_ms"] for ident in ids),
        "by_prompt_tokens": per_length,
    }


def with_trace(observer, traces):
    def observe(events, **arguments):
        # The benchmark has already drained the socket and fixed completion time.
        result = observer(events, **arguments)
        started = time.perf_counter()
        trace = trace_stream(events)
        if trace is not None:
            trace["capture_processing_ms"] = (time.perf_counter() - started) * 1000
            traces.append(trace)
        return result
    return observe


def main(argv):
    trace_path = Path(argv[0])
    traces = []
    previous = bench.observe_stream
    bench.observe_stream = with_trace(previous, traces)
    try:
        status = bench.main_with_args_for_test(argv[1:])
    finally:
        bench.observe_stream = previous
    trace_path.write_text(json.dumps(traces, separators=(",", ":"), allow_nan=False) + "\n")
    return status


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
