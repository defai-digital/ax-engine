"""Replay the frozen mixed workload over physical splits and 16-layer groups."""
from argparse import ArgumentParser
from collections import Counter, defaultdict
import json
from pathlib import Path
import subprocess
import sys

import run_selective_mixed as mixed

ROOT = Path(__file__).resolve().parent
ARMS = (("physical-1", False), ("layers-1", True), ("layers-2", True), ("physical-2", False))
GROUP_SIZE = 16


def require(valid, message):
    if not valid:
        raise ValueError(message)


def inputs():
    workload, corpus, cases = mixed.workload()
    require(Counter(len(case.input_tokens) for case in cases) == {512: 132, 2048: 66, 8192: 22},
            "The prompt workload changed")
    reference = ROOT / "solo-reference.json"
    reference_sha = mixed.digest(reference)
    expected = mixed.verify_rows(json.loads(reference.read_bytes()), cases)
    rec = json.loads((ROOT / "arrival-scale.json").read_bytes())
    stretched = ROOT / "half-rate-corpus.jsonl"
    rows = [json.loads(line) for line in corpus.read_text().splitlines()]
    derived = [row | {"arrival_s": 2 * row["arrival_s"]} for row in rows]
    require(rec["time_scale"] == 2 and rec["source_sha256"] == mixed.digest(corpus)
            and rec["derived_sha256"] == mixed.digest(stretched)
            and [json.loads(line) for line in stretched.read_text().splitlines()] == derived,
            "Only the frozen offered arrival clock may change")
    return workload | {"arrival_scale": rec}, stretched, mixed.bench.load_corpus(stretched), expected, reference_sha


def validate_progress(traces, observations, candidate):
    measured = {row["request_id"]: row for row in observations if row["phase"] == "measured"}
    by_id = {row["request_id"]: row for row in traces}
    require(len(by_id) == len(traces) and measured.keys() <= by_id.keys(), "Missing or repeated SSE traces")
    decoders = defaultdict(set)
    for ident, row in by_id.items():
        for step in row["decode_step_ids"][1:]:
            decoders[step].add(ident)
    by_prompt = Counter()
    for ident, measured_row in measured.items():
        trace = by_id[ident]
        length = len(measured_row["prompt_token_ids"])
        require(trace["initial_cursor"] == 0 and trace["cursor"] == length
                and len(trace["decode_step_ids"]) == len(measured_row["output_token_ids"]),
                "Stream did not consume its full prompt or publish every output token")
        boundaries = {row["cursor"] - row["width"]: row for row in trace["prefill"]}
        resumes = {}
        for row in trace["partial"]:
            cursor = row["cursor"]
            boundary = boundaries[cursor]
            previous = resumes.get(cursor, 0)
            require(candidate and length >= 2048 and row["scheduled"] == 2 and row["runner_time_us"] > 0
                    and row["previous"] == previous and row["completed"] == previous + GROUP_SIZE < 48
                    and row["logical_end"] == boundary["split_end"] == ((cursor // 2048) + 1) * 2048
                    and boundary["width"] in (511, 512) and row["step_id"] < boundary["step_id"]
                    and bool(decoders[row["step_id"]] - {ident}),
                    "Layer progress did not preserve the peer decode or original boundary")
            resumes[cursor] = row["completed"]
        if trace["partial"]:
            by_prompt[str(length)] += 1
    if candidate:
        require(bool(by_prompt), "The candidate did not exercise a measured layer suspension")
    return dict(by_prompt)


def main():
    p = ArgumentParser(description=__doc__)
    for name in ("pack", "binary", "link-root", "out"):
        p.add_argument(f"--{name}", type=Path)
    p.add_argument("--check-inputs", action="store_true")
    args = p.parse_args()
    workload, corpus, cases, expected, ref_sha = inputs()
    if args.check_inputs:
        print(f"Verified {len(cases)} frozen prompts and single-slot outputs.")
        return
    build = json.loads((ROOT / "build.json").read_bytes())
    inventory_path = ROOT / "mxfp4-inventory.json"
    inventory = json.loads(inventory_path.read_bytes())
    require(mixed.digest(args.binary) == build["server_sha256"], "The tested binary changed")
    manifest = mixed.native.validate_inventory(args.pack, inventory, args.link_root)
    require(manifest.get("model-manifest.json") ==
            "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef",
            "The delivered manifest changed")
    result = {"qualification": False, "build": build, "revision": inventory["revision"], "manifest": manifest,
              "inventory_sha256": mixed.digest(inventory_path), "workload": workload, "solo_sha256": ref_sha,
              "arms": {}}
    args.out.mkdir()

    def save(status):
        result["status"] = status
        temporary = args.out / "receipt.tmp"
        temporary.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
        temporary.replace(args.out / "receipt.json")
        print(status, flush=True)

    options = ("--disable-ngram-acceleration", "--total-blocks", "2048", "--max-batch-tokens", "2049",
               *mixed.RESERVE_OPTIONS)
    try:
        for name, candidate in ARMS:
            save(f"{name}-starting")
            quiet = mixed.native.wait_for_quiet()
            env = {"AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0", "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": "1",
                   "AX_MLX_FLASH_NEXT_PREFILL_LAYER_YIELD": "1" if candidate else "0",
                   "AX_MLX_FLASH_NEXT_PREFILL_LAYER_GROUP": str(GROUP_SIZE)}
            client = args.out / f"{name}.json"
            trace = args.out / f"{name}.trace.json"
            with mixed.server(args, name, mixed.MODEL, args.pack, 2, env=env, options=options,
                              stream_experts="auto", guard=True) as (base, _):
                require("decision=resident" in (args.out / f"{name}.log").read_text(), "Resident experts required")
                with (args.out / f"{name}.client.log").open("x") as output:
                    subprocess.run([sys.executable, str(ROOT / "capture_layer_steps.py"), str(trace),
                                    "--base-url", base, "--model-id", mixed.MODEL, "--input-kind", "tokens",
                                    "--corpus", str(corpus), "--corpus-arrivals", "--warmup-requests", "2",
                                    "--concurrency", "2", "--ignore-eos", "--record-token-ids", "--timeout", "300",
                                    "--output", str(client)], stdout=output, stderr=output, check=True, timeout=2300)
                observed = json.loads(client.read_bytes())
                tokens = mixed.verify_rows(observed, cases)
                changed = [key for key in expected if tokens[key] != expected[key]]
                require(not changed, f"Greedy output changed for {changed}")
                traces = json.loads(trace.read_bytes())
                progress = validate_progress(traces, observed["observations"], candidate)
                split = mixed.capture.summarize_activation(traces, observed["observations"])
                require(split["split_groups"] == split["split_groups_with_published_end"] > 0,
                        "Physical split control did not execute or lacked its split boundary")
                drained = mixed.wait_drained(base)
                require(json.loads(mixed.native.request(base, "/health"))["status"] == "ok", "Health declined")
            samples = [json.loads(line) for line in (args.out / f"{name}-samples.jsonl").read_text().splitlines()]
            require(samples and all(row["pressure"] == 1 for row in samples), "Memory pressure exceeded normal")
            result["arms"][name] = {"layer_group": GROUP_SIZE if candidate else None, "matched_requests": len(tokens),
                                    "matched_output_ids": sum(map(len, tokens.values())), "layer_requests": progress,
                                    "split_activation": split, "drained": drained, "pressure_samples": len(samples),
                                    "cpu_idle_before_percent": quiet["cpu_idle_percent"],
                                    "cpu_idle_after_percent": mixed.native.cpu_idle_percent(),
                                    "client_sha256": mixed.digest(client), "trace_sha256": mixed.digest(trace)}
            save(f"{name}-complete")
        require(mixed.native.validate_inventory(args.pack, inventory, args.link_root) == manifest, "Pack changed")
        save("complete")
    except Exception:
        save("failed")
        raise


if __name__ == "__main__":
    main()
