"""Recheck the exact Flash Next pair and seal its portable delivery evidence."""

from argparse import ArgumentParser
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import re

from compare_delivery import ARMS, ROOT, THRESHOLDS, assess_arm, delivery, gate, read, require

PRIVATE = re.compile(rb"/Users/|/Volumes/|/private/|/var/folders/|\b127\.0\.0\.1\b|df-macbook|um-macstudio|tn-macstudio")
ROUTE = "Flash Next MTP sidecar prefetch"
TRANSFER_REPLAY = Path("benchmarks/results/flash-next-fresh-delivery-38c90b27a-m5-20261122/replay.py")
MODES = (*delivery.CONTROL_MODES, "required-kill-switch")


def digest(raw):
    return sha256(raw).hexdigest()


def data(value):
    return (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()


def transfer_checker(repo):
    source = repo / TRANSFER_REPLAY
    spec = importlib.util.spec_from_file_location("flash_delivery_transfer_replay", source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.check_transfer


def validate(root, build, repo):
    stock = read(ROOT / "stock-native.json")
    thresholds = read(THRESHOLDS)
    pair = read(root / "pair.json")
    ready = pair["phase"] == "complete"
    labels = ARMS if ready else ARMS[:1]
    require(pair["phase"] in ("mapped-complete", "complete")
            and pair["arms"] == list(ARMS) and pair["qualification"] is False
            and pair["build"] == build and list(pair["results"]) == list(labels)
            and pair["modes"] == list(delivery.CONTROL_MODES)
            and pair["frozen_readiness"] == thresholds["readiness"]
            and pair["frozen_host"] == thresholds["timing_host"]
            and pair["pack_revision"] == stock["revision"],
            "The staging contract, release build or pair phase changed")
    check_transfer = transfer_checker(repo)
    arms = {}
    destinations = set()
    for label in labels:
        source = root / label
        result = read(source / "result.json")
        destination = result["download"]["terminal"]["dest"]
        require(isinstance(destination, str) and Path(destination).name == stock["revision"]
                and destination not in destinations, "Expected a distinct cache destination for every arm")
        destinations.add(destination)
        native = source / "native-support"
        original = pair["results"][label]
        host = read(native / "host-samples.json")
        require(set(host) == set(delivery.CONTROL_MODES)
                and all(all(type(value) in (int, float) for value in readings["cpu_idle_percent"])
                        and all(type(value) is int for value in readings["pressure"])
                        for readings in host.values()), "Invalid host sample types")
        arm = assess_arm(source, label == "prefetch", host, build, thresholds, stock)
        require(arm == original, f"Raw native or delivery receipts differ for {label}")
        count = check_transfer((source / "download.ndjson").read_bytes(), result,
                               thresholds["target"]["published_bytes"])
        arms[label] = {**arm, "verified_download_progress_events": count}
    eligible = ready and all(row["timing_eligible"] for row in arms.values())
    if ready:
        require(pair["timing_eligible"] is eligible, "Host eligibility changed")
    delta = None
    if eligible:
        before, after = [arms[label]["delivery_readiness"]["delivered"] for label in ARMS]
        if all(gate.positive_measurement(x.get(mode)) for x in (before, after) for mode in delivery.CONTROL_MODES):
            delta = {mode: round(after[mode] - before[mode], 3) for mode in delivery.CONTROL_MODES}
    require(pair.get("prefetch_minus_mapped_ready_seconds") == delta, "Startup timing comparison changed")
    return {"qualification": False, "runtime_commit": build["commit"], "phase": pair["phase"],
            "timing_eligible": eligible, "prefetch_minus_mapped_ready_seconds": delta, "arms": arms}


def seal(raw, out, build, repo):
    original_summary = validate(raw, build, repo)
    pair = read(raw / "pair.json")
    provenance = {}
    out.mkdir()
    for label in pair["results"]:
        source = raw / label
        delivery_raw = (source / "result.json").read_bytes()
        download_raw = (source / "download.ndjson").read_bytes()
        native_path = source / "native-support"
        target = out / label
        (target / "native-support").mkdir(parents=True)
        fields = read(source / "result.json")
        terminal = fields["download"]["terminal"]
        require(terminal == json.loads(download_raw.splitlines()[-1]) and isinstance(terminal["dest"], str),
                "Delivery and NDJSON terminal coordinates differ")
        terminal["dest"] = f"[{label}-cache]/snapshots/{fields['revision']}"
        original_progress = download_raw.rstrip(b"\n").rsplit(b"\n", 1)[0]
        changes = {
            "result.json": (delivery_raw, data(fields)),
            "download.ndjson": (download_raw, original_progress + b"\n" + json.dumps(terminal).encode() + b"\n"),
        }
        for item in ("result.json", "host-samples.json"):
            blob = (native_path / item).read_bytes()
            changes[f"native-support/{item}"] = (blob, blob)
        for mode in MODES:
            name = f"server-{mode}.log"
            blob = (native_path / name).read_bytes()
            lines = []
            for line in re.sub(r"\x1b\[[0-9;]*m", "", blob.decode()).splitlines():
                _, marker, fields = line.partition(ROUTE)
                if marker:
                    lines.append(marker + fields)
            clean = ("\n".join(lines) + "\n").encode()
            changes[f"native-support/{name}"] = (blob, clean)
        provenance[label] = {name: {"original": digest(before), "portable": digest(after)}
                             for name, (before, after) in changes.items()}
        for name, (_, portable) in changes.items():
            require(not PRIVATE.search(portable), f"Unexpected local identifier in {label}/{name}")
            (target / name).write_bytes(portable)
        pair["results"][label]["raw_delivery_sha256"] = digest(changes["result.json"][1])
        original_summary["arms"][label]["raw_delivery_sha256"] = digest(changes["result.json"][1])
    (out / "pair.json").write_bytes(data(pair))
    (out / "source-sha256.json").write_bytes(data(provenance))
    measured = validate(out, build, repo)
    require(original_summary == measured, "Portable evidence changed a delivery or startup observation")
    return measured


if __name__ == "__main__":
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("raw", type=Path)
    cli.add_argument("build", type=Path)
    cli.add_argument("--repo", type=Path, required=True)
    cli.add_argument("--seal", type=Path)
    args = cli.parse_args()
    build = read(args.build)
    result = seal(args.raw, args.seal, build, args.repo) if args.seal else validate(args.raw, build, args.repo)
    print(json.dumps(result, indent=2, allow_nan=False))
