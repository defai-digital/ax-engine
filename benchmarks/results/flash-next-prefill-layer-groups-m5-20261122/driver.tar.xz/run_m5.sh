#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
test "$(/usr/sbin/sysctl -n hw.model hw.memsize)" = "$(printf 'Mac17,6\n137438953472')"
if /bin/ps -axo comm= | /usr/bin/grep -E '/(ax-engine-server[^/]*|layer-peer-probe|mtp-audit)$'; then
    exit 1
fi
/usr/bin/shasum -a 256 -c inputs.sha256
cache="$1"
pack="$cache/models--AutomatosX--AX-Qwen3.8-Flash-Next-MLX-AXQ-MXFP4-MTP/snapshots/ff2a28485eb89bb60e8fe35dd6c65c51e63ee7b3"
python="$HOME/.venvs/ax-engine/bin/python"
mlx=$("$python" -c 'import importlib.metadata as m; assert m.version("mlx") == m.version("mlx-metal") == "0.32.4"; print(m.distribution("mlx").locate_file("mlx/lib"))')
exec /usr/bin/caffeinate -dimsu /usr/bin/env -i HOME="$HOME" \
  PATH="$HOME/.venvs/ax-engine/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin" \
  DYLD_LIBRARY_PATH="$mlx" PYTHONDONTWRITEBYTECODE=1 \
  "$python" -B -u run_layer_http.py --binary "$PWD/ax-engine-server-layer-http" \
  --pack "$pack" --link-root "$cache" --out "$PWD/http" --repeat
