"""Measure matched Flash Next workload arrivals under one and two live slots."""

import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import bench_ax_serving as bench
import capture_mixed_steps as capture
import check_flash_next_native_support as native
from run_flash_next_prefill_split_probe import MODEL, RESERVE_OPTIONS
from run_qwen38_reference_serving import server


ROOT = Path(__file__).resolve().parent
LENGTHS = (2048, 2049, 2050, 8192)
ARMS = (
    ("solo-1", 1, False), ("pair-off-1", 2, False), ("pair-on-1", 2, True),
    ("pair-on-2", 2, True), ("pair-off-2", 2, False), ("solo-2", 1, False),
)
COUNTERS = (
    "ax_engine_jobs_in_flight", "ax_engine_generation_jobs_pending",
    "ax_engine_generation_commands_queued", "ax_engine_generation_active_streams",
    "ax_engine_generation_buffered_stream_events",
)


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def workload():
    receipt = json.loads((ROOT/"workload.json").read_bytes())
    corpus = ROOT/"mixed-corpus.jsonl"
    if digest(corpus) != receipt["corpus_sha256"] or digest(Path(bench.__file__)) != receipt["benchmark_sha256"]:
        raise RuntimeError("Benchmark or workload checksum changed")
    rows = bench.load_corpus(corpus)
    if len(rows) != receipt["requests"] or len({row.id for row in rows}) != len(rows):
        raise RuntimeError("Workload request identities changed")
    return receipt, corpus, rows


def validate_inputs(args):
    build = json.loads(args.build_receipt.read_bytes())
    if digest(args.binary) != build["server_sha256"]:
        raise RuntimeError("The tested server binary differs from the split candidate")
    for length in LENGTHS:
        out = args.campaign/f"current-prefill-split-admission-{length}"
        audit = json.loads((out/"audit.json").read_bytes())
        raw = (out/"result.json").read_bytes()
        completed = json.loads(raw)
        if (completed["binary_sha256"] != build["server_sha256"]
                or completed["pack_revision"] != "ff2a28485eb89bb60e8fe35dd6c65c51e63ee7b3"
                or audit["receipt_sha256"] != sha256(raw).hexdigest() or audit["prompt_tokens"] != length
                or audit["split_requests"] <= 0 or audit["output_arrays_matched"] != 28
                or audit["disconnect_reuse_trials"] != 6):
            raise RuntimeError(f"The {length}-token split prerequisite is incomplete")
    return build


def wait_drained(base):
    deadline = time.monotonic()+20
    while time.monotonic() < deadline:
        reading = native.metrics(native.request(base,"/metrics").decode())
        if all(reading.get(name) == 0 for name in COUNTERS):
            return {name: reading[name] for name in COUNTERS}
        time.sleep(0.5)
    raise RuntimeError("Serving counters did not drain")


def verify_rows(artifact, rows):
    measured = [row for row in artifact["observations"] if row["phase"]=="measured"]
    if len(measured) != len(rows) or {row["prompt_id"] for row in measured} != {row.id for row in rows}:
        raise RuntimeError("Incomplete or duplicate measured workload")
    by_id = {row["prompt_id"]:row for row in measured}
    for expected in rows:
        result = by_id[expected.id]
        if (not result["ok"] or result["prompt_token_ids"] != expected.input_tokens
                or len(result["output_token_ids"]) != expected.max_output_tokens
                or result["scheduled_at_s"] != expected.arrival_s or result["category"] != expected.category):
            raise RuntimeError(f"Invalid result for {expected.id}")
    return {name: row["output_token_ids"] for name,row in by_id.items()}


def run_workload(args, base, owner, label, concurrency, corpus):
    output = args.out/f"{label}.json"
    trace = args.out/f"{label}-steps.json"
    command = [sys.executable, str(Path(capture.__file__)), str(trace),
               "--base-url", base, "--model-id", MODEL,
               "--corpus", str(corpus), "--corpus-arrivals", "--input-kind", "tokens",
               "--warmup-requests", "2", "--concurrency", str(concurrency), "--ignore-eos",
               "--record-token-ids", "--timeout", "300", "--output", str(output)]
    with (args.out/f"{label}-client.log").open("x") as log:
        child = subprocess.Popen(command, stdout=log, stderr=log)
        deadline = time.monotonic()+2300
        try:
            while child.poll() is None:
                if time.monotonic() >= deadline:
                    raise TimeoutError("The measured workload exceeded its deadline")
                os.kill(owner, 0)
                time.sleep(1)
        finally:
            native.stop_owned(child)
    if child.returncode != 0:
        raise RuntimeError(f"The benchmark process failed for {label}")
    return json.loads(output.read_bytes()), trace


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for path in ("campaign","binary","pack","build-receipt","out"):
        parser.add_argument("--"+path,type=Path)
    parser.add_argument("--check-workload",action="store_true")
    args = parser.parse_args()
    receipt, corpus, rows = workload()
    if args.check_workload:
        print(f"Verified {len(rows)} requests and frozen benchmark bytes.")
        return
    if not all(getattr(args,key) is not None for key in ("campaign","binary","pack","build_receipt","out")):
        parser.error("measurement requires all path arguments")
    build = validate_inputs(args)
    drivers = subprocess.check_output(["/bin/ps","-axo","comm="],text=True).splitlines()
    if any(Path(command.strip()).name.startswith("ax-engine-server") for command in drivers):
        raise RuntimeError("The device already has a running AX inference server")
    args.out.mkdir()
    record = {"workload":receipt,"binary_sha256":build["server_sha256"],
              "driver_sha256":digest(Path(__file__)), "capture_sha256":digest(Path(capture.__file__)),
              "status":"starting","arms":{}}

    def save(status):
        record["status"]=status
        pending=args.out/"receipt.tmp"
        pending.write_text(json.dumps(record,indent=2,allow_nan=False)+"\n")
        pending.replace(args.out/"receipt.json")
        print(status,flush=True)

    expected = None
    try:
        for label, lanes, split in ARMS:
            save(label+"-starting")
            quiet=native.wait_for_quiet()
            env={"AX_MLX_FLASH_NEXT_DIRECT_COALESCING":"0","AX_MLX_FLASH_NEXT_PREFILL_SPLIT":str(int(split))}
            options=("--disable-ngram-acceleration","--total-blocks","2048","--max-batch-tokens",
                     str(2048 if lanes==1 else 2049),*(RESERVE_OPTIONS if lanes==2 else ()))
            with server(args,label,MODEL,args.pack,lanes,env=env,options=options,
                        stream_experts="auto",guard=True) as (base,pid):
                if "decision=resident" not in (args.out/f"{label}.log").read_text():
                    raise RuntimeError("Expert streaming was active during a resident workload")
                artifact, trace=run_workload(args,base,pid,label,lanes,corpus)
                tokens=verify_rows(artifact,rows)
                activation=capture.summarize_activation(
                    json.loads(trace.read_bytes()), artifact["observations"]
                )
                if expected is None:
                    expected=tokens
                elif tokens != expected:
                    changed=[name for name in expected if expected[name]!=tokens[name]]
                    raise RuntimeError(f"Output token IDs changed for {changed}")
                drained=wait_drained(base)
                if json.loads(native.request(base, "/health"))["status"] != "ok":
                    raise RuntimeError("Server health declined during the workload")
            samples=[json.loads(line) for line in (args.out/f"{label}-samples.jsonl").read_text().splitlines()]
            if not samples or max(s["pressure"] for s in samples)>1:
                raise RuntimeError("The test did not retain normal measured memory pressure")
            record["arms"][label]={"lanes":lanes,"split":split,"quiet":quiet,"drained":drained,
                                   "peak_footprint_bytes":max(s["footprint_bytes"] for s in samples),
                                   "matched_outputs":len(tokens),"summary":artifact["summary"],
                                   "by_category":artifact["by_category"], "split_activation":activation,
                                   "step_trace_sha256":digest(trace)}
            save(label+"-complete")
        record["split_activation_confirmed"] = all(
            arm["split_activation"]["split_requests_with_route_and_shared_decode"] > 0
            if arm["split"] else arm["split_activation"]["split_groups"] == 0
            for arm in record["arms"].values()
        )
        save("complete")
    except Exception:
        save("failed")
        raise


if __name__ == "__main__":
    main()
