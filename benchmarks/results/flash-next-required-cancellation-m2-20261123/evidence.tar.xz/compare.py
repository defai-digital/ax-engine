"""Replay request cancellation and reuse against both signed-server policies."""

from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "bundle"))
import run_cancellation_controls as test
import run_sampling_controls as controls


def observations(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def verify(capture):
    assert (capture / "status.txt").read_bytes() == b"0\n"
    digest = (ROOT / "bundle/inputs.sha256").read_bytes()
    assert (capture / "inputs.sha256").read_bytes() == digest
    sealed = {name: key for key, name in map(str.split, digest.decode().splitlines())}
    assets = ROOT / "bundle"
    for name, expected in sealed.items():
        if name != "ax-engine-server":
            assert sha256((assets / name).read_bytes()).hexdigest() == expected, name
    build = controls.read(assets / "build.json")
    assert build["codesign_verified"] and build["server_sha256"] == sealed["ax-engine-server"] == controls.SERVER
    assert build["patch_sha256"] == sealed["source.patch"]
    inventory = controls.read(assets / "mxfp4-inventory.json")
    assert inventory["revision"] == "ff2a28485eb89bb60e8fe35dd6c65c51e63ee7b3" and len(inventory["members"]) == 49
    expected = {"model-manifest.json": sealed["model-manifest.json"]}
    ids = controls.prompt()
    arms, full = {}, {}
    for mode in ("required", "disabled"):
        result = capture / mode
        receipt = controls.read(result / "receipt.json")
        assert receipt["mode"] == mode and receipt["qualification"] is False
        assert receipt["server_sha256"] == controls.SERVER and receipt["manifest"] == expected
        assert receipt["publisher_members_verified_before_and_after"] == 49
        assert receipt["macos"] == "27.2.1"
        rows = observations(result / "cases.jsonl")
        test.verify(rows, mode, ids)
        stream_steps = observations(result / "disconnect-steps.jsonl")
        _, dropped, *_ = rows
        assert stream_steps and stream_steps[-1]["step"] == dropped["visible_step"]
        assert len(dropped["prefix"]) == dropped["visible_output_len"]
        assert [token for frame in stream_steps for token in frame["delta"]] == dropped["prefix"]
        assert all(0 <= frame["reported_output_length"] < controls.BUDGET
                   and 0 <= frame["reported_history_length"] < controls.BUDGET for frame in stream_steps)
        assert stream_steps[-1]["state"] == "runnable"
        samples = observations(result / f"{mode}-samples.jsonl")
        assert len(samples) == receipt["normal_pressure_samples"] > 0
        assert all(row["pressure"] == 1 and 0 < row["footprint_bytes"] <= 96 << 30 for row in samples)
        assert max(row["footprint_bytes"] for row in samples) == receipt["max_footprint_bytes"]
        log = (result / f"{mode}.log").read_text()
        reader, = [line for line in log.splitlines() if "Flash Next resident reader" in line]
        assert "reader=Mapped" in reader
        full[mode] = rows[0]["output_ids"]
        arms[mode] = {
            "normal_pressure_samples": len(samples),
            "peak_footprint_bytes": receipt["max_footprint_bytes"],
            "disconnect_progress_frames": len(stream_steps),
            "last_disconnect_snapshot_output_length": stream_steps[-1]["reported_output_length"],
            "last_disconnect_snapshot_history_length": stream_steps[-1]["reported_history_length"],
            "actions": {
                row["case"]: {"engine_steps": row["metrics"][test.STEPS],
                              "verified_steps": row["metrics"][controls.VERIFIED],
                              "accepted_steps": row["metrics"][test.ACCEPTED],
                              "output_ids": len(row["output_ids"] if "output_ids" in row else row["prefix"])}
                for row in rows
            },
        }
    assert full["required"] == full["disabled"]
    previous = controls.read(ROOT / "before-fix-observation.json")
    before = previous["before_server_build"]
    assert before["codesign_verified"] and before["server_sha256"] == (
        "c1a7c3f9dfb81613fc370758a0eece5f6105683d53baab7ea4bc3a371cb81de2"
    )
    cases = ROOT / "before-fix/cases.jsonl"
    frames = ROOT / "before-fix/disconnect-steps.jsonl"
    assert sha256(cases.read_bytes()).hexdigest() == previous["case_rows_sha256"]
    assert sha256(frames.read_bytes()).hexdigest() == previous["disconnect_frames_sha256"]
    assert observations(cases) == previous["case_rows"] and observations(frames) == previous["disconnect_frames"]
    baseline, disconnected, recovery = previous["case_rows"]
    assert recovery["output_ids"] == baseline["output_ids"] == full["required"]
    assert disconnected["decode_widths"] == [1, 1, 1, 2]
    assert disconnected["prefix"] == [value for frame in previous["disconnect_frames"] for value in frame["delta"]]
    assert disconnected["open_jobs"] == disconnected["open_streams"] == 1
    metrics = disconnected["metrics"]
    assert metrics[controls.VERIFIED] == 1 and metrics[test.ACCEPTED] == 0
    return {
        "before_fix": {"server_sha256": before["server_sha256"], "visible_decode_widths": [1, 1, 1, 2],
                       "reported_verified_steps": 1, "reported_accepted_steps": 0},
        "qualification": False, "hardware": "Mac Studio M2 Ultra 192 GB",
        "pack_revision": inventory["revision"], "server_sha256": controls.SERVER,
        "matching_completed_output_ids_per_policy": 3 * len(full["required"]),
        "matching_completed_output_ids_across_arms": len(full["required"]),
        "macos": "27.2.1", "arms": arms,
    }


if __name__ == "__main__":
    print(json.dumps(verify(Path(sys.argv[1])), indent=2, sort_keys=True, allow_nan=False))
