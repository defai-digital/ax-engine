"""Resolve and serve the delivered Flash Next pack through the signed offline alias."""

from argparse import ArgumentParser
from hashlib import file_digest
import json
from pathlib import Path
import re
import socket
import subprocess
import time

import check_flash_next_native_support as native
import run_flash_next_generate_matrix as matrix

ROOT = Path(__file__).resolve().parent
ALIAS = "qwen3.8-flash-next:axq"
OVERFLOW_REQUEST_ID = "qwen3.8-flash-next"
CONTEXT = 32768
COUNTERS = (
    "ax_engine_jobs_in_flight", "ax_engine_generation_jobs_pending",
    "ax_engine_generation_commands_queued", "ax_engine_generation_active_streams",
    "ax_engine_generation_buffered_stream_events",
)


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open("rb") as file:
        return file_digest(file, "sha256").hexdigest()


def attest(plan, cli_root, pack, revision, port, dry):
    resolved = plan["resolved"]
    assert plan["schema_version"] == "ax.local_serve_plan.v1" and plan["command"] == "serve"
    assert plan["input"] == ALIAS and resolved["model"] == ALIAS
    assert resolved["revision"] == revision and resolved["preset"] is None
    assert Path(resolved["path"]).resolve(strict=True) == pack
    assert resolved["download"]["offline"] is True
    assert plan["server"]["argv"] == [
        str(cli_root / "ax-engine-server"), "--host", "127.0.0.1", "--port", str(port),
        "--mlx", "--mlx-model-artifacts-dir", resolved["path"],
    ]
    if dry:
        assert resolved["kind"] == "model_resolution_plan" and resolved["download"]["required"] is False
    else:
        assert resolved["kind"] == "resolved_snapshot" and resolved["download"]["status"] == "ready"


def find_resolution(log):
    decoder = json.JSONDecoder()
    for match in re.finditer(r"(?m)^\{", log):
        try:
            record, _ = decoder.raw_decode(log[match.start():])
        except ValueError:
            continue
        if isinstance(record, dict) and record.get("schema_version") == "ax.local_serve_plan.v1":
            return record
    raise ValueError("The actual serve launch did not report its resolved snapshot")


def wait_ready(base, process, start):
    while process.poll() is None and time.monotonic() < start + 300:
        try:
            found = json.loads(native.request(base, "/v1/models"))["data"]
            break
        except OSError:
            time.sleep(0.5)
    else:
        raise RuntimeError("The offline alias did not start the signed local server")
    assert len(found) == 1 and found[0]["id"] == OVERFLOW_REQUEST_ID and found[0]["context_length"] == CONTEXT
    return time.monotonic() - start


def drain(base):
    deadline = time.monotonic() + 15
    while True:
        data = native.metrics(native.request(base, "/metrics").decode())
        if all(data.get(key) == 0 for key in COUNTERS):
            return {key: data[key] for key in COUNTERS}
        if time.monotonic() >= deadline:
            raise TimeoutError("The offline alias request did not drain")
        time.sleep(0.2)


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--fresh", type=Path, required=True)
    cli.add_argument("--out", type=Path, required=True)
    cli.add_argument("--resolver-only", action="store_true")
    args = cli.parse_args()
    fresh = args.fresh.resolve(strict=True)
    result = read(fresh / "evidence/delivery/result.json")
    build = read(fresh / "build.json")
    witness = read(ROOT / "signed-case.json")
    repo = native.PRIMARY_REPO.replace("/", "--")
    revision = witness["ref"]
    assert revision == native.PACK_REVISION and result["completed"] is True
    assert result["inventory_sha256"] == witness["inventory_sha256"] == build["inventory_sha256"]
    assert result["server_sha256"] == witness["server_sha256"] == sha(fresh / "ax-engine-server")
    cache = fresh / "fresh-cache"
    pack = (cache / f"models--{repo}" / "snapshots" / revision).resolve(strict=True)
    assert pack.is_dir() and pack.is_relative_to(cache)
    assert (pack / "model-manifest.json").is_file()
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        port = listener.getsockname()[1]
    command = [fresh / "ax-engine", "serve", ALIAS, "--offline", "--json", "--hf-cache-root",
               cache, "--host", "127.0.0.1", "--port", str(port)]
    environment = native.server_env({"RUST_LOG": "info,ax_engine_mlx::flash_next_startup=debug"})
    planned = json.loads(subprocess.check_output([*command, "--dry-run"], env=environment))
    attest(planned, fresh, pack, revision, port, dry=True)
    args.out.mkdir(exist_ok=False)
    if args.resolver_only:
        witness_out = {"alias": ALIAS, "revision": revision, "offline_cache_hit": True,
                       "cli_sha256": sha(fresh / "ax-engine"), "server_sha256": sha(fresh / "ax-engine-server"),
                       "native_flags": ["--host", "--port", "--mlx", "--mlx-model-artifacts-dir"],
                       "runtime_launched": False}
        (args.out / "resolver.json").write_text(json.dumps(witness_out, indent=2) + "\n")
        return
    tokens = matrix.workload_ids(matrix.pack_vocab_size(pack), witness["prompt_tokens"], witness["trial"])
    assert matrix.ids_sha(tokens) == witness["prompt_sha256"]
    base = f"http://127.0.0.1:{port}"
    log_path = args.out / "server.log"
    try:
        with log_path.open("xb") as raw:
            start = time.monotonic()
            process = subprocess.Popen(command, env=environment, stdout=raw, stderr=raw)
            try:
                ready = wait_ready(base, process, start)
                before = native.metrics(native.request(base, "/metrics").decode())
                response = matrix.generate(base, tokens, max_tokens=32, ignore_eos=True)
                after = native.metrics(native.request(base, "/metrics").decode())
                row = matrix.slim(response, before, after)
                assert row["output_tokens"] == witness["output_tokens"] and row["status"] == "finished"
                assert row["verified_steps"] == row["route_errors"] == 0
                drained = drain(base)
                assert json.loads(native.request(base, "/health"))["status"] == "ok"
            finally:
                native.stop_owned(process)
        assert process.returncode == 0
        log = re.sub(r"\x1b\[[0-9;]*m", "", log_path.read_text())
        attest(find_resolution(log), fresh, pack, revision, port, dry=False)
        assert re.findall(r"Flash Next resident reader[^\n]* reader=(\w+)", log) == ["AlignedBuffered"]
        assert re.search(r"context_tokens=32768 effective_sequence_cap=Some\(1\)", log)
    finally:
        if log_path.exists():
            text = log_path.read_text(errors="replace")
            for old, new in ((str(fresh), "[delivery]"), (str(ROOT), "[run]"),
                             (str(Path.home()), "[home]"), ("127.0.0.1", "[loopback]")):
                text = text.replace(old, new)
            log_path.write_text(text)
    record = {"alias": ALIAS, "revision": revision, "offline_cache_hit": True,
              "cli_sha256": sha(fresh / "ax-engine"), "server_sha256": sha(fresh / "ax-engine-server"),
              "http_ready_seconds_including_offline_resolution": ready, "context_tokens": CONTEXT,
              "max_live_requests": 1, "reader": "AlignedBuffered", "matched_output_ids": len(row["output_tokens"]),
              "verified_mtp_steps": row["verified_steps"], "health": "ok", "drained_counters": drained,
              "qualification": False}
    (args.out / "alias.json").write_text(json.dumps(record, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
