"""Observe token progress in a four-case Flash Next reference diagnostic."""

import argparse
from contextlib import closing
from hashlib import file_digest
import json
import os
from pathlib import Path
import subprocess
import sys
import time


QA_LIMIT = 4
WALL_LIMIT_SECONDS = 4 * 3600


def digest(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def verify_inputs(root):
    sources = json.loads((root / "source.json").read_text())
    for name, sha in sources.items():
        if digest(root / name) != sha:
            raise ValueError(f"Frozen source changed: {name}")
    return digest(root / "source.json")


def observe_stream(stream, event_log, ordinal):
    """Count native outputs, including any consumed EOS, before forwarding."""
    with closing(stream):
        print(json.dumps({"case": ordinal, "tokens": 0}), file=event_log, flush=True)
        for count, token in enumerate(stream, start=1):
            print(json.dumps({"case": ordinal, "tokens": count}), file=event_log, flush=True)
            yield token


def monitor(process, result, heartbeat, samples, watcher):
    before = time.monotonic()
    last_progress = before
    previous = None
    while process.poll() is None:
        now = time.monotonic()
        progress = watcher.generation(result), watcher.generation(heartbeat)
        if progress != previous:
            last_progress = now
            previous = progress
        sample = watcher.sample_host(process.pid, diagnose_host=True)
        sample["seconds_since_progress"] = round(now - last_progress, 1)
        sample["token_progress_seen"] = progress[1] is not None
        print(json.dumps(sample), file=samples, flush=True)
        if sample["pressure"] in watcher.CRITICAL_PRESSURE:
            return "critical system memory pressure"
        if now - before >= WALL_LIMIT_SECONDS:
            return "diagnostic wall limit"
        if now - last_progress >= watcher.MAX_NO_PROGRESS_SECONDS:
            return "neither the case receipt nor token heartbeat advanced"
        try:
            process.wait(timeout=watcher.POLL_SECONDS)
        except subprocess.TimeoutExpired:
            pass
    return None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("frozen", "model-dir", "out"):
        parser.add_argument(f"--{name}", required=True, type=Path)
    parser.add_argument("--child", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    source_sha = verify_inputs(args.frozen)
    sys.path.insert(0, str(args.frozen / "scripts"))
    import watch_flash_next_reference as watcher

    output = args.out.resolve()
    result = output / "reference" / "result.json"
    heartbeat = output / "token-progress.jsonl"
    if args.child:
        import run_flash_next_reference as reference

        def observed(model, mx, ids, chunk=reference.PREFILL_CHUNK):
            nonlocal case
            case += 1
            return observe_stream(original(model, mx, ids, chunk), event_log, case)

        case = 0
        original = reference.token_stream
        sys.argv[1:] = [
            "--model-dir", str(args.model_dir), "--output", str(result.parent),
            "--inventory", str(args.frozen / "benchmarks/results/qualification/2026-10-04-flash-next-mxfp4-native-support/pack-inventory.json"),
            "--phases", "qa", "--limit-items", str(QA_LIMIT),
        ]
        with heartbeat.open("x") as event_log:
            reference.token_stream = observed
            return reference.main()

    output.mkdir(exist_ok=False)
    status = {"diagnostic_only": True, "frozen_source_manifest_sha256": source_sha,
              "qa_limit": QA_LIMIT, "wired_residency_override": False}
    status_path = output / "status.json"
    status_path.write_text(json.dumps(status, indent=2) + "\n")
    env = {key: value for key, value in os.environ.items()
           if not key.startswith(("AX_", "MLX_", "DYLD_"))}
    with (output / "runner.log").open("x") as log, (output / "samples.jsonl").open("x") as samples:
        initial = watcher.sample_host(diagnose_host=True)
        print(json.dumps(initial), file=samples, flush=True)
        if initial["pressure"] in watcher.CRITICAL_PRESSURE:
            stop = "critical system memory pressure before launch"
            exit_code = None
        else:
            with subprocess.Popen([sys.executable, "-B", "-u", __file__, *sys.argv[1:], "--child"],
                                  env=env, stdout=log, stderr=log) as process:
                try:
                    stop = monitor(process, result, heartbeat, samples, watcher)
                finally:
                    if process.poll() is None:
                        process.terminate()
                        try:
                            process.wait(timeout=30)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait(timeout=30)
                exit_code = process.returncode
    partial = json.loads(result.read_text()) if result.exists() else {}
    completed_cases = len(partial.get("qa", {}).get("rows", []))
    status.update(exit_code=exit_code, stop_reason=stop,
                  complete=partial.get("completed") is True and completed_cases == QA_LIMIT
                  and exit_code == 0 and stop is None, completed_cases=completed_cases)
    if verify_inputs(args.frozen) != source_sha:
        raise ValueError("Frozen source manifest changed during the diagnostic")
    status_path.write_text(json.dumps(status, indent=2) + "\n")
    return 0 if status["complete"] else 1


if __name__ == "__main__":
    sys.exit(main())
