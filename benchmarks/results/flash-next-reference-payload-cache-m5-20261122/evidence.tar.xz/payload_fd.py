"""Select cache behavior for the pinned lazy MLX load's open shard descriptors."""
from errno import EBADF
import fcntl
import json
import os
from pathlib import Path
from stat import S_ISREG

F_NOCACHE = getattr(fcntl, 'F_NOCACHE', 48)


def indexed_payloads(root):
    contents = json.loads((root / 'model.safetensors.index.json').read_bytes())
    expected = {f'model-{number:05d}-of-00025.safetensors' for number in range(1, 26)}
    if set(contents['weight_map'].values()) != expected:
        raise ValueError('Unexpected reference shard inventory')
    return [root / name for name in sorted(expected)]


def configure_payload_cache(paths, mode):
    """Bind regular-file descriptor identities before applying Darwin F_NOCACHE."""
    if mode not in ('buffered', 'no-cache'):
        raise ValueError('Unknown payload mode')
    by_identity = {}
    for path in paths:
        metadata = path.stat()
        identity = (metadata.st_dev, metadata.st_ino)
        if identity in by_identity or not S_ISREG(metadata.st_mode):
            raise ValueError('Duplicate or nonregular publisher file')
        by_identity[identity] = path.name
    bindings = []
    for name in os.listdir('/dev/fd'):
        if not name.isdecimal():
            continue
        descriptor = int(name)
        try:
            metadata = os.fstat(descriptor)
        except OSError as error:
            if error.errno == EBADF:
                continue
            raise
        identity = (metadata.st_dev, metadata.st_ino)
        if identity in by_identity:
            bindings.append((descriptor, identity))
    if {identity for _, identity in bindings} != set(by_identity):
        raise ValueError('The lazy MLX graph did not hold every pinned payload descriptor')
    applied = {}
    for fd, identity in bindings:
        metadata = os.fstat(fd)
        if (metadata.st_dev, metadata.st_ino) != identity:
            raise ValueError('Lazy payload descriptor changed before setting its cache mode')
        if fcntl.fcntl(fd, F_NOCACHE, int(mode == 'no-cache')) != 0:
            raise OSError('Darwin did not accept the payload cache mode')
        name = by_identity[identity]
        applied[name] = applied.get(name, 0) + 1
    return {'mode': mode, 'members': applied, 'descriptors_modified': len(bindings)}
