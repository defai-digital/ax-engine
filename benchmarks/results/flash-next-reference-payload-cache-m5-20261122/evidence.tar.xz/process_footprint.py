"""Read the owned process footprint with the selected Darwin lab helper."""

import ctypes


def footprint_reader(library):
    function = ctypes.CDLL(str(library)).ax_lab_read_footprint
    pointer = ctypes.POINTER(ctypes.c_uint64)
    function.argtypes = (ctypes.c_int, pointer, pointer)
    function.restype = ctypes.c_int

    def sample(pid):
        physical, lifetime_peak = ctypes.c_uint64(), ctypes.c_uint64()
        error = function(pid, ctypes.byref(physical), ctypes.byref(lifetime_peak))
        if error:
            return {'physical_footprint_sample_errno': error}
        return {
            'physical_footprint_bytes': physical.value,
            'kernel_lifetime_peak_footprint_bytes': lifetime_peak.value,
        }

    return sample

