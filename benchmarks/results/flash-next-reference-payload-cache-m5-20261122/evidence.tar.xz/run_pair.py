"""Run isolated MLX payload cache controls in opposing order."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
from shutil import copyfile
import subprocess
import sys
from tempfile import TemporaryDirectory

from checksum_ledger import payloads
from hash_cache_probe import clone, darwin_calls

ORDER = (('no-cache-first', 'no-cache'), ('buffered-first', 'buffered'),
         ('buffered-second', 'buffered'), ('no-cache-second', 'no-cache'))
HERE = Path(__file__).resolve().parent


def run(args):
    args.output.mkdir(exist_ok=False)
    inventory = args.frozen / 'benchmarks/results/qualification/2026-10-04-flash-next-mxfp4-native-support/pack-inventory.json'
    selected = payloads(inventory)
    published = json.loads(inventory.read_bytes())['members']
    if not all(Path(row['name']).name == row['name'] for row in published):
        raise ValueError('Unexpected publisher path geometry')
    manifest = args.pack / 'model-manifest.json'
    manifest_hash = sha256(manifest.read_bytes()).hexdigest()
    if manifest_hash != '06cc592252dfe740b078519091995e706f2a3ae4b2e8b863720bea179d7d0e76':
        raise ValueError('Native manifest used by the reference diagnostics changed')
    functions = darwin_calls()
    arms = {}
    for label, mode in ORDER:
        print(f'{label} starting', flush=True)
        root = args.output / label
        root.mkdir()
        with TemporaryDirectory(dir=args.output, prefix='pack-copy-') as directory:
            replica = Path(directory)
            for member in published:
                original = (args.pack / member['name']).resolve(strict=True)
                if original.stat().st_size != member['size']:
                    raise ValueError(f"Publisher size changed: {member['name']}")
                clone(functions, original, replica / member['name'])
            copyfile(manifest, replica / 'model-manifest.json')
            subprocess.run([sys.executable, '-B', str(HERE / 'clean_state.py'),
                            str(args.frozen / 'scripts')], cwd=root, check=True)
            measurement = root / 'measurement'
            trial = subprocess.run([sys.executable, '-B', '-u', str(HERE / 'measure_checksum.py'),
                                    '--checksum-mode', 'no-cache', '--payload-cache-mode', mode,
                                    '--model-dir', str(replica),
                                    '--out', str(measurement), '--frozen', str(args.frozen)])
            receipt = json.loads((measurement / 'status.json').read_bytes())
            allowed = (trial.returncode == 0 and receipt['exit_code'] == 0 and receipt['stop_reason'] is None
                       or trial.returncode == 1 and receipt['exit_code'] == -15
                       and receipt['stop_reason'] == 'memory pressure above normal')
            if (not allowed or receipt['checksum_mode'] != 'no-cache'
                    or receipt['payload_cache_mode'] != mode or receipt['ordinary_qualification'] is not False):
                raise ValueError(f'Unexpected terminal state for {label}')
            events = [json.loads(line) for line in (measurement / 'checksum-events.jsonl').read_text().splitlines()]
            if {row['member'] for row in events} != selected.keys() or len(events) != len(selected):
                raise ValueError(f'Incomplete isolated checksums for {label}')
            descriptors = json.loads((measurement / 'payload-descriptors.json').read_bytes())
            if descriptors['mode'] != mode or set(descriptors['members']) != selected.keys() - {'mtp.safetensors'}:
                raise ValueError(f'Unexpected frozen MLX payload descriptors for {label}')
            arms[label] = {'mode': mode, 'receipt': receipt, 'completed_checksums': len(events),
                           'checksummed_bytes': sum(row['file_bytes'] for row in events)}
        print(f'{label} terminal', flush=True)
    report = {'scope': 'Diagnostic only. No prefill or QA.', 'native_manifest_sha256': manifest_hash, 'checksum_mode': 'no-cache',
              'order': ORDER, 'arms': arms}
    (args.output / 'result.json').write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    parser = ArgumentParser(description=__doc__)
    for name in ('frozen', 'pack', 'output'):
        parser.add_argument(name, type=Path)
    run(parser.parse_args())
