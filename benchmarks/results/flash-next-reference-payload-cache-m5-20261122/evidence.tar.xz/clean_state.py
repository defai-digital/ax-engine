"""Record the observed M5 state in a normal-pressure, quiet prelaunch window."""
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

sys.path.insert(0, sys.argv[1])
from check_flash_next_native_support import wait_for_quiet


def read(*args):
    return subprocess.check_output(args, text=True).strip()


def sample():
    vm = read('/usr/bin/vm_stat')
    pages = {label: int(value) for label, value in re.findall(r'^([^:]+):\s+(\d+)\.$', vm, re.M)}
    size = os.sysconf('SC_PAGE_SIZE')
    return {
        'pressure': int(read('/usr/sbin/sysctl', '-n', 'kern.memorystatus_vm_pressure_level')),
        'compressor_bytes': pages['Pages occupied by compressor'] * size,
        'free_bytes': pages['Pages free'] * size,
        'inactive_bytes': pages['Pages inactive'] * size,
        'swap': read('/usr/sbin/sysctl', '-n', 'vm.swapusage'),
    }


def main():
    deadline = time.monotonic() + 15 * 60
    consecutive_normal = 0
    with Path('prelaunch-samples.jsonl').open('x') as log:
        while time.monotonic() < deadline:
            row = sample()
            log.write(json.dumps(row) + '\n')
            log.flush()
            if row['pressure'] == 1:
                consecutive_normal += 1
            else:
                consecutive_normal = 0
            if consecutive_normal >= 3:
                quiet = wait_for_quiet()
                final = sample()
                log.write(json.dumps(final) + '\n')
                log.flush()
                if final['pressure'] == 1:
                    Path('prelaunch.json').write_text(json.dumps({
                        'policy': 'normal pressure and CPU quiet',
                        'quiet': quiet, 'sample': final,
                    }, indent=2) + '\n')
                    return
                consecutive_normal = 0
            time.sleep(15)
    raise TimeoutError('No stable normal-pressure prelaunch window. The ordinary retry was not started.')


if __name__ == '__main__':
    main()
