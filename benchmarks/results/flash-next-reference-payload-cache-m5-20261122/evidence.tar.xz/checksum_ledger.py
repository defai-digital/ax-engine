"""Isolate published payload checksum caching in the reference diagnostic."""

from hashlib import sha256
import json
import re
import subprocess
from time import monotonic

from hash_cache_probe import (INVENTORY_SHA256, PAGE_SIZE, REVISION, checksum,
                              darwin_calls, resident_pages)

VM_FIELDS = ('Pages free', 'Pages inactive', 'File-backed pages', 'Pages occupied by compressor')


def host_vm():
    raw = subprocess.check_output(['/usr/bin/vm_stat'], text=True)
    parsed = dict(re.findall(r'^([^:]+):\s+(\d+)\.$', raw, re.M))
    return {field: int(parsed[field]) * PAGE_SIZE for field in VM_FIELDS}


def payloads(inventory):
    raw = inventory.read_bytes()
    if sha256(raw).hexdigest() != INVENTORY_SHA256:
        raise ValueError('Reference inventory bytes changed')
    data = json.loads(raw)
    if data['revision'] != REVISION or len(data['members']) != 49:
        raise ValueError('Reference inventory identity changed')
    rows = {m['name']: m for m in data['members'] if m['name'].endswith('.safetensors')}
    if len(rows) != 26 or any('/' in name or row['sha256'] != row['publisher_sha256']
                              for name, row in rows.items()):
        raise ValueError('Publisher payload selection changed')
    return rows


def record_checksums(original_hash, pack, members, mode, log):
    if mode not in ('buffered', 'no-cache'):
        raise ValueError('Unknown reference checksum mode')
    libc = darwin_calls()
    hashed = set()

    def observed(path):
        if path.parent != pack or path.name not in members:
            return original_hash(path)
        entry = members[path.name]
        if path.name in hashed:
            raise ValueError(f'Repeated preflight checksum: {path.name}')
        before, pages = resident_pages(libc, path)
        start_vm = host_vm()
        # A separate owned-process monitor samples pressure throughout both
        # arms. Here the chunk reads use identical aligned buffers.
        verified = checksum(path, mode, entry['size'], entry['sha256'], lambda: 1, aligned=True)
        after, final_pages = resident_pages(libc, path)
        if pages != final_pages:
            raise ValueError(f'Checksum mapping geometry changed: {path.name}')
        hashed.add(path.name)
        print(json.dumps({'member': path.name, 'mode': mode, 'file_pages': pages,
                          'cached_before': before, 'cached_after': after,
                          'file_bytes': verified['bytes'], 'sha256': verified['sha256'],
                          'checksum_seconds': verified['checksum_seconds'],
                          'monotonic_seconds': monotonic(), 'vm_before': start_vm,
                          'vm_after': host_vm()}, allow_nan=False), file=log, flush=True)
        return verified['sha256']

    return observed, hashed
