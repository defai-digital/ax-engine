"""Mark the pinned reference's evaluation batches."""
import gzip
from hashlib import sha256
import json
from pathlib import Path


GRAPH = Path(__file__).with_name('graph.json.gz')
GRAPH_SHA256 = 'bbc459b8456395d817dd0f4a3a9f1b8adaa2763b10897e7f261f6483623c5d33'
BATCH_SIZE = 32
LAST_BATCH = 72
EXPECTED_ARRAYS = 2326


class ReachedMaterializationBoundary(Exception):
    """End the diagnostic before later materialization and generation."""


def graph():
    data = gzip.decompress(GRAPH.read_bytes())
    if sha256(data).hexdigest() != GRAPH_SHA256:
        raise ValueError('Pinned metadata graph changed')
    rows = json.loads(data)['parameters']
    if len(rows) != EXPECTED_ARRAYS:
        raise ValueError('Pinned graph array count changed')
    return rows


def run_materialization(materialize, model, mx, mark, expected):
    normal_eval = mx.eval
    batch = 0

    def measured_eval(*arrays):
        nonlocal batch
        start = batch * BATCH_SIZE
        group = expected[start:start + BATCH_SIZE]
        signatures = [(array.nbytes, list(array.shape), str(array.dtype)) for array in arrays]
        planned = [(row['logical_bytes'], row['shape'], row['dtype']) for row in group]
        if signatures != planned or not 1 <= len(group) <= BATCH_SIZE or batch > LAST_BATCH:
            raise ValueError(f'Materialization geometry differs at batch {batch}')
        allocation = sum(row['logical_bytes'] for row in group)
        ple = sum(row['logical_bytes'] for row in group if '.ngram_embedding.' in row['name'])
        mark('batch_start', batch=batch, logical_bytes=allocation, ple_bytes=ple)
        result = normal_eval(*arrays)
        mark('batch_end', batch=batch, logical_bytes=allocation, ple_bytes=ple)
        if batch == LAST_BATCH:
            mark('materialization_boundary', batch=batch)
            raise ReachedMaterializationBoundary
        batch += 1
        return result

    mx.eval = measured_eval
    try:
        materialize(model, mx)
    finally:
        mx.eval = normal_eval
    raise ValueError('Materialization ended before the final checked evaluation')


def verify_phase_order(phases):
    expected = ['lazy_load_start', 'lazy_load_end', 'materialize_start']
    expected.extend(phase for _ in range(LAST_BATCH + 1) for phase in ('batch_start', 'batch_end'))
    expected.append('materialization_boundary')
    if list(phases) != expected:
        raise ValueError(f'Incomplete full materialization phase sequence: {phases}')
