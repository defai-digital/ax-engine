"""Collect scheduler hold markers using the original timed SSE client."""
import sys

import capture_mixed_steps as capture

FLAG = "ax_scheduler_prefill_tail_deferred"
original = capture.trace_stream


def trace_stream(events):
    result = original(events)
    if result is None:
        return None
    held = []
    for kind, payload, elapsed in events:
        if kind != "step":
            continue
        step = payload["step"]
        decisions = (step.get("route") or {}).get("crossover_decisions") or {}
        if FLAG not in decisions:
            continue
        if (decisions[FLAG] != 1 or step["scheduled_requests"] != 1
                or capture.bench.delta_token_count(kind, payload) != 1):
            raise ValueError("A hold marker did not describe a singleton decode")
        held.append({"step_id": step["step_id"], "elapsed_s": elapsed})
    return result | {"held": held, "partial": []}


if __name__ == "__main__":
    capture.trace_stream = trace_stream
    raise SystemExit(capture.main(sys.argv[1:]))
