"""Replay frozen mixed arrivals with guarded admission and optional tail deferral."""
from argparse import ArgumentParser
from collections import Counter
import json
from pathlib import Path
import subprocess
import sys

import run_selective_mixed as mixed
from audit_natural_tail import audit

ROOT = Path(__file__).resolve().parent
ARMS = (("physical-1", False), ("held-1", True), ("held-2", True), ("physical-2", False))
SOLO_DIGEST = "612675166c33c197b0389795fa9db1109998454a877543114bda06663cfd8f9b"
BUILD = "8cb06414cc4dc3bf5d3b2de24a3f6182435fa3ca"


def require(valid, message):
    if not valid:
        raise ValueError(message)


def inputs():
    workload, corpus, cases = mixed.workload()
    require(Counter(len(case.input_tokens) for case in cases) == {512: 132, 2048: 66, 8192: 22},
            "The prompt workload changed")
    reference = ROOT / "solo-reference.json"
    reference_sha = mixed.digest(reference)
    require(reference_sha == SOLO_DIGEST, "The frozen single-slot reference changed")
    expected = mixed.verify_rows(json.loads(reference.read_bytes()), cases)
    return workload, corpus, cases, expected, reference_sha


def main():
    p = ArgumentParser(description=__doc__)
    for name in ("pack", "binary", "link-root", "out"):
        p.add_argument(f"--{name}", type=Path)
    p.add_argument("--check-inputs", action="store_true")
    args = p.parse_args()
    workload, corpus, cases, expected, ref_sha = inputs()
    if args.check_inputs:
        print(f"Verified {len(cases)} frozen prompts and single-slot outputs.")
        return
    build = json.loads((ROOT / "candidate-build.json").read_bytes())
    proof = json.loads((ROOT / "admission-proof.json").read_bytes())
    require(build["runtime_commit"] == BUILD and build["codesign_verified"]
            and proof["build"] == build and proof["matching_generated_ids"] == 288,
            "The exact M5 admission-control prerequisite changed")
    inventory_path = ROOT / "mxfp4-inventory.json"
    inventory = json.loads(inventory_path.read_bytes())
    require(mixed.digest(args.binary) == build["server_sha256"], "The tested binary changed")
    manifest = mixed.native.validate_inventory(args.pack, inventory, args.link_root)
    require(manifest.get("model-manifest.json") ==
            "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef",
            "The delivered manifest changed")
    result = {"qualification": False, "build": build, "revision": inventory["revision"], "manifest": manifest,
              "inventory_sha256": mixed.digest(inventory_path), "workload": workload, "solo_sha256": ref_sha,
              "arms": {}}
    args.out.mkdir()

    def save(status):
        result["status"] = status
        temporary = args.out / "receipt.tmp"
        temporary.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
        temporary.replace(args.out / "receipt.json")
        print(status, flush=True)

    options = ("--disable-ngram-acceleration", "--total-blocks", "2048", "--max-batch-tokens", "2049",
               *mixed.RESERVE_OPTIONS)
    try:
        for name, candidate in ARMS:
            save(f"{name}-starting")
            quiet = mixed.native.wait_for_quiet()
            env = {"AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0", "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": "1",
                   "AX_MLX_FLASH_NEXT_PREFILL_LAYER_YIELD": "0",
                   "AX_MLX_FLASH_NEXT_PREFILL_TAIL_DEFERRAL": str(int(candidate))}
            client = args.out / f"{name}.json"
            trace = args.out / f"{name}.trace.json"
            with mixed.server(args, name, mixed.MODEL, args.pack, 2, env=env, options=options,
                              stream_experts="auto", guard=True) as (base, _):
                require("decision=resident" in (args.out / f"{name}.log").read_text(), "Resident experts required")
                with (args.out / f"{name}.client.log").open("x") as output:
                    subprocess.run([sys.executable, str(ROOT / "capture_natural_tail.py"), str(trace),
                                    "--base-url", base, "--model-id", mixed.MODEL, "--input-kind", "tokens",
                                    "--corpus", str(corpus), "--corpus-arrivals", "--warmup-requests", "2",
                                    "--concurrency", "2", "--ignore-eos", "--record-token-ids", "--timeout", "300",
                                    "--output", str(client)], stdout=output, stderr=output, check=True, timeout=2300)
                observed = json.loads(client.read_bytes())
                tokens = mixed.verify_rows(observed, cases)
                changed = [key for key in expected if tokens[key] != expected[key]]
                require(not changed, f"Greedy output changed for {changed}")
                traces = json.loads(trace.read_bytes())
                exposure = audit(observed["observations"], traces, candidate)
                split = mixed.capture.summarize_activation(traces, observed["observations"])
                require(split["split_groups"] == split["split_groups_with_published_end"],
                        "Physical split route lacked its logical boundary")
                drained = mixed.wait_drained(base)
                require(json.loads(mixed.native.request(base, "/health"))["status"] == "ok", "Health declined")
            samples = [json.loads(line) for line in (args.out / f"{name}-samples.jsonl").read_text().splitlines()]
            require(samples and all(row["pressure"] == 1 for row in samples), "Memory pressure exceeded normal")
            result["arms"][name] = {"tail_deferral": candidate, "matched_requests": len(tokens),
                                    "matched_output_ids": sum(map(len, tokens.values())), "exposure": exposure,
                                    "split_activation": split, "drained": drained, "pressure_samples": len(samples),
                                    "cpu_idle_before_percent": quiet["cpu_idle_percent"],
                                    "cpu_idle_after_percent": mixed.native.cpu_idle_percent(),
                                    "client_sha256": mixed.digest(client), "trace_sha256": mixed.digest(trace)}
            save(f"{name}-complete")
        require(mixed.native.validate_inventory(args.pack, inventory, args.link_root) == manifest, "Pack changed")
        result["timing_eligible"] = all(
            arm["cpu_idle_before_percent"] >= 90 and arm["cpu_idle_after_percent"] >= 90
            for arm in result["arms"].values()
        )
        save("complete")
    except Exception:
        save("failed")
        raise


if __name__ == "__main__":
    main()
