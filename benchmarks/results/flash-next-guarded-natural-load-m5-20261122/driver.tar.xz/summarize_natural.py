"""Replay guarded mixed serving and report measured exposure per arrival order."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from math import isfinite
from pathlib import Path
from statistics import median

from run_natural_tail import ARMS, ROOT, audit, inputs, mixed, require


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def metrics_by_request(observations):
    return {
        row["prompt_id"]: {
            "prompt_tokens": len(row["prompt_token_ids"]),
            "maximum_gap_ms": max(row["stream_step_interval_ms"]),
            "client_wait_ms": row["queue_delay_ms"],
            "dispatch_ttft_ms": row["ttft_ms"],
            "offered_ttft_ms": row["queue_delay_ms"] + row["ttft_ms"],
        }
        for row in observations if row["phase"] == "measured"
    }


def paired_effects(baseline, treatment):
    require(baseline.keys() == treatment.keys(), "The replay paired different scheduled requests")
    effects = {}
    for length in (512, 2048, 8192):
        peers = [(before, treatment[name]) for name, before in baseline.items()
                 if before["prompt_tokens"] == length]
        require(all(after["prompt_tokens"] == length for _, after in peers), "Matched prompt length changed")
        effects[str(length)] = {
            key: median(after[key] - before[key] for before, after in peers)
            for key in ("maximum_gap_ms", "client_wait_ms", "dispatch_ttft_ms", "offered_ttft_ms")
        }
    return effects


def summarize(root):
    workload, _, cases, expected, oracle_hash = inputs()
    receipt_path = root / "receipt.json"
    receipt = read(receipt_path)
    source = read(root / "portable-sources.json")
    require(receipt["status"] == "complete" and receipt["qualification"] is False
            and list(receipt["arms"]) == [name for name, _ in ARMS]
            and source["receipt_sha256"] == digest(receipt_path)
            and list(source["arms"]) == list(receipt["arms"])
            and source["client_redaction"] == ["target.base_url", "corpus.path"]
            and receipt["workload"] == workload and receipt["solo_sha256"] == oracle_hash,
            "Terminal receipt or frozen workloads changed")
    proof = read(ROOT / "admission-proof.json")
    require(receipt["build"] == proof["build"] and proof["matching_generated_ids"] == 288,
            "The source does not match the validated guarded-admission executable")
    arms, indexed = {}, {}
    for label, enabled in ARMS:
        entry = receipt["arms"][label]
        hashes = source["arms"][label]
        trace_path = root / f"{label}.trace.json"
        client_path = root / f"{label}.json"
        samples_path = root / f"{label}-samples.jsonl"
        require(hashes["client_sha256"] == entry["client_sha256"]
                and hashes["cleaned_client_sha256"] == digest(client_path)
                and hashes["trace_sha256"] == entry["trace_sha256"] == digest(trace_path)
                and hashes["samples_sha256"] == digest(samples_path),
                f"Original or redacted evidence changed in {label}")
        client = read(client_path)
        require("base_url" not in client["target"] and "path" not in client["corpus"],
                "The portable receipt carries local client coordinates")
        observations = client["observations"]
        traces = read(trace_path)
        tokens = mixed.verify_rows(client, cases)
        exposure = audit(observations, traces, enabled)
        geometry = mixed.capture.summarize_activation(traces, observations)
        require(tokens == expected and entry["tail_deferral"] is enabled
                and entry["matched_requests"] == len(tokens)
                and entry["matched_output_ids"] == sum(map(len, tokens.values())) == 21_120
                and entry["exposure"] == exposure and entry["split_activation"] == geometry
                and geometry["split_groups"] == geometry["split_groups_with_published_end"]
                and entry["drained"] == dict.fromkeys(mixed.COUNTERS, 0),
                f"Serving identity, route or shutdown changed in {label}")
        samples = [json.loads(line) for line in samples_path.read_bytes().splitlines()]
        require(len(samples) == entry["pressure_samples"] > 0
                and all(row["pressure"] == 1 for row in samples), "Expected normal sampled pressure")
        idle = [entry["cpu_idle_before_percent"], entry["cpu_idle_after_percent"]]
        require(all(isfinite(x) and 0 <= x <= 100 for x in idle), "Invalid CPU telemetry")
        arms[label] = {
            "timing_eligible": min(idle) >= 90, "cpu_idle_percent": idle,
            "matched_output_ids": entry["matched_output_ids"], "normal_pressure_samples": len(samples),
            "peak_footprint_bytes": max(row["footprint_bytes"] for row in samples),
            **exposure,
        }
        indexed[label] = metrics_by_request(observations)

    require(receipt["timing_eligible"] is all(arm["timing_eligible"] for arm in arms.values()),
            "The controller changed its timing eligibility")
    pairs = {}
    for pair in (1, 2):
        base_name, candidate_name = f"physical-{pair}", f"held-{pair}"
        before, after = arms[base_name], arms[candidate_name]
        eligible = before["timing_eligible"] and after["timing_eligible"]
        row = {
            "timing_eligible": eligible,
            "control_late_opportunities": len(before["observed_shared_eligibility"]),
            "actual_held_arrivals": len(after["observed_held_arrivals"]),
        }
        if eligible:
            output_rate = "throughput_output_tokens_per_second"
            row["throughput_change_percent"] = 100 * (after[output_rate] / before[output_rate] - 1)
            row["median_matched_request_changes_ms"] = paired_effects(indexed[base_name], indexed[candidate_name])
        pairs[str(pair)] = row
    return {
        "qualification": False, "build": receipt["build"], "arms": arms, "paired_orders": pairs,
        "total_matching_output_ids": sum(row["matched_output_ids"] for row in arms.values()),
        "total_normal_pressure_samples": sum(row["normal_pressure_samples"] for row in arms.values()),
    }


if __name__ == "__main__":
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("path", type=Path)
    print(json.dumps(summarize(cli.parse_args().path), indent=2, sort_keys=True, allow_nan=False))
