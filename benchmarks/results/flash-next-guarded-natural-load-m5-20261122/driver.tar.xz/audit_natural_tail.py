"""Measure eligibility and actual late holds in the fixed two-client workload."""
from collections import Counter, defaultdict
from math import isclose, isfinite, ceil


def require(valid, message):
    if not valid:
        raise ValueError(message)


def milliseconds(row, key):
    value = row[key]
    require(type(value) in (int, float) and isfinite(value) and value >= 0,
            f"Invalid measurement for {key}")
    return value


def percentile95(values):
    ordered = sorted(values)
    return ordered[ceil(len(ordered) * 0.95) - 1]


def audit(observations, traces, enabled):
    measured = {r["request_id"]: r for r in observations if r["phase"] == "measured"}
    by_id = {p["request_id"]: p for p in traces}
    lengths = Counter(len(row["prompt_token_ids"]) for row in measured.values())
    require(lengths == {512: 132, 2048: 66, 8192: 22}
            and len(measured) == 220 and len(by_id) == len(traces) and measured.keys() <= by_id.keys(),
            "The frozen measured arrivals or request identities changed")

    short_by_step = defaultdict(list)
    long_by_first_prefill = {}
    complete = {}
    progress_by_step = defaultdict(set)
    for request_id, row in measured.items():
        trace = by_id[request_id]
        length = len(row["prompt_token_ids"])
        require(row["ok"] and len(row["output_token_ids"]) == 96
                and trace["initial_cursor"] == 0 and trace["cursor"] == length
                and len(trace["decode_step_ids"]) == len(set(trace["decode_step_ids"])) == 96
                and trace["prefill"] and not trace["partial"],
                "Incomplete outputs or unexpected prefill geometry")
        require(len(row["stream_step_interval_ms"]) == 95
                and all(isfinite(gap) and gap >= 0 for gap in row["stream_step_interval_ms"]),
                "Missing or invalid client inter-token gaps")
        start = milliseconds(row, "started_at_s")
        offered = milliseconds(row, "scheduled_at_s")
        queue = milliseconds(row, "queue_delay_ms")
        require(isclose(queue, (start - offered) * 1000, abs_tol=0.001),
                "Offered arrival and client queue accounting disagree")
        complete[request_id] = start + milliseconds(row, "e2e_latency_ms") / 1000
        for step in trace["decode_step_ids"]:
            progress_by_step[step].add(request_id)
        for step in trace["prefill"]:
            progress_by_step[step["step_id"]].add(request_id)
        if length == 512:
            for earlier_tokens, step in enumerate(trace["decode_step_ids"][1:], 1):
                short_by_step[step].append((request_id, earlier_tokens))
        if length == 8192:
            long_by_first_prefill[request_id] = trace["prefill"][0]

    shared = Counter()
    for active in progress_by_step.values():
        require(len(active) <= 2, "Measured engine step exceeded two resident lanes")
        if len(active) == 2:
            pair = sorted(len(measured[request]["prompt_token_ids"]) for request in active)
            require(pair[0] == 512, "An unmeasured medium or large pair executed together")
            shared[f"{pair[0]}/{pair[1]}"] += 1

    possible = []
    for ident, first in long_by_first_prefill.items():
        peers = short_by_step[first["step_id"]]
        for peer, earlier in peers:
            require(first["scheduled"] == 2, "A matching short decoder lacks a shared prefill step")
            if 84 <= earlier < 96:
                possible.append({"long": measured[ident]["prompt_id"], "short": measured[peer]["prompt_id"],
                                 "short_prior_output_tokens": earlier})

    held_arrivals = {}
    for ident, row in measured.items():
        trace = by_id[ident]
        markers = trace.get("held", ())
        ids = [event["step_id"] for event in markers]
        require(len(ids) == len(set(ids)) and ids == sorted(ids), "Repeated or backwards hold marker")
        for event in markers:
            step = event["step_id"]
            candidates = short_by_step[step]
            require(enabled and len(candidates) == 1 and candidates[0][0] == ident and candidates[0][1] >= 84,
                    "Hold marker does not belong to an eligible short decode tail")
            elapsed = milliseconds(event, "elapsed_s")
            now = row["started_at_s"] + elapsed
            peers = [key for key, prefill in long_by_first_prefill.items()
                     if measured[key]["started_at_s"] <= now <= complete[key] and prefill["step_id"] > step]
            require(len(peers) == 1, "Hold marker lacks a unique active peer with no prefill progress")
            peer = peers[0]
            previous = held_arrivals.setdefault(peer, (ident, []))
            require(previous[0] == ident, "A held request changed its short peer")
            previous[1].append(step)
        if ids:
            times = [event["elapsed_s"] for event in markers]
            start = trace["decode_step_ids"].index(ids[0])
            require(times == sorted(times) and len(ids) <= 12
                    and ids == trace["decode_step_ids"][start:start + len(ids)],
                    "Hold timing or consecutive decode boundary changed")

    earliest = min(r["started_at_s"] for r in measured.values())
    elapsed = max(complete.values()) - earliest
    require(elapsed > 0, "Measured throughput window is empty")
    by_length = {}
    for length in sorted(lengths):
        cohort = [row for row in measured.values() if len(row["prompt_token_ids"]) == length]
        by_length[str(length)] = {
            "p95_client_lane_wait_ms": percentile95([row["queue_delay_ms"] for row in cohort]),
            "p95_dispatch_ttft_ms": percentile95([milliseconds(row, "ttft_ms") for row in cohort]),
            "p95_offered_ttft_ms": percentile95([row["queue_delay_ms"] + row["ttft_ms"]
                                                 for row in cohort]),
        }
    return {
        "geometry_shared_steps": dict(shared),
        "timing_by_prompt_tokens": by_length,
        "matching_output_ids_required": 220 * 96,
        "long_requests": len(long_by_first_prefill),
        "observed_shared_eligibility": possible,
        "observed_held_arrivals": [
            {"long": measured[peer]["prompt_id"], "short": measured[short]["prompt_id"], "marked_steps": len(steps)}
            for peer, (short, steps) in held_arrivals.items()
        ],
        "throughput_output_tokens_per_second": 220 * 96 / elapsed,
        "p95_client_queue_ms": percentile95([r["queue_delay_ms"] for r in measured.values()]),
        "p95_offered_ttft_ms": percentile95([r["queue_delay_ms"] + milliseconds(r, "ttft_ms")
                                             for r in measured.values()]),
        "p95_short_max_token_gap_ms": percentile95([max(r["stream_step_interval_ms"]) for r in measured.values()
                                                    if len(r["prompt_token_ids"]) == 512]),
    }
