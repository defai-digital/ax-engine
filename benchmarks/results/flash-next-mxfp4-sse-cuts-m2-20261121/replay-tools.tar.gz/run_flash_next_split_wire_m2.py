"""Exercise per-request SSE split markers with one resident real-pack server."""

import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import subprocess
from threading import Event

import check_flash_next_native_support as native
from run_flash_next_prefill_split_probe import (
    MODEL, PROMPT_SHA256, RESERVE_OPTIONS, disconnect_and_reuse, generate, replay,
)
from run_flash_next_lifecycle import wait_drained
from run_qwen38_reference_serving import server, write_json
from verify_flash_next_prefill_split import (
    COUNTERS, INVENTORY_SHA, PHYSICAL_WIDTHS, SPLIT_PREFIX, verify_partition, verify_route_overlap,
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for option in ("binary", "flash", "prompts", "inventory", "out"):
        parser.add_argument(f"--{option}", type=Path, required=True)
    args = parser.parse_args()
    commands = subprocess.check_output(["ps", "-axo", "comm="], text=True)
    if any(Path(command.strip()).name.startswith("ax-engine-server") for command in commands.splitlines()):
        raise RuntimeError("Another AX server owns the inference device")
    assert native.sha256(args.prompts) == PROMPT_SHA256
    assert native.sha256(args.inventory) == INVENTORY_SHA
    binary_sha = native.sha256(args.binary)
    rows = [json.loads(line) for line in args.prompts.read_text().splitlines()]
    inventory = json.loads(args.inventory.read_text())
    manifest = native.validate_inventory(args.flash, inventory)
    clean = native.server_env()
    os.environ.clear()
    os.environ.update(clean)
    args.out.mkdir(parents=True, exist_ok=False)
    result = {
        "pack_revision": native.PACK_REVISION, "inventory_sha256": INVENTORY_SHA,
        "prompt_sha256": PROMPT_SHA256, "binary_sha256": binary_sha,
        "hardware": "Mac Studio M2 Ultra 192 GB, external SSD",
        "pairs": [], "disconnects": [], "drain_samples": [],
    }

    def drain(url):
        counters = wait_drained(url)
        assert counters.keys() == COUNTERS and all(value == 0 for value in counters.values())
        result["drain_samples"].append(counters)

    with server(args, "split-wire", MODEL, args.flash, 2,
                env={"AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0", "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": "1"},
                options=("--disable-ngram-acceleration", "--total-blocks", "2048",
                         "--max-batch-tokens", "2049", *RESERVE_OPTIONS),
                stream_experts="auto", guard=True) as (url, _):
        assert "decision=resident" in (args.out / "split-wire.log").read_text()
        result["serial"] = replay(url, rows, "serial", 0)
        expected = {request["prompt_id"]: request["output_tokens"] for request in result["serial"]}
        assert len(expected) == 2 and all(len(tokens) == 96 for tokens in expected.values())
        for row in result["serial"]:
            assert verify_partition(row, 2048, False) == 0
        drain(url)
        write_json(args.out / "partial.json", result)
        print("Serial controls verified.", flush=True)

        for leader in (0, 1):
            requests = replay(url, rows, "decode-arrival", leader)
            assert sum(verify_partition(row, 2048, True) for row in requests) == 1
            assert all(row["output_tokens"] == expected[row["prompt_id"]] for row in requests)
            verify_route_overlap({"requests": requests})
            drain(url)
            result["pairs"].append({"leader": leader, "requests": requests})
            write_json(args.out / "partial.json", result)
            print(f"Pair {leader} matched tokens and the request-specific cut.", flush=True)

        leader_ready = Event()
        short_decoder = dict(rows[0], max_output_tokens=5)

        def late_prefill():
            if not leader_ready.wait(30):
                raise TimeoutError("The short decoder did not begin")
            return generate(url, rows[1])

        with ThreadPoolExecutor(max_workers=2) as pool:
            leader_job = pool.submit(generate, url, short_decoder, on_first_output=leader_ready.set)
            prefill_job = pool.submit(late_prefill)
            decoder, target = leader_job.result(), prefill_job.result()
        assert decoder["output_tokens"] == expected[decoder["prompt_id"]][:5]
        assert target["output_tokens"] == expected[target["prompt_id"]]
        assert verify_partition(decoder, 2048, False) == 0
        assert verify_partition(target, 2048, True) == 1
        last_decoder_output = next(step for step in reversed(decoder["scheduled_work"])
                                   if step["delta_token_count"] > 0)
        assert any(step["step_id"] == last_decoder_output["step_id"] and step["scheduled_requests"] == 2
                   for step in target["prefill_progress"]), last_decoder_output
        drain(url)
        result["mixed_terminal_step"] = {"decoder": decoder, "prefill": target}
        write_json(args.out / "partial.json", result)
        print("The short decoder finished on a split prefill step without cross-request markers.", flush=True)

        for leader, mode in ((0, "prefill"), (1, "output")):
            trial = disconnect_and_reuse(url, rows, leader, mode)
            disconnected = trial["disconnected"]
            for label in ("survivor", "replacement"):
                row = trial[label]
                assert row["output_tokens"] == expected[row["prompt_id"]]
                verify_partition(row, 2048, False)
            cut = disconnected["prefill_progress"][0]
            assert cut["cursor"] == PHYSICAL_WIDTHS[0]
            assert cut["step_id"] in trial["shared_steps"]
            assert cut["prefill_route"] == {f'{SPLIT_PREFIX}{disconnected["request_id"]}': 2048}
            partial = disconnected["first_output_tokens"]
            assert partial == expected[disconnected["prompt_id"]][:len(partial)]
            if mode == "prefill":
                assert not partial and len(disconnected["prefill_progress"]) == 1
            else:
                assert partial and verify_partition(disconnected, 2048, True) == 1
            verify_route_overlap({"requests": [disconnected, trial["survivor"]]})
            for label in ("drained_after_disconnect", "drained_after_replacement"):
                counters = trial[label]
                assert counters.keys() == COUNTERS and all(value == 0 for value in counters.values())
                result["drain_samples"].append(counters)
            result["disconnects"].append(trial)
            write_json(args.out / "partial.json", result)
            print(f"Disconnect after {mode} recovered with a matching replacement.", flush=True)

    samples = [json.loads(line) for line in (args.out / "split-wire-samples.jsonl").read_text().splitlines()]
    assert samples and all(sample["pressure"] == 1 for sample in samples)
    assert native.validate_inventory(args.flash, inventory) == manifest
    assert native.sha256(args.binary) == binary_sha
    result["memory_samples"] = samples
    write_json(args.out / "result.json", result)


if __name__ == "__main__":
    main()
