"""Exercise the strict live step parser without loading model weights."""

import json
import time

from run_flash_next_prefill_split_probe import MODEL, read_stream
from split_step_route import SPLIT_PREFIX

REQUEST = {"request_id": 8, "processed_prompt_tokens": 0, "prompt_tokens": [1, 2]}
ROW = {"id": "fixture", "input_tokens": [1, 2], "max_output_tokens": 2}


def route(**decisions):
    return {"crossover_decisions": {f"{SPLIT_PREFIX}{key}": val for key, val in decisions.items()}}


def fixture(*, live=None, request_route=None, decode=None, terminal=None):
    events = [("request", {"request": REQUEST})]
    for step_id, cursor, delta, step_route in ((1, 1, [], live), (2, 2, [3], None), (3, 2, [4], decode)):
        events.append(("step", {
            "request": {**REQUEST, "processed_prompt_tokens": cursor, "route": request_route},
            "step": {"step_id": step_id, "scheduled_requests": 2, "scheduled_tokens": 2, "route": step_route},
            "delta_tokens": delta,
        }))
    events.append(("response", {"response": {
        **REQUEST, "model_id": MODEL, "status": "finished", "finish_reason": "max_output_tokens",
        "output_tokens": [3, 4], "route": terminal or {},
    }}))
    lines = [f"event: {name}\ndata: {json.dumps(payload)}\n\n".encode() for name, payload in events]
    return read_stream(b"".join(lines).splitlines(keepends=True), ROW, time.monotonic(), lambda: None)


def verify():
    own = route(**{"8": 2})
    foreign = route(**{"9": 2})
    valid = fixture(live=own, terminal=own)
    assert valid["request_id"] == 8
    assert valid["prefill_progress"][0]["prefill_route"] == own["crossover_decisions"]
    assert fixture(request_route=own)["prefill_progress"][0]["prefill_route"] == {}
    assert fixture(terminal=own)["prefill_progress"][0]["prefill_route"] == {}
    for invalid in ({"live": foreign}, {"request_route": foreign}, {"decode": own}, {"terminal": foreign}):
        try:
            fixture(**invalid)
        except RuntimeError as error:
            assert "prefill boundary" in str(error)
        else:
            raise AssertionError(f"Accepted invalid marker placement {invalid}")
    print("Seven native step parser controls passed.")


if __name__ == "__main__":
    verify()
