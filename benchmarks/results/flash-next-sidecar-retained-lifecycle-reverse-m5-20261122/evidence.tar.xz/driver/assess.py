"""Verify two retained-delivery Flash Next lifecycle runs."""

import json
from pathlib import Path
import re
import sys

from run_lifecycle_pair import MODES, ROOT, inspect_arm, native, read, require

PRIVATE = (b"127.0.0.1:", b"localhost:", b"/Users/", b"/private/tmp/", b"df-macbook", b"um-macstudio")
ROUTE_PREFIX = "Flash Next MTP sidecar prefetch"
ARMS = ("prefetch", "mapped")


def report(root, expected_build):
    stock = read(ROOT / "oracle.json")
    thresholds = read(ROOT / "scripts" / "flash_next_release_thresholds.json")
    observed = read(root / "pair.json")
    require(observed["phase"] == "complete" and observed["qualification"] is False
            and observed["build"] == expected_build
            and observed["arms"] == list(ARMS) and observed["modes"] == list(MODES)
            and list(observed["results"]) == list(ARMS)
            and observed["modes_readiness_seconds_max"] == thresholds["readiness"]["warm_seconds_max"]
            and observed["oracle_sha256"] == native.sha256(ROOT / "oracle.json"),
            "The terminal receipt changed the runtime or frozen pair")
    result = {}
    for label in ARMS:
        arm = root / label
        pressure = read(arm / "host-pressure.json")
        candidate = inspect_arm(arm, label == "prefetch", expected_build, stock, thresholds, pressure)
        require(candidate == observed["results"][label], f"Recomputed lifecycle results differ for {label}")
        result[label] = candidate
    return {
        "scope": "Paired retained-delivery lifecycle on M5 Max 128 GB",
        "qualification": False,
        "runtime_commit": expected_build["commit"],
        "readiness_seconds_max": thresholds["readiness"]["warm_seconds_max"],
        "timing_eligible": all(arm["timing_eligible"] for arm in result.values()),
        "arms": result,
    }


def safe_bytes(data):
    require(not any(marker in data for marker in PRIVATE), "Host-specific data in portable evidence")
    return data


def seal(raw, target, build):
    expected = report(raw, build)
    target.mkdir()
    (target / "pair.json").write_bytes(safe_bytes((raw / "pair.json").read_bytes()))
    for label in ARMS:
        source = raw / label
        arm = target / label
        arm.mkdir()
        for name in ("host-pressure.json", "result.json"):
            (arm / name).write_bytes(safe_bytes((source / name).read_bytes()))
        for mode in MODES:
            name = f"server-{mode}.log"
            text = re.sub(r"\x1b\[[0-9;]*m", "", (source / name).read_text())
            clean = []
            for line in text.splitlines():
                _, marker, detail = line.partition(ROUTE_PREFIX)
                if marker:
                    clean.append(marker + detail)
            (arm / name).write_bytes(safe_bytes(("\n".join(clean) + "\n").encode()))
    require(report(target, build) == expected, "Selective log retention changed route interpretation")
    return expected


if __name__ == "__main__":
    book, build_file, *sealed = map(Path, sys.argv[1:])
    require(len(sealed) <= 1, "Expected at most one output directory")
    build = read(build_file)
    result = seal(book, sealed[0], build) if sealed else report(book, build)
    print(json.dumps(result, indent=2, allow_nan=False))
