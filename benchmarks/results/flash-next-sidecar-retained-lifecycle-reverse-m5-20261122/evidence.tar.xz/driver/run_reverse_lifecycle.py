"""Repeat the frozen retained Flash Next lifecycle pair in reverse order."""

import run_lifecycle_pair as driver


if __name__ == "__main__":
    driver.ARMS = tuple(reversed(driver.ARMS))
    driver.main()
