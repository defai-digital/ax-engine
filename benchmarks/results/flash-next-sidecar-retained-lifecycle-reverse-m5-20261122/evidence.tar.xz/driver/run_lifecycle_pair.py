"""Compare the frozen staged lifecycle controls with both sidecar reader settings."""
from argparse import ArgumentParser
from importlib.metadata import distribution, version
import json
from math import isfinite
from pathlib import Path
import re
import subprocess
import sys
from tempfile import TemporaryDirectory
from unittest.mock import patch

from run_load_order import fresh_clone
from scripts import check_flash_next_native_support as native
from scripts import check_flash_next_release_gates as gate
from scripts import run_flash_next_lifecycle as lifecycle

ROOT = Path(__file__).resolve().parent
MODES = ("disabled", "default")
ARMS = ("mapped", "prefetch")
FLAG = "AX_MLX_FLASH_NEXT_MTP_SIDECAR_PREFETCH"
BYTES = 5_214_301_696
MANIFEST = "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef"


def require(valid, reason):
    if not valid:
        raise ValueError(reason)


def read(path):
    return json.loads(path.read_bytes())


def save(path, report):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def pressure():
    return int(subprocess.check_output(
        ["/usr/sbin/sysctl", "-n", "kern.memorystatus_vm_pressure_level"], text=True))


def stable(action):
    row = dict(action)
    if "usage" in row and "ax_engine" in row["usage"]:
        usage = dict(row["usage"])
        usage["ax_engine"] = {key: value for key, value in usage["ax_engine"].items()
                              if key not in ("prefill_time_us", "decode_time_us")}
        row["usage"] = usage
    return row


def inspect_arm(root, enabled, build, stock, thresholds, pressure_samples):
    result_path = root / "result.json"
    result = read(result_path)
    require(result["server_sha256"] == build["server_sha256"]
            and all(result[k] == stock[k] for k in ("inventory_sha256", "hardware", "revision"))
            and result["modes"] == list(MODES) == [run["mode"] for run in result["runs"]],
            "Lifecycle hardware, mode, model or executable changed")
    verdict, = gate.gate_lifecycle(result, thresholds)
    require(verdict["passed"], verdict["detail"])
    startup, reads = {}, {}
    for current, official in zip(result["runs"], stock["runs"], strict=True):
        mode = current["mode"]
        require(mode == official["mode"]
                and current["final_verified_steps"] == official["final_verified_steps"] == 0
                and [stable(row) for row in current["actions"]] == [stable(row) for row in official["actions"]],
                f"Frozen HTTP behavior or verifier changed in {mode}")
        seconds = current["ready_seconds"]
        require(type(seconds) in (int, float) and isfinite(seconds) and seconds > 0, "Invalid readiness")
        startup[mode] = seconds
        log = re.sub(r"\x1b\[[0-9;]*m", "", (root / f"server-{mode}.log").read_text())
        route = re.findall(r"Flash Next MTP sidecar prefetch completed bytes=(\d+) elapsed_ms=([\d.]+)", log)
        require("Flash Next MTP sidecar prefetch failed" not in log and len(route) == int(enabled)
                and all(int(count) == BYTES and 0 < float(elapsed) < float("inf") for count, elapsed in route),
                f"Unexpected pre-read route in {mode}")
        reads[mode] = float(route[0][1]) / 1000 if route else 0
    idle = [result["host_quiet"]["cpu_idle_percent"], result["host_idle_after"]]
    floor = thresholds["timing_host"]["min_cpu_idle_percent"]
    require(len(pressure_samples) == 2
            and all(isfinite(x) and 0 <= x <= 100 for x in idle), "Incomplete host telemetry")
    band = thresholds["readiness"]["warm_seconds_max"]
    return {"lifecycle": verdict, "readiness_seconds": startup, "ready_seconds_max": band,
            "readiness_band_met": all(value <= band for value in startup.values()),
            "timing_eligible": pressure_samples == [1, 1] and all(value >= floor for value in idle),
            "host_idle_percent": idle, "pressure_samples": pressure_samples, "prefetch_seconds": reads,
            "raw_lifecycle_sha256": native.sha256(result_path)}


def clone_snapshot(cache, target, inventory):
    pack = cache / ("models--" + native.PRIMARY_REPO.replace("/", "--")) / "snapshots" / native.PACK_REVISION
    manifest = (pack / "model-manifest.json").read_bytes()
    require(native.sha256(pack / "model-manifest.json") == MANIFEST and len(inventory["members"]) == 49,
            "The retained delivery manifest changed")
    for member in inventory["members"]:
        name = member["name"]
        source = (pack / name).resolve(strict=True)
        require(source.is_relative_to(cache) and source.stat().st_size == member["size"],
                "Publisher member escaped its cache or changed size")
        destination = target / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        fresh_clone(source, destination)
    (target / "model-manifest.json").write_bytes(manifest)


def main():
    parser = ArgumentParser(description=__doc__)
    for name in ("runtime", "cache", "output"):
        parser.add_argument(f"--{name}", type=Path)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    thresholds = read(ROOT / "scripts" / "flash_next_release_thresholds.json")
    stock = read(ROOT / "oracle.json")
    inventory = ROOT / "inventory.json"
    require(stock["modes"] == list(MODES) == thresholds["lifecycle"]["modes_required"]
            and stock["inventory_sha256"] == native.sha256(inventory), "Frozen lifecycle inputs changed")
    report = {
        "scope": "paired lifecycle on the retained pinned delivery",
        "qualification": False, "arms": list(ARMS), "modes": list(MODES),
        "modes_readiness_seconds_max": thresholds["readiness"]["warm_seconds_max"],
        "mode_actions": list(lifecycle.ACTIONS), "counter_names": list(lifecycle.COUNTERS),
        "oracle_sha256": native.sha256(ROOT / "oracle.json"),
    }
    if args.dry_run:
        print(json.dumps(report, indent=2))
        return
    if not all((args.runtime, args.cache, args.output)):
        parser.error("live execution requires runtime, cache and output")
    require(subprocess.check_output(["/usr/sbin/sysctl", "-n", "hw.model", "hw.memsize"], text=True).splitlines()
            == ["Mac17,6", "137438953472"], "Expected the product M5 Max host")
    runtime = args.runtime.resolve(strict=True)
    binary = runtime / "ax-engine-server"
    build = read(runtime / "build.json")
    require(build["codesign_verified"] is True and build["profile"] == "release-server"
            and build["mlx"] == build["mlx_metal"] == version("mlx") == version("mlx-metal") == "0.32.4"
            and build["server_sha256"] == native.sha256(binary)
            and build["libmlx_sha256"] == native.sha256(distribution("mlx").locate_file("mlx/lib/libmlx.dylib")),
            "Native binary or shared library changed")
    subprocess.run(["/usr/bin/codesign", "--verify", "--strict", binary], check=True)
    names = subprocess.check_output(["/bin/ps", "-axo", "comm="], text=True).splitlines()
    require(not any(Path(name.strip()).name.startswith("ax-engine-server") for name in names),
            "An inference server already owns the device")
    cache = args.cache.resolve(strict=True)
    output = args.output.resolve()
    output.mkdir()
    report.update(build=build, phase="starting", results={})
    save(output / "pair.json", report)
    original = native.server_env
    for arm in ARMS:
        enabled = arm == "prefetch"
        before = pressure()
        require(before == 1, "Memory pressure exceeded normal before lifecycle")
        with TemporaryDirectory(prefix="flash-next-lifecycle-", dir=output) as temporary:
            pack = Path(temporary)
            clone_snapshot(cache, pack, read(inventory))
            arm_path = output / arm
            argv = [sys.argv[0], "--model-dir", str(pack), "--inventory", str(inventory),
                    "--server-bin", str(binary), "--output", str(arm_path), "--modes", *MODES]
            with (patch.object(native, "server_env", lambda explicit=None: original(
                        {FLAG: str(int(enabled)), **(explicit or {})})),
                  patch.object(sys, "argv", argv)):
                require(lifecycle.main() == 0, "The frozen lifecycle runner failed")
            after = pressure()
            save(arm_path / "host-pressure.json", [before, after])
            report["results"][arm] = inspect_arm(arm_path, enabled, build, stock, thresholds, [before, after])
            report["phase"] = f"{arm}-complete"
            save(output / "pair.json", report)
    report["phase"] = "complete"
    save(output / "pair.json", report)


if __name__ == "__main__":
    main()
