#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
previous=$1
cache=$2
test "$(cat "$previous/status.txt")" = 0
test "$(/usr/sbin/sysctl -n hw.model hw.memsize)" = "$(printf 'Mac17,6\n137438953472')"
if /bin/ps -axo comm= | /usr/bin/grep -E '/(ax-engine-server[^/]*|ax-flash-shared-load-test|ax-ple-reader-test|direct_weights)$'; then
    exit 1
fi
/usr/bin/shasum -a 256 -c admission-inputs.sha256
pack="$cache/models--AutomatosX--AX-Qwen3.8-Flash-Next-MLX-AXQ-MXFP4-MTP/snapshots/ff2a28485eb89bb60e8fe35dd6c65c51e63ee7b3"
python="$HOME/.venvs/ax-engine/bin/python"
mlx=$("$python" -B -c 'from importlib.metadata import version, distribution; assert version("mlx") == version("mlx-metal") == "0.32.4"; print(distribution("mlx").locate_file("mlx/lib"))')
expected=$("$python" -B -c 'import json; print(json.load(open("candidate-build.json"))["libmlx_sha256"])')
test "$(shasum -a 256 "$mlx/libmlx.dylib" | awk '{print $1}')" = "$expected"
test "$(/usr/sbin/sysctl -n kern.memorystatus_vm_pressure_level)" = 1
exec /usr/bin/caffeinate -dimsu /usr/bin/env -i HOME="$HOME" \
    PATH="$HOME/.venvs/ax-engine/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin" \
    DYLD_LIBRARY_PATH="$mlx" PYTHONDONTWRITEBYTECODE=1 \
    "$python" -B -u verify_mixed_admission.py --binary "$PWD/ax-engine-server-resident-mixed" \
    --pack "$pack" --link-root "$cache" --out "$PWD/observed"
