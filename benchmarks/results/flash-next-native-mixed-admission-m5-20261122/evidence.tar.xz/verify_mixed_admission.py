"""Verify queued large requests and the existing held pair with the M5 pack."""
from argparse import ArgumentParser
import json
from pathlib import Path

from run_held_cancel import advance, post, snapshot, submit
from run_server_tail import burst, layer, mixed, require
from run_sustained_tail import inputs as mixed_inputs

ROOT = Path(__file__).resolve().parent
LABEL = "resident-mixed-admission"


def inputs():
    _, measured_pair, measured_oracle = layer.files()["ending-decoder"]
    pairs, expected = mixed_inputs()
    long = (pairs[0][1], pairs[1][1])
    require(long[0].id != long[1].id and all(len(case.input_tokens) == 8192
            and case.max_output_tokens == 96 for case in long), "Large prompt geometry changed")
    return measured_pair, measured_oracle, long, expected


def queued_large(base, first, second, expected, partial):
    first_submit, second_submit = (submit(base, case) for case in (first, second))
    a, b = (reply["request_id"] for reply in (first_submit, second_submit))
    require(a != b, "The two accepted requests share an ID")
    frames = []
    for cursor in (2048, 4096):
        step = advance(base)
        active, waiting = (snapshot(base, rid) for rid in (a, b))
        frames.append({"step": step, "active": active, "waiting": waiting})
        partial.write_text(json.dumps(frames, indent=2, allow_nan=False) + "\n")
        require(step["scheduled_requests"] == 1 and step["scheduled_tokens"] == 2048
                and active["processed_prompt_tokens"] == cursor and waiting["state"] == "waiting"
                and waiting["processed_prompt_tokens"] == waiting["output_len"] == 0,
                "The second large request became resident while the first held the lane")
    stopped = post(base, f"/v1/requests/{a}/cancel", {})
    require(stopped["state"] == "cancelled", "Cancellation did not finish")
    released = advance(base)
    promoted = snapshot(base, b)
    require(released["scheduled_requests"] == 1 and released["scheduled_tokens"] == 2048
            and promoted["state"] != "waiting" and promoted["processed_prompt_tokens"] == 2048,
            "The queued request changed its initial prefill width")
    for _ in range(112):
        advance(base)
        terminal = snapshot(base, b)
        if terminal["state"] in ("finished", "cancelled", "failed"):
            break
    else:
        raise ValueError("The queued request did not finish")
    require(terminal["state"] == "finished" and terminal["output_tokens"] == expected[second.id],
            "The admitted output differs from the frozen solo sequence")
    return {"submissions": [first_submit, second_submit], "frames": frames, "cancel": stopped,
            "release": released, "promoted": promoted, "terminal": terminal,
            "drained": mixed.wait_drained(base)}


def main():
    parser = ArgumentParser(description=__doc__)
    for field in ("binary", "pack", "link-root", "out"):
        parser.add_argument(f"--{field}", type=Path)
    parser.add_argument("--check-inputs", action="store_true")
    args = parser.parse_args()
    pair, oracle, long, expected = inputs()
    if args.check_inputs:
        print("Verified the two distinct 8K requests, existing held pair and frozen solo outputs.")
        return
    build = json.loads((ROOT / "candidate-build.json").read_bytes())
    inventory = json.loads((ROOT / "mxfp4-inventory.json").read_bytes())
    require(build["server_sha256"] == mixed.digest(args.binary) and build["codesign_verified"],
            "The measured native executable changed")
    manifest = mixed.native.validate_inventory(args.pack, inventory, args.link_root)
    require(manifest.get("model-manifest.json") ==
            "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef", "Delivered manifest changed")
    args.out.mkdir()
    options = ("--disable-ngram-acceleration", "--total-blocks", "2048", "--max-batch-tokens", "2049",
               *mixed.RESERVE_OPTIONS)
    env = {"AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0", "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": "1",
           "AX_MLX_FLASH_NEXT_PREFILL_TAIL_DEFERRAL": "1"}
    idle = [mixed.native.wait_for_quiet()["cpu_idle_percent"]]
    with mixed.server(args, LABEL, mixed.MODEL, args.pack, 2, env=env, options=options,
                      stream_experts="auto", guard=True) as (base, _):
        waiting = queued_large(base, *long, expected, args.out / "partial-wait.json")
        held = burst(base, pair, oracle, True, args.out / "partial-held.json")
        require(json.loads(mixed.native.request(base, "/health"))["status"] == "ok", "Health declined")
    idle.append(mixed.native.cpu_idle_percent())
    require(mixed.native.validate_inventory(args.pack, inventory, args.link_root) == manifest, "Pack changed")
    samples = [json.loads(row) for row in (args.out / f"{LABEL}-samples.jsonl").read_text().splitlines()]
    require(samples and {row["pressure"] for row in samples} == {1}, "Normal sampled pressure required")
    report = {"scope": "primary-tier experimental resident mixed admission", "qualification": False,
              "build": build, "manifest": manifest, "revision": inventory["revision"],
              "matching_generated_ids": 288, "queue": waiting, "existing_held_path": held,
              "cpu_idle_percent": idle, "normal_pressure_samples": len(samples)}
    (args.out / "receipt.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
