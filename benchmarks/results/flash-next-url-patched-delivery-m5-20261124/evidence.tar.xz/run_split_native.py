"""Schedule the frozen native suite on the shared qualification host."""

from contextlib import contextmanager
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from time import monotonic, sleep

BASE = Path(__file__).resolve().parent
SCRIPTS = BASE / 'scripts'
SLOT = Path.home() / 'build/.ax-flash-next-native-test-slot'
REFERENCE = Path(sys.argv[1])
OWNER = str(os.getpid())
sys.path.insert(0, str(SCRIPTS))
import check_flash_next_native_support as native
import run_flash_next_delivery as delivery


def phase(name):
    (BASE/'phase.txt').write_text(name+'\n')
    print(name, flush=True)


def reference_waits():
    if (REFERENCE/'status.txt').is_file():
        return True
    if (REFERENCE/'headroom.jsonl').is_file():
        return False
    try:
        sample = json.loads((REFERENCE/'capacity.latest.json').read_bytes())['capacity']
    except (OSError, ValueError, KeyError):
        return False
    observed = datetime.fromisoformat(sample['utc'])
    age = (datetime.now(timezone.utc)-observed).total_seconds()
    return 0 <= age <= 90 and not sample['eligible_for_attempt']


def normal_pressure():
    return subprocess.check_output(['/usr/sbin/sysctl','-n','kern.memorystatus_vm_pressure_level']).strip()==b'1'


def acquire(quiet):
    stop = monotonic() + 8*3600
    while monotonic() < stop:
        if not SLOT.exists() and reference_waits() and normal_pressure():
            idle = native.cpu_idle_percent() if quiet else None
            if idle is not None:
                with (BASE/'quiet-preflight.jsonl').open('a') as trace:
                    print(json.dumps({'utc': datetime.now(timezone.utc).isoformat(timespec='seconds'),
                                      'cpu_idle_percent': idle}), file=trace)
            if (idle is None or idle >= 90) and reference_waits() and normal_pressure():
                try:
                    SLOT.mkdir()
                except FileExistsError:
                    continue
                (SLOT/'owner.pid').write_text(OWNER+'\n')
                return
        sleep(15)
    raise TimeoutError('No eligible native test slot within the observation window')


def release():
    owner = SLOT/'owner.pid'
    try:
        belongs_to_run = owner.read_text().strip()==OWNER
    except FileNotFoundError:
        return
    if belongs_to_run:
        owner.unlink()
        SLOT.rmdir()


def ensure_no_model():
    commands = subprocess.check_output(['/bin/ps','-axo','comm='],text=True)
    if re.search(r'/(ax-engine-server[^/]*|mtp-audit|direct_weights|ax-flash-.*-test)$',commands,re.M):
        raise RuntimeError('Another native model process is running')


@contextmanager
def lane(quiet):
    acquire(quiet)
    try:
        ensure_no_model()
        yield
    finally:
        release()


def run_delivery(runtime):
    stock_control = delivery.run_control

    def wait_then_control(args, snapshot, output):
        release()
        phase('Waiting for quiet delivery controls')
        acquire(quiet=True)
        ensure_no_model()
        phase('Running delivery controls')
        return stock_control(args, snapshot, output)

    delivery.run_control = wait_then_control
    sys.argv = [str(SCRIPTS/'run_flash_next_delivery.py'), *runtime, '--ax-engine', str(BASE/'ax-engine'),
                '--cache-root', str(BASE/'fresh-cache'), '--output', str(BASE/'evidence/delivery')]
    phase('Waiting for cold delivery slot')
    with lane(quiet=False):
        (BASE/'evidence').mkdir()
        phase('Starting cold delivery')
        if delivery.main()!=0:
            raise RuntimeError('Cold delivery did not complete')


def main():
    runtime = ['--inventory',str(BASE/'inventory.json'),'--server-bin',str(BASE/'ax-engine-server')]
    run_delivery(runtime)
    snapshot = BASE/'fresh-cache/models--AutomatosX--AX-Qwen3.8-Flash-Next-MLX-AXQ-MXFP4-MTP/snapshots/ff2a28485eb89bb60e8fe35dd6c65c51e63ee7b3'
    if not (snapshot/'model-manifest.json').is_file():
        raise ValueError('The verified native snapshot is missing')
    runtime += ['--model-dir',str(snapshot),'--ordinary-launch']
    for name, output, extra in (('lifecycle','lifecycle',[]), ('qa_cohort','qa',[]),
                                ('generate_matrix','generate-matrix',['--repeats','2'])):
        phase(f'Waiting for quiet {name}')
        with lane(quiet=True):
            phase(f'Starting {name}')
            target = BASE/'evidence'/output
            subprocess.run([sys.executable,'-E','-s','-B','-u',str(SCRIPTS/f'run_flash_next_{name}.py'),
                            *runtime,'--output',str(target),*extra], check=True)
            if not (target/'result.json').is_file():
                raise RuntimeError(f'{name} did not produce a receipt')
    phase('Native suite complete')


if __name__=='__main__':
    main()
