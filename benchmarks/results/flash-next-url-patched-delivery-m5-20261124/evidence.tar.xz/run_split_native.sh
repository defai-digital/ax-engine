#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
export PATH="$HOME/.venvs/ax-engine/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export PYTHONDONTWRITEBYTECODE=1
readonly reference="$1"
readonly python="$HOME/.venvs/ax-engine/bin/python"
readonly slot="$HOME/build/.ax-flash-next-native-test-slot"
readonly base="$PWD"
result=1
trap 'printf "%s\n" "$result" > status.txt' EXIT
/usr/bin/shasum -a 256 -c inputs.sha256 >/dev/null
for name in ax-engine ax-engine-server; do /usr/bin/codesign --verify --strict "$base/$name"; done
test "$(sysctl -n hw.model hw.memsize)" = "$(printf 'Mac17,6\n137438953472')"
test "$(sw_vers -productVersion)" = "27.2.1"
test ! -e evidence && test ! -e fresh-cache
export DYLD_LIBRARY_PATH=$("$python" -E -s -B -c 'from importlib.metadata import distribution,version; assert version("mlx")==version("mlx-metal")=="0.32.4"; print(distribution("mlx").locate_file("mlx/lib"))')
expected=$("$python" -E -s -B -c 'import json; print(json.load(open("build.json"))["libmlx_sha256"])')
test "$(shasum -a 256 "$DYLD_LIBRARY_PATH/libmlx.dylib" | awk '{print $1}')" = "$expected"
/usr/bin/shasum -a 256 -c split-inputs.sha256 >/dev/null
"$python" -E -s -B -u run_split_native.py "$reference"
/usr/bin/shasum -a 256 -c inputs.sha256 >/dev/null
/usr/bin/shasum -a 256 -c split-inputs.sha256 >/dev/null
result=0
