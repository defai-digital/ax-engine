#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
role=$1
source_path=$2
reference=$3
retained=$4
slot="$HOME/build/.ax-flash-next-native-test-slot"
export PATH="$HOME/.venvs/ax-engine/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
owned=0
finish() {
    code=$?
    if (( owned )) && test "$(cat "$slot/owner.pid" 2>/dev/null)" = "$$"; then
        rm "$slot/owner.pid"
        rmdir "$slot"
    fi
    printf '%s\n' "$code" > status.txt
}
trap finish EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
/usr/bin/shasum -a 256 -c inputs.sha256 >/dev/null
/usr/bin/codesign --verify --strict ax-engine-server
if [[ "$role" == m5 ]]; then
    test "$(/usr/sbin/sysctl -n hw.model hw.memsize)" = "$(printf 'Mac17,6\n137438953472')"
    python="$HOME/.venvs/ax-engine/bin/python"
    ref_python="$HOME/build/flash-next-official-20260923/launch-reference-env/bin/python"
    cache="$source_path/fresh-cache"
    pack="$cache/models--AutomatosX--AX-Qwen3.8-Flash-Next-MLX-AXQ-MXFP4-MTP/snapshots/ff2a28485eb89bb60e8fe35dd6c65c51e63ee7b3"
    test "$(cat "$source_path/status.txt")" = 0
else
    test "$role" = m2
    test "$(/usr/sbin/sysctl -n machdep.cpu.brand_string hw.memsize)" = "$(printf 'Apple M2 Ultra\n206158430208')"
    test "$(cat "$source_path/status.txt")" = 0
    python="$HOME/code/ax-engine/.venv/bin/python"
    pack=$(cat "$source_path/pack.pointer")
    cache="$pack"
fi
test -d "$pack"
lib=$("$python" -B -c 'from importlib.metadata import distribution,version; assert version("mlx")==version("mlx-metal")=="0.32.4"; print(distribution("mlx").locate_file("mlx/lib"))')
expected=$("$python" -B -c 'import json; print(json.load(open("build.json"))["libmlx_sha256"])')
test "$(shasum -a 256 "$lib/libmlx.dylib" | awk '{print $1}')" = "$expected"
deadline=$((SECONDS+54000))
while (( SECONDS < deadline )); do
    if [[ "$role" == m5 ]] && ! test -s "$retained/status.txt"; then sleep 30; continue; fi
    if test "$(/usr/sbin/sysctl -n kern.memorystatus_vm_pressure_level)" = 1 && mkdir "$slot" 2>/dev/null; then
        printf '%s\n' "$$" > "$slot/owner.pid"
        owned=1
        if ! /bin/ps -axo comm= | /usr/bin/grep -Eq '/(ax-engine-server[^/]*|mtp-audit|direct_weights|ax-flash-shared-load-test|ax-ple-reader-test)$'; then
            if [[ "$role" == m2 ]] || test -s "$reference/status.txt"; then break; fi
            if ! test -s "$reference/headroom.jsonl"; then
                (cd "$reference" && "$ref_python" -B recover.py --preflight) > capacity-before.json
                if "$python" -B -c 'import json,sys; r=json.load(open("capacity-before.json"))["capacity"]; sys.exit(not (r["reason"]=="background-rss-exceeds-signed-margin" and r["pressure"]==1))'; then break; fi
            fi
        fi
        rm "$slot/owner.pid"
        rmdir "$slot"
        owned=0
    fi
    sleep 30
done
test "$owned" = 1
/usr/bin/caffeinate -i /usr/bin/env -i HOME="$HOME" PATH="$PATH" DYLD_LIBRARY_PATH="$lib" PYTHONDONTWRITEBYTECODE=1 \
    "$python" -B -u check_pair_guard.py --binary "$PWD/ax-engine-server" --pack "$pack" --link-root "$cache" --out "$PWD/observed"
/usr/bin/shasum -a 256 -c inputs.sha256 >/dev/null
test "$(/usr/sbin/sysctl -n kern.memorystatus_vm_pressure_level)" = 1
