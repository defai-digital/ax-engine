"""Check FIFO Flash Next two-slot residency through the native HTTP path."""

from argparse import ArgumentParser
import json
from pathlib import Path
import subprocess
from urllib.error import HTTPError

import check_openai_concurrency as frozen
import run_selective_mixed as mixed

ROOT = Path(__file__).resolve().parent
LABEL = "flash-next-pair-guard"
TERMINAL = {"finished", "cancelled", "failed"}
ENV = {"AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0", "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": "1",
       "RUST_LOG": "info,ax_engine_mlx::flash_next_startup=debug"}


def request(base, path, body=None):
    result = mixed.native.request(base, path) if body is None else mixed.native.request(base, path, body)
    return json.loads(result)


def submit(base, case):
    result = request(base, "/v1/requests", {
        "model": mixed.MODEL, "input_tokens": case.input_tokens,
        "max_output_tokens": case.max_output_tokens, "sampling": {"temperature": 0, "ignore_eos": True},
    })
    return result["request_id"]


def snapshot(base, request_id):
    return request(base, f"/v1/requests/{request_id}")


def advance(base):
    result = request(base, "/v1/step", {})
    return {key: result[key] for key in ("step_id", "scheduled_requests", "scheduled_tokens")}


def finish(base, *request_ids):
    for _ in range(256):
        states = [snapshot(base, item) for item in request_ids]
        if all(row["state"] in TERMINAL for row in states):
            assert all(row["state"] == "finished" and len(row["output_tokens"]) == 96 for row in states)
            assert all(type(token) is int and token >= 0 for row in states for token in row["output_tokens"])
            return states
        advance(base)
    raise RuntimeError("Native stepwise requests did not finish")


def queued(base, first, second, solo, output):
    a, b = submit(base, first), submit(base, second)
    assert a != b
    try:
        submit(base, first)
    except HTTPError as error:
        with error:
            rejection = {"status": error.code, "code": json.load(error)["error"]["code"]}
    else:
        raise AssertionError("Two occupied slots accepted a third request")
    assert rejection == {"status": 429, "code": "concurrency_limit"}
    frames = []
    for cursor in (2048, 4096):
        step, active, waiting = advance(base), snapshot(base, a), snapshot(base, b)
        frames.append({"step": step, "active": active, "waiting": waiting})
        output.write_text(json.dumps(frames, indent=2, allow_nan=False) + "\n")
        assert step["scheduled_requests"] == 1 and step["scheduled_tokens"] == 2048
        assert active["processed_prompt_tokens"] == cursor and waiting["state"] == "waiting"
        assert waiting["processed_prompt_tokens"] == waiting["output_len"] == 0
    cancelled = request(base, f"/v1/requests/{a}/cancel", {})
    assert cancelled["state"] == "cancelled"
    released, promoted = advance(base), snapshot(base, b)
    assert released["scheduled_requests"] == 1 and released["scheduled_tokens"] == 2048
    assert promoted["state"] != "waiting" and promoted["processed_prompt_tokens"] == 2048
    (result,) = finish(base, b)
    assert result["output_tokens"] == solo[second.id]
    return {"frames": frames, "rejection": rejection, "cancelled": cancelled, "release": released,
            "promoted": promoted, "completion": result, "drained": mixed.wait_drained(base)}


def share(base, short, long, solo):
    a = submit(base, short)
    for _ in range(12):
        advance(base)
        if snapshot(base, a)["output_len"]:
            break
    else:
        raise AssertionError("Short context did not enter decode")
    b = submit(base, long)
    shared, short_live, long_live = advance(base), snapshot(base, a), snapshot(base, b)
    assert shared["scheduled_requests"] == 2 and shared["scheduled_tokens"] == 513
    assert short_live["output_len"] > 1 and long_live["processed_prompt_tokens"] == 512
    completions = finish(base, a, b)
    assert [row["output_tokens"] for row in completions] == [solo[short.id], solo[long.id]]
    return {"shared": shared, "short_live": short_live, "long_live": long_live,
            "completion": completions, "drained": mixed.wait_drained(base)}


def main():
    cli = ArgumentParser(description=__doc__)
    for field in ("binary", "pack", "link-root", "out"):
        cli.add_argument(f"--{field}", type=Path)
    cli.add_argument("--check-inputs", action="store_true")
    args = cli.parse_args()
    first, second = frozen.inputs()
    short = next(row for row in mixed.bench.load_corpus(ROOT / "mixed-corpus.jsonl") if len(row.input_tokens) == 512)
    assert short.max_output_tokens == first.max_output_tokens == second.max_output_tokens == 96
    if args.check_inputs:
        print("Verified two distinct 8,192-token prompts and a 512-token prompt from the frozen workload.")
        return
    build = json.loads((ROOT / "build.json").read_bytes())
    inventory = json.loads((ROOT / "mxfp4-inventory.json").read_bytes())
    software = json.loads((ROOT / "candidate-software-receipt.json").read_bytes())
    assert mixed.digest(args.binary) == build["server_sha256"] and build["codesign_verified"]
    assert build["source_base"] == software["original_source_base"]
    assert build["patch_sha256"] == software["signed_runtime_patch_sha256"] == mixed.digest(ROOT / "source.patch")
    manifest = mixed.native.validate_inventory(args.pack, inventory, args.link_root)
    assert manifest["model-manifest.json"] == frozen.MANIFEST
    args.out.mkdir()
    options = ("--disable-ngram-acceleration", "--total-blocks", "2048", "--max-batch-tokens", "2049",
               *mixed.RESERVE_OPTIONS)
    idle = [mixed.native.wait_for_quiet()["cpu_idle_percent"]]
    with mixed.server(args, LABEL, mixed.MODEL, args.pack, 2, env=ENV, options=options,
                      stream_experts="auto", guard=True) as (base, _):
        solo = {}
        for prompt in (short, second):
            (result,) = finish(base, submit(base, prompt))
            solo[prompt.id] = result["output_tokens"]
            mixed.wait_drained(base)
        deferred = queued(base, first, second, solo, args.out / "partial-wait.json")
        overlap = share(base, short, second, solo)
        assert request(base, "/health")["status"] == "ok"
    idle.append(mixed.native.cpu_idle_percent())
    log = args.out / f"{LABEL}.log"
    text = log.read_text()
    assert "decision=resident" in text and "reader=Mapped" in text
    for old, new in ((str(args.pack), "[pack]"), (str(ROOT), "[run]"),
                     (str(Path.home()), "[home]"), ("127.0.0.1", "[loopback]")):
        text = text.replace(old, new)
    log.write_text(text)
    samples = [json.loads(row) for row in (args.out / f"{LABEL}-samples.jsonl").read_text().splitlines()]
    assert samples and {row["pressure"] for row in samples} == {1}
    assert mixed.native.validate_inventory(args.pack, inventory, args.link_root) == manifest
    def sysctl(name):
        return subprocess.check_output(["/usr/sbin/sysctl", "-n", name], text=True).strip()

    chip = sysctl("machdep.cpu.brand_string")
    hardware = {"form_factor": {"Apple M2 Ultra": "Mac Studio", "Apple M5 Max": "MacBook Pro"}[chip],
                "soc": chip, "memory_bytes": int(sysctl("hw.memsize")),
                "os": subprocess.check_output(["/usr/bin/sw_vers", "-productVersion"], text=True).strip()}
    record = {"scope": "Explicit two-slot physical-prefill pair admission", "qualification": False,
              "build": build, "candidate": software, "hardware": hardware,
              "manifest": manifest, "revision": inventory["revision"], "flags": ENV,
              "case_ids": [first.id, second.id, short.id], "solo": solo, "queue": deferred,
              "shared": overlap, "matching_output_ids": 288, "cpu_idle_percent": idle,
              "normal_pressure_samples": len(samples)}
    (args.out / "receipt.json").write_text(json.dumps(record, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
