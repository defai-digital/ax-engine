#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
fresh=$1
reference=$2
functional=$3
readonly python="$HOME/.venvs/ax-engine/bin/python"
readonly ref_python="$HOME/build/flash-next-official-20260923/launch-reference-env/bin/python"
readonly slot="$HOME/build/.ax-flash-next-native-test-slot"
export PATH="$HOME/.venvs/ax-engine/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
owned=0
release_slot() {
    if (( owned )) && test "$(cat "$slot/owner.pid" 2>/dev/null)" = "$$"; then
        rm "$slot/owner.pid"
        rmdir "$slot"
    fi
    owned=0
}
finish() { code=$?; release_slot; printf '%s\n' "$code" > status.txt; }
trap finish EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
/usr/bin/shasum -a 256 -c inputs.sha256 >/dev/null
/usr/bin/codesign --verify --strict ax-engine-server
cmp build.json "$functional/build.json"
test "$(cat "$functional/status.txt")" = 0
test -s "$functional/observed/receipt.json"
test "$(cat "$fresh/status.txt")" = 0
test "$(/usr/sbin/sysctl -n hw.model hw.memsize)" = "$(printf 'Mac17,6\n137438953472')"
lib=$("$python" -B -c 'from importlib.metadata import distribution,version; assert version("mlx")==version("mlx-metal")=="0.32.4"; print(distribution("mlx").locate_file("mlx/lib"))')
expected=$("$python" -B -c 'import json; print(json.load(open("build.json"))["libmlx_sha256"])')
test "$(shasum -a 256 "$lib/libmlx.dylib" | awk '{print $1}')" = "$expected"
cache="$fresh/fresh-cache"
pack="$cache/models--AutomatosX--AX-Qwen3.8-Flash-Next-MLX-AXQ-MXFP4-MTP/snapshots/ff2a28485eb89bb60e8fe35dd6c65c51e63ee7b3"
readonly deadline=$((SECONDS + 54000))
acquire() {
    local arm=$1
    while (( SECONDS < deadline )); do
        if test "$(/usr/sbin/sysctl -n kern.memorystatus_vm_pressure_level)" = 1 && mkdir "$slot" 2>/dev/null; then
            printf '%s\n' "$$" > "$slot/owner.pid"
            owned=1
            if ! /bin/ps -axo comm= | /usr/bin/grep -Eq '/(ax-engine-server[^/]*|mtp-audit|direct_weights|ax-flash-shared-load-test|ax-ple-reader-test)$'; then
                if test -s "$reference/status.txt"; then return; fi
                if ! test -s "$reference/headroom.jsonl"; then
                    (cd "$reference" && "$ref_python" -B recover.py --preflight) > "capacity-$arm.json"
                    if "$python" -B - "capacity-$arm.json" <<'PY'
import json,sys
with open(sys.argv[1]) as f:
    record = json.load(f)["capacity"]
sys.exit(not (record["reason"] == "background-rss-exceeds-signed-margin" and record["pressure"] == 1
              and record["eligible_for_attempt"] is False))
PY
                    then return; fi
                fi
            fi
            release_slot
        fi
        sleep 30
    done
    return 75
}
mkdir observed
for arm in single-first paired-first paired-second single-second; do
    acquire "$arm"
    printf '%s starting\n' "$arm"
    /usr/bin/caffeinate -dimsu /usr/bin/env -i HOME="$HOME" PATH="$PATH" DYLD_LIBRARY_PATH="$lib" PYTHONDONTWRITEBYTECODE=1 \
        "$python" -B -u run_pair_natural.py --arm "$arm" --binary "$PWD/ax-engine-server" \
        --pack "$pack" --link-root "$cache" --out "$PWD/observed/$arm"
    test -s "observed/$arm/receipt.json"
    printf '%s complete\n' "$arm"
    release_slot
done
/usr/bin/shasum -a 256 -c inputs.sha256 >/dev/null
