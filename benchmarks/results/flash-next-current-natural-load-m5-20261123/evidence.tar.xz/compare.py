"""Compare both ordered natural-load pairs from their original measured rows."""
from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "bundle"))
import run_pair_natural as campaign


def read(path):
    return json.loads(path.read_bytes())


def delta(base, treatment):
    metrics = dict(throughput_ratio=treatment["delivered_tokens_per_second"] / base["delivered_tokens_per_second"])
    for length in ("512", "2048", "8192"):
        old, new = (case["by_prompt_tokens"][length] for case in (base, treatment))
        metrics[length] = {field + "_p95_ratio": new[field]["p95"] / old[field]["p95"]
                           for field in ("arrival_to_first_token_ms", "arrival_to_completion_ms", "client_ttft_ms",
                                         "per_request_gap_p95_ms", "per_request_gap_max_ms")}
    return metrics


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("capture", type=Path)
    args = cli.parse_args()
    cohort, prompts, oracle = campaign.inputs()
    assert (args.capture / "status.txt").read_bytes() == b"0\n"
    build = read(args.capture / "build.json")
    dossier = {}
    for arm, lanes in campaign.ARMS.items():
        path = args.capture / "observed" / arm
        receipt = read(path / "receipt.json")
        assert receipt["lanes"] == lanes and receipt["arm"] == arm and receipt["build"] == build
        assert receipt["qualification"] is False and not any(receipt["drained"].values())
        assert receipt["flags"]["AX_MLX_FLASH_NEXT_ALIGNED_BUFFERED"] == "0"
        summary = campaign.examine(arm, read(path / f"{arm}.json"), read(path / f"{arm}-steps.json"), prompts, oracle)
        assert summary == receipt["summary"]
        samples = [json.loads(line) for line in (path / f"{arm}-samples.jsonl").read_text().splitlines()]
        assert len(samples) == receipt["normal_pressure_samples"] > 0
        assert all(row["pressure"] == 1 for row in samples)
        assert max(row["footprint_bytes"] for row in samples) == receipt["max_footprint_bytes"] <= 96 << 30
        idle = receipt["cpu_idle_percent"]
        assert len(idle) == 2 and all(0 <= value <= 100 for value in idle)
        eligible = all(value >= 90 for value in idle)
        assert eligible == receipt["timing_eligible"]
        dossier[arm] = {"timing_eligible": eligible, "idle_percent": idle, "summary": summary,
                         "normal_pressure_samples": len(samples), "max_footprint_bytes": receipt["max_footprint_bytes"]}
    comparisons = {}
    for label in ("first", "second"):
        control, paired = (dossier[f"{kind}-{label}"] for kind in ("single", "paired"))
        eligible = control["timing_eligible"] and paired["timing_eligible"]
        comparisons[label] = {"timing_eligible": eligible,
                              "observed_8192_with_short_peer": paired["summary"]["observed_8192_with_short_peer"]}
        if eligible:
            comparisons[label]["two_slots_over_one_slot"] = delta(control["summary"], paired["summary"])
    print(json.dumps({"scope":"Experimental natural offered-load comparison", "qualification":False,
                      "server_sha256": build["server_sha256"], "corpus_sha256": sha256(cohort.read_bytes()).hexdigest(),
                      "arms": dossier, "comparison": comparisons}, sort_keys=True, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
