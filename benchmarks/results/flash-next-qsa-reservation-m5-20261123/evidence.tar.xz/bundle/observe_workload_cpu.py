"""Recompute CPU idle from passive Darwin ticks during the natural-load client."""

import ctypes
import json
import time

CPU_LOAD_INFO = 3
CPU_STATES = ("user", "system", "idle", "nice")
UINT32_MASK = (1 << 32) - 1


def clock_ticks():
    library = ctypes.CDLL(None)
    library.mach_host_self.argtypes = ()
    library.mach_host_self.restype = ctypes.c_uint
    library.host_statistics.argtypes = (ctypes.c_uint, ctypes.c_int,
                                        ctypes.POINTER(ctypes.c_uint),
                                        ctypes.POINTER(ctypes.c_uint))
    library.host_statistics.restype = ctypes.c_int
    host = library.mach_host_self()

    def sample():
        ticks = (ctypes.c_uint * len(CPU_STATES))()
        count = ctypes.c_uint(len(ticks))
        error = library.host_statistics(host, CPU_LOAD_INFO, ticks, ctypes.byref(count))
        if error or count.value != len(ticks):
            raise RuntimeError(f"Unexpected HOST_CPU_LOAD_INFO result ({error}, {count.value})")
        return dict(zip(CPU_STATES, ticks, strict=True))

    return sample


def tick_delta(before, after):
    return {state: (after[state] - before[state]) & UINT32_MASK for state in CPU_STATES}


class WorkloadCpu:
    def __init__(self, output):
        self.output = output
        self.read_ticks = clock_ticks()
        self.previous = None

    def sample(self, *, force=False):
        now = time.monotonic()
        if not force and self.previous is not None and now - self.previous < 5:
            return
        row = {"monotonic_seconds": now, "ticks": self.read_ticks()}
        self.output.write(json.dumps(row, allow_nan=False) + "\n")
        self.previous = now


def summarize(path):
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    assert len(rows) >= 2
    for row in rows:
        assert set(row["ticks"]) == set(CPU_STATES)
        assert all(0 <= count <= UINT32_MASK for count in row["ticks"].values())
    duration, idle_ticks, total_ticks, intervals, below_floor = 0.0, 0, 0, 0, 0
    for previous, current in zip(rows, rows[1:]):
        elapsed = current["monotonic_seconds"] - previous["monotonic_seconds"]
        assert elapsed > 0
        duration += elapsed
        delta = tick_delta(previous["ticks"], current["ticks"])
        total = sum(delta.values())
        if total == 0:
            continue
        idle_ticks += delta["idle"]
        total_ticks += total
        intervals += 1
        if 100 * delta["idle"] < 90 * total:
            below_floor += 1
    assert total_ticks > 0
    return {
        "client_window_seconds": duration,
        "idle_percent": 100 * idle_ticks / total_ticks,
        "sampled_intervals": intervals,
        "intervals_below_90_percent": below_floor,
    }
