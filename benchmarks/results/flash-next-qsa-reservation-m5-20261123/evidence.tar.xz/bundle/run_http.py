"""Measure routed QSA K/V gather engagement and single-request serving timing."""

from argparse import ArgumentParser
from importlib.metadata import version
import json
from pathlib import Path
from socket import socket
from subprocess import Popen
from threading import Event, Thread
import time

import check_flash_next_native_support as native
import observe_workload_cpu as cpu
import run_flash_next_generate_matrix as matrix
import run_flash_next_lifecycle as lifecycle
import run_flash_next_qa_cohort as qa
from run_qwen38_reference_serving import monitor_memory

HERE = Path(__file__).resolve().parent
TILES = "ax_engine_mlx_flash_next_qsa_paired_gather_tiles_total"
FORWARD = "ax_engine_mlx_prefill_forward_wall_us_total"
SWITCH = "AX_MLX_FLASH_NEXT_QSA_PAIRED_GATHER"
BUDGET = 64
KEYS = (TILES, FORWARD, native.VERIFIED, *native.ERRORS)


def metrics(base):
    values = native.metrics(native.request(base, "/metrics").decode())
    return {key: int(values[key]) for key in KEYS}


def run_request(base, prompt, label, read_cpu, paired, timed):
    before = metrics(base)
    assert all(value == 0 for value in lifecycle.wait_drained(base).values())
    idle_before = native.wait_for_quiet()["cpu_idle_percent"] if timed else None
    start = read_cpu()
    response = matrix.generate(base, prompt, BUDGET, ignore_eos=True)
    end = read_cpu()
    idle_after = native.cpu_idle_percent() if timed else None
    drained = lifecycle.wait_drained(base)
    after = metrics(base)
    delta = {key: after[key] - before[key] for key in KEYS}
    activation = native.check_activation(before, after, False, len(response["output_tokens"]), BUDGET)
    assert not any(activation.values()), activation
    assert response["prompt_tokens"] == prompt and len(response["output_tokens"]) == BUDGET
    assert response["finish_reason"] == "max_output_tokens", response["finish_reason"]
    assert delta[FORWARD] > 0 and all(value == 0 for value in drained.values())
    tiles = delta[TILES]
    assert (tiles > 0 if paired and len(prompt) == 8192 else tiles == 0), (label, tiles)
    ticks = cpu.tick_delta(start, end)
    assert sum(ticks.values()) > 0
    return {
        "prompt": label, "prompt_length": len(prompt), "prompt_sha256": matrix.ids_sha(prompt),
        "output_tokens": response["output_tokens"], "finish_reason": response["finish_reason"],
        "metrics_delta": delta, "resources_after": drained, "client_timing": response["client_timing"],
        "host_ticks_before": start, "host_ticks_after": end,
        "request_host_idle_percent": 100 * ticks["idle"] / sum(ticks.values()),
        "idle_percent_endpoints": [idle_before, idle_after],
    }


def run(args, parsed):
    paired = args.arm.startswith("paired")
    flags = {
        "AX_MLX_PREFIX_CACHE_DISK_DISABLED": "1",
        "AX_ENGINE_PREFIX_REUSE_DISABLED": "1",
        "AX_MLX_PREFIX_CACHE_MAX_BYTES": "0",
        "AX_MLX_PREFIX_CACHE_MAX_ENTRIES": "0",
        "RUST_LOG": "info,ax_engine_mlx::flash_next_startup=debug",
    }
    if paired:
        flags[SWITCH] = "1"
    with socket() as listener:
        listener.bind(("127.0.0.1", 0))
        port = listener.getsockname()[1]
    base = f"http://127.0.0.1:{port}"
    log_path = args.out / "server.log"
    native.wait_for_quiet()
    started = time.monotonic()
    cmd = qa.server_command(HERE / "ax-engine-server", args.pack, "default", port, ordinary_launch=True)
    if not args.measure:
        # The 32K single-slot defaults are specific to the M5 profile.
        cmd.extend(("--total-blocks", "2048", "--max-concurrent-requests", "1"))
    read_cpu = cpu.clock_ticks()
    with log_path.open("w") as log:
        proc = Popen(cmd, stdout=log, stderr=log,
                     env=native.server_env(flags), start_new_session=True)
        stop = Event()
        monitor = Thread(target=monitor_memory, args=(args.out, "server", proc, stop), daemon=True)
        monitor.start()
        try:
            while True:
                if proc.poll() is not None or time.monotonic() - started > qa.READY_TIMEOUT:
                    raise RuntimeError("The owned server did not become ready")
                try:
                    models = json.loads(native.request(base, "/v1/models"))
                    break
                except (OSError, ValueError):
                    time.sleep(1)
            model = qa.check_standard_model(models, qa.ORDINARY_MODEL_ID)
            ready_seconds = time.monotonic() - started
            reference = "long-replay"
            labels = [reference, *parsed] if args.measure else list(parsed)
            if args.measure and args.arm.endswith("second"):
                labels[1:] = reversed(labels[1:])
            with (args.out / "requests.jsonl").open("x") as stream:
                for position, label in enumerate(labels):
                    warmup = args.measure and position == 0
                    row = run_request(base, parsed[label], label, read_cpu, paired,
                                      timed=args.measure and not warmup)
                    print(json.dumps({"warmup": warmup, **row}), file=stream, flush=True)
                    print(label, row["metrics_delta"][TILES], row["client_timing"]["ttft_seconds"], flush=True)
        finally:
            stop.set()
            monitor.join()
            native.stop_owned(proc)
    messages = log_path.read_text(errors="replace")
    assert "failed to warm up; using stock gather" not in messages
    pressure = [json.loads(line) for line in (args.out / "server-samples.jsonl").read_text().splitlines()]
    assert pressure and all(row["pressure"] == 1 for row in pressure)
    native.scrub_log(log_path)
    return {"mode": args.arm, "flags": flags, "model": model, "ready_seconds": ready_seconds,
            "pressure_samples": len(pressure), "peak_rss_bytes": max(row["rss_bytes"] for row in pressure),
            "peak_footprint_bytes": max(row["footprint_bytes"] for row in pressure)}


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--arm", choices=("stock-first", "paired-first", "paired-second", "stock-second"),
                     required=True)
    cli.add_argument("--pack", required=True, type=Path)
    cli.add_argument("--link-root", type=Path)
    cli.add_argument("--out", required=True, type=Path)
    cli.add_argument("--measure", action="store_true")
    args = cli.parse_args()
    assert version("mlx") == version("mlx-metal") == "0.32.4"
    build = json.loads((HERE / "build.json").read_bytes())
    assert build["binary_sha256"] == native.sha256(HERE / "ax-engine-server")
    assert build["patch_sha256"] == native.sha256(HERE / "source.patch")
    inventory = json.loads((HERE / "mxfp4-inventory.json").read_bytes())
    verified = native.validate_inventory(args.pack, inventory, args.link_root)
    assert len(inventory["members"]) == 49
    assert verified["model-manifest.json"] == (
        "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef")
    prompts = json.loads((HERE / "prompts.json").read_bytes())
    args.out.mkdir()
    result = run(args, prompts)
    assert native.validate_inventory(args.pack, inventory, args.link_root) == verified
    result.update({"build": build, "pack_sha256": verified, "qualification": False,
                   "input_sha256": native.sha256(HERE / "prompts.json"),
                   "requests_sha256": native.sha256(args.out / "requests.jsonl")})
    (args.out / "receipt.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
