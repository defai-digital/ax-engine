#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
test "$(/usr/sbin/sysctl -n machdep.cpu.brand_string)" = 'Apple M2 Ultra'
test "$(/usr/sbin/sysctl -n hw.memsize kern.memorystatus_vm_pressure_level)" = "$(printf '206158430208\n1')"
slot="$HOME/build/.ax-flash-next-native-test-slot"
mkdir "$slot" || { printf '74\n' > status.txt; exit 74; }
printf '%s\n' "$$" > "$slot/owner.pid"

release() {
    code=$?
    if test "$(cat "$slot/owner.pid")" = "$$"; then
        rm "$slot/owner.pid"
        rmdir "$slot"
    fi
    printf '%s\n' "$code" > status.txt
}
trap release EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM

if ps -axo comm= | grep -Eq '/(ax-engine-server[^/]*|mtp-audit|direct_weights|ax-flash-.*-test)$'; then exit 74; fi
shasum -a 256 -c inputs.sha256 >/dev/null
codesign --verify --strict ax-engine-server
python="$HOME/code/ax-engine/.venv/bin/python"
lib=$("$python" -B -c 'from importlib.metadata import distribution,version; assert version("mlx")==version("mlx-metal")=="0.32.4"; print(distribution("mlx").locate_file("mlx/lib"))')
expected=$("$python" -B -c 'import json; print(json.load(open("build.json"))["libmlx_sha256"])')
test "$(shasum -a 256 "$lib/libmlx.dylib" | awk '{print $1}')" = "$expected"
pack=$(mktemp -d "$HOME/models/.ax-flash-required-sampling.XXXXXXXX")
"$python" -B - "$HOME/models/ax-engine-flash-next-mxfp4-ff2a2848" "$pack" <<'PY'
from pathlib import Path
import json, os, shutil, sys
source, destination = map(Path, sys.argv[1:])
source = source.resolve(strict=True)
rows = json.loads(Path("mxfp4-inventory.json").read_bytes())["members"]
assert len(rows) == 49
for row in rows:
    relative = Path(row["name"])
    assert not relative.is_absolute() and ".." not in relative.parts
    member = (source / relative).resolve(strict=True)
    assert member.is_relative_to(source) and member.stat().st_size == row["size"]
    target = destination / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    os.link(member, target)
shutil.copy2("model-manifest.json", destination / "model-manifest.json")
PY
for mode in required disabled; do
    printf '%s starting\n' "$mode"
    /usr/bin/caffeinate -i /usr/bin/env -i HOME="$HOME" PATH=/usr/bin:/bin:/usr/sbin:/sbin \
        DYLD_LIBRARY_PATH="$lib" PYTHONDONTWRITEBYTECODE=1 "$python" -B -u run_sampling_controls.py \
        --mode "$mode" --binary "$PWD/ax-engine-server" --pack "$pack" --out "$PWD/$mode"
    test "$(/usr/sbin/sysctl -n kern.memorystatus_vm_pressure_level)" = 1
    printf '%s complete\n' "$mode"
done
shasum -a 256 -c inputs.sha256 >/dev/null
