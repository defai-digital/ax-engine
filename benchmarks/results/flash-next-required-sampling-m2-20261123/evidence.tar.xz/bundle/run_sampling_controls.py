"""Check Flash Next sampling and greedy MTP isolation through native SSE."""

from argparse import ArgumentParser
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import time

from bench_ax_serving import parse_sse_text
import check_flash_next_native_support as native
import run_qwen38_reference_serving as serving


ROOT = Path(__file__).resolve().parent
SERVER = "c1a7c3f9dfb81613fc370758a0eece5f6105683d53baab7ea4bc3a371cb81de2"
MODEL = "qwen3.8-flash-next:axq"
FALLBACK = "ax_engine_flash_next_mtp_direct_fallback_not_strict_greedy_total"
VERIFIED = native.VERIFIED
KEYS = (VERIFIED, FALLBACK, *native.ERRORS)
DRAINED = (
    "ax_engine_jobs_in_flight",
    "ax_engine_generation_jobs_pending",
    "ax_engine_generation_commands_queued",
    "ax_engine_generation_active_streams",
    "ax_engine_generation_buffered_stream_events",
)
BUDGET = 64
BASE = {"temperature": 0.0, "ignore_eos": True, "top_p": 1.0, "top_k": 0, "repetition_penalty": 1.0}
RANDOM = {**BASE, "temperature": 0.9, "top_p": 0.95, "top_k": 30, "seed_explicit": True}
CASES = {
    "greedy-before": BASE,
    "seed-a": {**RANDOM, "seed": 1729},
    "seed-b": {**RANDOM, "seed": 1730},
    "seed-a-repeat": {**RANDOM, "seed": 1729},
    "penalized-greedy": {**BASE, "repetition_penalty": 1.2},
    "greedy-after": BASE,
}


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def prompt():
    path = ROOT / "mixed-corpus.jsonl"
    assert digest(path) == "2c0c205d803207df6316dbd0076eef97451a55c80c0413fdc6b3bee5ffef7e9a"
    target, = (row for row in map(json.loads, path.read_text().splitlines()) if row["id"] == "mixed-004")
    ids = target["input_tokens"]
    assert len(ids) == 512
    return ids


def get_metrics(base):
    return native.metrics(native.request(base, "/metrics").decode())


def wait_drained(base):
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        counters = get_metrics(base)
        if all(counters.get(key) == 0 for key in DRAINED):
            return counters
        time.sleep(0.25)
    raise RuntimeError("The controlled request did not drain all resource counters")


def stream(base, ids, sampling):
    raw = native.request(base, "/v1/generate/stream", {
        "model": MODEL, "input_tokens": ids, "max_output_tokens": BUDGET, "sampling": sampling,
    })
    frames = parse_sse_text(raw.decode())
    assert frames and frames[0][0] == "request" and frames[-1][0] == "response"
    tokens = []
    responses = []
    acknowledgments = []
    for name, body in frames:
        assert name in {"request", "step", "response"}, name
        event = json.loads(body)
        if "request" in event:
            acknowledgments.append(event["request"]["request_id"])
        tokens.extend(event.get("delta_tokens", []))
        if name == "response":
            responses.append(event["response"])
    final, = responses
    assert acknowledgments and set(acknowledgments) == {final["request_id"]}
    assert final["model_id"] == MODEL and final["prompt_tokens"] == ids
    assert final["status"] == "finished" and final["finish_reason"] == "max_output_tokens"
    assert tokens == final["output_tokens"] and len(tokens) == BUDGET
    return {"output_ids": tokens, "terminal_reason": final["finish_reason"],
            "route": final["route"].get("crossover_decisions", {})}


def check_rows(rows, mode, *, enforce):
    assert [row["case"] for row in rows] == list(CASES)
    outputs = {}
    for row in rows:
        case = row["case"]
        assert row["sampling"] == CASES[case] and len(row["output_ids"]) == BUDGET
        assert row["terminal_reason"] == "max_output_tokens"
        assert set(row["drained"]) == set(DRAINED) and not any(row["drained"].values())
        assert set(row["counters"]) == set(KEYS) and all(value >= 0 for value in row["counters"].values())
        assert all(row["counters"][key] == 0 for key in native.ERRORS)
        if enforce:
            drafted = mode == "required" and case.startswith("greedy-")
            assert (row["counters"][VERIFIED] > 0) is drafted, (mode,case,row["counters"])
            sampled = mode == "required" and not case.startswith("greedy-")
            assert (row["counters"][FALLBACK] > 0) is sampled, (mode,case,row["counters"])
        outputs[case] = row["output_ids"]
    if enforce:
        assert outputs["greedy-before"] == outputs["greedy-after"]
        assert outputs["seed-a"] == outputs["seed-a-repeat"]
        assert outputs["seed-a"] != outputs["seed-b"]
    return outputs


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--mode", choices=("disabled", "required"))
    for flag in ("binary", "pack", "out"):
        cli.add_argument(f"--{flag}", type=Path)
    cli.add_argument("--check-inputs", action="store_true")
    args = cli.parse_args()
    ids = prompt()
    build = read(ROOT / "build.json")
    assert build["codesign_verified"] and build["server_sha256"] == SERVER
    assert digest(ROOT / "source.patch") == build["patch_sha256"]
    if args.check_inputs:
        print(f"Bound {len(ids)} input tokens and {len(CASES)} sampling cases for both policies.")
        return
    assert digest(args.binary) == SERVER
    inventory = read(ROOT / "mxfp4-inventory.json")
    manifest = native.validate_inventory(args.pack, inventory)
    assert manifest == {"model-manifest.json": digest(ROOT / "model-manifest.json")}
    args.out.mkdir()
    rows = []
    env = {"AX_FLASH_NEXT_MTP_COST": "0", "RUST_LOG": "info,ax_engine_mlx::flash_next_startup=debug"}
    with serving.server(args, args.mode, MODEL, args.pack, 1, env=env, guard=True, mtp=args.mode,
                        prefill_chunk=2048, options=("--total-blocks", "2048", "--disable-ngram-acceleration")) as (base, pid):
        mapped = subprocess.check_output(["/usr/sbin/lsof", "-a", "-p", str(pid), "-d", "txt", "-Fn"], text=True)
        libraries = [Path(line[1:]) for line in mapped.splitlines()
                     if line.startswith("n") and line.endswith("/libmlx.dylib")]
        library, = libraries
        assert digest(library) == build["libmlx_sha256"]
        for name, config in CASES.items():
            before = wait_drained(base)
            result = stream(base, ids, config)
            after = wait_drained(base)
            row = {
                "case": name, "sampling": config, **result,
                "drained": {key: after[key] for key in DRAINED},
                "counters": {key: after[key] - before[key] for key in KEYS},
            }
            rows.append(row)
            with (args.out / "cases.jsonl").open("a") as output:
                output.write(json.dumps(row, allow_nan=False) + "\n")
            print(f"{args.mode} {name} completed", flush=True)
        assert json.loads(native.request(base, "/health"))["status"] == "ok"
    log = args.out / f"{args.mode}.log"
    text = log.read_text()
    resident = [line for line in text.splitlines() if "Flash Next resident reader" in line]
    assert len(resident) == 1 and "reader=Mapped" in resident[0]
    for old, new in ((str(args.pack), "[pack]"), (str(ROOT), "[run]"), (str(Path.home()), "[home]"),
                     ("127.0.0.1", "[loopback]")):
        text = text.replace(old, new)
    log.write_text(text)
    samples = [json.loads(line) for line in (args.out / f"{args.mode}-samples.jsonl").read_text().splitlines()]
    assert samples and all(row["pressure"] == 1 and row["footprint_bytes"] <= 96 << 30 for row in samples)
    assert native.validate_inventory(args.pack, inventory) == manifest
    check_rows(rows, args.mode, enforce=True)
    result = {"mode": args.mode, "qualification": False, "server_sha256": SERVER,
              "manifest": manifest, "normal_pressure_samples": len(samples),
              "max_footprint_bytes": max(row["footprint_bytes"] for row in samples)}
    (args.out / "receipt.json").write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
