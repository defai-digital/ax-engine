"""Replay the two native Flash Next sampling-policy controls."""

from argparse import ArgumentParser
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "bundle"))
import run_sampling_controls as test


def comparison(capture):
    assert (capture / "status.txt").read_bytes() == b"0\n"
    build = test.read(capture / "build.json")
    assert build == test.read(test.ROOT / "build.json") and build["server_sha256"] == test.SERVER
    assert test.digest(test.ROOT / "source.patch") == build["patch_sha256"]
    assert (capture / "inputs.sha256").read_bytes() == (test.ROOT / "inputs.sha256").read_bytes()
    manifest = {"model-manifest.json": test.digest(test.ROOT / "model-manifest.json")}
    output = {}
    arms = {}
    for mode in ("disabled", "required"):
        source = capture / mode
        receipt = test.read(source / "receipt.json")
        assert receipt["mode"] == mode and receipt["server_sha256"] == test.SERVER
        assert receipt["qualification"] is False and receipt["manifest"] == manifest
        rows = [json.loads(row) for row in (source / "cases.jsonl").read_text().splitlines()]
        output[mode] = test.check_rows(rows, mode, enforce=True)
        pressure = [json.loads(row) for row in (source / f"{mode}-samples.jsonl").read_text().splitlines()]
        assert len(pressure) == receipt["normal_pressure_samples"] > 0
        assert all(row["pressure"] == 1 for row in pressure)
        assert max(row["footprint_bytes"] for row in pressure) == receipt["max_footprint_bytes"] <= 96 << 30
        arms[mode] = {
            "records": {row["case"]: {"verified_steps": row["counters"][test.VERIFIED],
                                      "not_strict_greedy": row["counters"][test.FALLBACK]}
                        for row in rows},
            "normal_pressure_samples": len(pressure),
            "max_footprint_bytes": receipt["max_footprint_bytes"],
        }

    differences = {}
    for case in test.CASES:
        a, b = output["disabled"][case], output["required"][case]
        indices = [index for index, (left, right) in enumerate(zip(a, b, strict=True)) if left != right]
        if indices:
            differences[case] = {"first_index": indices[0], "tokens_different": len(indices)}
    return {
        "scope": "Native Flash Next SSE sampling fallback and greedy request isolation",
        "qualification": False, "server_sha256": test.SERVER, "cases": len(test.CASES),
        "verified_output_positions_per_arm": len(test.CASES) * test.BUDGET,
        "same_mode_seed_replay": True, "different_seed_result": True,
        "cross_policy_differences": differences, "arms": arms,
    }


if __name__ == "__main__":
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("capture", type=Path)
    args = cli.parse_args()
    print(json.dumps(comparison(args.capture), indent=2, sort_keys=True, allow_nan=False))
