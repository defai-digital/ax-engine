"""Exercise mixed admission through the OpenAI-compatible streaming API."""
from argparse import ArgumentParser
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
from threading import Event
from time import monotonic, sleep
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import run_selective_mixed as mixed

ROOT = Path(__file__).resolve().parent
CORPUS = "2c0c205d803207df6316dbd0076eef97451a55c80c0413fdc6b3bee5ffef7e9a"
MANIFEST = "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef"
COMMIT = "8cb06414cc4dc3bf5d3b2de24a3f6182435fa3ca"
JOBS, STREAMS = mixed.COUNTERS[0], mixed.COUNTERS[3]
WAITING = "ax_engine_step_waiting_requests"
SCHEDULED = "ax_engine_step_scheduled_requests"
STEPS = "ax_engine_steps_total"
METRICS = (JOBS, STREAMS, WAITING, SCHEDULED, STEPS)
COMPLETIONS = "/v1/completions"
CHAT = "/v1/chat/completions"


def require(valid, message):
    if not valid:
        raise ValueError(message)


def inputs():
    corpus = ROOT / "mixed-corpus.jsonl"
    require(mixed.digest(corpus) == CORPUS, "The frozen prompts changed")
    rows = mixed.bench.load_corpus(corpus)
    large = [row for row in rows if len(row.input_tokens) == 8192]
    first, second = large[0], large[2]
    require(first.id != second.id and first.max_output_tokens == second.max_output_tokens == 96,
            "The original large-prompt cases changed")
    return first, second


def completion(case):
    return {"model": mixed.MODEL, "prompt": case.input_tokens, "max_tokens": case.max_output_tokens,
            "temperature": 0, "ignore_eos": True, "stream": True, "stream_options": {"include_usage": True}}


def chat():
    return {"model": mixed.MODEL, "messages": [{"role": "user", "content": "Count from 1 to 12. Only numbers."}],
            "temperature": 0, "max_tokens": 32, "stream": True, "stream_options": {"include_usage": True},
            "chat_template_kwargs": {"enable_thinking": False}}


def open_stream(base, route, payload):
    request = Request(base + route, data=json.dumps(payload).encode(),
                      headers={"Content-Type": "application/json"})
    return urlopen(request, timeout=180)


def events(response):
    for line in response:
        if not line.startswith(b"data:"):
            continue
        data = line[5:].strip()
        if data == b"[DONE]":
            yield None
        else:
            item = json.loads(data)
            require("error" not in item and "id" in item, "Invalid OpenAI SSE event")
            yield item


def text_fragment(choice):
    return choice.get("text", (choice.get("delta") or {}).get("content")) or ""


def completed(response, first_token=None):
    text, ends, usage, request_id, done = [], [], [], set(), False
    for item in events(response):
        if item is None:
            require(not done, "Repeated DONE")
            done = True
            continue
        require(not done, "SSE event after DONE")
        request_id.add(item["id"])
        for choice in item["choices"]:
            fragment = text_fragment(choice)
            if fragment and first_token is not None:
                first_token.set()
            text.append(fragment)
            if choice["finish_reason"] is not None:
                ends.append(choice["finish_reason"])
        if item.get("usage") is not None:
            usage.append({k: item["usage"][k] for k in ("prompt_tokens", "completion_tokens", "total_tokens")})
    require(len(request_id) == len(ends) == len(usage) == 1 and done and "".join(text),
            "Incomplete SSE identity, finish, usage, or DONE sequence")
    return {"request_id": next(iter(request_id)), "text": "".join(text),
            "finish_reason": ends[0], "usage": usage[0]}


def normalized(result):
    return {key: result[key] for key in ("text", "finish_reason", "usage")}


def stats(base):
    points = mixed.native.metrics(mixed.native.request(base, "/metrics").decode())
    return {key: points.get(key) for key in METRICS}


def wait_stats(base, check, timeout):
    deadline = monotonic() + timeout
    while monotonic() < deadline:
        snap = stats(base)
        if check(snap):
            return snap
        sleep(0.025)
    raise ValueError(f"Timed out waiting for the observed scheduling state {snap}")


def burst(base, cases, baseline, progress):
    first, second = cases
    first_text, release, second_headers, second_text = (Event() for _ in range(4))

    def victim():
        with open_stream(base, COMPLETIONS, completion(first)) as response:
            for item in events(response):
                if item is not None and any(text_fragment(x) for x in item["choices"]):
                    first_text.set()
                    require(release.wait(10), "The active client did not receive the disconnect signal")
                    return {"request_id": item["id"], "closed_after_first_content_event": True}
        raise ValueError("The first client emitted no text before disconnect")

    def survivor():
        with open_stream(base, COMPLETIONS, completion(second)) as response:
            second_headers.set()
            return completed(response, second_text)

    with ThreadPoolExecutor(max_workers=2) as executor:
        victim_future = executor.submit(victim)
        try:
            require(first_text.wait(100), "The first stream did not begin")
            original = wait_stats(base, lambda x: x[JOBS] == x[STREAMS] == 1, 2)
            remaining = executor.submit(survivor)
            require(second_headers.wait(4), "The second SSE connection did not receive headers")
            queued = wait_stats(base, lambda x: x[JOBS] == x[STREAMS] == 2 and
                                x[WAITING] == x[SCHEDULED] == 1 and x[STEPS] > original[STEPS], 4)
            progress.write_text(json.dumps({"initial": original, "observed_queue": queued}, indent=2) + "\n")
            require(not second_text.is_set(), "The deferred large stream emitted text")
            try:
                with open_stream(base, CHAT, chat()) as unexpected:
                    raise ValueError(f"The third client was admitted with HTTP {unexpected.status}")
            except HTTPError as error:
                with error:
                    blocked = {"status": error.code, "code": json.loads(error.read())["error"]["code"]}
                require(blocked == {"status": 429, "code": "concurrency_limit"}, "Wrong shared admission error")
            require(not second_text.is_set(), "The deferred stream emitted text before cancellation")
            before_disconnect = stats(base)
            require(before_disconnect[JOBS] == before_disconnect[STREAMS] == 2,
                    "The first request already released its slot")
        finally:
            release.set()
        closed = victim_future.result(timeout=15)
        after_disconnect = wait_stats(base, lambda x: x[JOBS] == x[STREAMS] == 1, 20)
        require(not remaining.done(), "The survivor finished before the replacement was submitted")
        with open_stream(base, CHAT, chat()) as response:
            replacement = completed(response)
        surviving = remaining.result(timeout=120)
    require(len({closed["request_id"], surviving["request_id"], replacement["request_id"]}) == 3
            and normalized(surviving) == normalized(baseline["completion"])
            and normalized(replacement) == normalized(baseline["chat"]),
            "The survivor or replacement changed its output, accounting or identity")
    return {"initial": original, "observed_queue": queued, "before_disconnect": before_disconnect,
            "after_disconnect": after_disconnect, "overload": blocked, "disconnected": closed,
            "survivor": surviving, "replacement": replacement, "drained": mixed.wait_drained(base)}


def main():
    parser = ArgumentParser(description=__doc__)
    for field in ("binary", "pack", "out"):
        parser.add_argument(f"--{field}", type=Path)
    parser.add_argument("--check-inputs", action="store_true")
    args = parser.parse_args()
    cases = inputs()
    if args.check_inputs:
        print(f"Frozen OpenAI completion cases {cases[0].id} and {cases[1].id}.")
        return
    build = json.loads((ROOT / "candidate-build.json").read_bytes())
    require(build["runtime_commit"] == COMMIT and build["codesign_verified"] is True
            and mixed.digest(args.binary) == build["server_sha256"], "Guarded release executable changed")
    inventory = json.loads((ROOT / "mxfp4-inventory.json").read_bytes())
    manifest = mixed.native.validate_inventory(args.pack, inventory)
    require(manifest.get("model-manifest.json") == MANIFEST, "The delivered manifest changed")
    args.out.mkdir()
    flags = ("--disable-ngram-acceleration", "--total-blocks", "2048", "--max-batch-tokens", "2049",
             *mixed.RESERVE_OPTIONS)
    env = {"AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0", "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": "1",
           "AX_MLX_FLASH_NEXT_PREFILL_TAIL_DEFERRAL": "0"}
    with mixed.server(args, "openai", mixed.MODEL, args.pack, 2, env=env, options=flags,
                      stream_experts="auto", guard=True) as (base, _):
        require("decision=resident" in (args.out / "openai.log").read_text(), "Resident execution required")
        baseline = {}
        for name, route, payload in (("completion", COMPLETIONS, completion(cases[1])), ("chat", CHAT, chat())):
            with open_stream(base, route, payload) as response:
                baseline[name] = completed(response)
            mixed.wait_drained(base)
        require(baseline["completion"]["finish_reason"] == "length"
                and baseline["completion"]["usage"] == {
                    "prompt_tokens": 8192, "completion_tokens": 96, "total_tokens": 8288,
                }, "The token-prompt completion changed its budget or prompt geometry")
        outcome = burst(base, cases, baseline, args.out / "progress.json")
        require(json.loads(mixed.native.request(base, "/health"))["status"] == "ok", "Health declined")
    samples = [json.loads(line) for line in (args.out / "openai-samples.jsonl").read_text().splitlines()]
    require(samples and {row["pressure"] for row in samples} == {1}, "Memory pressure exceeded normal")
    require(mixed.native.validate_inventory(args.pack, inventory) == manifest, "Publisher bytes changed")
    report = {"qualification": False, "scope": "OpenAI HTTP lifecycle on M2 Ultra 192 GB",
              "build": build, "manifest": manifest, "frozen_case_ids": [case.id for case in cases],
              "baseline": baseline, "result": outcome, "normal_pressure_samples": len(samples)}
    (args.out / "receipt.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
