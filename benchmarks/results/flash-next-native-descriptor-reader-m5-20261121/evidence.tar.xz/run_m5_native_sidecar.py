"""Compare two Flash Next sidecar readers with the ordinary M5 launch."""

import argparse
from concurrent.futures import ThreadPoolExecutor
import ctypes
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import platform
import socket
from statistics import median
import subprocess
import tempfile
from threading import Event
import time
from urllib.error import HTTPError

from run_load_order import cache_state, fresh_clone
from scripts import check_flash_next_native_support as native
from scripts import run_flash_next_generate_matrix as matrix
from scripts.watch_flash_next_reference import CRITICAL_PRESSURE, sample_host


REVISION = 'ff2a28485eb89bb60e8fe35dd6c65c51e63ee7b3'
MODEL_ID = 'qwen3.8-flash-next'
CONTEXT = 32768
COMPLETION_TOKENS = 32
TIMED_LENGTHS = (512, 2048, 8192)
LENGTHS = (*TIMED_LENGTHS, CONTEXT - COMPLETION_TOKENS)
ARMS = [
    ('mmap-1', 'name-order'),
    ('descriptor-1', 'descriptor-lazy'),
    ('descriptor-2', 'descriptor-lazy'),
    ('mmap-2', 'name-order'),
]
EXPECTED_CASE_FIELDS = (
    'prompt_hash', 'prompt_tokens', 'output_tokens', 'finish_reason', 'status',
    'mtp', 'verifier_schedule', 'verified_steps', 'route_errors',
)
STARTUP_TIMEOUT = 1800
MEMORY_GAUGES = {
    'mlx_active_bytes': 'ax_engine_memory_mlx_active_bytes',
    'mlx_cache_bytes': 'ax_engine_memory_mlx_cache_bytes',
    'mlx_peak_bytes': 'ax_engine_memory_mlx_peak_bytes',
    'server_rss_bytes': 'ax_engine_memory_host_resident_bytes',
}


def health(base):
    body = json.loads(native.request(base, '/health'))
    if body.get('status') != 'ok':
        raise RuntimeError('Native server did not report healthy')
    return body['status']


def ordinary_model(base):
    models = json.loads(native.request(base, '/v1/models'))['data']
    if len(models) != 1 or models[0]['id'] != MODEL_ID or models[0]['context_length'] != CONTEXT:
        raise RuntimeError('Expected the inferred Flash Next model with a 32768-token context')
    return {'id': models[0]['id'], 'context_length': models[0]['context_length']}


def verify_overflow(base, prompt):
    try:
        native.request(base, '/v1/completions',
                       {'model': MODEL_ID, 'prompt': prompt, 'max_tokens': COMPLETION_TOKENS + 1,
                        'temperature': 0})
    except HTTPError as error:
        code = json.load(error)['error']['code']
        if error.code == 400 and code == 'context_length_exceeded':
            return {'http_status': error.code, 'error_code': code}
        raise RuntimeError(f'Unexpected boundary response {error.code}, {code}') from error
    raise RuntimeError('The ordinary completions route accepted a 32769-token request')


def choose_ordinary_command(server, root, port):
    return [str(server), '--mlx', '--mlx-model-artifacts-dir', str(root),
            '--host', '127.0.0.1', '--port', str(port)]


def footprint_reader(library):
    function = ctypes.CDLL(str(library)).ax_lab_read_footprint
    pointer = ctypes.POINTER(ctypes.c_uint64)
    function.argtypes = (ctypes.c_int, pointer, pointer)
    function.restype = ctypes.c_int

    def sample(pid):
        physical, lifetime_peak = ctypes.c_uint64(), ctypes.c_uint64()
        error = function(pid, ctypes.byref(physical), ctypes.byref(lifetime_peak))
        if error:
            return {'physical_footprint_sample_errno': error}
        return {
            'physical_footprint_bytes': physical.value,
            'kernel_lifetime_peak_footprint_bytes': lifetime_peak.value,
        }

    return sample


def allocator_sample(metrics):
    return {key: int(metrics[name]) if name in metrics else None
            for key, name in MEMORY_GAUGES.items()}


def sample_live_server(child, began, samples, stop, footprint):
    while not stop.is_set():
        observation = sample_host(child.pid) | footprint(child.pid)
        print(json.dumps(observation | {'elapsed_seconds': time.monotonic() - began}),
              file=samples, flush=True)
        if observation['pressure'] in CRITICAL_PRESSURE:
            child.terminate()
            raise RuntimeError('Critical memory pressure during loader or inference control')
        stop.wait(5)


def boot(args, root, label, mode, ids, output, footprint):
    with socket.socket() as listener:
        listener.bind(('127.0.0.1', 0))
        port = listener.getsockname()[1]
    base = f'http://127.0.0.1:{port}'
    command = choose_ordinary_command(args.server, root, port)
    log_path = args.output / f'{label}.log'
    with (
        log_path.open('x') as log,
        (args.output / f'{label}-samples.jsonl').open('x') as samples,
        ThreadPoolExecutor(max_workers=1) as collector,
    ):
        began = time.monotonic()
        child = subprocess.Popen(command, env=native.server_env({'AX_FLASH_NEXT_SIDECAR_LOAD_LAB': mode}),
                                 stdout=log, stderr=log)
        stop = Event()
        collection = collector.submit(sample_live_server, child, began, samples, stop, footprint)
        try:
            while True:
                if child.poll() is not None:
                    raise RuntimeError(f'Owned native loader exited with {child.returncode}')
                try:
                    output['model'] = ordinary_model(base)
                except OSError:
                    if time.monotonic() - began > STARTUP_TIMEOUT:
                        raise TimeoutError('Native load readiness deadline elapsed')
                    time.sleep(2)
                else:
                    break
            output['ready_seconds'] = time.monotonic() - began
            output['health_ready'] = health(base)
            output['allocator_at_ready'] = allocator_sample(
                native.metrics(native.request(base, '/metrics').decode())
            )
            output['context_overflow'] = verify_overflow(base, ids[-1])
            for run in ids:
                before = native.metrics(native.request(base, '/metrics').decode())
                result = matrix.generate(base, run, max_tokens=COMPLETION_TOKENS, ignore_eos=True)
                after = native.metrics(native.request(base, '/metrics').decode())
                row = matrix.slim(result, before, after)
                if len(row['output_tokens']) != COMPLETION_TOKENS or result['prompt_tokens'] != run:
                    raise RuntimeError(f'Token geometry changed at {len(run)} prompt tokens')
                native.check_activation(before, after, False, COMPLETION_TOKENS, COMPLETION_TOKENS)
                matrix.check_verifier_schedule(row, 'default', 'canonical')
                if row['mtp'].get('available') is not True or row['mtp'].get('active') is not False:
                    raise RuntimeError('Expected an attached inactive MTP sidecar on ordinary launch')
                output['cases'].append({
                    'prompt_hash': matrix.ids_sha(run), **row,
                    'allocator_after_request': allocator_sample(after),
                })
            output['health_after_requests'] = health(base)
            output['process_before_stop'] = footprint(child.pid)
        finally:
            stop.set()
            try:
                collection.result()
            finally:
                native.stop_owned(child)
    observations = [
        json.loads(line)
        for line in (args.output / f'{label}-samples.jsonl').read_text().splitlines()
    ]
    output['peak_sampled_rss_bytes'] = max(
        row['reference_rss_bytes'] for row in observations if 'reference_rss_bytes' in row
    )
    for metric in ('physical_footprint_bytes', 'kernel_lifetime_peak_footprint_bytes'):
        present = [row[metric] for row in (*observations, output['process_before_stop']) if metric in row]
        output[f'max_observed_{metric}'] = max(present, default=None)
    output['pressure_levels'] = sorted({row['pressure'] for row in observations})
    log = log_path.read_text()
    profile = [line for line in log.splitlines()
               if 'resolved the Flash Next M5 Max 128 GB serving profile' in line]
    plan = [line for line in log.splitlines() if 'memory plan: ' in line]
    if not any('context_tokens=32768' in line and 'effective_sequence_cap=Some(1)' in line for line in profile):
        raise RuntimeError('The ordinary launch did not resolve the one-request 32K profile')
    if not any('decision=resident' in line and 'live-sequences=1 ' in line for line in plan):
        raise RuntimeError('The ordinary launch did not keep Flash Next resident')
    output['profile'] = {'effective_sequence_cap': 1, 'expert_residency': 'resident'}
    sidecar = load_phase(log, 'flash_next_sidecar_loader_lab', ('tensor_count', 'elapsed_seconds'))
    if sidecar['loader_mode'] != mode or sidecar['tensor_count'] != 31:
        raise RuntimeError('Unexpected sidecar reader or tensor count in startup')
    output['sidecar'] = sidecar
    output['trunk'] = load_phase(log, 'flash_next_resident_loader_lab',
                                 ('shard_count', 'tensor_count', 'elapsed_seconds'))
    if output['trunk']['shard_count'] != 15 or output['trunk']['tensor_count'] != 1942:
        raise RuntimeError('The startup changed the pinned trunk selection')
    if output['ready_seconds'] < sidecar['elapsed_seconds'] + output['trunk']['elapsed_seconds']:
        raise RuntimeError('Reader phase timings exceed total readiness time')


def load_phase(log, label, fields):
    lines = [line for line in log.splitlines() if label in line]
    if len(lines) != 1:
        raise RuntimeError(f'Expected one {label} observation, got {len(lines)}')
    pieces = dict(token.split('=', 1) for token in lines[0].split() if '=' in token)
    if set(fields) - pieces.keys():
        raise RuntimeError(f'Incomplete {label} observation')
    observation = {name: (float(pieces[name]) if name == 'elapsed_seconds' else int(pieces[name]))
                   for name in fields}
    if label == 'flash_next_sidecar_loader_lab':
        observation['loader_mode'] = pieces.get('loader_mode', '').strip('"')
    return observation


def compare(arms, prior_prefixes):
    ordered = [arms[label] for label, _ in ARMS]
    baseline = ordered[0]
    expected = [[row[key] for key in EXPECTED_CASE_FIELDS] for row in baseline['cases']]
    for (label, mode), arm in zip(ARMS, ordered, strict=True):
        if arm['health_ready'] != 'ok' or arm['health_after_requests'] != 'ok':
            raise RuntimeError(f'{label} reported unhealthy')
        if arm['context_overflow'] != {'http_status': 400, 'error_code': 'context_length_exceeded'}:
            raise RuntimeError(f'{label} changed the ordinary 32K context limit')
        if [row['prompt_tokens'] for row in arm['cases']] != list(LENGTHS):
            raise RuntimeError(f'{label} lacks one or more fixed prompt sizes')
        for row in arm['cases']:
            mtp = row['mtp']
            if (len(row['output_tokens']) != COMPLETION_TOKENS or row['verified_steps'] != 0
                    or row['route_errors'] != 0 or mtp.get('available') is not True
                    or mtp.get('active') is not False):
                raise RuntimeError(f'{label} changed ordinary direct generation or MTP availability')
        for row in arm['cases']:
            prior = prior_prefixes.get(str(row['prompt_tokens']))
            if prior and any(row[field] != prior[field] for field in ('prompt_hash', 'output_tokens')):
                raise RuntimeError(f'{label} disagrees with the prior M5 native output')
        observed = [[row[key] for key in EXPECTED_CASE_FIELDS] for row in arm['cases']]
        if observed != expected:
            raise RuntimeError(f'{label} changed one or more output IDs or route fields')
        if any(arm[key] != baseline[key] for key in ('model', 'profile')):
            raise RuntimeError(f'{label} changed the ordinary launch profile')
        if arm['sidecar']['loader_mode'] != mode or arm['sidecar']['tensor_count'] != 31:
            raise RuntimeError(f'{label} changed the selected sidecar reader or tensors')
        if arm['pressure_levels'] != [1] or not arm['max_observed_kernel_lifetime_peak_footprint_bytes']:
            raise RuntimeError(f'{label} lacks normal-pressure startup and process footprint evidence')

    def measurement(mode):
        rows = [arms[label] for label, reader in ARMS if reader == mode]
        timings = {}
        for length in TIMED_LENGTHS:
            index = LENGTHS.index(length)
            samples = [row['cases'][index]['timing'] for row in rows]
            timings[str(length)] = {
                'median_ttft_seconds': median(item['ttft_seconds'] for item in samples),
                'median_decode_tokens_per_second': median(matrix.decode_rate(item) for item in samples),
            }
        return {
            'ready_seconds': [row['ready_seconds'] for row in rows],
            'sidecar_seconds': [row['sidecar']['elapsed_seconds'] for row in rows],
            'trunk_seconds': [row['trunk']['elapsed_seconds'] for row in rows],
            'peak_sampled_rss_bytes': [row['peak_sampled_rss_bytes'] for row in rows],
            'lifetime_peak_footprint_bytes': [
                row['max_observed_kernel_lifetime_peak_footprint_bytes'] for row in rows
            ],
            'resident_sidecar_pages': [row['sidecar_initial_page_state']['resident_pages'] for row in rows],
            'short_case_timings': timings,
        }

    return {
        'matched_output_ids_per_arm': sum(len(row['output_tokens']) for row in baseline['cases']),
        'prior_native_matched_ids_per_arm': sum(len(row['output_tokens']) for row in prior_prefixes.values()),
        'mmap': measurement('name-order'),
        'descriptor_lazy': measurement('descriptor-lazy'),
    }


def sidecar_page_state(root, selection):
    state = cache_state({**selection, 'path': str(root / 'mtp.safetensors')})
    if (state.get('selected_pages') != 318256 or
            not 0 <= state.get('resident_pages', -1) <= state['selected_pages']):
        raise RuntimeError(f'Unexpected selected sidecar page state: {state}')
    return state


def verified_members(pack, members):
    for member in members:
        file = pack / member['name']
        if file.stat().st_size != member['size'] or native.sha256(file) != member['sha256']:
            raise RuntimeError(f'Publisher file drift: {member["name"]}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('server', 'pack', 'inventory', 'scratch-dir', 'build-receipt', 'output'):
        parser.add_argument('--'+key, type=Path, required=True)
    args = parser.parse_args()
    model_code = subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip()
    assert model_code == 'Mac17,6'
    build = json.loads(args.build_receipt.read_text())
    inventory = json.loads(args.inventory.read_text())
    assert build['server_sha256'] == native.sha256(args.server)
    assert inventory['revision'] == REVISION and len(inventory['members']) == 49
    names = subprocess.check_output(['/bin/ps', '-axo', 'comm='], text=True).splitlines()
    if any(Path(name.strip()).name.startswith('ax-engine-server') for name in names):
        raise RuntimeError('The device has an active server')
    fixture_dir = Path(__file__).resolve().parent
    manifest = fixture_dir / 'model-manifest.json'
    page_plan = fixture_dir / 'sidecar-selection.json'
    prior_path = fixture_dir / 'prior-native-prefixes.json'
    prior = json.loads(prior_path.read_text())
    assert prior['pack_revision'] == REVISION and prior['macos'] == platform.mac_ver()[0]
    assert set(prior['cases']) == {str(length) for length in TIMED_LENGTHS}
    footprint_library = fixture_dir / 'loader_footprint.dylib'
    footprint = footprint_reader(footprint_library)
    selection = json.loads(page_plan.read_text())
    sidecar_selection, = selection['files']
    sidecar, = (member for member in inventory['members'] if member['name'] == 'mtp.safetensors')
    assert selection['revision'] == REVISION and len(sidecar_selection['names']) == 31
    assert selection['expected_sha256'] == sidecar['sha256']
    args.output.mkdir(exist_ok=False)
    started = datetime.now(timezone.utc).isoformat(timespec='seconds')
    record = {'status':'checking-publisher', 'build':build, 'pack_revision':REVISION,
              'hardware':'MacBook Pro M5 Max 128 GB, internal SSD',
              'macos_version': platform.mac_ver()[0],
              'runner_sha256': native.sha256(Path(__file__)),
              'model_manifest_sha256': native.sha256(manifest),
              'inventory_sha256': native.sha256(args.inventory),
              'footprint_probe_sha256': native.sha256(footprint_library),
              'footprint_probe_source_sha256': native.sha256(fixture_dir / 'loader_footprint.c'),
              'sidecar_selection_sha256': native.sha256(page_plan),
              'prior_native_prefixes_sha256': native.sha256(prior_path),
              'libmlx_sha256': native.sha256(Path(os.environ['DYLD_LIBRARY_PATH']) / 'libmlx.dylib'),
              'started':started, 'launch':'ordinary-32k-resident-single-request',
              'case_prompt_lengths':LENGTHS, 'arms':{}}

    def save(status):
        record['status'] = status
        temporary = args.output / 'receipt.tmp'
        temporary.write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
        temporary.replace(args.output / 'receipt.json')
        print(status,flush=True)

    try:
        save('checking-publisher')
        members = [entry['name'] for entry in inventory['members']]
        verified_members(args.pack, inventory['members'])
        vocab = matrix.pack_vocab_size(args.pack)
        ids = [matrix.workload_ids(vocab, size, 0) for size in LENGTHS]
        for label, mode in ARMS:
            with tempfile.TemporaryDirectory(dir=args.scratch_dir) as directory:
                root = Path(directory)
                for name in members:
                    fresh_clone((args.pack/name).resolve(strict=True), root/name)
                (root/'model-manifest.json').write_bytes(manifest.read_bytes())
                quiet = native.wait_for_quiet()
                output = record['arms'][label] = {
                    'cases': [], 'loader_mode': mode, 'quiet_baseline': quiet,
                    'sidecar_initial_page_state': sidecar_page_state(root, sidecar_selection),
                }
                save(label+'-starting')
                boot(args, root, label, mode, ids, output, footprint)
                save(label+'-complete')
        record['diagnostic_comparison'] = compare(record['arms'], prior['cases'])
        save('checking-publisher-after')
        verified_members(args.pack, inventory['members'])
        assert record['model_manifest_sha256'] == native.sha256(manifest)
        save('complete')
    except Exception:
        save('failed')
        raise


if __name__ == '__main__':
    main()
