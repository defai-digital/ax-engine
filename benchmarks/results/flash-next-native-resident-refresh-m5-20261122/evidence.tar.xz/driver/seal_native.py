"""Bind current M5 native controls to the signed Flash Next direct workloads."""
from argparse import ArgumentParser
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ARMS = ("disabled", "default")
PIN = "ff2a28485eb89bb60e8fe35dd6c65c51e63ee7b3"
MANIFEST = "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef"


def read(path):
    return json.loads(path.read_bytes())


def need(valid, message):
    if not valid:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def prompt_rows(folder):
    rows = {}
    for path in sorted(folder.glob("[0-9][0-9][0-9]-*.json")):
        row = read(path)
        stable_usage = tuple(row["usage"][key] for key in ("prompt_tokens", "completion_tokens", "total_tokens"))
        need(row["id"] not in rows, "Duplicate QA case")
        rows[row["id"]] = fingerprint([row["index"], row["id"], row["text"], row["finish_reason"], stable_usage])
    need(len(rows) == 105, "Missing QA cases")
    return rows


def matrix_rows(run):
    payload = {
        "cells": [[c["length"], c["run"], c["warmup"], c["output_tokens"]] for c in run["cells"]],
        "trajectories": [[c["index"], c["output_tokens"]] for c in run["trajectories"]],
        "prompt_id_hashes": run["prompt_id_hashes"],
    }
    need(len(payload["cells"]) == 15 and len(payload["trajectories"]) == 16, "Incomplete matrix workload")
    return fingerprint(payload)


def build_reference(signed):
    matrix = signed / "generate-matrix" / "result.json"
    qa = signed / "qa" / "result.json"
    return {"scope": "Signed v7.9.0 native output controls",
            "inputs_sha256": {"qa_result": digest(qa), "matrix_result": digest(matrix)},
            "qa": {arm: prompt_rows(qa.parent / arm) for arm in ARMS},
            "matrix": {arm: matrix_rows(read(matrix)["runs"][arm]) for arm in ARMS}}


def validate(result, reference):
    build = read(ROOT / "build.json")
    inventory = digest(ROOT / "inventory.json")
    need(build["server_sha256"] == digest(ROOT / "ax-engine-server"), "The tested executable changed")
    rows = {leg: read(result / leg / "result.json")
            for leg in ("native-support", "qa", "lifecycle", "generate-matrix")}
    for name, data in rows.items():
        need(data["revision"] == PIN and data["server_sha256"] == build["server_sha256"]
             and data["inventory_sha256"] == inventory
             and data["hardware"]["soc"] == "Apple M5 Max", f"{name}: identity drift")
    support = rows["native-support"]
    need(support["native_manifest_before"]["model-manifest.json"] == MANIFEST
         and support["native_manifest_before"] == support["native_manifest_after"]
         and support["functional_controls_passed"] and len(support["results"]) == 3
         and all(len(cases) == 7 for cases in support["results"].values())
         and support["negative_control_result"]["activation_error_observed"],
         "Native controls, manifest or activation safety failed")
    need(rows["lifecycle"]["lifecycle_passed"] and len(rows["lifecycle"]["runs"]) == 2,
         "Current native lifecycle did not complete")
    actual_qa = {arm: prompt_rows(result / "qa" / arm) for arm in ARMS}
    actual_matrix = {arm: matrix_rows(rows["generate-matrix"]["runs"][arm]) for arm in ARMS}
    repeats = read(result / "generate-matrix" / "raw-runs.json")
    need(repeats.keys() == reference["matrix"].keys()
         and all(len(repeats[arm]) == 2 and all(matrix_rows(run) == reference["matrix"][arm]
                                              for run in repeats[arm]) for arm in ARMS),
         "At least one independent matrix output differs from the signed native run")
    need(actual_qa == reference["qa"] and actual_matrix == reference["matrix"],
         "Current native QA text, stop states or matrix output changed")
    quiet = {name: [rows[name]["host_quiet"]["cpu_idle_percent"], rows[name]["host_idle_after"]]
             for name in ("qa", "lifecycle", "generate-matrix")}
    return {
        "scope": "Current-source native controls on the resident Flash Next standard",
        "qualification": False,
        "build": build, "pack_revision": PIN, "manifest_sha256": MANIFEST,
        "inventory_sha256": inventory, "reference_control_sha256": digest(ROOT / "signed-native.json"),
        "observed_sha256": {name: digest(result / name / "result.json") for name in rows},
        "native_http_cases": 21, "matched_qa_rows": 210, "matched_independent_matrix_arrays": 124,
        "readiness_seconds": support["readiness_seconds"],
        "quiet_samples": quiet,
        "timing_eligible_legs": [name for name, samples in quiet.items() if all(90 <= n <= 100 for n in samples)],
    }


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--build-reference", type=Path)
    parser.add_argument("--observed", type=Path)
    args = parser.parse_args()
    if args.build_reference:
        record = build_reference(args.build_reference)
    else:
        record = validate(args.observed, read(ROOT / "signed-native.json"))
    print(json.dumps(record, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
