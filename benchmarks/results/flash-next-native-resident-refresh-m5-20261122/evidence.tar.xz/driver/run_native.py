"""Run the unmodified Flash Next native release workloads on a pinned staged view."""
from argparse import ArgumentParser
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from time import monotonic

from run_load_order import fresh_clone
from scripts import check_flash_next_native_support as native
from seal_native import MANIFEST, ROOT


def normal_pressure():
    read = subprocess.check_output(["/usr/sbin/sysctl", "-n", "kern.memorystatus_vm_pressure_level"], text=True)
    if read.strip() != "1":
        raise ValueError("Native acceptance requires normal host memory pressure")


def explicit_skip_control(executable, pack, evidence):
    started = monotonic()
    child = subprocess.run(native.server_command(executable, pack, "required", 0),
                           env=native.server_env({
                               "RUST_LOG": "info,ax_engine_mlx::flash_next_startup=debug",
                               "AX_MLX_SKIP_MTP_SIDECAR": "1",
                           }),
                           check=False, capture_output=True, text=True, timeout=60)
    log = child.stdout + child.stderr
    markers = ('phase="resident_tensors"', 'phase="mtp_sidecar"',
               "MTP admission at runner construction", "wired GPU residency for this session")
    stable = log.replace(str(pack), "[pack]").replace(str(Path.home()), "[home]").replace("127.0.0.1", "[loopback]")
    (evidence / "explicit-skip-output.txt").write_text(stable)
    if child.returncode != 1 or "MlxMtpRequiredButUnavailable" not in log or any(x in log for x in markers):
        raise ValueError("Explicit sidecar bypass did not reject Required MTP before native startup")
    (evidence / "explicit-skip.json").write_text(
        json.dumps({"completed": True, "code": child.returncode,
                    "elapsed_seconds": monotonic() - started, "payload_markers": {x: 0 for x in markers}},
                   indent=2, allow_nan=False) + "\n")


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--cache", type=Path, required=True)
    args = parser.parse_args()
    output = ROOT / "observed"
    output.mkdir()
    inventory_file = ROOT / "inventory.json"
    inventory = json.loads(inventory_file.read_bytes())
    pin = args.cache / "models--AutomatosX--AX-Qwen3.8-Flash-Next-MLX-AXQ-MXFP4-MTP"
    source = pin / "snapshots" / native.PACK_REVISION
    frozen = source / "model-manifest.json"
    if native.sha256(frozen) != MANIFEST or len(inventory["members"]) != 49:
        raise ValueError("The cached snapshot does not carry the frozen qualification manifest")
    exe = ROOT / "ax-engine-server"
    build = json.loads((ROOT / "build.json").read_bytes())
    if native.sha256(exe) != build["server_sha256"]:
        raise ValueError("The staged release-server executable changed")
    normal_pressure()
    native.wait_for_quiet()
    with TemporaryDirectory(prefix="resident-view-", dir=ROOT) as folder:
        pack = Path(folder)
        for member in inventory["members"]:
            blob = (source / member["name"]).resolve(strict=True)
            if not blob.is_relative_to(args.cache.resolve()) or blob.stat().st_size != member["size"]:
                raise ValueError("A cached publisher member escaped its root or size")
            fresh_clone(blob, pack / member["name"])
        (pack / "model-manifest.json").write_bytes(frozen.read_bytes())
        if native.validate_inventory(pack, inventory)["model-manifest.json"] != MANIFEST:
            raise ValueError("The staged artifact view did not reproduce the exact frozen manifest")
        explicit_skip_control(exe, pack, output)
        for script, target, extra in (
            ("check_flash_next_native_support.py", "native-support", ["--modes", "disabled", "required", "default"]),
            ("run_flash_next_qa_cohort.py", "qa", ["--ordinary-launch"]),
            ("run_flash_next_lifecycle.py", "lifecycle", ["--modes", "disabled", "default"]),
            ("run_flash_next_generate_matrix.py", "generate-matrix", ["--modes", "disabled", "default", "--repeats", "2"]),
        ):
            normal_pressure()
            print(target + "-starting", flush=True)
            subprocess.run([sys.executable, "-B", "-u", ROOT / "scripts" / script,
                            "--model-dir", pack, "--inventory", inventory_file, "--server-bin", exe,
                            "--output", output / target, *extra],
                           cwd=ROOT, check=True)
            print(target + "-complete", flush=True)
    with (output / "comparison.json").open("xb") as file:
        subprocess.run([sys.executable, "-B", ROOT / "seal_native.py", "--observed", output],
                       check=True, cwd=ROOT, stdout=file)
    print("current-native-refresh-complete", flush=True)


if __name__ == "__main__":
    main()
