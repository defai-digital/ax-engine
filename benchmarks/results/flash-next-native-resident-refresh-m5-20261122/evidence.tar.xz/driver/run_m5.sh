#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
shasum -a 256 -c inputs.sha256
[[ $(/usr/sbin/sysctl -n hw.model hw.memsize) = "$(printf 'Mac17,6\n137438953472')" ]]
if /bin/ps -axo comm= | /usr/bin/grep -E '/(ax-engine-server[^/]*|direct_weights|ax-flash-shared-load-test)$'; then exit 1; fi
python="$HOME/.venvs/ax-engine/bin/python"
lib=$("$python" -B -c 'from importlib.metadata import version, distribution; assert version("mlx") == version("mlx-metal") == "0.32.4"; print(distribution("mlx").locate_file("mlx/lib"))')
expected=$("$python" -B -c 'import json; print(json.load(open("build.json"))["libmlx_sha256"])')
test "$(shasum -a 256 "$lib/libmlx.dylib" | awk '{print $1}')" = "$expected"
test "$(stat -f %d "$1")" = "$(stat -f %d .)"
exec /usr/bin/caffeinate -dimsu /usr/bin/env -i HOME="$HOME" \
    PATH="$HOME/.venvs/ax-engine/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin" \
    DYLD_LIBRARY_PATH="$lib" "$python" -B -u run_native.py --cache "$1"
