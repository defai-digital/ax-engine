#!/bin/bash
set -euo pipefail
source="$1"
cache="$2"
deadline=$((SECONDS + 21600))
echo waiting-for-shared-load-check
while test ! -s "$source/status.txt"; do
    kill -0 "$(cat "$source/owner.pid")" 2>/dev/null && (( SECONDS < deadline )) || exit 2
    sleep 15
done
exec bash run_m5.sh "$cache"
