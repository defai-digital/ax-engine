"""Run and replay the two process orders for Flash Next fixed-prefix extension."""

from argparse import ArgumentParser
import json
from pathlib import Path
from statistics import median

from run_fixed_extension import (
    CASES, CORPUS, MANIFEST, ROOT, check_case, mixed, read, require, run_arm, save, workload,
)

ARMS = (("off-1", False), ("on-1", True), ("on-2", True), ("off-2", False))
IDLE_FLOOR = 90.0


def timing(row):
    target = row["target"]
    first = next(item for item in target["scheduled_work"] if item["delta_token_count"])
    peer_output_times = [item["received_seconds"] for item in row["peer"]["scheduled_work"]
                         if item["delta_token_count"]]
    gaps = [later - earlier for earlier, later in zip(peer_output_times, peer_output_times[1:])]
    require(gaps and min(gaps) >= 0 and first["received_seconds"] > 0,
            "Invalid client output timestamps")
    return {
        "target_ttft_seconds": first["received_seconds"],
        "peer_max_gap_seconds": max(gaps),
        "pair_wall_seconds": row["wall_seconds"],
    }


def summarize(results):
    require(set(results) == {name for name, _ in ARMS}, "Incomplete process comparison")
    seed = results[ARMS[0][0]]["seed"]["output_tokens"]
    baseline = results[ARMS[0][0]]["outputs"]
    timing_rows, qualified_arms = {}, {}
    for name, enabled in ARMS:
        record = results[name]
        require(record["outputs"] == baseline and record["seed"]["output_tokens"] == seed,
                "The switch or process order changed greedy token IDs")
        require(record["normal_pressure_samples"] > 0
                and record["outputs"] == {label: check_case(record["cases"][label], enabled and eligible,
                                                           cancelled, tail)
                                          for label, _, _, cancelled, eligible, tail in CASES},
                "A request, restore, or pressure control no longer reconciles")
        qualified_arms[name] = min(record["idle_before"], record["idle_after"]) >= IDLE_FLOOR
        timing_rows[name] = {label: timing(record["cases"][label]) for label, *_ in CASES}
    pairs = []
    for off, on in (("off-1", "on-1"), ("off-2", "on-2")):
        timing_eligible = qualified_arms[off] and qualified_arms[on]
        shifts = {}
        if timing_eligible:
            for metric in ("target_ttft_seconds", "peer_max_gap_seconds", "pair_wall_seconds"):
                shifts[metric] = median(timing_rows[off][label][metric] - timing_rows[on][label][metric]
                                        for label, _, _, _, eligible, _ in CASES if eligible)
        pairs.append({"off": off, "on": on, "timing_eligible": timing_eligible,
                      "median_off_minus_on_seconds": shifts})
    return {
        "cpu_idle_floor_percent": IDLE_FLOOR,
        "tokens_per_process": len(seed) + sum(len(ids) for row in baseline.values() for ids in row.values()),
        "timing_arms": qualified_arms, "timing_rows": timing_rows, "paired_differences": pairs,
        "performance_comparison_eligible": all(pair["timing_eligible"] for pair in pairs),
    }


def main():
    parser = ArgumentParser(description=__doc__)
    for name in ("binary", "pack", "cache", "out", "replay"):
        parser.add_argument(f"--{name}", type=Path)
    args = parser.parse_args()
    if args.replay:
        recorded = read(args.replay)
        require(recorded["qualification"] is False, "Expected a guarded campaign")
        audited = summarize(recorded["arms"])
        require(audited == recorded["comparison"], "Recorded comparison disagrees with the raw arms")
        print(json.dumps(audited, indent=2, sort_keys=True, allow_nan=False))
        return
    require(args.binary is not None and args.pack is not None and args.out is not None, "Missing run input")
    build = read(ROOT / "build.json")
    inventory = read(ROOT / "mxfp4-inventory.json")
    require(mixed.digest(args.binary) == build["server_sha256"] and build["codesign_verified"] is True,
            "Signed executable changed")
    require(mixed.native.validate_inventory(args.pack, inventory, args.cache) == MANIFEST,
            "Delivered model manifest changed")
    args.out.mkdir()
    arms, prompts = {}, workload()
    for name, enabled in ARMS:
        before = mixed.native.wait_for_quiet(IDLE_FLOOR, timeout=900)
        arm = run_arm(args, args.pack, prompts, name, enabled)
        arm["idle_before"] = before["cpu_idle_percent"]
        arm["idle_after"] = mixed.native.cpu_idle_percent()
        arms[name] = arm
        save(args.out / f"{name}-arm.json", arm)
    require(mixed.native.validate_inventory(args.pack, inventory, args.cache) == MANIFEST,
            "Publisher data changed")
    save(args.out / "receipt.json", {"qualification": False, "build": build, "manifest": MANIFEST,
                                    "corpus_sha256": CORPUS, "arms": arms, "comparison": summarize(arms)})


if __name__ == "__main__":
    main()
