"""Verify a bounded priority-short decode hold in the real Flash Next server."""

from argparse import ArgumentParser
import json
from pathlib import Path
import subprocess

import check_openai_concurrency as frozen
import check_short_prefill_first as priority
from check_pair_guard import advance, finish, request, snapshot, submit
import run_selective_mixed as mixed


ROOT = Path(__file__).resolve().parent
FLAG = "AX_MLX_FLASH_NEXT_DRAIN_PRIORITY_SHORT"
MARKER = "ax_scheduler_resident_short_decode_hold"


def decision(snapshot, name):
    return (snapshot.get("route") or {}).get("crossover_decisions", {}).get(name, 0)


def pair(base, long, short):
    owner, guest, grant = priority.begin_pair(base, long, short)
    priority.assert_progress(grant["step"], grant["long"], grant["short"], True)
    return owner, guest, grant


def held_step(base, owner, guest, ordinal, expected, frames):
    step = advance(base)
    long, short = snapshot(base, owner), snapshot(base, guest)
    assert step["scheduled_requests"] == step["scheduled_tokens"] == 1
    assert long["processed_prompt_tokens"] == 2048 and long["output_len"] == 0
    assert short["output_tokens"] == expected[:ordinal]
    assert bool(decision(short, MARKER))
    frames.append({"step": step, "long_cursor": long["processed_prompt_tokens"],
                   "short_length": short["output_len"], "short_state": short["state"],
                   "marker": decision(short, MARKER)})


def resumed(step, row):
    assert step["scheduled_requests"] == 1 and step["scheduled_tokens"] == 2048
    assert row["processed_prompt_tokens"] == 4096


def observe(args, long, short, successor, drain, solo):
    label = "drain" if drain else "mixed"
    env = {
        "AX_MLX_FLASH_NEXT_ALIGNED_BUFFERED": "0",
        "AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0",
        "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": "1",
        "AX_MLX_FLASH_NEXT_SHORT_PREFILL_FIRST": "1",
        FLAG: str(int(drain)),
        "RUST_LOG": "info,ax_engine_mlx::flash_next_startup=debug",
    }
    options = ("--disable-ngram-acceleration", "--total-blocks", "2048",
               "--max-batch-tokens", "2049", *mixed.RESERVE_OPTIONS)
    with mixed.server(args, label, mixed.MODEL, args.pack, 2, env=env, options=options,
                      stream_experts="auto", guard=True) as (base, _):
        if not drain:
            for item in (long, short, successor):
                (row,) = finish(base, submit(base, item))
                solo[item.id] = row["output_tokens"]
                mixed.wait_drained(base)
        owner, guest, grant = pair(base, long, short)
        assert grant["short"]["output_tokens"] == solo[short.id][:1]
        frames = []
        recovery = None
        if drain:
            for ordinal in range(2, 97):
                held_step(base, owner, guest, ordinal, solo[short.id], frames)
            assert frames[-1]["short_state"] == "finished"
            step, current = advance(base), snapshot(base, owner)
            resumed(step, current)
            first = {"step": step, "long": current}
        else:
            step = advance(base)
            current, decoder = snapshot(base, owner), snapshot(base, guest)
            assert step["scheduled_requests"] == 2 and step["scheduled_tokens"] == 513
            assert current["processed_prompt_tokens"] == 2560
            assert decoder["output_tokens"] == solo[short.id][:2] and not decision(decoder, MARKER)
            first = {"step": step, "long": current, "short": decoder}
        done = finish(base, owner, guest)
        assert [item["output_tokens"] for item in done] == [solo[long.id], solo[short.id]]
        counters = mixed.wait_drained(base)
        if drain:
            owner, guest, _ = pair(base, long, short)
            cancelled_frames = []
            held_step(base, owner, guest, 2, solo[short.id], cancelled_frames)
            cancelled = request(base, f"/v1/requests/{guest}/cancel", {})
            assert cancelled["state"] == "cancelled"
            replacement = submit(base, successor)
            step = advance(base)
            current, waiting = snapshot(base, owner), snapshot(base, replacement)
            resumed(step, current)
            assert waiting["processed_prompt_tokens"] == waiting["output_len"] == 0
            after_cancel = finish(base, owner, replacement)
            assert [item["output_tokens"] for item in after_cancel] == [solo[long.id], solo[successor.id]]
            recovery = {"cancelled": cancelled, "held": cancelled_frames, "resume": step,
                        "resumed_long": current, "replacement_at_resume": waiting,
                        "completed": after_cancel, "drained": mixed.wait_drained(base)}
        assert request(base, "/health")["status"] == "ok"
    path = args.out / f"{label}.log"
    log = path.read_text()
    assert "decision=resident" in log and "reader=Mapped" in log
    for old, new in ((str(args.pack), "[pack]"), (str(ROOT), "[run]"),
                     (str(Path.home()), "[home]"), ("127.0.0.1", "[loopback]")):
        log = log.replace(old, new)
    path.write_text(log)
    samples = [json.loads(line) for line in (args.out / f"{label}-samples.jsonl").read_bytes().splitlines()]
    assert samples and all(row["pressure"] == 1 and row["footprint_bytes"] <= 96 << 30 for row in samples)
    return {"drain": drain, "flags": env, "grant": grant, "first_long_step": first, "held_decode": frames,
            "completed": done, "drained": counters, "recovery": recovery,
            "pressure_samples": len(samples), "max_footprint_bytes": max(r["footprint_bytes"] for r in samples)}


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--check-inputs", action="store_true")
    for name in ("binary", "pack", "out"):
        cli.add_argument(f"--{name}", type=Path)
    args = cli.parse_args()
    prompts = priority.cases()
    assert [len(row.input_tokens) for row in prompts] == [8192, 512, 512]
    if args.check_inputs:
        print("Verified frozen long, short and replacement prompt geometry.")
        return
    build = priority.read(ROOT / "build.json")
    assert mixed.digest(args.binary) == build["server_sha256"] and build["codesign_verified"]
    assert mixed.digest(ROOT / "source.patch") == build["patch_sha256"]
    inventory = priority.read(ROOT / "mxfp4-inventory.json")
    manifest = mixed.native.validate_inventory(args.pack, inventory)
    assert manifest["model-manifest.json"] == frozen.MANIFEST
    args.out.mkdir()
    solo = {}
    arms = [observe(args, *prompts, drain, solo) for drain in (False, True)]
    assert mixed.native.validate_inventory(args.pack, inventory) == manifest
    os_version = subprocess.check_output(["/usr/bin/sw_vers", "-productVersion"], text=True).strip()
    result = {"scope": "Priority short decode drain", "qualification": False, "build": build,
              "manifest": manifest, "pack_revision": inventory["revision"], "macos": os_version,
              "prompt_ids": [row.id for row in prompts], "solo": solo, "arms": arms}
    (args.out / "receipt.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
