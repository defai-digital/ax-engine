"""Check admission after a 512-token request frees a native serving slot."""

from argparse import ArgumentParser
import json
from pathlib import Path
import subprocess

import check_openai_concurrency as frozen
from check_pair_guard import TERMINAL, advance, finish, request, snapshot, submit
from check_priority_drain import FLAG, MARKER, decision, held_step, pair
import run_selective_mixed as mixed


ROOT = Path(__file__).resolve().parent
IDS = ("mixed-073", "mixed-074", "mixed-075")


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def prompts():
    frozen.inputs()
    by_id = {row.id: row for row in mixed.bench.load_corpus(ROOT / "mixed-corpus.jsonl")}
    selected = [by_id[name] for name in IDS]
    assert [len(row.input_tokens) for row in selected] == [8192, 512, 2048]
    assert [row.max_output_tokens for row in selected] == [96, 96, 96]
    return selected


def cursor(row):
    return {key: row[key] for key in ("state", "processed_prompt_tokens", "output_len")}


def assert_waiting(row):
    assert cursor(row) == {"state": "waiting", "processed_prompt_tokens": 0, "output_len": 0}


def finish_short(base, owner, guest, expected, drain):
    frames = []
    for ordinal in range(2, len(expected) + 1):
        if drain:
            held_step(base, owner, guest, ordinal, expected, frames)
        else:
            step = advance(base)
            short = snapshot(base, guest)
            assert short["output_tokens"] == expected[:ordinal]
            assert not decision(short, MARKER)
            frames.append({"step": step, "long": cursor(snapshot(base, owner)), "short": cursor(short)})
    short = snapshot(base, guest)
    assert short["state"] == "finished" and short["output_tokens"] == expected
    return frames


def observe_wait(base, owner, queued, expected):
    assert_waiting(snapshot(base, queued))
    frames = []
    for _ in range(128):
        step = advance(base)
        long, medium = snapshot(base, owner), snapshot(base, queued)
        assert_waiting(medium)
        assert step["scheduled_requests"] == 1
        assert long["output_tokens"] == expected[:long["output_len"]]
        frames.append({"step": step, "long": cursor(long), "medium": cursor(medium)})
        if long["state"] == "finished":
            assert long["output_tokens"] == expected
            return frames
        assert long["state"] not in TERMINAL
    raise RuntimeError("The original long request did not finish within 128 steps")


def observe(args, cases, drain, solo):
    label = "drain" if drain else "mixed"
    long, short, medium = cases
    env = {
        "AX_MLX_FLASH_NEXT_ALIGNED_BUFFERED": "0",
        "AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0",
        "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": "1",
        "AX_MLX_FLASH_NEXT_SHORT_PREFILL_FIRST": "1",
        FLAG: str(int(drain)),
        "RUST_LOG": "info,ax_engine_mlx::flash_next_startup=debug",
    }
    options = ("--disable-ngram-acceleration", "--total-blocks", "2048",
               "--max-batch-tokens", "2049", *mixed.RESERVE_OPTIONS)
    with mixed.server(args, label, mixed.MODEL, args.pack, 2, env=env, options=options,
                      stream_experts="auto", guard=True) as (base, _):
        if not drain:
            for item in cases:
                (row,) = finish(base, submit(base, item))
                solo[item.id] = row["output_tokens"]
                mixed.wait_drained(base)
            print("Solo outputs verified.", flush=True)
        owner, guest, grant = pair(base, long, short)
        assert grant["short"]["output_tokens"] == solo[short.id][:1]
        short_steps = finish_short(base, owner, guest, solo[short.id], drain)
        at_handoff = cursor(snapshot(base, owner))
        assert at_handoff["state"] == "runnable"
        queued = submit(base, medium)
        assert len({queued, owner, guest}) == 3
        waiting = cursor(snapshot(base, queued))
        print(f"{label}: short finished, long at {at_handoff}, medium at {waiting}", flush=True)
        blocked = observe_wait(base, owner, queued, solo[long.id])
        release = advance(base)
        medium_start = snapshot(base, queued)
        assert release["step_id"] == blocked[-1]["step"]["step_id"] + 1
        assert release["scheduled_requests"] == 1 and release["scheduled_tokens"] == 2048
        assert medium_start["state"] == "runnable" and medium_start["processed_prompt_tokens"] == 2048
        assert medium_start["output_tokens"] == solo[medium.id][:1]
        completed = finish(base, owner, guest, queued)
        assert [row["output_tokens"] for row in completed] == [solo[row.id] for row in cases]
        drained = mixed.wait_drained(base)
        assert request(base, "/health")["status"] == "ok"
        print(f"{label}: medium waited {len(blocked)} steps and finished with exact IDs.", flush=True)
    log_path = args.out / f"{label}.log"
    log = log_path.read_text()
    assert "decision=resident" in log and "reader=Mapped" in log
    for before, after in ((str(args.pack), "[pack]"), (str(ROOT), "[run]"),
                          (str(Path.home()), "[home]"), ("127.0.0.1", "[loopback]")):
        log = log.replace(before, after)
    log_path.write_text(log)
    samples = [json.loads(line) for line in (args.out / f"{label}-samples.jsonl").read_bytes().splitlines()]
    assert samples and all(row["pressure"] == 1 and 0 < row["footprint_bytes"] <= 96 << 30 for row in samples)
    return {
        "flags": env, "grant": grant, "short_steps": short_steps, "long_at_handoff": at_handoff,
        "medium_at_handoff": waiting, "blocked": blocked, "release": release,
        "medium_first_prefill": cursor(medium_start), "completed": completed, "drained": drained,
        "normal_pressure_samples": len(samples), "peak_footprint_bytes": max(row["footprint_bytes"] for row in samples),
    }


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--check-inputs", action="store_true")
    for name in ("binary", "pack", "out"):
        cli.add_argument(f"--{name}", type=Path)
    args = cli.parse_args()
    cases = prompts()
    if args.check_inputs:
        print("Verified the frozen 8,192/512/2,048-token prompt handoff.")
        return
    build = json.loads((ROOT / "build.json").read_bytes())
    assert mixed.digest(args.binary) == build["server_sha256"] and build["codesign_verified"]
    assert mixed.digest(ROOT / "source.patch") == build["patch_sha256"]
    inventory = json.loads((ROOT / "mxfp4-inventory.json").read_bytes())
    assert len(inventory["members"]) == 49
    manifest = mixed.native.validate_inventory(args.pack, inventory)
    assert manifest == {"model-manifest.json": frozen.MANIFEST}
    args.out.mkdir()
    solo = {}
    for label, drain in (("mixed", False), ("drain", True)):
        print(f"{label} starting", flush=True)
        write(args.out / f"{label}.json", observe(args, cases, drain, solo))
    assert mixed.native.validate_inventory(args.pack, inventory) == manifest
    version = subprocess.check_output(["/usr/bin/sw_vers", "-productVersion"], text=True).strip()
    write(args.out / "receipt.json", {
        "scope": "Stepwise native FIFO after a short prompt completes", "qualification": False,
        "hardware": "Mac Studio M2 Ultra 192 GB", "macos": version, "build": build,
        "pack_revision": inventory["revision"], "publisher_members_verified_before_and_after": 49,
        "manifest": manifest, "prompt_ids": IDS, "solo": solo,
    })


if __name__ == "__main__":
    main()
