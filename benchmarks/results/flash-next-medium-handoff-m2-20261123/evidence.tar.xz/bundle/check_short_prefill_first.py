"""Check one bounded short prefill turn through the real Flash Next HTTP runner."""

from argparse import ArgumentParser
import json
from pathlib import Path
import subprocess

from check_pair_guard import advance, finish, request, snapshot, submit
import check_openai_concurrency as frozen
import run_selective_mixed as mixed


ROOT = Path(__file__).resolve().parent
FLAG = "AX_MLX_FLASH_NEXT_SHORT_PREFILL_FIRST"


def read(path):
    return json.loads(path.read_bytes())


def assert_progress(step, long, short, early):
    assert step["scheduled_requests"] == 1
    if early:
        assert step["scheduled_tokens"] == 512
        assert long["processed_prompt_tokens"] == 2048 and long["output_len"] == 0
        assert short["processed_prompt_tokens"] == 512 and short["output_len"] == 1
    else:
        assert step["scheduled_tokens"] == 2048
        assert long["processed_prompt_tokens"] == 4096 and long["output_len"] == 0
        assert short["processed_prompt_tokens"] == short["output_len"] == 0
    assert long["state"] == short["state"] == "runnable"


def cases():
    long, _ = frozen.inputs()
    short = [row for row in mixed.bench.load_corpus(ROOT / "mixed-corpus.jsonl")
             if len(row.input_tokens) == 512][:2]
    assert len(short) == 2 and short[0].id != short[1].id
    assert all(row.max_output_tokens == 96 for row in [long, *short])
    return long, *short


def begin_pair(base, long, short):
    owner = submit(base, long)
    first = advance(base)
    assert first["scheduled_requests"] == 1 and first["scheduled_tokens"] == 2048
    state = snapshot(base, owner)
    assert state["processed_prompt_tokens"] == 2048 and state["output_len"] == 0
    guest = submit(base, short)
    step = advance(base)
    return owner, guest, {"step": step, "long": snapshot(base, owner), "short": snapshot(base, guest)}


def run_arm(args, long, short, successor, enabled, solo):
    label = "short-first" if enabled else "fifo"
    env = {"AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0", "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": "1",
           FLAG: str(int(enabled)), "RUST_LOG": "info,ax_engine_mlx::flash_next_startup=debug"}
    options = ("--disable-ngram-acceleration", "--total-blocks", "2048", "--max-batch-tokens", "2049",
               *mixed.RESERVE_OPTIONS)
    with mixed.server(args, label, mixed.MODEL, args.pack, 2, env=env, options=options,
                      stream_experts="auto", guard=True) as (base, _):
        if not enabled:
            for case in (long, short, successor):
                (state,) = finish(base, submit(base, case))
                solo[case.id] = state["output_tokens"]
                mixed.wait_drained(base)
        owner, guest, observed = begin_pair(base, long, short)
        assert_progress(observed["step"], observed["long"], observed["short"], enabled)
        completed = finish(base, owner, guest)
        assert [state["output_tokens"] for state in completed] == [solo[long.id], solo[short.id]]
        drains = [mixed.wait_drained(base)]
        cancel_case = None
        if enabled:
            owner, guest, first = begin_pair(base, long, short)
            assert_progress(first["step"], first["long"], first["short"], True)
            cancelled = request(base, f"/v1/requests/{guest}/cancel", {})
            assert cancelled["state"] == "cancelled"
            replacement = submit(base, successor)
            choice = advance(base)
            held = snapshot(base, owner), snapshot(base, replacement)
            assert_progress(choice, *held, False)
            next_state = finish(base, owner, replacement)
            assert [state["output_tokens"] for state in next_state] == [solo[long.id], solo[successor.id]]
            drains.append(mixed.wait_drained(base))
            cancel_case = {"first": first, "cancelled": cancelled, "next_step": choice,
                           "after_replacement": held, "completed": next_state}
        assert request(base, "/health")["status"] == "ok"
    log = args.out / f"{label}.log"
    text = log.read_text()
    assert "decision=resident" in text and "reader=Mapped" in text
    for before, after in ((str(args.pack), "[pack]"), (str(ROOT), "[run]"),
                          (str(Path.home()), "[home]"), ("127.0.0.1", "[loopback]")):
        text = text.replace(before, after)
    log.write_text(text)
    samples = [json.loads(row) for row in (args.out / f"{label}-samples.jsonl").read_text().splitlines()]
    assert samples and {row["pressure"] for row in samples} == {1}
    return {"enabled": enabled, "flags": env, "first": observed, "completed": completed,
            "cancel_and_replace": cancel_case, "drains": drains, "normal_pressure_samples": len(samples),
            "peak_physical_footprint_bytes": max(row["footprint_bytes"] for row in samples)}


def main():
    parser = ArgumentParser(description=__doc__)
    for name in ("binary", "pack", "link-root", "out"):
        parser.add_argument("--" + name, type=Path)
    parser.add_argument("--check-inputs", action="store_true")
    args = parser.parse_args()
    prompts = cases()
    if args.check_inputs:
        print("Verified one 8K and two distinct 512-token control prompts.")
        return
    build = read(ROOT / "build.json")
    assert build["codesign_verified"] and mixed.digest(args.binary) == build["server_sha256"]
    assert mixed.digest(ROOT / "source.patch") == build["patch_sha256"]
    inventory = read(ROOT / "mxfp4-inventory.json")
    manifest = mixed.native.validate_inventory(args.pack, inventory, args.link_root)
    assert manifest["model-manifest.json"] == frozen.MANIFEST
    args.out.mkdir()
    solo = {}
    arms = [run_arm(args, *prompts, enabled, solo) for enabled in (False, True)]
    assert mixed.native.validate_inventory(args.pack, inventory, args.link_root) == manifest
    chip = subprocess.check_output(("sysctl", "-n", "machdep.cpu.brand_string"), text=True).strip()
    hardware = {
        "soc": chip,
        "unified_memory_bytes": int(subprocess.check_output(("sysctl", "-n", "hw.memsize"))),
        "os": subprocess.check_output(("sw_vers", "-productVersion"), text=True).strip(),
        "storage": "internal SSD",
    }
    receipt = {"qualification": False, "scope": "Bounded short prefill turn functional check",
               "hardware": hardware, "build": build, "manifest": manifest, "revision": inventory["revision"],
               "prompt_ids": [prompt.id for prompt in prompts], "solo": solo, "arms": arms}
    (args.out / "receipt.json").write_text(json.dumps(receipt, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
