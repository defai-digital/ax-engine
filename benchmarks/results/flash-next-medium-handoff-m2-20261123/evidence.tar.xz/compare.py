"""Replay the exact native successor-admission receipt from its step snapshots."""

from hashlib import sha256
import json
from pathlib import Path
import sys


WORK = Path(__file__).resolve().parent
HOLD = "AX_MLX_FLASH_NEXT_DRAIN_PRIORITY_SHORT"
VACANT = {"state": "waiting", "processed_prompt_tokens": 0, "output_len": 0}
COUNTERS = {
    "ax_engine_jobs_in_flight", "ax_engine_generation_jobs_pending",
    "ax_engine_generation_commands_queued", "ax_engine_generation_active_streams",
    "ax_engine_generation_buffered_stream_events",
}


def load(path):
    return json.loads(path.read_bytes())


def check(arm, mode, oracle, log, samples):
    long, short, medium = oracle
    grant = arm["grant"]
    assert grant["step"]["scheduled_requests"] == 1 and grant["step"]["scheduled_tokens"] == 512
    assert grant["long"]["processed_prompt_tokens"] == 2048 and grant["long"]["output_len"] == 0
    assert grant["short"]["output_tokens"] == short[:1]
    assert arm["flags"][HOLD] == str(int(mode == "drain"))
    assert arm["flags"]["AX_MLX_FLASH_NEXT_SHORT_PREFILL_FIRST"] == "1"
    assert arm["flags"]["AX_MLX_FLASH_NEXT_PREFILL_SPLIT"] == "1"
    assert arm["flags"]["AX_MLX_FLASH_NEXT_ALIGNED_BUFFERED"] == "0"
    assert arm["flags"]["AX_MLX_FLASH_NEXT_DIRECT_COALESCING"] == "0"

    short_steps = arm["short_steps"]
    assert len(short_steps) == 95
    assert arm["long_at_handoff"]["state"] == "runnable"
    if mode == "drain":
        for n, frame in enumerate(short_steps, 2):
            assert frame["short_length"] == n and frame["long_cursor"] == 2048 and frame["marker"]
            assert frame["step"]["scheduled_requests"] == frame["step"]["scheduled_tokens"] == 1
        assert short_steps[-1]["short_state"] == "finished"
        assert arm["long_at_handoff"] == {
            "state": "runnable", "processed_prompt_tokens": 2048, "output_len": 0,
        }
    else:
        assert short_steps[0]["step"]["scheduled_tokens"] == 513
        assert short_steps[0]["long"]["processed_prompt_tokens"] == 2560
        for n, frame in enumerate(short_steps, 2):
            assert frame["short"]["output_len"] == n
        assert short_steps[-1]["short"]["state"] == "finished"
        assert short_steps[-1]["long"] == arm["long_at_handoff"]

    assert arm["medium_at_handoff"] == VACANT
    blocked = arm["blocked"]
    assert blocked and all(row["medium"] == VACANT for row in blocked)
    assert all(row["step"]["scheduled_requests"] == 1 for row in blocked)
    assert all(row["long"]["state"] == "runnable" for row in blocked[:-1])
    assert blocked[-1]["long"] == {"state": "finished", "processed_prompt_tokens": 8192, "output_len": 96}
    release = arm["release"]
    assert release["scheduled_requests"] == 1 and release["scheduled_tokens"] == 2048
    assert arm["medium_first_prefill"] == {
        "state": "runnable", "processed_prompt_tokens": 2048, "output_len": 1,
    }
    step_ids = [grant["step"]["step_id"],
                *(row["step"]["step_id"] for row in (*short_steps, *blocked)),
                release["step_id"]]
    assert step_ids == list(range(step_ids[0], step_ids[0] + len(step_ids)))

    assert [row["state"] for row in arm["completed"]] == ["finished"] * 3
    assert [row["output_tokens"] for row in arm["completed"]] == [long, short, medium]
    assert set(arm["drained"]) == COUNTERS and all(value == 0 for value in arm["drained"].values())
    assert "decision=resident" in log and "reader=Mapped" in log
    assert len(samples) == arm["normal_pressure_samples"] > 0
    assert all(sample["pressure"] == 1 for sample in samples)
    peak = max(sample["footprint_bytes"] for sample in samples)
    assert peak == arm["peak_footprint_bytes"] and 0 < peak <= 96 << 30
    return {
        "long_at_handoff": arm["long_at_handoff"], "medium_wait_steps": len(blocked),
        "medium_started_one_step_after_long_end": True, "exact_output_ids": sum(map(len, oracle)),
        "normal_pressure_samples": len(samples), "peak_footprint_bytes": peak,
    }


def compare(capture):
    assert (capture / "status.txt").read_bytes() == b"0\n"
    manifest = (WORK / "bundle/inputs.sha256").read_bytes()
    assert (capture / "inputs.sha256").read_bytes() == manifest
    entries = {name: digest for digest, name in map(str.split, manifest.decode().splitlines())}
    assert entries.keys() | {"inputs.sha256"} == {item.name for item in (WORK / "bundle").iterdir()} | {
        "ax-engine-server",
    }
    for name, digest in entries.items():
        if name != "ax-engine-server":
            assert sha256((WORK / "bundle" / name).read_bytes()).hexdigest() == digest, name
    build = load(WORK / "bundle/build.json")
    assert build["codesign_verified"] and build["server_sha256"] == entries["ax-engine-server"]
    assert build["patch_sha256"] == entries["source.patch"]
    observed = capture / "observed"
    receipt = load(observed / "receipt.json")
    assert receipt["build"] == build and receipt["qualification"] is False
    assert receipt["manifest"] == {"model-manifest.json": entries["model-manifest.json"]}
    inventory = load(WORK / "bundle/mxfp4-inventory.json")
    assert receipt["publisher_members_verified_before_and_after"] == len(inventory["members"]) == 49
    assert receipt["pack_revision"] == inventory["revision"] == "ff2a28485eb89bb60e8fe35dd6c65c51e63ee7b3"
    assert receipt["prompt_ids"] == ["mixed-073", "mixed-074", "mixed-075"]
    oracle = [receipt["solo"][name] for name in receipt["prompt_ids"]]
    assert all(len(ids) == 96 and all(type(token) is int and token >= 0 for token in ids) for ids in oracle)
    arms = {}
    for mode in ("mixed", "drain"):
        arms[mode] = check(
            load(observed / f"{mode}.json"), mode, oracle,
            (observed / f"{mode}.log").read_text(),
            [json.loads(row) for row in (observed / f"{mode}-samples.jsonl").read_bytes().splitlines()],
        )
    return {
        "qualification": False, "tested_experimental_commit": build["experiment_commit"],
        "pack_revision": receipt["pack_revision"], "hardware": receipt["hardware"], "macos": receipt["macos"],
        "prompt_ids": receipt["prompt_ids"], "arms": arms,
    }


if __name__ == "__main__":
    print(json.dumps(compare(Path(sys.argv[1])), indent=2, sort_keys=True, allow_nan=False))
