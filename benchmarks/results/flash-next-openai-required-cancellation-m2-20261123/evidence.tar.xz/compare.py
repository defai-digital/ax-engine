"""Recheck signed Flash Next cancellation receipts on the selected hardware."""

from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "bundle"))
import run_primary_controls as primary
import run_cancellation_controls as native
import run_sampling_controls as controls

PRIMARY = False


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def action(row):
    return {"engine_steps": row["metrics"][native.STEPS],
            "verified_steps": row["metrics"][controls.VERIFIED],
            "accepted_steps": row["metrics"][native.ACCEPTED]}


def verify(capture):
    assert (capture / "status.txt").read_bytes() == b"0\n"
    bundle = ROOT / "bundle"
    manifest = (bundle / "inputs.sha256").read_bytes()
    assert (capture / "inputs.sha256").read_bytes() == manifest
    files = {name: digest for digest, name in map(str.split, manifest.decode().splitlines())}
    for name, digest in files.items():
        if name != "ax-engine-server":
            assert sha256((bundle / name).read_bytes()).hexdigest() == digest, name
    build = controls.read(bundle / "build.json")
    assert build["codesign_verified"] and build["server_sha256"] == files["ax-engine-server"] == controls.SERVER
    assert build["patch_sha256"] == files["source.patch"]
    assert (bundle / "build.json").read_bytes() == (capture / "build.json").read_bytes()
    inventory = controls.read(bundle / "mxfp4-inventory.json")
    assert inventory["revision"] == "ff2a28485eb89bb60e8fe35dd6c65c51e63ee7b3" and len(inventory["members"]) == 49
    modes = ("default", "required") if PRIMARY else ("disabled", "required")
    hardware = "MacBook Pro M5 Max 128 GB" if PRIMARY else "Mac Studio M2 Ultra 192 GB"
    expected_reader = primary.READER if PRIMARY else "Mapped"
    expected_manifest = {"model-manifest.json": files["model-manifest.json"]}
    ids = controls.prompt()
    arm, native_ids, openai_text = {}, {}, {}
    for mode in modes:
        folder = capture / mode
        receipt = controls.read(folder / "receipt.json")
        assert receipt["mode"] == mode and receipt["qualification"] is False
        assert receipt["server_sha256"] == controls.SERVER and receipt["manifest"] == expected_manifest
        assert receipt["publisher_members_verified_before_and_after"] == 49 and receipt["macos"] == "27.2.1"
        samples = rows(folder / f"{mode}-samples.jsonl")
        assert len(samples) == receipt["normal_pressure_samples"] > 0
        assert all(row["pressure"] == 1 and 0 < row["footprint_bytes"] <= 96 << 30 for row in samples)
        assert max(row["footprint_bytes"] for row in samples) == receipt["max_footprint_bytes"]
        reader, = [line for line in (folder / f"{mode}.log").read_text().splitlines()
                   if "Flash Next resident reader" in line]
        assert f"reader={expected_reader}" in reader
        openai = rows(folder / "openai.jsonl")
        primary.verify_openai(openai, mode)
        for completed in (openai[0], openai[2]):
            assert completed["usage"]["prompt_tokens"] == len(ids)
            assert completed["usage"]["total_tokens"] == len(ids) + controls.BUDGET
        openai_text[mode] = openai[0]["text"]
        arm[mode] = {
            "openai": {row["case"]: action(row) for row in openai},
            "openai_disconnect_visible_chunks": openai[1]["visible_chunks"],
            "openai_verified_before_disconnect": openai[1]["while_open"][controls.VERIFIED],
            "openai_accepted_before_disconnect": openai[1]["while_open"][native.ACCEPTED],
            "normal_pressure_samples": len(samples),
            "peak_footprint_bytes": receipt["max_footprint_bytes"],
        }
        if PRIMARY:
            assert receipt["reader"] == expected_reader and receipt["native_actions"] == 5
            assert receipt["openai_actions"] == 3
            cases = rows(folder / "cases.jsonl")
            native.verify(cases, "required" if mode == "required" else "disabled", ids)
            prefix = rows(folder / "disconnect-steps.jsonl")
            assert prefix[-1]["step"] == cases[1]["visible_step"] and prefix[-1]["state"] == "runnable"
            assert [token for step in prefix for token in step["delta"]] == cases[1]["prefix"]
            native_ids[mode] = cases[0]["output_ids"]
            arm[mode]["native"] = {row["case"]: action(row) for row in cases}
    result = {"qualification": False, "hardware": hardware, "macos": "27.2.1", "reader": expected_reader,
              "pack_revision": inventory["revision"], "server_sha256": controls.SERVER,
              "same_openai_complete_text_across_policies": openai_text[modes[0]] == openai_text[modes[1]],
              "arms": arm}
    if PRIMARY:
        result["native_output_differences_across_policies"] = [
            i for i, (a, b) in enumerate(zip(native_ids[modes[0]], native_ids[modes[1]], strict=True)) if a != b
        ]
    return result


if __name__ == "__main__":
    print(json.dumps(verify(Path(sys.argv[1])), indent=2, sort_keys=True, allow_nan=False))
