"""Check the OpenAI streaming completion cancellation path on M2 Ultra."""

from argparse import ArgumentParser
import json
from pathlib import Path
import re
import subprocess

import run_cancellation_controls as native
import run_primary_controls as primary
import run_sampling_controls as controls


ROOT = Path(__file__).resolve().parent


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--mode", choices=("disabled", "required"))
    for name in ("binary", "pack", "out"):
        cli.add_argument(f"--{name}", type=Path)
    cli.add_argument("--check-inputs", action="store_true")
    args = cli.parse_args()
    ids = controls.prompt()
    build = controls.read(ROOT / "build.json")
    assert build["codesign_verified"] and build["server_sha256"] == controls.SERVER
    assert controls.digest(ROOT / "source.patch") == build["patch_sha256"]
    if args.check_inputs:
        return
    assert controls.digest(args.binary) == controls.SERVER
    inventory = controls.read(ROOT / "mxfp4-inventory.json")
    assert len(inventory["members"]) == 49
    manifest = controls.native.validate_inventory(args.pack, inventory)
    assert manifest == {"model-manifest.json": controls.digest(ROOT / "model-manifest.json")}
    args.out.mkdir()
    rows = []
    env = {"AX_FLASH_NEXT_MTP_COST": "0", "RUST_LOG": "info,ax_engine_mlx::flash_next_startup=debug"}
    with controls.serving.server(
        args, args.mode, controls.MODEL, args.pack, 1, env=env, guard=True, mtp=args.mode,
        prefill_chunk=2048, options=("--total-blocks", "2048", "--disable-ngram-acceleration"),
    ) as (base, pid):
        primary.ensure_library(pid, build["libmlx_sha256"])
        for name in primary.OPENAI_ACTIONS:
            row = native.checked_action(
                base, name, lambda before: primary.openai_stream(
                    base, ids, args.mode, before=before if name == "disconnect" else None))
            rows.append(row)
            native.write_line(args.out / "openai.jsonl", row)
            print(f"{args.mode} OpenAI {name} completed", flush=True)
        assert native.call(base, "/health")["status"] == "ok"
    primary.verify_openai(rows, args.mode)
    log = args.out / f"{args.mode}.log"
    text = log.read_text()
    reader, = [line for line in text.splitlines() if "Flash Next resident reader" in line]
    assert "reader=Mapped" in reader
    for old, new in ((str(args.pack), "[pack]"), (str(ROOT), "[run]"), (str(Path.home()), "[home]")):
        text = text.replace(old, new)
    text = re.sub(r"127\.0\.0\.1(?::\d+)?", "[loopback]", text)
    log.write_text(text)
    samples = [json.loads(line) for line in (args.out / f"{args.mode}-samples.jsonl").read_text().splitlines()]
    assert samples and all(row["pressure"] == 1 and 0 < row["footprint_bytes"] <= 96 << 30 for row in samples)
    assert controls.native.validate_inventory(args.pack, inventory) == manifest
    version = subprocess.check_output(["/usr/bin/sw_vers", "-productVersion"], text=True).strip()
    result = {"mode": args.mode, "qualification": False, "server_sha256": controls.SERVER, "manifest": manifest,
              "macos": version, "publisher_members_verified_before_and_after": 49,
              "normal_pressure_samples": len(samples), "max_footprint_bytes": max(row["footprint_bytes"] for row in samples)}
    (args.out / "receipt.json").write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
