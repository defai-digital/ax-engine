"""Verify Flash Next live-prefix route, identity, pressure and matched timing."""

from argparse import ArgumentParser
import json
from pathlib import Path
from statistics import quantiles

from run_live_prefix import (
    MODES, REUSED, ROOT, STORES, WORKLOAD, check_pair, has_decision, mixed,
    read, require, responses, restored_l1, workload,
)


def peer_gaps(row):
    times = [frame["received_seconds"] for frame in row["peer"]["scheduled_work"]
             if frame["delta_token_count"]]
    gaps = [b-a for a, b in zip(times, times[1:])]
    require(len(gaps) > 10 and all(0 <= sample <= row["wall_seconds"] for sample in gaps),
            "Peer stream gaps are incomplete")
    return quantiles(gaps, n=20, method="inclusive")[-1], max(gaps)


def replay(capture):
    result = read(capture / "receipt.json")
    prompts = workload()
    extension = prompts["target"]["input_tokens"]
    seed = prompts["seed-a"]["input_tokens"]
    require(len(seed) == 2048 and len(extension) == 2112 and extension[:2048] == seed,
            "The strict extension no longer follows its seeded prefix")
    build = read(ROOT / "candidate-build.json")
    inventory = read(ROOT / "mxfp4-inventory.json")
    require(result["qualification"] is False and result["build"] == build
            and result["pack_revision"] == inventory["revision"]
            and result["workload_sha256"] == WORKLOAD and result["order"] == list(MODES)
            and set(result["arms"]) == set(MODES), "A signed build, prompt, pack, or arm changed")
    arms = {}
    expected = None
    for mode in MODES:
        arm = result["arms"][mode]
        warm = mode.startswith("warm")
        for seed_name, seed in arm["seeds"].items():
            require(seed["prompt_id"] == seed_name and len(seed["output_tokens"]) == 1
                    and has_decision(seed, STORES) is warm and not has_decision(seed, REUSED),
                    "The frozen seed route changed")
        require(set(arm["seeds"]) == {"seed-a", "seed-b"}, "The seed roster changed")
        for label, peer, target in (("exact", "survivor-a", "hit-a"), ("cancel", "survivor-b", "hit-b"),
                                    ("extension", "extension-peer", "target")):
            row = arm[label]
            require(row["peer"]["prompt_id"] == prompts[peer]["id"]
                    and row["target"]["prompt_id"] == prompts[target]["id"]
                    and row["shared_steps"] == check_pair(row, warm, cancelled=label == "cancel",
                                                          extension=label == "extension"),
                    f"Request identity or shared-step roster changed in {mode}/{label}")
            if warm and label != "extension":
                first_output = next(index for index, frame in enumerate(row["target"]["scheduled_work"])
                                    if frame["delta_token_count"] > 0)
                work = row["target"]["scheduled_work"][:first_output + 1]
                require(all(frame["scheduled_tokens"] <= 2 for frame in work)
                        and work[-1]["step_id"] in row["shared_steps"],
                        "The restored hit still scheduled prefix rows before its first output")
            elif label == "extension":
                advances = [frame["advanced_prompt_tokens"] for frame in row["target"]["prefill_progress"]]
                require(advances == [2048, 64], "The cold extension lost its independent 64-token suffix")
        require(arm["replacement"]["prompt_id"] == "hit-b"
                and restored_l1(arm["replacement"]) is warm
                and arm["replacement"]["output_tokens"][:1] == arm["cancel"]["target"]["first_output_tokens"]
                and arm["final_drained"] == dict.fromkeys(mixed.COUNTERS, 0),
                "Replacement did not retain the cancelled request's prefix and first token")
        observed = responses(arm)
        if expected is None:
            expected = observed
        require(observed == expected, "Token IDs differ between code paths")
        samples = list(map(json.loads, (capture / f"{mode}-samples.jsonl").read_text().splitlines()))
        require(len(samples) == arm["samples"] > 0 and all(row["pressure"] == 1 for row in samples)
                and max(row["footprint_bytes"] for row in samples) == arm["peak_footprint_bytes"]
                and arm["peak_footprint_bytes"] <= 96 * 2**30,
                "Host pressure or peak footprint report changed")
        require(b"decision=resident" in (capture / f"{mode}.log").read_bytes(),
                "The signed server did not select resident loading")
        idle = [arm[k] for k in ("before", "after")]
        require(all(0 <= n <= 100 for n in idle), "Invalid host idle observation")
        exact = arm["exact"]
        peer_p95, peer_max = peer_gaps(exact)
        require(0 < exact["target"]["ttft_seconds"] < exact["wall_seconds"]
                and 0 < peer_max <= exact["wall_seconds"], "Invalid paired elapsed time")
        arms[mode] = {"timing_eligible": min(idle) >= 90, "cpu_idle_percent": idle,
                      "exact_target_ttft_seconds": exact["target"]["ttft_seconds"],
                      "exact_peer_gap_p95_seconds": peer_p95, "exact_peer_max_gap_seconds": peer_max,
                      "exact_pair_wall_seconds": exact["wall_seconds"],
                      "exact_shared_steps": len(exact["shared_steps"]),
                      "normal_pressure_samples": len(samples),
                      "peak_footprint_bytes": arm["peak_footprint_bytes"]}
    pairs = []
    for cold_label, warm_label in (("cold-1", "warm-1"), ("cold-2", "warm-2")):
        cold, warm = arms[cold_label], arms[warm_label]
        eligible = cold["timing_eligible"] and warm["timing_eligible"]
        pairs.append({"cold": cold_label, "warm": warm_label, "timing_eligible": eligible,
                      "warm_to_cold_ratio": {key: warm[key] / cold[key] for key in
                                             ("exact_target_ttft_seconds", "exact_peer_max_gap_seconds",
                                              "exact_pair_wall_seconds")} if eligible else None})
    count = sum(len(reply) for label in ("exact", "cancel", "extension") for reply in expected[label])
    count += len(expected["replacement"]) + sum(len(reply) for reply in expected["seeds"].values())
    require(count == 867, "The measured output roster changed")
    return {"qualification": False, "order": MODES, "arms": arms, "pairs": pairs,
            "matched_output_ids_per_arm": count,
            "timing_eligible": all(arm["timing_eligible"] for arm in arms.values()),
            "matched_exact_and_extension_pairs": 2 * len(arms), "cancel_and_replacement_pairs": len(arms)}


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("capture", type=Path)
    print(json.dumps(replay(parser.parse_args().capture), indent=2, sort_keys=True, allow_nan=False))
