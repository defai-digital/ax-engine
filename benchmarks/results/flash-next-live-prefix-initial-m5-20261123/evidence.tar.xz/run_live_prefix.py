"""Compare concurrent exact Flash Next prompt reuse on one signed binary."""

from argparse import ArgumentParser
import json
from pathlib import Path
from time import monotonic

import run_selective_mixed as mixed
from run_warm_prefix import REUSED, SOURCE, STORES, build_prompts, generate, overlap, restored_l1

ROOT = Path(__file__).resolve().parent
WORKLOAD = "2c0c205d803207df6316dbd0076eef97451a55c80c0413fdc6b3bee5ffef7e9a"
MANIFEST = {"model-manifest.json": "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef"}
MODES = ("cold-1", "warm-1", "warm-2", "cold-2")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_bytes())


def save(path, value):
    target = path.with_suffix(".tmp")
    target.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")
    target.replace(path)


def workload():
    path = ROOT / "mixed-corpus.jsonl"
    require(mixed.digest(path) == WORKLOAD, "The verified source corpus changed")
    prompts = build_prompts(path)
    short = [row["input_tokens"] for row in map(json.loads, path.read_text().splitlines())
             if len(row["input_tokens"]) == 512]
    prompts["extension-peer"] = {"id": "extension-peer", "input_tokens": short[6], "max_output_tokens": 192}
    for letter in ("a", "b"):
        prompts[f"hit-{letter}"] = {**prompts[f"seed-{letter}"], "id": f"hit-{letter}", "max_output_tokens": 96}
    require(len({prompts[name]["input_tokens"][0] for name in
                 ("seed-a", "seed-b", "survivor-a", "survivor-b", "extension-peer")}) == 5,
            "Workload prefixes are no longer disjoint")
    return prompts


def has_decision(result, key):
    return any(row["decisions"].get(key, 0) for row in result["cache_events"])


def check_pair(row, warm, *, cancelled=False, extension=False):
    peer, target = row["peer"], row["target"]
    reused = warm and not extension
    require(restored_l1(target) is reused and has_decision(target, REUSED) is reused
            and not has_decision(peer, REUSED), "Unexpected cache route during overlap")
    require(all(event["request_id"] == target["request_id"] for event in target["cache_events"]
                if event["decisions"].get(REUSED)),
            "The restore event belongs to another stream")
    peer_steps = [frame["step_id"] for frame in peer["scheduled_work"] if frame["delta_token_count"]]
    work = target["scheduled_work"]
    shared = sorted({frame["step_id"] for frame in work
                     if frame["scheduled_requests"] == 2 and frame["step_id"] in peer_steps[1:-1]})
    require(shared, "The two requests did not run a shared step while the peer was already decoding")
    if reused:
        require(any(frame["step_id"] in shared and frame["delta_token_count"] for frame in work),
                "The restored request did not decode with its peer")
    else:
        require(target["prefill_progress"][0]["advanced_prompt_tokens"] == 2048,
                "The cold first item did not process the full 2,048-token cut")
    own = target["first_output_tokens"] if cancelled else target["output_tokens"]
    require(len(own) == (1 if cancelled else 96) and len(peer["output_tokens"]) == 192,
            "Generated or disconnected token count changed")
    require(row["drained"] == dict.fromkeys(mixed.COUNTERS, 0), "Mixed work did not drain")
    return shared


def pair(base, peer, target, *, disconnect=False):
    start = monotonic()
    survived, result = overlap(base, peer, target, disconnect=disconnect)
    return {"peer": survived, "target": result, "drained": mixed.wait_drained(base),
            "wall_seconds": monotonic() - start}


def run_arm(args, pack, prompts, name):
    warm = name.startswith("warm")
    env = {"AX_ENGINE_PREFIX_REUSE_DISABLED": "0" if warm else "1",
           "AX_MLX_PREFIX_CACHE_MAX_BYTES": "2147483648" if warm else "0",
           "AX_MLX_PREFIX_CACHE_MAX_ENTRIES": "8" if warm else "0",
           "AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0", "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": "0",
           "AX_MLX_FLASH_NEXT_PREFILL_TAIL_DEFERRAL": "0"}
    flags = ("--disable-ngram-acceleration", "--total-blocks", "2048", "--max-batch-tokens", "2049",
             *mixed.RESERVE_OPTIONS)
    result = {"before": mixed.native.wait_for_quiet()["cpu_idle_percent"]}
    with mixed.server(args, name, mixed.MODEL, pack, 2, env=env, options=flags,
                      stream_experts="auto", guard=True) as (base, _):
        require("decision=resident" in (args.out / f"{name}.log").read_text(), "Resident experts required")
        result["seeds"] = {}
        for name_seed in ("seed-a", "seed-b"):
            stored = generate(base, prompts[name_seed])
            require(has_decision(stored, STORES) is warm and not has_decision(stored, REUSED),
                    "Seed storage or reuse did not match the arm")
            result["seeds"][name_seed] = stored
            mixed.wait_drained(base)
        for label, peer, target in (("exact", "survivor-a", "hit-a"),
                                    ("cancel", "survivor-b", "hit-b"),
                                    ("extension", "extension-peer", "target")):
            result[label] = pair(base, prompts[peer], prompts[target], disconnect=label == "cancel")
            save(args.out / f"{name}-partial.json", result)
            print(f"{name} {label} captured", flush=True)
            result[label]["shared_steps"] = check_pair(result[label], warm, cancelled=label == "cancel",
                                                       extension=label == "extension")
        replacement = generate(base, prompts["hit-b"])
        require(restored_l1(replacement) is warm, "Replacement used a different cache route")
        result["replacement"] = replacement
        result["final_drained"] = mixed.wait_drained(base)
        require(json.loads(mixed.native.request(base, "/health"))["status"] == "ok", "Health check failed")
    mixed.native.scrub_log(args.out / f"{name}.log")
    samples = [json.loads(line) for line in (args.out / f"{name}-samples.jsonl").read_text().splitlines()]
    require(samples and all(row["pressure"] == 1 for row in samples), "Host pressure exceeded normal")
    result["after"] = mixed.native.cpu_idle_percent()
    result["samples"] = len(samples)
    result["peak_footprint_bytes"] = max(row["footprint_bytes"] for row in samples)
    return result


def responses(arm):
    rows = {label: (arm[label]["peer"]["output_tokens"],
                    arm[label]["target"]["first_output_tokens"] if label == "cancel"
                    else arm[label]["target"]["output_tokens"])
            for label in ("exact", "cancel", "extension")}
    rows["replacement"] = arm["replacement"]["output_tokens"]
    rows["seeds"] = {name: result["output_tokens"] for name, result in arm["seeds"].items()}
    return rows


def main():
    parser = ArgumentParser(description=__doc__)
    for field in ("binary", "cache", "out"):
        parser.add_argument(f"--{field}", type=Path)
    parser.add_argument("--check-inputs", action="store_true")
    args = parser.parse_args()
    prompts = workload()
    if args.check_inputs:
        print(json.dumps({name: len(row["input_tokens"]) for name, row in prompts.items()}))
        return
    require(args.binary is not None and args.cache is not None and args.out is not None, "Missing run input")
    build = read(ROOT / "candidate-build.json")
    inventory = read(ROOT / "mxfp4-inventory.json")
    require(mixed.digest(args.binary) == build["server_sha256"] and build["codesign_verified"] is True,
            "The same signed server is required in every arm")
    pack = args.cache / f"models--{inventory['repo_id'].replace('/', '--')}" / "snapshots" / inventory["revision"]
    require(mixed.native.validate_inventory(pack, inventory, args.cache) == MANIFEST,
            "Delivered model manifest changed")
    args.out.mkdir()
    result = {"qualification": False, "build": build, "workload_sha256": WORKLOAD,
              "pack_revision": inventory["revision"], "order": MODES, "arms": {}}
    expected = None
    for mode in MODES:
        arm = run_arm(args, pack, prompts, mode)
        result["arms"][mode] = arm
        save(args.out / "partial.json", result)
        observed = responses(arm)
        if expected is None:
            expected = observed
        require(observed == expected, "Output IDs changed across cache modes")
        print(f"{mode} complete. CPU idle {arm['before']:.2f}% / {arm['after']:.2f}%.", flush=True)
    require(mixed.native.validate_inventory(pack, inventory, args.cache) == MANIFEST
            and mixed.digest(args.binary) == build["server_sha256"], "Publisher inventory or executable changed")
    save(args.out / "receipt.json", result)


if __name__ == "__main__":
    main()
