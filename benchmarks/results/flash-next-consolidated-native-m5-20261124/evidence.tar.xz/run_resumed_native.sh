#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
readonly python="$HOME/.venvs/ax-engine/bin/python"
readonly slot="$HOME/build/.ax-flash-next-native-test-slot"
readonly base="$PWD"
finish_code=1
trap 'printf "%s\n" "$finish_code" > status.txt' EXIT
/usr/bin/shasum -a 256 -c inputs.sha256 >/dev/null
/usr/bin/shasum -a 256 -c resume-inputs.sha256 >/dev/null
for name in ax-engine ax-engine-server; do /usr/bin/codesign --verify --strict "$base/$name"; done
test "$(sysctl -n hw.model hw.memsize)" = "$(printf 'Mac17,6\n137438953472')"
test "$(sw_vers -productVersion)" = "27.2.1"
export PATH="$HOME/.venvs/ax-engine/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin"
export DYLD_LIBRARY_PATH=$("$python" -E -s -B -c 'from importlib.metadata import distribution,version; assert version("mlx")==version("mlx-metal")=="0.32.4"; print(distribution("mlx").locate_file("mlx/lib"))')
expected=$("$python" -E -s -B -c 'import json; print(json.load(open("build.json"))["libmlx_sha256"])')
test "$(shasum -a 256 "$DYLD_LIBRARY_PATH/libmlx.dylib" | awk '{print $1}')" = "$expected"
acquired=0
for attempt in {1..40}; do
    if test "$(sysctl -n kern.memorystatus_vm_pressure_level)" = 1 && mkdir "$slot" 2>/dev/null; then
        acquired=1
        break
    fi
    sleep 15
done
test "$acquired" = 1
printf '%s\n' "$$" > "$slot/owner.pid"
finish() {
    if test "$(cat "$slot/owner.pid")" = "$$"; then rm "$slot/owner.pid"; rmdir "$slot"; fi
    printf '%s\n' "$finish_code" > status.txt
}
trap finish EXIT
if ps -axo comm= | grep -Eq '/(ax-engine-server[^/]*|mtp-audit|direct_weights|ax-flash-.*-test)$'; then exit 74; fi
snapshot="$base/fresh-cache/models--AutomatosX--AX-Qwen3.8-Flash-Next-MLX-AXQ-MXFP4-MTP/snapshots/ff2a28485eb89bb60e8fe35dd6c65c51e63ee7b3"
test -f "$snapshot/model-manifest.json"
"$python" -E -s -B - <<'PY'
from hashlib import sha256
import json
from pathlib import Path

build = json.loads(Path('build.json').read_bytes())
delivery = json.loads(Path('evidence/delivery/result.json').read_bytes())
controls_raw = Path('evidence/delivery/native-support/result.json').read_bytes()
controls = json.loads(controls_raw)
assert delivery['completed'] and delivery['fresh_cache'] and not delivery['resumed']
assert delivery['download']['exit_code'] == 0 and delivery['verification']['members_verified'] == 49
assert delivery['revision'] == controls['revision'] == 'ff2a28485eb89bb60e8fe35dd6c65c51e63ee7b3'
assert delivery['server_sha256'] == controls['server_sha256'] == build['server_sha256']
assert delivery['download']['ax_engine_sha256'] == build['cli_sha256']
assert delivery['inventory_sha256'] == controls['inventory_sha256'] == sha256(Path('inventory.json').read_bytes()).hexdigest()
assert delivery['native_support']['result_sha256'] == sha256(controls_raw).hexdigest()
assert controls['functional_controls_passed'] and all(len(v) == 7 for v in controls['results'].values())
PY
runtime=(--inventory "$base/inventory.json" --server-bin "$base/ax-engine-server" --model-dir "$snapshot" --ordinary-launch)
for phase in lifecycle qa_cohort generate_matrix; do
    test "$(sysctl -n kern.memorystatus_vm_pressure_level)" = 1
    case "$phase" in
        lifecycle) output=lifecycle ;;
        qa_cohort) output=qa ;;
        generate_matrix) output=generate-matrix ;;
    esac
    test ! -e "$base/evidence/$output"
    printf 'Starting %s\n' "$phase"
    if [[ "$phase" == generate_matrix ]]; then
        "$python" -E -s -B -u "scripts/run_flash_next_$phase.py" "${runtime[@]}" --output "$base/evidence/$output" --repeats 2
    else
        "$python" -E -s -B -u "scripts/run_flash_next_$phase.py" "${runtime[@]}" --output "$base/evidence/$output"
    fi
    test -s "evidence/$output/result.json"
    printf '%s complete\n' "$phase"
done
/usr/bin/shasum -a 256 -c inputs.sha256 >/dev/null
/usr/bin/shasum -a 256 -c resume-inputs.sha256 >/dev/null
finish_code=0
