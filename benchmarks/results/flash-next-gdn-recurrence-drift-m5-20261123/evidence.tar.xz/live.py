"""Replay both native Flash Next prefill geometries from the signed HTTP suite."""
from argparse import ArgumentParser
from importlib.metadata import version
import json
import os
from pathlib import Path
from subprocess import Popen
from threading import Event, Thread

from check_flash_next_native_support import sha256, validate_inventory, stop_owned
from run_qwen38_reference_serving import monitor_memory

HERE = Path(__file__).resolve().parent
TEST = "runner::flash_next_tests::aligned_state_tests::flash_next_real_runner_prefill_geometry_witnesses"
BINARY = HERE / "ax-flash-prefill-geometry-test"


def one_arm(width, pack, prompt, ids, output):
    output.mkdir()
    result = output / "result"
    flags = {
        "AX_FLASH_NEXT_GDN_GEOMETRY_REPLAY": "1",
        "AX_MLX_FLASH_NEXT_GDN_PREFILL_MLX": "1",
        "AX_MLX_FLASH_NEXT_QSA_GROUPED_EVAL": "0",
        "AX_MLX_FLASH_NEXT_QSA_PAIRED_GATHER": "0",
        "AX_MLX_FLASH_NEXT_QSA_INDEXED_PREFILL": "0",
        "AX_MLX_LONG_PROMPT_PREFILL_CHUNK": str(width),
        "AX_MLX_PREFIX_CACHE_DISK_DISABLED": "1",
        "AX_ENGINE_PREFIX_REUSE_DISABLED": "1",
        "AX_MLX_PREFIX_CACHE_MAX_BYTES": "0",
        "AX_MLX_PREFIX_CACHE_MAX_ENTRIES": "0",
    }
    environment = os.environ | flags | {
        "AX_FLASH_NEXT_REAL_PACK": str(pack),
        "AX_FLASH_NEXT_ALIGNED_RESULT_DIR": str(result),
        "AX_FLASH_NEXT_PROMPT_IDS": prompt,
        "AX_FLASH_NEXT_EXPECTED_IDS": json.dumps(ids),
        "AX_FLASH_NEXT_GEOMETRY_WIDTH": str(width),
    }
    with (output / "test.log").open("w") as log:
        proc = Popen([BINARY, TEST, "--exact", "--ignored", "--nocapture"],
                     env=environment, stdout=log, stderr=log, start_new_session=True)
        stop = Event()
        monitor = Thread(target=monitor_memory, args=(output, "native", proc, stop), daemon=True)
        monitor.start()
        try:
            status = proc.wait(timeout=720)
        finally:
            stop_owned(proc)
            stop.set()
            monitor.join(timeout=4)
    assert status == 0, (output / "test.log").read_text()[-4500:]
    assert "1 passed; 0 failed" in (output / "test.log").read_text(errors="replace")
    samples_path = output / "native-samples.jsonl"
    samples = [json.loads(line) for line in samples_path.read_text().splitlines()]
    assert samples and all(s["pressure"] == 1 and s["footprint_bytes"] <= 96 * 2**30 for s in samples)
    return {"flags": flags, "sample_count": len(samples), "samples_sha256": sha256(samples_path),
            "original_test_log_sha256": sha256(output / "test.log"),
            "result_sha256": sha256(result / "result.json"),
            "recurrence_sha256": sha256(result / "recurrence.json"),
            "sampled_footprint_peak_bytes": max(s["footprint_bytes"] for s in samples)}


def main():
    cli = ArgumentParser(description=__doc__)
    cli.add_argument("--pack", type=Path, required=True)
    cli.add_argument("--link-root", type=Path)
    cli.add_argument("--out", type=Path, required=True)
    args = cli.parse_args()
    build = json.loads((HERE / "build.json").read_text())
    assert version("mlx") == version("mlx-metal") == build["mlx"] == "0.32.4"
    assert sha256(BINARY) == build["binary_sha256"]
    assert sha256(HERE / "source.patch") == build["patch_sha256"]
    inventory = json.loads((HERE / "mxfp4-inventory.json").read_text())
    assert len(inventory["members"]) == 49
    verified = validate_inventory(args.pack, inventory, args.link_root)
    assert verified["model-manifest.json"] == build["manifest_sha256"]
    expected = json.loads((HERE / "prior-ids.json").read_text())
    prompt = (HERE / "prompt.json").read_text().strip()
    assert len(json.loads(prompt)) == 8192
    args.out.mkdir()
    for width in (512, 2048):
        print(f"Starting {width} rows", flush=True)
        output = args.out / str(width)
        arm = one_arm(width, args.pack, prompt, expected[str(width)], output)
        (output / "receipt.json").write_text(json.dumps(arm, indent=2, sort_keys=True) + "\n")
        print(f"{width} rows passed", flush=True)
    assert validate_inventory(args.pack, inventory, args.link_root) == verified
    result = {"build": build, "test": TEST, "qualification": False, "manifest": verified,
              "prompt_sha256": sha256(HERE / "prompt.json"),
              "prior_ids_sha256": sha256(HERE / "prior-ids.json")}
    (args.out / "receipt.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
