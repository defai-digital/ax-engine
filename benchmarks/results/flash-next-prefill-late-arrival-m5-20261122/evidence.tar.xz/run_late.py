"""Replay a late overlapping arrival triggered by the short SSE token stream."""

from argparse import ArgumentParser
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
from threading import Event
from time import perf_counter

import capture_layer_steps as capture
import run_layer_http as layer

mixed = layer.mixed
bench = mixed.bench
require = layer.require
ROOT = Path(__file__).resolve().parent
TRIGGER_TOKEN = 84
LOGICAL = 2048
SPLIT_WIDTHS = [512, 512, 512, 511, 1]
ARMS = (("physical-1", False), ("layers-1", True), ("layers-2", True), ("physical-2", False))


def burst(base, cases, expected, candidate, raw_path):
    short, long = cases
    begin = perf_counter()
    ready = Event()
    trigger = []

    def stream(case):
        if case is long and not ready.wait(timeout=20):
            raise TimeoutError("Short stream did not reach the trigger token")
        started = perf_counter()
        payload = {"model": mixed.MODEL, "input_tokens": case.input_tokens,
                   "max_output_tokens": case.max_output_tokens,
                   "sampling": {"temperature": 0, "ignore_eos": True}}
        events = []
        visible = 0
        for kind, data, elapsed in bench.http_sse_events(
                f"{base}/v1/generate/stream", payload, 90, started=started):
            events.append((kind, data, elapsed))
            visible += bench.delta_token_count(kind, data)
            if case is short and not ready.is_set() and visible >= TRIGGER_TOKEN:
                require(visible == TRIGGER_TOKEN, "Short stream skipped the trigger token")
                trigger.append({"seconds": started + elapsed - begin, "step_id": data["step"]["step_id"]})
                ready.set()
        done = perf_counter()
        result = bench.observe_stream(events, prompt=case, scheduled_at_s=started,
                                      started_at_s=started, completed_at_s=done, record_token_ids=True)
        require(result["ok"] and result["output_token_ids"] == expected[case.id]
                and result["prompt_token_ids"] == case.input_tokens, "Stream token identity changed")
        result["started_at_s"] = started - begin
        result["scheduled_at_s"] = result["started_at_s"]
        return result, capture.trace_stream(events)

    with ThreadPoolExecutor(max_workers=2) as workers:
        first, second = workers.submit(stream, short), workers.submit(stream, long)
        short_result, short_trace = first.result()
        long_result, long_trace = second.result()
    raw = {"trigger": trigger, "trigger_token": TRIGGER_TOKEN,
           "observations": [short_result, long_result], "traces": [short_trace, long_trace]}
    raw_path.write_text(json.dumps(raw, indent=2, allow_nan=False) + "\n")
    return raw | verify_late_trace(raw, candidate) | {"drained": mixed.wait_drained(base)}


def verify_late_trace(raw, candidate):
    short, long = raw["traces"]
    short_result, long_result = raw["observations"]
    trigger = raw["trigger"]
    require(raw["trigger_token"] == TRIGGER_TOKEN and len(trigger) == 1
            and len(short["decode_step_ids"]) == len(long["decode_step_ids"]) == 96
            and short["decode_step_ids"][TRIGGER_TOKEN - 1] == trigger[0]["step_id"]
            and [row["request_id"] for row in raw["traces"]]
            == [row["request_id"] for row in raw["observations"]],
            "Observed trigger or stream identity changed")
    require(trigger[0]["seconds"] <= long_result["started_at_s"] <
            short_result["started_at_s"] + short_result["e2e_latency_ms"] / 1000, "Late arrival did not overlap")
    require((short["initial_cursor"], long["initial_cursor"]) == (0, 0)
            and (short["cursor"], long["cursor"]) == (512, 8192) and not short["partial"],
            "Request-local prompt cursor changed")
    short_steps = set(short["decode_step_ids"][TRIGGER_TOKEN:])
    partial = long["partial"]
    if candidate:
        layer.check_trace([short, long], 16, "ending-decoder")
        require(all(row["step_id"] in short_steps for row in partial),
                "A layer suspension lacks a real peer output after the trigger")
    else:
        require(not partial, "The physical-only control suspended layers")

    cursor = 0
    groups = {}
    for row in long["prefill"]:
        end = (cursor // LOGICAL + 1) * LOGICAL
        require(row["width"] > 0 and cursor + row["width"] == row["cursor"] <= end,
                "A row crossed or left a hole in its logical boundary")
        require(row["scheduled"] == (2 if row["step_id"] in short_steps else 1),
                "Scheduled peers differ from the published short stream")
        groups.setdefault(end, []).append(row)
        cursor = row["cursor"]
    split_chunks = ordinary_chunks = 0
    initials = {row["cursor"] for row in partial if row["step_id"] in short_steps and row["previous"] == 0}
    for end, rows in groups.items():
        widths = [row["width"] for row in rows]
        markers = {row["split_end"] for row in rows}
        if markers == {end}:
            require(widths == SPLIT_WIDTHS and (rows[0]["step_id"] in short_steps or end - LOGICAL in initials),
                    "An in-progress split lost its original widths or started without the peer")
            split_chunks += 1
        else:
            require(markers == {None} and widths == [LOGICAL] and rows[0]["step_id"] > max(short_steps),
                    "A solo logical item overlapped the peer or altered its boundary")
            ordinary_chunks += 1
    require(cursor == long["cursor"] and split_chunks > 0 and ordinary_chunks > 0
            and split_chunks + ordinary_chunks == 4, "The prompt did not cover both shared and solo continuation")
    return {"layer_progress_steps": len(partial),
            "split_logical_chunks": split_chunks, "ordinary_logical_chunks": ordinary_chunks,
            "long_scheduled_widths": [row["width"] for row in long["prefill"]]}


def main():
    parser = ArgumentParser(description=__doc__)
    for name in ("binary", "pack", "link-root", "out"):
        parser.add_argument(f"--{name}", type=Path)
    parser.add_argument("--check-inputs", action="store_true")
    args = parser.parse_args()
    _, cases, expected = layer.files()["ending-decoder"]
    require(cases[0].max_output_tokens == cases[1].max_output_tokens == 96, "Unexpected token budget")
    if args.check_inputs:
        print("Verified the late-arrival prompts and all 192 solo output IDs.")
        return
    build = json.loads((ROOT / "build.json").read_bytes())
    inventory = json.loads((ROOT / "mxfp4-inventory.json").read_bytes())
    require(mixed.digest(args.binary) == build["server_sha256"], "Binary differs from build receipt")
    manifest = mixed.native.validate_inventory(args.pack, inventory, args.link_root)
    require(manifest.get("model-manifest.json") ==
            "62f61c17cf571afc24dfb3002afd7c3c9b038b0eb80cde182f143266954e61ef",
            "The delivered manifest changed")
    args.out.mkdir()
    record = {"qualification": False, "build": build, "pack_revision": inventory["revision"], "manifest": manifest,
              "inventory_sha256": mixed.digest(ROOT / "mxfp4-inventory.json"), "arms": {}}

    def save(status):
        record["status"] = status
        temporary = args.out / "receipt.tmp"
        temporary.write_text(json.dumps(record, indent=2, allow_nan=False) + "\n")
        temporary.replace(args.out / "receipt.json")
        print(status, flush=True)

    options = ("--disable-ngram-acceleration", "--total-blocks", "2048", "--max-batch-tokens", "2049",
               *mixed.RESERVE_OPTIONS)
    try:
        for name, candidate in ARMS:
            save(f"{name}-starting")
            quiet = mixed.native.wait_for_quiet()
            env = {"AX_MLX_FLASH_NEXT_DIRECT_COALESCING": "0", "AX_MLX_FLASH_NEXT_PREFILL_SPLIT": "1",
                   "AX_MLX_FLASH_NEXT_PREFILL_LAYER_YIELD": "1" if candidate else "0",
                   "AX_MLX_FLASH_NEXT_PREFILL_LAYER_GROUP": "16"}
            with mixed.server(args, name, mixed.MODEL, args.pack, 2, env=env, options=options,
                              stream_experts="auto", guard=True) as (base, _):
                require("decision=resident" in (args.out / f"{name}.log").read_text(), "Resident experts required")
                data = burst(base, cases, expected, candidate, args.out / f"{name}.partial.json")
                require(json.loads(mixed.native.request(base, "/health"))["status"] == "ok", "Health declined")
            path = args.out / f"{name}.json"
            path.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")
            samples = [json.loads(line) for line in (args.out / f"{name}-samples.jsonl").read_text().splitlines()]
            require(samples and all(row["pressure"] == 1 for row in samples), "Memory pressure exceeded normal")
            record["arms"][name] = {
                "layer_group": 16 if candidate else None, "layer_progress_steps": data["layer_progress_steps"],
                "cpu_idle_before_percent": quiet["cpu_idle_percent"], "cpu_idle_after_percent": mixed.native.cpu_idle_percent(),
                "sample_count": len(samples), "data_sha256": mixed.digest(path),
            }
            save(f"{name}-complete")
        require(mixed.native.validate_inventory(args.pack, inventory, args.link_root) == manifest, "Pack changed")
        save("complete")
    except Exception:
        save("failed")
        raise


if __name__ == "__main__":
    main()
