#!/bin/bash
set -euo pipefail
owner="$1"
deadline=$((SECONDS + 3600))
echo waiting-for-late-arrival-comparison
while test ! -s "$owner/status.txt"; do
    kill -0 "$(cat "$owner/owner.pid")" 2>/dev/null && (( SECONDS < deadline )) || exit 2
    sleep 10
done
exec bash run_m5.sh
