#!/bin/bash
set -euo pipefail
umask 077
cd "$(dirname "$0")"
export PYTHONDONTWRITEBYTECODE=1
test "$(/usr/sbin/sysctl -n hw.model hw.memsize)" = "$(printf 'Mac17,6\n137438953472')"
if /bin/ps -axo comm= | /usr/bin/grep -E '/(ax-engine-server[^/]*|layer-peer-probe|mtp-audit)$'; then
    exit 1
fi
/usr/bin/shasum -a 256 -c inputs.sha256
pack="$HOME/build/packs/ax-qwen38-flash-next-mxfp4-ff2a2848"
test -f "$pack/mtp.safetensors"
python="$HOME/.venvs/ax-engine/bin/python"
mlx=$("$python" -B -c 'import importlib.metadata as m; assert m.version("mlx") == m.version("mlx-metal") == "0.32.4"; print(m.distribution("mlx").locate_file("mlx/lib"))')
expected=$("$python" -B -c 'import json; print(json.load(open("build.json"))["libmlx_sha256"])')
test "$(/usr/bin/shasum -a 256 "$mlx/libmlx.dylib" | /usr/bin/awk '{print $1}')" = "$expected"
mkdir clones
exec /usr/bin/caffeinate -dimsu /usr/bin/env -i HOME="$HOME" \
  PATH="$HOME/.venvs/ax-engine/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin" \
  DYLD_LIBRARY_PATH="$mlx" PYTHONDONTWRITEBYTECODE=1 \
  "$python" -B -u run_sidecar_bypass.py --server "$PWD/ax-engine-server" --pack "$pack" \
  --inventory "$PWD/mxfp4-inventory.json" --scratch-dir "$PWD/clones" \
  --build-receipt "$PWD/build.json" --output "$PWD/bypass"
